//
//  GameItems.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation
import SwiftUI

// MARK: - Game Item Protocol

protocol GameItem: Identifiable, Equatable {
    var id: UUID { get }
    var nameKey: String { get }
}

// MARK: - Game Color Model

struct GameColor: GameItem {
    let id = UUID()
    let color: Color
    let nameKey: String // Localization key
    
    // Manual Equatable implementation to compare by nameKey
    static func == (lhs: GameColor, rhs: GameColor) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    // Standard mode: 10 colors (primary + secondary colors)
    static let standardColors: [GameColor] = [
        GameColor(color: .red, nameKey: "Red"),
        GameColor(color: .blue, nameKey: "Blue"),
        GameColor(color: .green, nameKey: "Green"),
        GameColor(color: .yellow, nameKey: "Yellow"),
        GameColor(color: .orange, nameKey: "Orange"),
        GameColor(color: .purple, nameKey: "Purple"),
        GameColor(color: .brown, nameKey: "Brown"),
        GameColor(color: .cyan, nameKey: "Cyan"),
        GameColor(color: .pink, nameKey: "Pink"),
        GameColor(color: .indigo, nameKey: "Indigo")
    ]
    
    // Pro mode: 16 colors (harder, double points)
    static let proColors: [GameColor] = [
        GameColor(color: .red, nameKey: "Red"),
        GameColor(color: .blue, nameKey: "Blue"),
        GameColor(color: .green, nameKey: "Green"),
        GameColor(color: .yellow, nameKey: "Yellow"),
        GameColor(color: .orange, nameKey: "Orange"),
        GameColor(color: .purple, nameKey: "Purple"),
        GameColor(color: .brown, nameKey: "Brown"),
        GameColor(color: .cyan, nameKey: "Cyan"),
        GameColor(color: .gray, nameKey: "Gray"),
        GameColor(color: .indigo, nameKey: "Indigo"),
        GameColor(color: .mint, nameKey: "Mint"),
        GameColor(color: .teal, nameKey: "Teal"),
        GameColor(color: Color(red: 1.0, green: 0.75, blue: 0.8), nameKey: "Pink"),
        GameColor(color: Color(red: 0.5, green: 0.0, blue: 0.5), nameKey: "Violet"),
        GameColor(color: Color(red: 0.6, green: 0.4, blue: 0.2), nameKey: "Tan"),
        GameColor(color: Color(red: 0.5, green: 0.5, blue: 0.5), nameKey: "Silver")
    ]
    
    // Legacy property for backwards compatibility
    static let allColors: [GameColor] = standardColors
}

// MARK: - Game Emoji Model

struct GameEmoji: GameItem {
    let id = UUID()
    let emoji: String
    let nameKey: String // Localization key
    
    // Manual Equatable implementation to compare by nameKey
    static func == (lhs: GameEmoji, rhs: GameEmoji) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    // Standard mode: 20 emojis (popular and distinct)
    static let standardEmojis: [GameEmoji] = [
        GameEmoji(emoji: "😀", nameKey: "EmojiGrinning"),
        GameEmoji(emoji: "😂", nameKey: "EmojiLaughing"),
        GameEmoji(emoji: "😍", nameKey: "EmojiHeart"),
        GameEmoji(emoji: "🤔", nameKey: "EmojiThinking"),
        GameEmoji(emoji: "😎", nameKey: "EmojiCool"),
        GameEmoji(emoji: "🤯", nameKey: "EmojiMindBlown"),
        GameEmoji(emoji: "🥳", nameKey: "EmojiParty"),
        GameEmoji(emoji: "😴", nameKey: "EmojiSleepy"),
        GameEmoji(emoji: "👻", nameKey: "EmojiGhost"),
        GameEmoji(emoji: "👽", nameKey: "EmojiAlien"),
        GameEmoji(emoji: "🤖", nameKey: "EmojiRobot"),
        GameEmoji(emoji: "💩", nameKey: "EmojiPoop"),
        GameEmoji(emoji: "🔥", nameKey: "EmojiFire"),
        GameEmoji(emoji: "⭐️", nameKey: "EmojiStar"),
        GameEmoji(emoji: "❤️", nameKey: "EmojiRedHeart"),
        GameEmoji(emoji: "🐶", nameKey: "EmojiDog"),
        GameEmoji(emoji: "🐱", nameKey: "EmojiCat"),
        GameEmoji(emoji: "🍕", nameKey: "EmojiPizza"),
        GameEmoji(emoji: "🎮", nameKey: "EmojiGamepad"),
        GameEmoji(emoji: "🚀", nameKey: "EmojiRocket")
    ]
    
    // Pro mode: 100 emojis (maximum variety!)
    static let proEmojis: [GameEmoji] = [
        // Faces & Emotions (24)
        GameEmoji(emoji: "😀", nameKey: "EmojiGrinning"),
        GameEmoji(emoji: "😂", nameKey: "EmojiLaughing"),
        GameEmoji(emoji: "😍", nameKey: "EmojiHeart"),
        GameEmoji(emoji: "🤔", nameKey: "EmojiThinking"),
        GameEmoji(emoji: "😎", nameKey: "EmojiCool"),
        GameEmoji(emoji: "🤯", nameKey: "EmojiMindBlown"),
        GameEmoji(emoji: "🥳", nameKey: "EmojiParty"),
        GameEmoji(emoji: "😴", nameKey: "EmojiSleepy"),
        GameEmoji(emoji: "🤑", nameKey: "EmojiMoney"),
        GameEmoji(emoji: "🤠", nameKey: "EmojiCowboy"),
        GameEmoji(emoji: "🤡", nameKey: "EmojiClown"),
        GameEmoji(emoji: "😇", nameKey: "EmojiAngel"),
        GameEmoji(emoji: "😈", nameKey: "EmojiDevil"),
        GameEmoji(emoji: "🥶", nameKey: "EmojiFreezing"),
        GameEmoji(emoji: "🥵", nameKey: "EmojiHot"),
        GameEmoji(emoji: "🤢", nameKey: "EmojiNauseated"),
        GameEmoji(emoji: "🤓", nameKey: "EmojiNerd"),
        GameEmoji(emoji: "🧐", nameKey: "EmojiMonocle"),
        GameEmoji(emoji: "😱", nameKey: "EmojiScreaming"),
        GameEmoji(emoji: "🤐", nameKey: "EmojiZipper"),
        GameEmoji(emoji: "🥺", nameKey: "EmojiPleading"),
        GameEmoji(emoji: "😭", nameKey: "EmojiCrying"),
        GameEmoji(emoji: "😤", nameKey: "EmojiSteam"),
        GameEmoji(emoji: "🤪", nameKey: "EmojiZany"),
        
        // Creatures & Fantasy (15)
        GameEmoji(emoji: "👻", nameKey: "EmojiGhost"),
        GameEmoji(emoji: "👽", nameKey: "EmojiAlien"),
        GameEmoji(emoji: "🤖", nameKey: "EmojiRobot"),
        GameEmoji(emoji: "🎃", nameKey: "EmojiPumpkin"),
        GameEmoji(emoji: "💀", nameKey: "EmojiSkull"),
        GameEmoji(emoji: "👹", nameKey: "EmojiOgre"),
        GameEmoji(emoji: "👺", nameKey: "EmojiGoblin"),
        GameEmoji(emoji: "🦄", nameKey: "EmojiUnicorn"),
        GameEmoji(emoji: "🐉", nameKey: "EmojiDragon"),
        GameEmoji(emoji: "🦖", nameKey: "EmojiDino"),
        GameEmoji(emoji: "🐙", nameKey: "EmojiOctopus"),
        GameEmoji(emoji: "🦑", nameKey: "EmojiSquid"),
        GameEmoji(emoji: "🦈", nameKey: "EmojiShark"),
        GameEmoji(emoji: "🐊", nameKey: "EmojiCrocodile"),
        GameEmoji(emoji: "🦎", nameKey: "EmojiLizard"),
        
        // Animals (16)
        GameEmoji(emoji: "🐶", nameKey: "EmojiDog"),
        GameEmoji(emoji: "🐱", nameKey: "EmojiCat"),
        GameEmoji(emoji: "🐭", nameKey: "EmojiMouse"),
        GameEmoji(emoji: "🐼", nameKey: "EmojiPanda"),
        GameEmoji(emoji: "🦁", nameKey: "EmojiLion"),
        GameEmoji(emoji: "🐯", nameKey: "EmojiTiger"),
        GameEmoji(emoji: "🐸", nameKey: "EmojiFrog"),
        GameEmoji(emoji: "🦊", nameKey: "EmojiFox"),
        GameEmoji(emoji: "🐵", nameKey: "EmojiMonkey"),
        GameEmoji(emoji: "🐔", nameKey: "EmojiChicken"),
        GameEmoji(emoji: "🐧", nameKey: "EmojiPenguin"),
        GameEmoji(emoji: "🦉", nameKey: "EmojiOwl"),
        GameEmoji(emoji: "🦅", nameKey: "EmojiEagle"),
        GameEmoji(emoji: "🐺", nameKey: "EmojiWolf"),
        GameEmoji(emoji: "🐻", nameKey: "EmojiBear"),
        GameEmoji(emoji: "🐨", nameKey: "EmojiKoala"),
        
        // Food & Drinks (15)
        GameEmoji(emoji: "🍕", nameKey: "EmojiPizza"),
        GameEmoji(emoji: "🍔", nameKey: "EmojiBurger"),
        GameEmoji(emoji: "🍎", nameKey: "EmojiApple"),
        GameEmoji(emoji: "🍌", nameKey: "EmojiBanana"),
        GameEmoji(emoji: "🍇", nameKey: "EmojiGrapes"),
        GameEmoji(emoji: "🍓", nameKey: "EmojiStrawberry"),
        GameEmoji(emoji: "🍉", nameKey: "EmojiWatermelon"),
        GameEmoji(emoji: "🍪", nameKey: "EmojiCookie"),
        GameEmoji(emoji: "🍰", nameKey: "EmojiCake"),
        GameEmoji(emoji: "🍩", nameKey: "EmojiDonut"),
        GameEmoji(emoji: "🍦", nameKey: "EmojiIceCream"),
        GameEmoji(emoji: "🌭", nameKey: "EmojiHotDog"),
        GameEmoji(emoji: "🌮", nameKey: "EmojiTaco"),
        GameEmoji(emoji: "🍣", nameKey: "EmojiSushi"),
        GameEmoji(emoji: "☕️", nameKey: "EmojiCoffee"),
        
        // Sports & Activities (10)
        GameEmoji(emoji: "⚽️", nameKey: "EmojiSoccer"),
        GameEmoji(emoji: "🏀", nameKey: "EmojiBasketball"),
        GameEmoji(emoji: "🏈", nameKey: "EmojiFootball"),
        GameEmoji(emoji: "⚾️", nameKey: "EmojiBaseball"),
        GameEmoji(emoji: "🎾", nameKey: "EmojiTennis"),
        GameEmoji(emoji: "🏐", nameKey: "EmojiVolleyball"),
        GameEmoji(emoji: "🎱", nameKey: "Emoji8Ball"),
        GameEmoji(emoji: "🏓", nameKey: "EmojiPingPong"),
        GameEmoji(emoji: "🥊", nameKey: "EmojiBoxing"),
        GameEmoji(emoji: "🎳", nameKey: "EmojiBowling"),
        
        // Transportation & Travel (10)
        GameEmoji(emoji: "🚀", nameKey: "EmojiRocket"),
        GameEmoji(emoji: "✈️", nameKey: "EmojiAirplane"),
        GameEmoji(emoji: "🚗", nameKey: "EmojiCar"),
        GameEmoji(emoji: "🚕", nameKey: "EmojiTaxi"),
        GameEmoji(emoji: "🚌", nameKey: "EmojiBus"),
        GameEmoji(emoji: "🚁", nameKey: "EmojiHelicopter"),
        GameEmoji(emoji: "🚂", nameKey: "EmojiTrain"),
        GameEmoji(emoji: "🛸", nameKey: "EmojiUFO"),
        GameEmoji(emoji: "🚢", nameKey: "EmojiShip"),
        GameEmoji(emoji: "⛵️", nameKey: "EmojiSailboat"),
        
        // Nature & Weather (10)
        GameEmoji(emoji: "🌸", nameKey: "EmojiCherryBlossom"),
        GameEmoji(emoji: "🌺", nameKey: "EmojiHibiscus"),
        GameEmoji(emoji: "🌻", nameKey: "EmojiSunflower"),
        GameEmoji(emoji: "🌹", nameKey: "EmojiRose"),
        GameEmoji(emoji: "🌲", nameKey: "EmojiTree"),
        GameEmoji(emoji: "🍁", nameKey: "EmojiMapleLeaf"),
        GameEmoji(emoji: "🌵", nameKey: "EmojiCactus"),
        GameEmoji(emoji: "☃️", nameKey: "EmojiSnowman"),
        GameEmoji(emoji: "🌊", nameKey: "EmojiWave"),
        GameEmoji(emoji: "⛱️", nameKey: "EmojiBeachUmbrella"),
        
        // Objects, Symbols & More (10)
        GameEmoji(emoji: "💩", nameKey: "EmojiPoop"),
        GameEmoji(emoji: "🔥", nameKey: "EmojiFire"),
        GameEmoji(emoji: "⭐️", nameKey: "EmojiStar"),
        GameEmoji(emoji: "💎", nameKey: "EmojiDiamond"),
        GameEmoji(emoji: "👑", nameKey: "EmojiCrown"),
        GameEmoji(emoji: "🎯", nameKey: "EmojiTarget"),
        GameEmoji(emoji: "🎮", nameKey: "EmojiGamepad"),
        GameEmoji(emoji: "🎲", nameKey: "EmojiDice"),
        GameEmoji(emoji: "🎪", nameKey: "EmojiTent"),
        GameEmoji(emoji: "🎉", nameKey: "EmojiConfetti"),
        GameEmoji(emoji: "⚡️", nameKey: "EmojiLightning"),
        GameEmoji(emoji: "💥", nameKey: "EmojiBoom"),
        GameEmoji(emoji: "💫", nameKey: "EmojiDizzy"),
        GameEmoji(emoji: "🌈", nameKey: "EmojiRainbow"),
        GameEmoji(emoji: "🌙", nameKey: "EmojiMoon"),
        GameEmoji(emoji: "☀️", nameKey: "EmojiSun"),
        GameEmoji(emoji: "❤️", nameKey: "EmojiRedHeart"),
        GameEmoji(emoji: "💚", nameKey: "EmojiGreenHeart"),
        GameEmoji(emoji: "💙", nameKey: "EmojiBlueHeart"),
        GameEmoji(emoji: "💜", nameKey: "EmojiPurpleHeart")
    ]
}

// MARK: - Game Shape Model

struct GameShape: GameItem {
    let id = UUID()
    let shape: String  // Unicode character for the shape
    let nameKey: String // Localization key
    
    // Manual Equatable implementation to compare by nameKey
    static func == (lhs: GameShape, rhs: GameShape) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    // Standard mode: 12 shapes (fun and distinct)
    static let standardShapes: [GameShape] = [
        GameShape(shape: "●", nameKey: "ShapeCircle"),
        GameShape(shape: "■", nameKey: "ShapeSquare"),
        GameShape(shape: "▲", nameKey: "ShapeTriangle"),
        GameShape(shape: "★", nameKey: "ShapeStar"),
        GameShape(shape: "♦", nameKey: "ShapeDiamond"),
        GameShape(shape: "♥", nameKey: "ShapeHeart"),
        GameShape(shape: "⬟", nameKey: "ShapePentagon"),
        GameShape(shape: "⬢", nameKey: "ShapeHexagon"),
        GameShape(shape: "▼", nameKey: "ShapeTriangleDown"),
        GameShape(shape: "○", nameKey: "ShapeCircleOutline"),
        GameShape(shape: "♠", nameKey: "ShapeSpade"),
        GameShape(shape: "♣", nameKey: "ShapeClub")
    ]
    
    // Pro mode: 21 shapes (more variety and challenge)
    static let proShapes: [GameShape] = [
        // Basic shapes
        GameShape(shape: "●", nameKey: "ShapeCircle"),
        GameShape(shape: "■", nameKey: "ShapeSquare"),
        GameShape(shape: "▲", nameKey: "ShapeTriangle"),
        GameShape(shape: "★", nameKey: "ShapeStar"),
        GameShape(shape: "♦", nameKey: "ShapeDiamond"),
        GameShape(shape: "♥", nameKey: "ShapeHeart"),
        GameShape(shape: "⬟", nameKey: "ShapePentagon"),
        GameShape(shape: "⬢", nameKey: "ShapeHexagon"),
        GameShape(shape: "▼", nameKey: "ShapeTriangleDown"),
        GameShape(shape: "○", nameKey: "ShapeCircleOutline"),
        
        // Additional pro shapes
        GameShape(shape: "◼", nameKey: "ShapeSquareSmall"),
        GameShape(shape: "▶", nameKey: "ShapeTriangleRight"),
        GameShape(shape: "◀", nameKey: "ShapeTriangleLeft"),
        GameShape(shape: "♠", nameKey: "ShapeSpade"),
        GameShape(shape: "♣", nameKey: "ShapeClub"),
        GameShape(shape: "☆", nameKey: "ShapeStarEmpty"),
        GameShape(shape: "✪", nameKey: "ShapeStarCircled"),
        GameShape(shape: "◉", nameKey: "ShapeBullseye"),
        GameShape(shape: "⬛", nameKey: "ShapeSquareLarge"),
        GameShape(shape: "⬜", nameKey: "ShapeSquareWhite"),
        GameShape(shape: "✚", nameKey: "ShapePlus")
    ]
}

// MARK: - Game Flag Model

struct GameFlag: GameItem {
    let id = UUID()
    let emoji: String      // Unicode flag emoji
    let nameKey: String    // Localization key for country name
    
    // Manual Equatable implementation to compare by nameKey
    static func == (lhs: GameFlag, rhs: GameFlag) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    // Standard mode: 20 well-known country flags
    static let standardFlags: [GameFlag] = [
        GameFlag(emoji: "🇺🇸", nameKey: "FlagUSA"),
        GameFlag(emoji: "🇬🇧", nameKey: "FlagUK"),
        GameFlag(emoji: "🇩🇪", nameKey: "FlagGermany"),
        GameFlag(emoji: "🇫🇷", nameKey: "FlagFrance"),
        GameFlag(emoji: "🇪🇸", nameKey: "FlagSpain"),
        GameFlag(emoji: "🇮🇹", nameKey: "FlagItaly"),
        GameFlag(emoji: "🇯🇵", nameKey: "FlagJapan"),
        GameFlag(emoji: "🇨🇳", nameKey: "FlagChina"),
        GameFlag(emoji: "🇨🇦", nameKey: "FlagCanada"),
        GameFlag(emoji: "🇦🇺", nameKey: "FlagAustralia"),
        GameFlag(emoji: "🇧🇷", nameKey: "FlagBrazil"),
        GameFlag(emoji: "🇲🇽", nameKey: "FlagMexico"),
        GameFlag(emoji: "🇮🇳", nameKey: "FlagIndia"),
        GameFlag(emoji: "🇦🇹", nameKey: "FlagAustria"),
        GameFlag(emoji: "🇨🇭", nameKey: "FlagSwitzerland"),
        GameFlag(emoji: "🇳🇱", nameKey: "FlagNetherlands"),
        GameFlag(emoji: "🇸🇪", nameKey: "FlagSweden"),
        GameFlag(emoji: "🇰🇷", nameKey: "FlagSouthKorea"),
        GameFlag(emoji: "🇷🇺", nameKey: "FlagRussia"),
        GameFlag(emoji: "🇵🇹", nameKey: "FlagPortugal")
    ]
    
    // Pro mode: 60 country flags (global coverage!)
    static let proFlags: [GameFlag] = [
        // Standard flags (20)
        GameFlag(emoji: "🇺🇸", nameKey: "FlagUSA"),
        GameFlag(emoji: "🇬🇧", nameKey: "FlagUK"),
        GameFlag(emoji: "🇩🇪", nameKey: "FlagGermany"),
        GameFlag(emoji: "🇫🇷", nameKey: "FlagFrance"),
        GameFlag(emoji: "🇪🇸", nameKey: "FlagSpain"),
        GameFlag(emoji: "🇮🇹", nameKey: "FlagItaly"),
        GameFlag(emoji: "🇯🇵", nameKey: "FlagJapan"),
        GameFlag(emoji: "🇨🇳", nameKey: "FlagChina"),
        GameFlag(emoji: "🇨🇦", nameKey: "FlagCanada"),
        GameFlag(emoji: "🇦🇺", nameKey: "FlagAustralia"),
        GameFlag(emoji: "🇧🇷", nameKey: "FlagBrazil"),
        GameFlag(emoji: "🇲🇽", nameKey: "FlagMexico"),
        GameFlag(emoji: "🇮🇳", nameKey: "FlagIndia"),
        GameFlag(emoji: "🇦🇹", nameKey: "FlagAustria"),
        GameFlag(emoji: "🇨🇭", nameKey: "FlagSwitzerland"),
        GameFlag(emoji: "🇳🇱", nameKey: "FlagNetherlands"),
        GameFlag(emoji: "🇸🇪", nameKey: "FlagSweden"),
        GameFlag(emoji: "🇰🇷", nameKey: "FlagSouthKorea"),
        GameFlag(emoji: "🇷🇺", nameKey: "FlagRussia"),
        GameFlag(emoji: "🇵🇹", nameKey: "FlagPortugal"),
        
        // European countries (15)
        GameFlag(emoji: "🇬🇷", nameKey: "FlagGreece"),
        GameFlag(emoji: "🇳🇴", nameKey: "FlagNorway"),
        GameFlag(emoji: "🇩🇰", nameKey: "FlagDenmark"),
        GameFlag(emoji: "🇫🇮", nameKey: "FlagFinland"),
        GameFlag(emoji: "🇵🇱", nameKey: "FlagPoland"),
        GameFlag(emoji: "🇹🇷", nameKey: "FlagTurkey"),
        GameFlag(emoji: "🇮🇪", nameKey: "FlagIreland"),
        GameFlag(emoji: "🇧🇪", nameKey: "FlagBelgium"),
        GameFlag(emoji: "🇨🇿", nameKey: "FlagCzechia"),
        GameFlag(emoji: "🇭🇺", nameKey: "FlagHungary"),
        GameFlag(emoji: "🇷🇴", nameKey: "FlagRomania"),
        GameFlag(emoji: "🇺🇦", nameKey: "FlagUkraine"),
        GameFlag(emoji: "🇭🇷", nameKey: "FlagCroatia"),
        GameFlag(emoji: "🇸🇰", nameKey: "FlagSlovakia"),
        GameFlag(emoji: "🇧🇬", nameKey: "FlagBulgaria"),
        
        // Americas (10)
        GameFlag(emoji: "🇦🇷", nameKey: "FlagArgentina"),
        GameFlag(emoji: "🇨🇱", nameKey: "FlagChile"),
        GameFlag(emoji: "🇨🇴", nameKey: "FlagColombia"),
        GameFlag(emoji: "🇵🇪", nameKey: "FlagPeru"),
        GameFlag(emoji: "🇻🇪", nameKey: "FlagVenezuela"),
        GameFlag(emoji: "🇪🇨", nameKey: "FlagEcuador"),
        GameFlag(emoji: "🇺🇾", nameKey: "FlagUruguay"),
        GameFlag(emoji: "🇨🇷", nameKey: "FlagCostaRica"),
        GameFlag(emoji: "🇨🇺", nameKey: "FlagCuba"),
        GameFlag(emoji: "🇵🇦", nameKey: "FlagPanama"),
        
        // Asia & Oceania (10)
        GameFlag(emoji: "🇹🇭", nameKey: "FlagThailand"),
        GameFlag(emoji: "🇻🇳", nameKey: "FlagVietnam"),
        GameFlag(emoji: "🇵🇭", nameKey: "FlagPhilippines"),
        GameFlag(emoji: "🇸🇬", nameKey: "FlagSingapore"),
        GameFlag(emoji: "🇲🇾", nameKey: "FlagMalaysia"),
        GameFlag(emoji: "🇮🇩", nameKey: "FlagIndonesia"),
        GameFlag(emoji: "🇳🇿", nameKey: "FlagNewZealand"),
        GameFlag(emoji: "🇵🇰", nameKey: "FlagPakistan"),
        GameFlag(emoji: "🇧🇩", nameKey: "FlagBangladesh"),
        GameFlag(emoji: "🇱🇰", nameKey: "FlagSriLanka"),
        
        // Africa & Middle East (5)
        GameFlag(emoji: "🇿🇦", nameKey: "FlagSouthAfrica"),
        GameFlag(emoji: "🇪🇬", nameKey: "FlagEgypt"),
        GameFlag(emoji: "🇳🇬", nameKey: "FlagNigeria"),
        GameFlag(emoji: "🇰🇪", nameKey: "FlagKenya"),
        GameFlag(emoji: "🇮🇱", nameKey: "FlagIsrael")
    ]
}

// MARK: - Game Number Model

struct GameNumber: GameItem {
    let id = UUID()
    let value: Int
    let nameKey: String // Localization key
    
    // Manual Equatable implementation to compare by nameKey
    static func == (lhs: GameNumber, rhs: GameNumber) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    // Standard mode: 0-12 (13 numbers, beginner-friendly)
    static let standardNumbers: [GameNumber] = {
        return (0...12).map { num in
            GameNumber(value: num, nameKey: "Number\(num)")
        }
    }()
    
    // Pro mode: 0-99 (100 numbers, challenging)
    static let proNumbers: [GameNumber] = {
        return (0...99).map { num in
            GameNumber(value: num, nameKey: "Number\(num)")
        }
    }()
}
