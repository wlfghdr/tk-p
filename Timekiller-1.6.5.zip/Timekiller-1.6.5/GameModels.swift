//
//  GameModels.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation
import SwiftUI

// MARK: - Game Mode

enum GameMode: String, CaseIterable, Identifiable {
    case colors = "colors"
    case numbers = "numbers"
    case shapes = "shapes"
    case flags = "flags"
    case emojis = "emojis"
    
    var id: String { rawValue }
    
    var nameKey: String {
        switch self {
        case .colors: return "ModeColors"
        case .numbers: return "ModeNumbers"
        case .shapes: return "ModeShapes"
        case .flags: return "ModeFlags"
        case .emojis: return "ModeEmojis"
        }
    }
}

// MARK: - Universal Tile Content

enum TileContent: Equatable {
    case color(GameColor)
    case number(GameNumber)
    case shape(GameShape)
    case flag(GameFlag)
    case emoji(GameEmoji)
    
    var nameKey: String {
        switch self {
        case .color(let gameColor): return gameColor.nameKey
        case .number(let gameNumber): return gameNumber.nameKey
        case .shape(let gameShape): return gameShape.nameKey
        case .flag(let gameFlag): return gameFlag.nameKey
        case .emoji(let gameEmoji): return gameEmoji.nameKey
        }
    }
    
    var id: UUID {
        switch self {
        case .color(let gameColor): return gameColor.id
        case .number(let gameNumber): return gameNumber.id
        case .shape(let gameShape): return gameShape.id
        case .flag(let gameFlag): return gameFlag.id
        case .emoji(let gameEmoji): return gameEmoji.id
        }
    }
}

// MARK: - Grid Size (iOS only)

enum GridSize: String, CaseIterable, Identifiable {
    case grid2x2 = "2x2"
    case grid2x4 = "2x4"
    case grid3x5 = "3x5"
    
    var id: String { rawValue }
    
    var tileCount: Int {
        switch self {
        case .grid2x2: return 4
        case .grid2x4: return 8
        case .grid3x5: return 15
        }
    }
    
    var columns: Int {
        switch self {
        case .grid2x2: return 2
        case .grid2x4: return 2
        case .grid3x5: return 3
        }
    }
    
    var rows: Int {
        switch self {
        case .grid2x2: return 2
        case .grid2x4: return 4
        case .grid3x5: return 5
        }
    }
}

// MARK: - Level-Based Progression Functions

/// Returns the grid size that should be used for a given level
func gridSizeForLevel(_ level: Int) -> GridSize {
    if level <= 4 {
        return .grid2x2  // Levels 1-4: Small grid (4 tiles)
    } else if level <= 10 {
        return .grid2x4  // Levels 5-10: Medium grid (8 tiles)
    } else {
        return .grid3x5  // Levels 11+: Large grid (15 tiles)
    }
}

/// Returns the number of correct answers required for a given level
func requiredCorrectAnswers(level: Int) -> Int {
    if level <= 7 {
        return 1  // Levels 1-7: Single answer
    } else if level <= 15 {
        return 2  // Levels 8-15: Double answers
    } else if level <= 22 {
        return 3  // Levels 16-22: Triple answers
    } else {
        return 4  // Levels 23+: Quad answers
    }
}

/// Returns the base time duration for a given level
/// Base times: 2×2 = 8s, 2×4 = 12s, 3×5 = 15s
/// From Level 25 onwards: 5% reduction per level (gentler curve for longer gameplay)
func baseTimeForLevel(_ level: Int) -> Double {
    let gridSize = gridSizeForLevel(level)
    
    // Base duration by grid size
    let baseDuration: Double
    switch gridSize {
    case .grid2x2:
        baseDuration = 8.0   // 4 tiles: 8 seconds
    case .grid2x4:
        baseDuration = 12.0  // 8 tiles: 12 seconds
    case .grid3x5:
        baseDuration = 15.0  // 15 tiles: 15 seconds
    }
    
    // No time reduction for levels 1-24
    if level < 25 {
        return baseDuration
    }
    
    // From level 25 onwards: 5% reduction per level (gentler than before)
    // Level 25: 95% time, Level 26: 90.25% time, Level 27: 85.7% time, etc.
    let levelsAbove24 = level - 24
    let reductionFactor = pow(0.95, Double(levelsAbove24))
    return baseDuration * reductionFactor
}

// MARK: - Tile Data Model

struct TileData: Identifiable {
    let id = UUID()
    let displayContent: TileContent      // The content name to display as text
    let backgroundContent: TileContent   // The actual background content
    
    // Convenience property for rendering background color
    var backgroundColor: Color {
        switch backgroundContent {
        case .color(let gameColor):
            return gameColor.color
        case .number(_), .shape(_), .flag(_), .emoji(_):
            // For numbers, shapes, flags and emojis, use a neutral background that adapts to light/dark mode
            #if os(watchOS)
            return Color(white: 0.2) // watchOS: use a dark gray that works well
            #else
            return Color(.secondarySystemBackground)
            #endif
        }
    }
    
    // Get the visual content (shape/emoji/number string if not color mode)
    var visualContent: String? {
        switch backgroundContent {
        case .color(_):
            return nil
        case .number(let gameNumber):
            return String(gameNumber.value)
        case .shape(let gameShape):
            return gameShape.shape
        case .flag(let gameFlag):
            return gameFlag.emoji
        case .emoji(let gameEmoji):
            return gameEmoji.emoji
        }
    }
    
    // Check if text matches background content
    var isCorrect: Bool {
        displayContent.nameKey == backgroundContent.nameKey
    }
}
