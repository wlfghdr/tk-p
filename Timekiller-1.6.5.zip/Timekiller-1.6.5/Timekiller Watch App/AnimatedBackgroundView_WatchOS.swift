//
//  AnimatedBackgroundView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI

// MARK: - Pre-computed shape data for better performance
struct FloatingShapeData: Identifiable {
    let id: Int
    let shapeSize: CGFloat
    let startX: CGFloat
    let startY: CGFloat
    let offsetX: CGFloat
    let offsetY: CGFloat
    let duration: Double
    let delay: Double
    let variant: Int
    let color: Color
    let emoji: String
    let shapeType: Int
}

// MARK: - Animated Background (watchOS)
struct AnimatedBackgroundView_WatchOS: View {
    @Environment(\.colorScheme) var systemColorScheme
    @Environment(\.scenePhase) var scenePhase
    
    let colorScheme: ColorScheme?
    let gameMode: GameMode
    let reduceMotion: Bool
    let isPlaying: Bool  // Add this parameter to know when to pause/resume
    
    @State private var animationPhase: CGFloat = 0
    @State private var shapeData: [FloatingShapeData] = []
    
    private var effectiveColorScheme: ColorScheme {
        colorScheme ?? systemColorScheme
    }
    
    var body: some View {
        ZStack {
            // Base gradient
            baseGradient
            
            // Material overlay in the middle
            Rectangle()
                .fill(.ultraThinMaterial)
            
            // Floating shapes layer - ABOVE material
            // Only show animated shapes when NOT playing
            if !isPlaying && !reduceMotion && !shapeData.isEmpty {
                GeometryReader { geometry in
                    // Use ForEach with individual views for better animation support
                    ForEach(shapeData) { data in
                        Group {
                            if data.variant == 0 {
                                // Emoji
                                Text(data.emoji)
                                    .font(.system(size: data.shapeSize * 0.6))
                            } else {
                                // Colored circle
                                Circle()
                                    .fill(data.color)
                                    .frame(width: data.shapeSize, height: data.shapeSize)
                            }
                        }
                        .blur(radius: data.variant == 0 ? 4 : 20)
                        .opacity(effectiveColorScheme == .dark ? 0.3 : 0.2)
                        .offset(
                            x: data.startX + (animationPhase * data.offsetX),
                            y: data.startY + (animationPhase * data.offsetY)
                        )
                    }
                }
            }
        }
        .ignoresSafeArea()
        .onAppear {
            // Pre-compute shape data once when appearing
            if shapeData.isEmpty {
                computeShapeData()
            }
            // Start animation when view appears
            if !isPlaying && !reduceMotion {
                startAnimation()
            }
        }
        .onChange(of: scenePhase) { _, newPhase in
            // Restart animation when app becomes active and shapes are visible
            if newPhase == .active && !isPlaying && !reduceMotion {
                startAnimation()
            }
        }
        .onChange(of: isPlaying) { _, newValue in
            // Restart animation when returning to start screen (shapes become visible)
            if !newValue && !reduceMotion {
                startAnimation()
            }
        }
    }
    
    // MARK: - Component Views
    
    private var baseGradient: some View {
        LinearGradient(
            colors: [
                effectiveColorScheme == .dark ? Color(red: 0.08, green: 0.09, blue: 0.11) : Color(red: 0.97, green: 0.97, blue: 0.98),
                effectiveColorScheme == .dark ? Color(red: 0.04, green: 0.05, blue: 0.06) : Color(red: 0.93, green: 0.94, blue: 0.96)
            ],
            startPoint: .top,
            endPoint: .bottom
        )
    }
    
    // MARK: - Animation Logic
    
    private func computeShapeData() {
        // Pre-compute random values once instead of during render
        let emojis = ["🎨", "⭐️", "🎯", "✨", "🌟", "🎪"]
        let colors: [Color] = [.red, .blue, .green, .yellow, .purple, .orange, .pink, .cyan, .indigo, .teal]
        
        // Reduce from 10 to 6 shapes for better performance
        shapeData = (0..<6).map { index in
            FloatingShapeData(
                id: index,
                shapeSize: CGFloat.random(in: 40...90),
                startX: CGFloat.random(in: -30...200),
                startY: CGFloat.random(in: -30...250),
                offsetX: CGFloat.random(in: -70...70),
                offsetY: CGFloat.random(in: -120...120),
                duration: Double.random(in: 12...22),
                delay: Double(index) * 0.8,
                variant: index % 2,
                color: colors[index % colors.count],
                emoji: emojis[index % emojis.count],
                shapeType: index % 4
            )
        }
    }
    
    private func startAnimation() {
        // Reset and restart animation with slower, smoother duration
        animationPhase = 0
        withAnimation(.linear(duration: 16).repeatForever(autoreverses: true)) {
            animationPhase = 1
        }
    }
    
    private var allColors: [Color] {
        // Mix all colors
        [.red, .blue, .green, .yellow, .purple, .orange, .pink, .cyan, .indigo, .teal]
    }
}

// MARK: - Preview
#Preview {
    AnimatedBackgroundView_WatchOS(
        colorScheme: nil,
        gameMode: .colors,
        reduceMotion: false,
        isPlaying: false
    )
}
