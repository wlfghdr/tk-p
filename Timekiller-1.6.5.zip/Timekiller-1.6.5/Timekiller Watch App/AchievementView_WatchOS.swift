//
//  AchievementView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI

// MARK: - Achievement Overview View (watchOS optimized)
struct AchievementView_WatchOS: View {
    let language: String
    let playerName: String
    let achievementStore: AchievementStore
    
    var body: some View {
        List {
            // Early Achievements (Level 5)
            Section {
                ForEach(earlyAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("EarlyAchievements", language: language))
            }
            
            // Unlocking Achievements (Level 10, 20, 30)
            Section {
                ForEach(unlockingAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("UnlockingAchievements", language: language))
            }
            
            // Intermediate Achievements (Level 15)
            Section {
                ForEach(intermediateAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("IntermediateAchievements", language: language))
            }
            
            // Advanced Achievements (Level 25)
            Section {
                ForEach(advancedAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("AdvancedAchievements", language: language))
            }
            
            // Mastery Achievements (Level 30 Standard)
            Section {
                ForEach(masteryAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("MasteryAchievements", language: language))
            }
            
            // Pro Mastery Achievements (Level 30 Pro)
            Section {
                ForEach(proMasteryAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("ProMasteryAchievements", language: language))
            }
            
            // Ultimate Achievement
            Section {
                ForEach(ultimateAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("UltimateAchievement", language: language))
            }
        }
    }
    
    // MARK: - Helper Views
    
    @ViewBuilder
    private func achievementRow(achievement: Achievement) -> some View {
        let isUnlocked = achievementStore.isUnlocked(achievement.id)
        
        HStack(spacing: 6) {
            Text(achievement.iconEmoji)
                .font(.system(size: 20))
                .grayscale(isUnlocked ? 0 : 1)
                .opacity(isUnlocked ? 1 : 0.5)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(L(achievement.nameKey, language: language))
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(isUnlocked ? .primary : .secondary)
                
                Text(L(achievement.explanationKey, language: language))
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            
            Spacer()
            
            if isUnlocked {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.green)
                    .font(.caption2)
            } else {
                Image(systemName: "lock.fill")
                    .foregroundStyle(.secondary)
                    .font(.caption2)
            }
        }
        .padding(.vertical, 2)
    }
    
    // MARK: - Achievement Groupings
    
    private var earlyAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(5, _, false) = achievement.unlockCondition {
                return true
            }
            // Include Numbers Level 10 achievement
            if achievement.id == "count_on_me" {
                return true
            }
            return false
        }
    }
    
    private var unlockingAchievements: [Achievement] {
        ["polygon_prodigy", "flag_dropper", "smiley_summoner", "ultra_instinct"].compactMap { id in
            Achievement.all.first { $0.id == id }
        }
    }
    
    private var intermediateAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            // Include level 10 and level 15 achievements (but not the unlocking ones)
            if case .reachLevel(let level, _, false) = achievement.unlockCondition {
                return (level == 15) && achievement.unlocksContent == nil
            }
            return false
        }
    }
    
    private var advancedAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            // Include level 20 and level 25 achievements (but not the unlocking ones)
            if case .reachLevel(let level, _, false) = achievement.unlockCondition {
                return (level == 20 || level == 25) && achievement.unlocksContent == nil
            }
            return false
        }
    }
    
    private var masteryAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(30, _, false) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var proMasteryAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(30, _, true) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var ultimateAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevelInAllModes = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
}

// MARK: - Preview
#Preview {
    NavigationStack {
        AchievementView_WatchOS(
            language: "en",
            playerName: "Player",
            achievementStore: AchievementStore()
        )
        .navigationTitle("Achievements")
        .navigationBarTitleDisplayMode(.inline)
    }
}
