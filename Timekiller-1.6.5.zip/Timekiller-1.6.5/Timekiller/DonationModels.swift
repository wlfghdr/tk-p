//
//  DonationModels.swift
//  Timekiller
//
//  Created on 01.01.26.
//

import Foundation

// MARK: - Donation Product

/// Donation tiers available for tip jar
enum DonationProduct: String, CaseIterable, Identifiable {
    case coffee = "wulf.ai.timekiller.tip.coffee"
    case beer = "wulf.ai.timekiller.tip.beer"
    case pizza = "wulf.ai.timekiller.tip.pizza"
    case wine = "wulf.ai.timekiller.tip.wine"
    case subscription = "wulf.ai.timekiller.tip.devsubscription"
    case sportscar = "wulf.ai.timekiller.tip.sportscar"
    
    var id: String { rawValue }
    
    /// Emoji icon for the donation tier
    var emoji: String {
        switch self {
        case .coffee: return "☕"
        case .beer: return "🍺"
        case .pizza: return "🍕"
        case .wine: return "🍷"
        case .subscription: return "💻"
        case .sportscar: return "🏎️"
        }
    }
    
    /// Localization key for the donation tier name
    var nameKey: String {
        switch self {
        case .coffee: return "DonationCoffee"
        case .beer: return "DonationBeer"
        case .pizza: return "DonationPizza"
        case .wine: return "DonationWine"
        case .subscription: return "DonationSubscription"
        case .sportscar: return "DonationSportscar"
        }
    }
    
    /// Localization key for the donation tier description
    var descriptionKey: String {
        switch self {
        case .coffee: return "DonationCoffeeDesc"
        case .beer: return "DonationBeerDesc"
        case .pizza: return "DonationPizzaDesc"
        case .wine: return "DonationWineDesc"
        case .subscription: return "DonationSubscriptionDesc"
        case .sportscar: return "DonationSportscarDesc"
        }
    }
    
    /// Fallback price in USD (used in StoreKit config, actual prices come from StoreKit)
    var fallbackPrice: Decimal {
        switch self {
        case .coffee: return 0.99
        case .beer: return 2.99
        case .pizza: return 4.99
        case .wine: return 9.99
        case .subscription: return 24.99
        case .sportscar: return 49.99
        }
    }
}
