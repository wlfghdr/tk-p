//
//  GameCenterManager.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 29.12.25.
//

import Foundation
import GameKit
import SwiftUI
import Observation

#if os(iOS)
import UIKit
#endif

/// Manages Game Center authentication, leaderboards, and achievements
@Observable
final class GameCenterManager {
    static let shared = GameCenterManager()
    
    // MARK: - State
    var isAuthenticated = false
    var isEnabled = false  // User preference to use Game Center
    var localPlayer: GKLocalPlayer?
    var authenticationError: String?
    var gameCenterPlayerName: String?  // Display name from Game Center
    
    // MARK: - Leaderboard IDs (from achievements.md)
    enum LeaderboardID: String {
        // Global leaderboard (legacy - all modes combined)
        case ios = "wulf.ai.timekiller.highscores.ios"
        
        // Mode-specific leaderboards
        case colorsNormal = "wulf.ai.timekiller.highscores.colors"
        case colorsPro = "wulf.ai.timekiller.highscores.colors.pro"
        case numbersNormal = "wulf.ai.timekiller.highscores.numbers"
        case numbersPro = "wulf.ai.timekiller.highscores.numbers.pro"
        case shapesNormal = "wulf.ai.timekiller.highscores.shapes"
        case shapesPro = "wulf.ai.timekiller.highscores.shapes.pro"
        case flagsNormal = "wulf.ai.timekiller.highscores.flags"
        case flagsPro = "wulf.ai.timekiller.highscores.flags.pro"
        case emojisNormal = "wulf.ai.timekiller.highscores.emojis"
        case emojisPro = "wulf.ai.timekiller.highscores.emojis.pro"
    }
    
    // MARK: - Achievement IDs (from achievements.md)
    enum AchievementID: String {
        // Early Achievements
        case colorCadet = "wulf.ai.timekiller.AchievementColorCadet"
        case shapeNovice = "wulf.ai.timekiller.AchievementShapeNovice"
        case emojiApprentice = "wulf.ai.timekiller.AchievementEmojiApprentice"
        
        // Unlocking Achievements
        case polygonProdigy = "wulf.ai.timekiller.AchievementPolygonProdigy"
        case smileySummoner = "wulf.ai.timekiller.AchievementSmileySummoner"
        case ultraInstinct = "wulf.ai.timekiller.AchievementUltraInstinct"
        
        // Intermediate Achievements
        case rainbowWrangler = "wulf.ai.timekiller.AchievementRainbowWrangler"
        case triangleTamer = "wulf.ai.timekiller.AchievementTriangleTamer"
        case emojiEnthusiast = "wulf.ai.timekiller.AchievementEmojiEnthusiast"
        
        // Advanced Achievements
        case colorVirtuoso = "wulf.ai.timekiller.AchievementColorVirtuoso"
        case shapeMaster = "wulf.ai.timekiller.AchievementShapeMaster"
        case emojiExpert = "wulf.ai.timekiller.AchievementEmojiExpert"
        
        // Mastery Achievements
        case chromaticChampion = "wulf.ai.timekiller.AchievementChromaticChampion"
        case geometryGenius = "wulf.ai.timekiller.AchievementGeometryGenius"
        case emojiOverlord = "wulf.ai.timekiller.AchievementEmojiOverlord"
        
        // Pro Mastery Achievements
        case rainbowAnnihilator = "wulf.ai.timekiller.AchievementRainbowAnnihilator"
        case shapeSorcerer = "wulf.ai.timekiller.AchievementShapeSorcerer"
        case emojiApocalypse = "wulf.ai.timekiller.AchievementEmojiApocalypse"
        
        // Ultimate Achievement
        case theUnkillable = "wulf.ai.timekiller.AchievementTheUnkillable"
        
        /// Map local achievement ID to Game Center achievement ID
        static func fromLocalID(_ localID: String) -> String? {
            switch localID {
            case "color_cadet": return AchievementID.colorCadet.rawValue
            case "shape_novice": return AchievementID.shapeNovice.rawValue
            case "emoji_apprentice": return AchievementID.emojiApprentice.rawValue
            case "polygon_prodigy": return AchievementID.polygonProdigy.rawValue
            case "smiley_summoner": return AchievementID.smileySummoner.rawValue
            case "ultra_instinct": return AchievementID.ultraInstinct.rawValue
            case "rainbow_wrangler": return AchievementID.rainbowWrangler.rawValue
            case "triangle_tamer": return AchievementID.triangleTamer.rawValue
            case "emoji_enthusiast": return AchievementID.emojiEnthusiast.rawValue
            case "color_virtuoso": return AchievementID.colorVirtuoso.rawValue
            case "shape_master": return AchievementID.shapeMaster.rawValue
            case "emoji_expert": return AchievementID.emojiExpert.rawValue
            case "chromatic_champion": return AchievementID.chromaticChampion.rawValue
            case "geometry_genius": return AchievementID.geometryGenius.rawValue
            case "emoji_overlord": return AchievementID.emojiOverlord.rawValue
            case "rainbow_annihilator": return AchievementID.rainbowAnnihilator.rawValue
            case "shape_sorcerer": return AchievementID.shapeSorcerer.rawValue
            case "emoji_apocalypse": return AchievementID.emojiApocalypse.rawValue
            case "the_unkillable": return AchievementID.theUnkillable.rawValue
            default: return nil
            }
        }
    }
    
    private init() {
        // Load user preference for Game Center
        #if os(watchOS)
        // Disable Game Center on watchOS — local highscores only
        isEnabled = false
        #else
        isEnabled = UserDefaults.standard.bool(forKey: "tk_gamecenter_enabled")
        #endif
    }
    
    // MARK: - Authentication
    
    /// Authenticate with Game Center
    func authenticate() {
        #if os(watchOS)
        // Disable Game Center on watchOS
        return
        #endif
        guard isEnabled else { return }
        
        localPlayer = GKLocalPlayer.local
        
        // Check if player is already authenticated
        if localPlayer?.isAuthenticated == true {
            isAuthenticated = true
            authenticationError = nil
            gameCenterPlayerName = localPlayer?.displayName ?? localPlayer?.alias ?? "Player"
            // Sync data from Game Center when authenticated
            Task {
                await syncFromGameCenter()
            }
            return
        }
        
        #if os(iOS)
              localPlayer?.authenticateHandler = { [weak self] (viewController: UIViewController?, error: Error?) in
                  guard let self = self else { return }
                  
                  if let error = error {
                      DispatchQueue.main.async {
                          self.isAuthenticated = false
                          self.authenticationError = error.localizedDescription
                      }
                      print("Game Center authentication failed: \(error.localizedDescription)")
                      return
                  }
                  
                  if let viewController = viewController {
                      // Need to present view controller
                      DispatchQueue.main.async {
                          if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                             let rootViewController = windowScene.windows.first?.rootViewController {
                              rootViewController.present(viewController, animated: true)
                          }
                      }
                  } else {
                      // No view controller and no error means authentication is done
                      DispatchQueue.main.async {
                          self.isAuthenticated = self.localPlayer?.isAuthenticated ?? false
                          self.authenticationError = nil
                          self.gameCenterPlayerName = self.localPlayer?.displayName ?? self.localPlayer?.alias ?? "Player"
                          // Sync data from Game Center after authentication
                          Task {
                              await self.syncFromGameCenter()
                          }
                      }
                  }
              }
        #else
              localPlayer?.authenticateHandler = { [weak self] (_, error) in
                  guard let self = self else { return }
                  
                  if let error = error {
                      DispatchQueue.main.async {
                          self.isAuthenticated = false
                          self.authenticationError = error.localizedDescription
                      }
                      print("Game Center authentication failed: \(error.localizedDescription)")
                      return
                  }
                  
                  // No UI to present on this platform; just update state
                  DispatchQueue.main.async {
                      self.isAuthenticated = self.localPlayer?.isAuthenticated ?? false
                      self.authenticationError = nil
                      self.gameCenterPlayerName = self.localPlayer?.displayName ?? self.localPlayer?.alias ?? "Player"
                      // Sync data from Game Center after authentication
                      Task {
                          await self.syncFromGameCenter()
                      }
                  }
              }
        #endif
    }
    
    /// Enable Game Center and authenticate
    func enable() {
        #if os(watchOS)
        // Game Center is disabled on watchOS — force local highscores only
        isEnabled = false
        UserDefaults.standard.set(false, forKey: "tk_gamecenter_enabled")
        return
        #endif
        isEnabled = true
        UserDefaults.standard.set(true, forKey: "tk_gamecenter_enabled")
        authenticate()
    }
    
    /// Disable Game Center
    func disable() {
        isEnabled = false
        UserDefaults.standard.set(false, forKey: "tk_gamecenter_enabled")
        isAuthenticated = false
        gameCenterPlayerName = nil
    }
    
    // MARK: - Leaderboards
    
    /// Submit score to the appropriate leaderboard(s)
    func submitScore(_ score: Int, gameMode: String = "colors", isPro: Bool = false, platform: Platform = .currentPlatform) async {
        #if os(watchOS)
        // Online highscores disabled on watchOS
        return
        #endif
        guard isEnabled && isAuthenticated else { return }
        
        // Determine which leaderboards to submit to
        var leaderboardIDs: [String] = []
        
        // Add legacy global leaderboard (for backwards compatibility)
        switch platform {
        case .ios, .currentPlatform:
            #if os(iOS)
            leaderboardIDs.append(LeaderboardID.ios.rawValue)
            #endif
        }
        
        // Add mode-specific leaderboard
        let modeSpecificLeaderboard: LeaderboardID?
        switch (gameMode, isPro) {
        case ("colors", false):
            modeSpecificLeaderboard = .colorsNormal
        case ("colors", true):
            modeSpecificLeaderboard = .colorsPro
        case ("numbers", false):
            modeSpecificLeaderboard = .numbersNormal
        case ("numbers", true):
            modeSpecificLeaderboard = .numbersPro
        case ("shapes", false):
            modeSpecificLeaderboard = .shapesNormal
        case ("shapes", true):
            modeSpecificLeaderboard = .shapesPro
        case ("flags", false):
            modeSpecificLeaderboard = .flagsNormal
        case ("flags", true):
            modeSpecificLeaderboard = .flagsPro
        case ("emojis", false):
            modeSpecificLeaderboard = .emojisNormal
        case ("emojis", true):
            modeSpecificLeaderboard = .emojisPro
        default:
            modeSpecificLeaderboard = nil
        }
        
        if let modeLeaderboard = modeSpecificLeaderboard {
            leaderboardIDs.append(modeLeaderboard.rawValue)
        }
        
        guard !leaderboardIDs.isEmpty else {
            print("⚠️ No leaderboards found for mode: \(gameMode), pro: \(isPro)")
            return
        }
        
        // Create context value from gameMode and isPro
        // We encode the game mode and pro status into the context field
        // Context format: [gameMode enum value (0-4)] + [isPro flag (0 or 1000)]
        let gameModeValue: Int
        switch gameMode {
        case "colors": gameModeValue = 0
        case "numbers": gameModeValue = 1
        case "shapes": gameModeValue = 2
        case "flags": gameModeValue = 3
        case "emojis": gameModeValue = 4
        default: gameModeValue = 0
        }
        
        let context = gameModeValue + (isPro ? 1000 : 0)
        
        GKLeaderboard.submitScore(score, context: context, player: GKLocalPlayer.local, leaderboardIDs: leaderboardIDs) { error in
            if let error = error {
                print("❌ Failed to submit score: \(error.localizedDescription)")
            } else {
                print("✅ Score \(score) submitted to \(leaderboardIDs.count) leaderboard(s): \(leaderboardIDs.joined(separator: ", ")) (mode: \(gameMode), pro: \(isPro))")
            }
        }
    }
    
    /// Load leaderboard entries
    func loadLeaderboard(leaderboardID: LeaderboardID, playerScope: GKLeaderboard.PlayerScope = .global, timeScope: GKLeaderboard.TimeScope = .allTime, range: NSRange = NSRange(location: 1, length: 25)) async -> [GKLeaderboard.Entry] {
        #if os(watchOS)
        // Online highscores disabled on watchOS
        return []
        #endif
        guard isEnabled && isAuthenticated else { return [] }
        
        return await withCheckedContinuation { continuation in
            GKLeaderboard.loadLeaderboards(IDs: [leaderboardID.rawValue]) { leaderboards, error in
                guard let leaderboard = leaderboards?.first, error == nil else {
                    if let error = error {
                        print("❌ Failed to load leaderboard: \(error.localizedDescription)")
                    }
                    continuation.resume(returning: [])
                    return
                }
                
                leaderboard.loadEntries(for: playerScope, timeScope: timeScope, range: range) { local, entries, _, error in
                    if let error = error {
                        print("❌ Failed to load leaderboard entries: \(error.localizedDescription)")
                        continuation.resume(returning: [])
                        return
                    }
                    
                    var result: [GKLeaderboard.Entry] = []
                    if let localEntry = local {
                        result.append(localEntry)
                    }
                    if let entries = entries {
                        result.append(contentsOf: entries)
                    }
                    continuation.resume(returning: result)
                }
            }
        }
    }
    
    /// Get leaderboard ID for displaying leaderboard
    /// Use this with the .gameCenter() modifier in your SwiftUI views
    @MainActor
    func gameCenterLeaderboardID(_ leaderboardID: LeaderboardID) -> String? {
        guard isEnabled && isAuthenticated else { return nil }
        return leaderboardID.rawValue
    }
    
    // MARK: - Achievements
    
    /// Report achievement progress to Game Center
    func reportAchievement(localID: String, percentComplete: Double = 100.0) async {
        #if os(watchOS)
        // Achievements reporting to Game Center disabled on watchOS
        return
        #endif
        guard isEnabled && isAuthenticated else { return }
        guard let gameCenterID = AchievementID.fromLocalID(localID) else {
            print("⚠️ No Game Center mapping for achievement: \(localID)")
            return
        }
        
        let achievement = GKAchievement(identifier: gameCenterID)
        achievement.percentComplete = percentComplete
        achievement.showsCompletionBanner = true
        
        GKAchievement.report([achievement]) { error in
            if let error = error {
                print("❌ Failed to report achievement: \(error.localizedDescription)")
            } else {
                print("✅ Achievement reported: \(gameCenterID) (\(percentComplete)%)")
            }
        }
    }
    
    /// Report multiple achievements to Game Center
    func reportAchievements(_ localIDs: [String]) async {
        #if os(watchOS)
        // Achievements reporting disabled on watchOS
        return
        #endif
        guard isEnabled && isAuthenticated else { return }
        
        let achievements = localIDs.compactMap { localID -> GKAchievement? in
            guard let gameCenterID = AchievementID.fromLocalID(localID) else { return nil }
            let achievement = GKAchievement(identifier: gameCenterID)
            achievement.percentComplete = 100.0
            achievement.showsCompletionBanner = true
            return achievement
        }
        
        guard !achievements.isEmpty else { return }
        
        GKAchievement.report(achievements) { error in
            if let error = error {
                print("❌ Failed to report achievements: \(error.localizedDescription)")
            } else {
                print("✅ Reported \(achievements.count) achievements to Game Center")
            }
        }
    }
    
    /// Load all achievements from Game Center
    func loadAchievements() async -> [GKAchievement] {
        #if os(watchOS)
        // Achievements loading from Game Center disabled on watchOS
        return []
        #endif
        guard isEnabled && isAuthenticated else { return [] }
        
        return await withCheckedContinuation { continuation in
            GKAchievement.loadAchievements { achievements, error in
                if let error = error {
                    print("❌ Failed to load achievements: \(error.localizedDescription)")
                    continuation.resume(returning: [])
                } else {
                    continuation.resume(returning: achievements ?? [])
                }
            }
        }
    }
    
    /// Check if Game Center UI can be presented
    var canPresentGameCenterUI: Bool {
        isEnabled && isAuthenticated
    }
    
    // MARK: - Helper Types
    
    enum Platform {
        case ios
        case currentPlatform
    }
    
    // MARK: - Syncing
    
    /// Sync achievements and scores bidirectionally between Game Center and local storage
    /// On first connection, this will push local player data to the Game Center player
    /// Call this after authentication to restore user progress on new devices
    /// - Parameters:
    ///   - achievementStore: The local achievement store to sync with
    ///   - highscoreStore: The local highscore store to sync with
    ///   - previousLocalPlayer: Optional name of the player before switching to Game Center (for first-time sync)
    func syncFromGameCenter(achievementStore: AchievementStore, highscoreStore: HighscoreStore, previousLocalPlayer: String? = nil) async {
        #if os(watchOS)
        return
        #endif
        guard isEnabled && isAuthenticated else { return }
        guard let playerName = gameCenterPlayerName else { return }
        
        print("🔄 Starting Game Center sync for player: \(playerName)...")
        
        // Check if this is a first-time connection (Game Center player doesn't exist yet)
        let isFirstTimeConnection = !achievementStore.playerExists(name: playerName)
        
        // Create player profile if it doesn't exist
        if !achievementStore.playerExists(name: playerName) {
            achievementStore.createPlayer(name: playerName)
            print("  ℹ️ Created new Game Center player profile")
        }
        
        // If first-time connection and we have a previous local player, migrate their data
        if isFirstTimeConnection, let localPlayer = previousLocalPlayer, localPlayer != playerName {
            print("  🔄 First-time Game Center connection detected - migrating local player '\(localPlayer)' data to Game Center player '\(playerName)'")
            await migrateLocalPlayerToGameCenter(
                from: localPlayer,
                to: playerName,
                achievementStore: achievementStore,
                highscoreStore: highscoreStore
            )
        }
        
        // Switch to Game Center player
        achievementStore.currentPlayerName = playerName
        
        // Sync achievements from Game Center to local (merge any cloud achievements)
        await syncAchievementsFromGameCenter(achievementStore: achievementStore)
        
        // Sync scores from Game Center to local (take the best score)
        await syncScoresFromGameCenter(highscoreStore: highscoreStore, playerName: playerName)
        
        // Sync any local data back to Game Center (in case user played offline)
        await syncLocalToGameCenter(achievementStore: achievementStore, highscoreStore: highscoreStore, playerName: playerName)
        
        print("✅ Game Center sync complete for player: \(playerName)")
    }
    
    /// Migrate local player's achievements and scores to Game Center player on first connection
    /// This ensures players don't lose progress when enabling Game Center for the first time
    private func migrateLocalPlayerToGameCenter(
        from localPlayer: String,
        to gameCenterPlayer: String,
        achievementStore: AchievementStore,
        highscoreStore: HighscoreStore
    ) async {
        print("  📦 Migrating data from '\(localPlayer)' to '\(gameCenterPlayer)'...")
        
        // Temporarily switch to local player to read their data
        let originalPlayer = achievementStore.currentPlayerName
        achievementStore.currentPlayerName = localPlayer
        
        // Copy local player's achievements to Game Center player
        let localAchievements = Array(achievementStore.unlockedAchievementIDs)
        let localLevelCompletions = achievementStore.levelCompletions
        
        // Switch to Game Center player
        achievementStore.currentPlayerName = gameCenterPlayer
        
        // Merge achievements
        if !localAchievements.isEmpty {
            print("    📥 Migrating \(localAchievements.count) achievements...")
            for achievementID in localAchievements {
                achievementStore.unlockedAchievementIDs.insert(achievementID)
            }
            
            // Upload to Game Center
            await reportAchievements(localAchievements)
            print("    ✅ Uploaded achievements to Game Center")
        }
        
        // Merge level completions
        if !localLevelCompletions.isEmpty {
            print("    📥 Migrating level completion progress...")
            for (key, level) in localLevelCompletions {
                let currentLevel = achievementStore.levelCompletions[key] ?? 0
                achievementStore.levelCompletions[key] = max(level, currentLevel)
            }
            print("    ✅ Level progress migrated")
        }
        
        // Copy local player's best score to Game Center player
        if let localBestScore = highscoreStore.entries.first(where: { $0.playerName == localPlayer }) {
            print("    📥 Migrating best score: \(localBestScore.score) (level \(localBestScore.maxLevel))...")
            
            // Add to Game Center player's local scores
            highscoreStore.add(
                score: localBestScore.score,
                playerName: gameCenterPlayer,
                maxLevel: localBestScore.maxLevel,
                achievementIDs: localBestScore.achievementIDs,
                gameMode: localBestScore.gameMode,
                isPro: localBestScore.isPro
            )
            
            // Upload to Game Center leaderboard
            await submitScore(localBestScore.score, gameMode: localBestScore.gameMode, isPro: localBestScore.isPro)
            print("    ✅ Score uploaded to Game Center leaderboard")
        }
        
        print("  ✅ Migration complete!")
        
        // Restore original player context
        achievementStore.currentPlayerName = originalPlayer
    }
    
    /// Convenience method without parameters - to be called with injected stores
    private func syncFromGameCenter() async {
        // This will be called from authentication handlers
        // The actual sync needs to be triggered from the app with proper store references
        print("⚠️ Game Center authenticated - sync pending (requires store references)")
    }
    
    /// Sync achievements from Game Center to local storage
    private func syncAchievementsFromGameCenter(achievementStore: AchievementStore) async {
        let gcAchievements = await loadAchievements()
        
        guard !gcAchievements.isEmpty else {
            print("ℹ️ No Game Center achievements to sync")
            return
        }
        
        var syncedCount = 0
        var newAchievements: [String] = []
        
        // Map Game Center achievements back to local IDs
        for gcAchievement in gcAchievements {
            guard gcAchievement.isCompleted else { continue }
            
            // Find matching local achievement ID
            if let localID = localIDFromGameCenter(gcAchievement.identifier) {
                if !achievementStore.isUnlocked(localID) {
                    // Unlock locally if found in Game Center but not local
                    achievementStore.unlockedAchievementIDs.insert(localID)
                    newAchievements.append(localID)
                    syncedCount += 1
                }
            }
        }
        
        if syncedCount > 0 {
            print("✅ Synced \(syncedCount) achievements from Game Center to local: \(newAchievements)")
            
            // Derive level completions from achievements
            // This ensures mode unlocks work correctly after sync
            deriveProgressFromAchievements(achievementStore: achievementStore, achievements: newAchievements)
        } else {
            print("ℹ️ All Game Center achievements already exist locally")
        }
    }
    
    /// Derive level completion progress from synced achievements
    /// Game Center achievements are binary, but we need level progress for unlocks
    private func deriveProgressFromAchievements(achievementStore: AchievementStore, achievements: [String]) {
        // Map achievements to their level requirements
        let achievementLevels: [String: (mode: String, level: Int, isPro: Bool)] = [
            "color_cadet": ("colors", 5, false),
            "shape_novice": ("shapes", 5, false),
            "emoji_apprentice": ("emojis", 5, false),
            "polygon_prodigy": ("colors", 10, false),
            "smiley_summoner": ("colors", 20, false),
            "ultra_instinct": ("colors", 30, false),
            "rainbow_wrangler": ("colors", 15, false),
            "triangle_tamer": ("shapes", 15, false),
            "emoji_enthusiast": ("emojis", 15, false),
            "color_virtuoso": ("colors", 25, false),
            "shape_master": ("shapes", 25, false),
            "emoji_expert": ("emojis", 25, false),
            "chromatic_champion": ("colors", 30, false),
            "geometry_genius": ("shapes", 30, false),
            "emoji_overlord": ("emojis", 30, false),
            "rainbow_annihilator": ("colors", 30, true),
            "shape_sorcerer": ("shapes", 30, true),
            "emoji_apocalypse": ("emojis", 30, true),
            "the_unkillable": ("colors", 30, false) // Special case - all modes
        ]
        
        for achievementID in achievements {
            if let info = achievementLevels[achievementID] {
                let key = "\(info.mode)_\(info.isPro)"
                let currentLevel = achievementStore.levelCompletions[key] ?? 0
                
                // Only update if the achievement level is higher
                if info.level > currentLevel {
                    achievementStore.levelCompletions[key] = info.level
                    print("  📊 Updated \(key) progress to level \(info.level)")
                }
                
                // Special handling for "the_unkillable" - all modes at level 30
                if achievementID == "the_unkillable" {
                    for mode in ["colors", "shapes", "emojis"] {
                        for isPro in [false, true] {
                            let allKey = "\(mode)_\(isPro)"
                            let currentAllLevel = achievementStore.levelCompletions[allKey] ?? 0
                            if 30 > currentAllLevel {
                                achievementStore.levelCompletions[allKey] = 30
                                print("  📊 Updated \(allKey) progress to level 30 (from ultimate achievement)")
                            }
                        }
                    }
                }
            }
        }
    }
    
    /// Sync high scores from Game Center to local storage
    private func syncScoresFromGameCenter(highscoreStore: HighscoreStore, playerName: String) async {
        // Load player's best score from Game Center
        let entries = await loadLeaderboard(
            leaderboardID: .ios,
            playerScope: .global,
            timeScope: .allTime,
            range: NSRange(location: 1, length: 1)
        )
        
        // Find the local player's entry
        guard let localPlayerEntry = entries.first(where: { $0.player.gamePlayerID == GKLocalPlayer.local.gamePlayerID }) else {
            print("ℹ️ No Game Center score found for this player")
            return
        }
        
        let gcScore = localPlayerEntry.score
        
        // Decode game mode and pro status from context
        let context = localPlayerEntry.context
        let gameModeValue = context % 1000
        let isPro = context >= 1000
        let gameMode: String
        switch gameModeValue {
        case 0: gameMode = "colors"
        case 1: gameMode = "numbers"
        case 2: gameMode = "shapes"
        case 3: gameMode = "flags"
        case 4: gameMode = "emojis"
        default: gameMode = "colors"
        }
        
        // Check if this score already exists in local highscores
        let existingScore = highscoreStore.entries.first(where: { $0.playerName == playerName })
        
        if let existing = existingScore {
            if gcScore > existing.score {
                // Game Center has a higher score - add it locally
                print("📥 Syncing higher score from Game Center: \(gcScore) (local was \(existing.score))")
                highscoreStore.add(score: gcScore, playerName: playerName, maxLevel: 1, achievementIDs: [], gameMode: gameMode, isPro: isPro)
            } else {
                print("ℹ️ Local score (\(existing.score)) is >= Game Center score (\(gcScore))")
            }
        } else {
            // No local score for this player - add Game Center score
            print("📥 Adding Game Center score to local storage: \(gcScore)")
            highscoreStore.add(score: gcScore, playerName: playerName, maxLevel: 1, achievementIDs: [], gameMode: gameMode, isPro: isPro)
        }
    }
    
    /// Sync local achievements and scores to Game Center (for offline play catch-up)
    private func syncLocalToGameCenter(achievementStore: AchievementStore, highscoreStore: HighscoreStore, playerName: String) async {
        print("📤 Syncing local data to Game Center...")
        
        // Sync achievements
        let localAchievements = Array(achievementStore.unlockedAchievementIDs)
        if !localAchievements.isEmpty {
            await reportAchievements(localAchievements)
            print("  ✅ Uploaded \(localAchievements.count) achievements to Game Center")
        }
        
        // Sync best score for this player
        if let bestLocal = highscoreStore.entries.first(where: { $0.playerName == playerName }) {
            await submitScore(bestLocal.score, gameMode: bestLocal.gameMode, isPro: bestLocal.isPro)
            print("  ✅ Uploaded score \(bestLocal.score) to Game Center (mode: \(bestLocal.gameMode), pro: \(bestLocal.isPro))")
        }
    }
    
    /// Map Game Center achievement ID back to local achievement ID
    private func localIDFromGameCenter(_ gameCenterID: String) -> String? {
        // Reverse lookup of the AchievementID mapping
        switch gameCenterID {
        case AchievementID.colorCadet.rawValue: return "color_cadet"
        case AchievementID.shapeNovice.rawValue: return "shape_novice"
        case AchievementID.emojiApprentice.rawValue: return "emoji_apprentice"
        case AchievementID.polygonProdigy.rawValue: return "polygon_prodigy"
        case AchievementID.smileySummoner.rawValue: return "smiley_summoner"
        case AchievementID.ultraInstinct.rawValue: return "ultra_instinct"
        case AchievementID.rainbowWrangler.rawValue: return "rainbow_wrangler"
        case AchievementID.triangleTamer.rawValue: return "triangle_tamer"
        case AchievementID.emojiEnthusiast.rawValue: return "emoji_enthusiast"
        case AchievementID.colorVirtuoso.rawValue: return "color_virtuoso"
        case AchievementID.shapeMaster.rawValue: return "shape_master"
        case AchievementID.emojiExpert.rawValue: return "emoji_expert"
        case AchievementID.chromaticChampion.rawValue: return "chromatic_champion"
        case AchievementID.geometryGenius.rawValue: return "geometry_genius"
        case AchievementID.emojiOverlord.rawValue: return "emoji_overlord"
        case AchievementID.rainbowAnnihilator.rawValue: return "rainbow_annihilator"
        case AchievementID.shapeSorcerer.rawValue: return "shape_sorcerer"
        case AchievementID.emojiApocalypse.rawValue: return "emoji_apocalypse"
        case AchievementID.theUnkillable.rawValue: return "the_unkillable"
        default: return nil
        }
    }
}

// MARK: - Game Center Presentation Types

/// Enum for specifying what Game Center content to display
enum GameCenterContent {
    case leaderboard(id: String)
    case achievements
}

