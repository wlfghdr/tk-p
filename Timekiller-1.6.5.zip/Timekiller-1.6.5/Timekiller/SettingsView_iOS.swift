//
//  SettingsView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI

// MARK: - Settings View
struct SettingsView_iOS: View {
    @Binding var playerName: String
    @Binding var appLanguage: String
    @Binding var gridSizeRaw: String
    @Binding var appTheme: String
    @Binding var proMode: Bool
    @Binding var gameModeRaw: String
    @Binding var soundEnabled: Bool
    @Binding var hapticsEnabled: Bool
    @Binding var showPlayerSelection: Bool  // Add binding for player selection
    @Binding var startLevel: Int  // Add start level binding
    
    let gameCenterManager: GameCenterManager
    
    @Environment(\.dismiss) private var dismiss
    @State private var isEnablingGameCenter = false
    
    private var gameMode: GameMode {
        GameMode(rawValue: gameModeRaw) ?? .colors
    }
    
    // Dev Mode: Check if player name is "Wulf" (trimmed, case-insensitive)
    private var isDevMode: Bool {
        let normalized = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.caseInsensitiveCompare("Wulf") == .orderedSame
    }
    
    private var appVersion: String {
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
        let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "Unknown"
        return "\(version) (\(build))"
    }
    
    private func setDefaultNameIfEmpty() {
        let trimmed = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            playerName = ContentView_iOS.defaultPlayerName()
        }
    }
    
    var body: some View {
        NavigationStack {
            Form {
                // MARK: - Player Section
                Section {
                    // Show Game Center name when enabled and authenticated
                    if gameCenterManager.isEnabled && gameCenterManager.isAuthenticated,
                       let gcPlayerName = gameCenterManager.gameCenterPlayerName {
                        HStack {
                            Image(systemName: "gamecontroller.fill")
                                .foregroundStyle(.green)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(gcPlayerName)
                                    .font(.body.bold())
                                Text(L("GameCenterPlayer", language: appLanguage))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .listRowBackground(Color.green.opacity(0.1))
                    } else {
                        // Local player name (only editable when Game Center is off)
                        TextField(L("PlayerName", language: appLanguage), text: $playerName)
                            .onChange(of: playerName) { oldValue, newValue in
                                // Only trim whitespace, don't set default while typing
                                let trimmed = newValue.trimmingCharacters(in: .whitespaces)
                                if !trimmed.isEmpty && trimmed != newValue {
                                    playerName = trimmed
                                }
                            }
                            .onSubmit {
                                // Set default name when user submits (presses return) with empty field
                                setDefaultNameIfEmpty()
                            }
                    }
                    
                    // Switch player button (only show when Game Center is off)
                    if !gameCenterManager.isEnabled || !gameCenterManager.isAuthenticated {
                        Button {
                            showPlayerSelection = true
                            dismiss()
                        } label: {
                            HStack {
                                Image(systemName: "person.2.fill")
                                Text(L("SwitchPlayer", language: appLanguage))
                            }
                        }
                    }
                }
                
                // MARK: - Dev Mode Section (only visible if dev mode active)
                if isDevMode {
                    Section {
                        HStack {
                            Image(systemName: "wrench.and.screwdriver.fill")
                                .foregroundStyle(.orange)
                            Text(L("DevModeActive", language: appLanguage))
                                .font(.headline)
                            Spacer()
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.orange)
                        }
                        
                        Picker(L("StartLevel", language: appLanguage), selection: $startLevel) {
                            ForEach(1...30, id: \.self) { level in
                                Text("Level \(level)").tag(level)
                            }
                        }
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text(L("DevModeInfo", language: appLanguage))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text("• \(L("DevModeFeature1", language: appLanguage))")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                            Text("• \(L("DevModeFeature2", language: appLanguage))")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    } header: {
                        Text(L("DeveloperMode", language: appLanguage))
                    }
                }
                
                // MARK: - Game Center Section (direkt nach Player, um die Verbindung klar zu machen)
                Section {
                    Toggle(isOn: Binding(
                        get: { gameCenterManager.isEnabled },
                        set: { newValue in
                            if newValue {
                                isEnablingGameCenter = true
                                gameCenterManager.enable()
                                isEnablingGameCenter = false
                            } else {
                                gameCenterManager.disable()
                            }
                        }
                    )) {
                        HStack {
                            if isEnablingGameCenter {
                                ProgressView()
                                    .controlSize(.small)
                                    .padding(.trailing, 4)
                            }
                            Text(L("OnlineMode", language: appLanguage))
                        }
                    }
                    .disabled(isEnablingGameCenter)
                    
                    if gameCenterManager.isEnabled {
                        HStack {
                            Text(L("Status", language: appLanguage))
                            Spacer()
                            if gameCenterManager.isAuthenticated {
                                HStack(spacing: 4) {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundStyle(.green)
                                    Text(L("Connected", language: appLanguage))
                                        .foregroundStyle(.secondary)
                                }
                            } else {
                                HStack(spacing: 4) {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundStyle(.red)
                                    Text(L("NotConnected", language: appLanguage))
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                        
                        #if targetEnvironment(simulator)
                        if !gameCenterManager.isAuthenticated {
                            Text("Game Center may not work in Simulator. Please test on a real device.")
                                .font(.caption)
                                .foregroundStyle(.orange)
                        }
                        #endif
                        
                        if let error = gameCenterManager.authenticationError {
                            Text(error)
                                .font(.caption)
                                .foregroundStyle(.red)
                        }
                    }
                } header: {
                    Text(L("GameCenter", language: appLanguage))
                } footer: {
                    Text(L("GameCenterDescription", language: appLanguage))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                
                // MARK: - Feedback Section
                Section {
                    Toggle(L("Sound", language: appLanguage), isOn: $soundEnabled)
                    Toggle(L("Haptics", language: appLanguage), isOn: $hapticsEnabled)
                } header: {
                    Text(L("Feedback", language: appLanguage))
                }
                
                // MARK: - Theme Section
                Section {
                    Picker(L("Theme", language: appLanguage), selection: $appTheme) {
                        Text(L("ThemeSystem", language: appLanguage)).tag("system")
                        Text(L("ThemeLight", language: appLanguage)).tag("light")
                        Text(L("ThemeDark", language: appLanguage)).tag("dark")
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text(L("Theme", language: appLanguage))
                }
                
                Section {
                    Picker(L("Language", language: appLanguage), selection: $appLanguage) {
                        Text(L("German", language: appLanguage)).tag("de")
                        Text(L("English", language: appLanguage)).tag("en")
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text(L("Language", language: appLanguage))
                }
                
                Section {
                    HStack {
                        Text(L("Version", language: appLanguage))
                        Spacer()
                        Text(appVersion)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text(L("About", language: appLanguage))
                }
            }
            .navigationTitle(L("Settings", language: appLanguage))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(L("Done", language: appLanguage)) {
                        dismiss()
                    }
                }
            }
            .onDisappear {
                // Set default name when leaving settings with empty field
                setDefaultNameIfEmpty()
            }
        }
    }
}
