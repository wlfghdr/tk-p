//
//  HighscoreView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI
import GameKit

// MARK: - Highscore View
struct HighscoreView_iOS: View {
    let store: HighscoreStore
    let language: String
    let achievementStore: AchievementStore
    let playerName: String
    let gameCenterManager: GameCenterManager
    
    @State private var showAchievements = false
    @State private var showGameCenterLeaderboard = false
    @State private var showGameCenterAchievements = false
    @State private var isEnablingGameCenter = false
    @State private var presentedLeaderboardID: String?
    
    var body: some View {
        List {
            donationSection
            gameCenterSection
            achievementsButtonSection
            localHighscoresSection
        }
        .sheet(isPresented: $showGameCenterLeaderboard) {
            if let leaderboardID = presentedLeaderboardID {
                GameCenterLeaderboardView(leaderboardID: leaderboardID)
            }
        }
        .sheet(isPresented: $showGameCenterAchievements) {
            GameCenterAchievementsView()
        }
        .sheet(isPresented: $showAchievements) {
            achievementsSheet
        }
    }
    
    // MARK: - View Components
    
    @ViewBuilder
    private var donationSection: some View {
        #if os(iOS)
        Section {
            VStack(spacing: 12) {
                let prompts = ["DonateHighscore1", "DonateHighscore2", "DonateHighscore3"]
                let randomPrompt = prompts.randomElement() ?? prompts[0]
                
                Text(L(randomPrompt, language: language))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
                
                DonateButton(language: language, style: .withText)
                    .frame(maxWidth: .infinity)
            }
            .listRowBackground(Color.clear)
            .listRowInsets(EdgeInsets(top: 12, leading: 16, bottom: 12, trailing: 16))
        }
        #endif
    }
    
    @ViewBuilder
    private var gameCenterSection: some View {
        Section {
            if gameCenterManager.isEnabled && gameCenterManager.isAuthenticated {
                authenticatedGameCenterButtons
            } else if gameCenterManager.isEnabled && !gameCenterManager.isAuthenticated {
                gameCenterWarning
            } else {
                gameCenterPromotionButton
            }
        } header: {
            if gameCenterManager.isEnabled {
                Text(L("OnlineLeaderboards", language: language))
            }
        }
    }
    
    private var authenticatedGameCenterButtons: some View {
        Group {
            leaderboardButton
            achievementsGameCenterButton
        }
    }
    
    private var leaderboardButton: some View {
        Button {
            if let leaderboardID = gameCenterManager.gameCenterLeaderboardID(.ios) {
                presentedLeaderboardID = leaderboardID
                showGameCenterLeaderboard = true
            }
        } label: {
            HStack {
                Image(systemName: "trophy.fill")
                    .font(.title2)
                    .foregroundStyle(.yellow)
                    .frame(width: 44)
                VStack(alignment: .leading, spacing: 4) {
                    Text(L("ViewGlobalLeaderboards", language: language))
                        .font(.headline)
                        .foregroundStyle(.primary)
                    Text(L("CompeteWithPlayers", language: language))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundStyle(.tertiary)
            }
            .padding(.vertical, 4)
        }
        .disabled(gameCenterManager.gameCenterLeaderboardID(.ios) == nil)
    }
    
    private var achievementsGameCenterButton: some View {
        Button {
            showGameCenterAchievements = true
        } label: {
            HStack {
                Image(systemName: "star.fill")
                    .font(.title2)
                    .foregroundStyle(.orange)
                    .frame(width: 44)
                VStack(alignment: .leading, spacing: 4) {
                    Text(L("ViewGameCenterAchievements", language: language))
                        .font(.headline)
                        .foregroundStyle(.primary)
                    Text(L("TrackYourProgress", language: language))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundStyle(.tertiary)
            }
            .padding(.vertical, 4)
        }
    }
    
    private var gameCenterWarning: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.title2)
                    .foregroundStyle(.orange)
                VStack(alignment: .leading, spacing: 4) {
                    Text(L("GameCenterNotConnected", language: language))
                        .font(.headline)
                    Text(L("EnableInSettings", language: language))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
        }
        .padding(.vertical, 4)
    }
    
    private var gameCenterPromotionButton: some View {
        Button {
            enableGameCenter()
        } label: {
            gameCenterPromotionContent
        }
        .buttonStyle(.plain)
        .disabled(isEnablingGameCenter)
        .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
        .listRowBackground(Color.clear)
    }
    
    private var gameCenterPromotionContent: some View {
        HStack(spacing: 12) {
            gameCenterIcon
            
            VStack(alignment: .leading, spacing: 4) {
                Text(L("JoinGlobalLeaderboards", language: language))
                    .font(.headline)
                    .foregroundStyle(.primary)
                
                Text(L("CompeteWorldwide", language: language))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
            
            gameCenterActionIndicator
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.secondarySystemBackground))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(gameCenterGradient, lineWidth: 2)
        )
    }
    
    private var gameCenterIcon: some View {
        ZStack {
            Circle()
                .fill(gameCenterGradient)
                .frame(width: 50, height: 50)
            
            Image(systemName: "globe.americas.fill")
                .font(.title3)
                .foregroundStyle(.white)
        }
    }
    
    private var gameCenterActionIndicator: some View {
        Group {
            if isEnablingGameCenter {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle())
            } else {
                Image(systemName: "arrow.right.circle.fill")
                    .font(.title2)
                    .foregroundStyle(gameCenterGradient)
            }
        }
    }
    
    private var gameCenterGradient: LinearGradient {
        LinearGradient(
            colors: [.blue, .cyan],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var achievementsButtonSection: some View {
        Section {
            Button {
                showAchievements = true
            } label: {
                HStack {
                    Image(systemName: "trophy.fill")
                        .foregroundStyle(.yellow)
                    Text(L("Achievements", language: language))
                        .font(.headline)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundStyle(.secondary)
                }
            }
        }
    }
    
    @ViewBuilder
    private var localHighscoresSection: some View {
        Section {
            if store.entries.isEmpty {
                Text(L("NoHighscores", language: language))
                    .foregroundStyle(.secondary)
                    .italic()
            } else {
                ForEach(store.entries) { entry in
                    highscoreEntryView(entry)
                }
            }
        } header: {
            Text(L("LocalHighscores", language: language))
        }
    }
    
    private func highscoreEntryView(_ entry: HighscoreEntry) -> some View {
        VStack(spacing: 8) {
            highscoreEntryHeader(entry)
            
            if !entry.achievementIDs.isEmpty {
                achievementsForEntry(entry)
            }
        }
    }
    
    private func highscoreEntryHeader(_ entry: HighscoreEntry) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(entry.playerName)
                    .font(.headline)
                highscoreEntryMetadata(entry)
            }
            
            Spacer()
            
            Text("\(entry.score)")
                .font(.title2.bold())
                .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
        }
    }
    
    private func highscoreEntryMetadata(_ entry: HighscoreEntry) -> some View {
        HStack(spacing: 8) {
            Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                .font(.caption)
                .foregroundStyle(.secondary)
            Text("•")
                .font(.caption)
                .foregroundStyle(.secondary)
            Text("Level \(entry.maxLevel)")
                .font(.caption)
                .foregroundStyle(.tint)
            Text("•")
                .font(.caption)
                .foregroundStyle(.secondary)
            gameModeIndicator(entry)
        }
    }
    
    private func gameModeIndicator(_ entry: HighscoreEntry) -> some View {
        HStack(spacing: 2) {
            Image(systemName: gameModeIcon(for: entry.gameMode))
                .font(.caption)
            Text(L(gameModeNameKey(for: entry.gameMode), language: language))
                .font(.caption)
            if entry.isPro {
                Text("Pro")
                    .font(.caption2.bold())
                    .foregroundStyle(.orange)
                    .padding(.horizontal, 4)
                    .padding(.vertical, 1)
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(4)
            }
        }
        .foregroundStyle(.secondary)
    }
    
    private func achievementsForEntry(_ entry: HighscoreEntry) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(Achievement.all.filter { entry.achievementIDs.contains($0.id) }, id: \.id) { achievement in
                achievementBadge(achievement)
            }
        }
        .padding(.top, 4)
    }
    
    private func achievementBadge(_ achievement: Achievement) -> some View {
        HStack(spacing: 8) {
            Text(achievement.iconEmoji)
                .font(.system(size: 24))
                .frame(width: 32, alignment: .center)
            VStack(alignment: .leading, spacing: 2) {
                Text(L(achievement.nameKey, language: language))
                    .font(.caption.bold())
                Text(L(achievement.explanationKey, language: language))
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(8)
        .background(Color(.tertiarySystemBackground))
        .cornerRadius(8)
    }
    
    private var achievementsSheet: some View {
        NavigationStack {
            AchievementView_iOS(language: language, playerName: playerName, achievementStore: achievementStore)
                .navigationTitle(L("Achievements", language: language))
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button(L("Done", language: language)) {
                            showAchievements = false
                        }
                    }
                }
        }
    }
    
    private func enableGameCenter() {
        isEnablingGameCenter = true
        gameCenterManager.enable()
        // Reset the loading state after a brief delay to allow authentication UI to appear
        Task {
            try? await Task.sleep(for: .seconds(0.5))
            isEnablingGameCenter = false
        }
    }
    
    // Helper functions for game mode display
    private func gameModeIcon(for mode: String) -> String {
        switch mode {
        case "colors": return "paintpalette.fill"
        case "numbers": return "number.square.fill"
        case "shapes": return "star.square.fill"
        case "flags": return "flag.fill"
        case "emojis": return "face.smiling.fill"
        default: return "questionmark.circle"
        }
    }
    
    private func gameModeNameKey(for mode: String) -> String {
        switch mode {
        case "colors": return "ModeColors"
        case "numbers": return "ModeNumbers"
        case "shapes": return "ModeShapes"
        case "flags": return "ModeFlags"
        case "emojis": return "ModeEmojis"
        default: return "ModeColors"
        }
    }
}

// MARK: - SwiftUI GameKit Views

@available(iOS 14.0, *)
struct GameCenterLeaderboardView: UIViewControllerRepresentable {
    let leaderboardID: String
    
    func makeUIViewController(context: Context) -> UIViewController {
        if #available(iOS 26.0, *) {
            // For iOS 26+, return a placeholder that won't be used
            // In production, you should use the new GameKit SwiftUI APIs when they're available
            return UIViewController()
        } else {
            let viewController = GKGameCenterViewController(leaderboardID: leaderboardID, playerScope: .global, timeScope: .allTime)
            viewController.gameCenterDelegate = context.coordinator
            return viewController
        }
    }
    
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
        // No updates needed
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, GKGameCenterControllerDelegate {
        let parent: GameCenterLeaderboardView
        
        init(_ parent: GameCenterLeaderboardView) {
            self.parent = parent
        }
        
        func gameCenterViewControllerDidFinish(_ gameCenterViewController: GKGameCenterViewController) {
            gameCenterViewController.dismiss(animated: true)
        }
    }
}

@available(iOS 14.0, *)
struct GameCenterAchievementsView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UIViewController {
        if #available(iOS 26.0, *) {
            // For iOS 26+, return a placeholder that won't be used
            // In production, you should use the new GameKit SwiftUI APIs when they're available
            return UIViewController()
        } else {
            let viewController = GKGameCenterViewController(state: .achievements)
            viewController.gameCenterDelegate = context.coordinator
            return viewController
        }
    }
    
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
        // No updates needed
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, GKGameCenterControllerDelegate {
        let parent: GameCenterAchievementsView
        
        init(_ parent: GameCenterAchievementsView) {
            self.parent = parent
        }
        
        func gameCenterViewControllerDidFinish(_ gameCenterViewController: GKGameCenterViewController) {
            gameCenterViewController.dismiss(animated: true)
        }
    }
}


