//
//  FeedbackManager.swift
//  Timekiller
//
//  Created by Copilot on 23.12.25.
//

import SwiftUI
import AVFoundation
import OSLog

#if os(iOS)
import UIKit
import AudioToolbox
#endif

#if os(watchOS)
import WatchKit
#endif

// MARK: - Feedback Types

/// Different types of haptic and sound feedback used throughout the game.
///
/// Each type maps to platform-specific haptic patterns and sounds:
/// - **iOS**: Uses `UIFeedbackGenerator` and system sounds
/// - **watchOS**: Uses `WKInterfaceDevice` haptic patterns with built-in audio
enum FeedbackType {
    case correctTap    // Success haptic + pleasant "tink" sound
    case wrongTap      // Error haptic + subtle "tock" sound  
    case timeout       // Same as wrongTap (equivalent outcome)
    case timeWarning   // Warning haptic + alert sound at 3 seconds
    case levelComplete // Multi-part celebration sequence with fanfare
    case tileTap       // Light impact for UI interactions
    case gameStart     // Success haptic + begin sound
    case gameOver      // Error haptic + end sound
}

// MARK: - Sound Constants

#if os(iOS)
/// System sound identifiers for iOS audio feedback via Audio Services framework.
///
/// System sounds provide zero-latency playback, no additional assets, and familiar UI patterns.
/// Sounds respect the device mute switch and volume settings.
private enum SystemSound: UInt32 {
    case tink = 1054      // High-pitched success ping
    case tock = 1053      // Low subtle click for errors
    case alert = 1057     // Attention-grabbing warning
    case fanfare = 1025   // Multi-note celebration
    case tap = 1104       // Soft neutral tap
    case begin = 1110     // Rising start tone
    case end = 1111       // Falling conclusion tone
}
#endif

// MARK: - Timing Constants

/// Timing constants for multi-part haptic feedback sequences.
/// Delays are tuned for natural-feeling, rhythmic feedback patterns.
private enum HapticTiming {
    static let levelCompleteCelebrationDelay: TimeInterval = 0.15  // 150ms - spacing for level complete
    static let iOSDoubleTapDelay: TimeInterval = 0.1               // 100ms - iOS rapid double-tap
}

// MARK: - Feedback Manager

/// Manages haptic and sound feedback throughout the application.
///
/// Centralized singleton service providing consistent sensory feedback for game events.
/// Abstracts platform-specific APIs into a simple semantic interface.
///
/// **Platform Support:**
/// - iOS: UIFeedbackGenerator + AudioServices system sounds
/// - watchOS: WKInterfaceDevice haptic patterns (includes audio)
@Observable
class FeedbackManager {
    
    // MARK: - Singleton
    
    /// Shared singleton instance.
    static let shared = FeedbackManager()
    
    // MARK: - Settings
    
    /// Controls whether sound effects are played (default: true).
    var soundEnabled: Bool = true
    
    /// Controls whether haptic feedback is triggered (default: true).
    var hapticsEnabled: Bool = true
    
    // MARK: - Initialization
    
    /// Private initializer for singleton pattern. Configures audio session on iOS.
    private init() {
        #if os(iOS)
        setupAudioSession()
        #endif
    }
    
    // MARK: - Setup
    
    #if os(iOS)
    /// Configures iOS audio session with `.ambient` category for game sounds.
    /// This allows mixing with other audio and respects the mute switch.
    private func setupAudioSession() {
        do {
            // Configure audio session for ambient mixing
            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
            
            // Activate the audio session
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            // Log error but don't crash - app can function without sounds
            Logger.feedback.error("Audio session setup failed: \(error.localizedDescription, privacy: .public)")
        }
    }
    #endif
    
    // MARK: - Public API
    
    /// Triggers haptic and sound feedback for the specified event type.
    func trigger(_ type: FeedbackType) {
        // Trigger haptic feedback if enabled
        if hapticsEnabled {
            triggerHaptic(for: type)
        }
        
        // Trigger sound feedback if enabled
        if soundEnabled {
            triggerSound(for: type)
        }
    }
    
    // MARK: - Haptic Feedback
    
    /// Triggers platform-specific haptic feedback.
    /// - iOS: Uses UIFeedbackGenerator (notification, impact types)
    /// - watchOS: Uses WKInterfaceDevice haptic patterns
    private func triggerHaptic(for type: FeedbackType) {
        #if os(iOS)
        switch type {
        case .correctTap:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.success)
            
        case .wrongTap, .timeout:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.error)
            
        case .timeWarning:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.warning)
            
        case .levelComplete:
            // Multi-part: success → (100ms) → success → (150ms) → heavy impact
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.success)
            DispatchQueue.main.asyncAfter(deadline: .now() + HapticTiming.iOSDoubleTapDelay) { [generator] in
                generator.notificationOccurred(.success)
            }
            let heavyImpact = UIImpactFeedbackGenerator(style: .heavy)
            DispatchQueue.main.asyncAfter(deadline: .now() + HapticTiming.levelCompleteCelebrationDelay) { [heavyImpact] in
                heavyImpact.impactOccurred()
            }
            
        case .tileTap:
            let generator = UIImpactFeedbackGenerator(style: .light)
            generator.impactOccurred()

        case .gameStart:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.success)
        
        case .gameOver:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.error)
        }
        #elseif os(watchOS)
        switch type {
        case .correctTap:
            WKInterfaceDevice.current().play(.success)
            
        case .wrongTap, .timeout:
            WKInterfaceDevice.current().play(.failure)
            
        case .timeWarning:
            WKInterfaceDevice.current().play(.retry)
            
        case .levelComplete:
            // Multi-part celebration: success → (150ms) → success → (300ms) → click
            let device = WKInterfaceDevice.current()
            device.play(.success)
            DispatchQueue.main.asyncAfter(deadline: .now() + HapticTiming.levelCompleteCelebrationDelay) { [device] in
                device.play(.success)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + (HapticTiming.levelCompleteCelebrationDelay * 2)) { [device] in
                device.play(.click)
            }
            
        case .tileTap:
            WKInterfaceDevice.current().play(.click)

        case .gameStart:
            WKInterfaceDevice.current().play(.success)
        
        case .gameOver:
            WKInterfaceDevice.current().play(.failure)
        }
        #endif
    }
    
    // MARK: - Sound Feedback
    
    /// Triggers platform-specific sound feedback.
    /// - iOS: Plays system sounds via AudioServices
    /// - watchOS: No-op (haptics include built-in audio)
    private func triggerSound(for type: FeedbackType) {
        #if os(iOS)
        // Map feedback type to appropriate system sound ID
        let soundID: UInt32 = switch type {
        case .correctTap:
            SystemSound.tink.rawValue // Pleasant "tink" for correct answers
        case .wrongTap:
            SystemSound.tock.rawValue // Subtle "tock" for wrong answers
        case .timeout:
            SystemSound.tock.rawValue // Same sound as wrong answer (equivalent outcome)
        case .timeWarning:
            SystemSound.alert.rawValue // Alert sound for time warnings
        case .levelComplete:
            SystemSound.fanfare.rawValue // Celebratory fanfare
        case .tileTap:
            SystemSound.tap.rawValue // Light tap sound for UI
        case .gameStart:
            SystemSound.begin.rawValue // Start sound
        case .gameOver:
            SystemSound.end.rawValue // End sound
        }
        
        if type == .levelComplete {
            // Multi-part: fanfare → (150ms) → tink
            AudioServicesPlaySystemSound(SystemSound.fanfare.rawValue)
            DispatchQueue.main.asyncAfter(deadline: .now() + HapticTiming.levelCompleteCelebrationDelay) {
                AudioServicesPlaySystemSound(SystemSound.tink.rawValue)
            }
        } else {
            AudioServicesPlaySystemSound(soundID)
        }
        #elseif os(watchOS)
        // watchOS haptics include built-in audio - no separate sounds needed
        #endif
    }
}

