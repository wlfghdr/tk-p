//
//  GameItems.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation
import SwiftUI

// MARK: - Game Item Protocol

/// Base protocol for all game content items (colors, numbers, shapes, flags, emojis).
///
/// `GameItem` provides a common interface for all types of content that can appear
/// on game tiles. Each item must be:
/// - **Identifiable**: Has a unique UUID for SwiftUI list rendering
/// - **Equatable**: Can be compared for matching logic
/// - **Localizable**: Has a nameKey for displaying translated names
///
/// All game item types conform to this protocol, enabling uniform handling across
/// different game modes without type-specific branching.
///
/// ## Conforming Types
/// - `GameColor`: Color items for Colors mode
/// - `GameNumber`: Number items for Numbers mode
/// - `GameShape`: Shape items for Shapes mode
/// - `GameFlag`: Flag items for Flags mode
/// - `GameEmoji`: Emoji items for Emojis mode
protocol GameItem: Identifiable, Equatable {
    /// Unique identifier for this item (used by SwiftUI for list rendering)
    var id: UUID { get }
    
    /// Localization key for displaying the item's name in the user's language
    /// Example: "Red", "Number5", "ShapeCircle", "FlagUSA", "EmojiHeart"
    var nameKey: String { get }
}

// MARK: - Game Color Model

/// Represents a color item used in Colors game mode.
///
/// `GameColor` pairs a SwiftUI `Color` with a localization key for its name.
/// Players must match color names (text) with their corresponding color backgrounds.
///
/// ## Difficulty Levels
/// - **Standard Mode**: 10 colors (primary + secondary colors)
/// - **Pro Mode**: 16 colors (adds subtle variations like Violet, Tan, Silver)
///
/// ## Equality
/// Colors are compared by their `nameKey` rather than color values, ensuring
/// that two colors with the same name are considered equal even if their
/// exact RGB values differ slightly.
///
/// ## Example
/// ```swift
/// let redColor = GameColor(color: .red, nameKey: "Red")
/// let anotherRed = GameColor(color: .red, nameKey: "Red")
/// print(redColor == anotherRed) // true (compared by nameKey)
/// ```
struct GameColor: GameItem {
    /// Unique identifier for this color item
    let id = UUID()
    
    /// The SwiftUI Color to display as the tile background
    let color: Color
    
    /// Localization key for the color's name (e.g., "Red", "Blue", "Purple")
    let nameKey: String
    
    /// Compares colors by their name key rather than color values.
    ///
    /// This ensures that colors are matched based on their semantic meaning
    /// (what they're called) rather than exact RGB values.
    ///
    /// - Parameters:
    ///   - lhs: Left-hand side color
    ///   - rhs: Right-hand side color
    /// - Returns: `true` if both colors have the same nameKey
    static func == (lhs: GameColor, rhs: GameColor) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    /// Standard difficulty color set (10 colors).
    ///
    /// Includes familiar, easily distinguishable colors suitable for beginners:
    /// - Primary colors: Red, Blue, Yellow
    /// - Secondary colors: Green, Orange, Purple
    /// - Additional colors: Brown, Cyan, Pink, Indigo
    ///
    /// These colors have strong visual contrast and are universally recognizable.
    static let standardColors: [GameColor] = [
        GameColor(color: .red, nameKey: "Red"),
        GameColor(color: .blue, nameKey: "Blue"),
        GameColor(color: .green, nameKey: "Green"),
        GameColor(color: .yellow, nameKey: "Yellow"),
        GameColor(color: .orange, nameKey: "Orange"),
        GameColor(color: .purple, nameKey: "Purple"),
        GameColor(color: .brown, nameKey: "Brown"),
        GameColor(color: .cyan, nameKey: "Cyan"),
        GameColor(color: .pink, nameKey: "Pink"),
        GameColor(color: .indigo, nameKey: "Indigo")
    ]
    
    /// Pro difficulty color set (16 colors).
    ///
    /// Extends standard colors with additional challenging variations:
    /// - All 10 standard colors
    /// - Additional colors: Gray, Mint, Teal
    /// - Subtle variations: Violet (purple variant), Tan (brown variant), Silver (gray variant)
    ///
    /// The increased variety and similar colors make Pro mode significantly more challenging.
    /// Pro mode awards double points to reflect the higher difficulty.
    static let proColors: [GameColor] = [
        GameColor(color: .red, nameKey: "Red"),
        GameColor(color: .blue, nameKey: "Blue"),
        GameColor(color: .green, nameKey: "Green"),
        GameColor(color: .yellow, nameKey: "Yellow"),
        GameColor(color: .orange, nameKey: "Orange"),
        GameColor(color: .purple, nameKey: "Purple"),
        GameColor(color: .brown, nameKey: "Brown"),
        GameColor(color: .cyan, nameKey: "Cyan"),
        GameColor(color: .gray, nameKey: "Gray"),
        GameColor(color: .indigo, nameKey: "Indigo"),
        GameColor(color: .mint, nameKey: "Mint"),
        GameColor(color: .teal, nameKey: "Teal"),
        GameColor(color: Color(red: 1.0, green: 0.75, blue: 0.8), nameKey: "Pink"),
        GameColor(color: Color(red: 0.5, green: 0.0, blue: 0.5), nameKey: "Violet"),
        GameColor(color: Color(red: 0.6, green: 0.4, blue: 0.2), nameKey: "Tan"),
        GameColor(color: Color(red: 0.5, green: 0.5, blue: 0.5), nameKey: "Silver")
    ]
    
    /// Legacy property providing backward compatibility with older code.
    ///
    /// Originally, the app only had one color set. This property maintains
    /// compatibility with code that referenced `GameColor.allColors`.
    ///
    /// - Note: New code should use `standardColors` or `proColors` explicitly
    static let allColors: [GameColor] = standardColors
}

// MARK: - Game Emoji Model

/// Represents an emoji item used in Emojis game mode.
///
/// `GameEmoji` pairs an emoji character with a localization key for its name.
/// Players must match emoji names (text like "Heart" or "Dog") with their
/// corresponding emoji characters (❤️, 🐶).
///
/// ## Difficulty Levels
/// - **Standard Mode**: 20 popular, easily recognizable emojis
/// - **Pro Mode**: 100 diverse emojis across 7 categories
///
/// ## Categories (Pro Mode)
/// 1. **Faces & Emotions** (24 emojis) - Expression-based emojis
/// 2. **Creatures & Fantasy** (15 emojis) - Ghosts, robots, dragons, etc.
/// 3. **Animals** (16 emojis) - Real-world animals
/// 4. **Food & Drinks** (15 emojis) - Culinary items
/// 5. **Sports & Activities** (10 emojis) - Sports equipment and activities
/// 6. **Transportation & Travel** (10 emojis) - Vehicles and travel
/// 7. **Nature, Weather & Objects** (10+ emojis) - Natural and symbolic items
///
/// ## Example
/// ```swift
/// let heart = GameEmoji(emoji: "❤️", nameKey: "EmojiRedHeart")
/// // Player sees "Red Heart" text and must find the ❤️ emoji
/// ```
struct GameEmoji: GameItem {
    /// Unique identifier for this emoji item
    let id = UUID()
    
    /// The emoji character to display (e.g., "😀", "🎮", "❤️")
    let emoji: String
    
    /// Localization key for the emoji's name (e.g., "EmojiGrinning", "EmojiHeart")
    let nameKey: String
    
    /// Compares emojis by their name key rather than unicode values.
    ///
    /// This ensures semantic equality based on what the emoji represents,
    /// not its specific unicode encoding.
    ///
    /// - Parameters:
    ///   - lhs: Left-hand side emoji
    ///   - rhs: Right-hand side emoji
    /// - Returns: `true` if both emojis have the same nameKey
    static func == (lhs: GameEmoji, rhs: GameEmoji) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    /// Standard difficulty emoji set (20 emojis).
    ///
    /// Curated collection of the most popular and easily recognizable emojis
    /// that players will be familiar with. Perfect for beginners or casual play.
    ///
    /// Includes:
    /// - Common faces (😀, 😂, 😍, 😎, etc.)
    /// - Popular creatures (👻, 👽, 🤖)
    /// - Universal symbols (🔥, ⭐️, ❤️)
    /// - Beloved animals (🐶, 🐱)
    /// - Common objects (🍕, 🎮, 🚀)
    static let standardEmojis: [GameEmoji] = [
        GameEmoji(emoji: "😀", nameKey: "EmojiGrinning"),
        GameEmoji(emoji: "😂", nameKey: "EmojiLaughing"),
        GameEmoji(emoji: "😍", nameKey: "EmojiHeart"),
        GameEmoji(emoji: "🤔", nameKey: "EmojiThinking"),
        GameEmoji(emoji: "😎", nameKey: "EmojiCool"),
        GameEmoji(emoji: "🤯", nameKey: "EmojiMindBlown"),
        GameEmoji(emoji: "🥳", nameKey: "EmojiParty"),
        GameEmoji(emoji: "😴", nameKey: "EmojiSleepy"),
        GameEmoji(emoji: "👻", nameKey: "EmojiGhost"),
        GameEmoji(emoji: "👽", nameKey: "EmojiAlien"),
        GameEmoji(emoji: "🤖", nameKey: "EmojiRobot"),
        GameEmoji(emoji: "💩", nameKey: "EmojiPoop"),
        GameEmoji(emoji: "🔥", nameKey: "EmojiFire"),
        GameEmoji(emoji: "⭐️", nameKey: "EmojiStar"),
        GameEmoji(emoji: "❤️", nameKey: "EmojiRedHeart"),
        GameEmoji(emoji: "🐶", nameKey: "EmojiDog"),
        GameEmoji(emoji: "🐱", nameKey: "EmojiCat"),
        GameEmoji(emoji: "🍕", nameKey: "EmojiPizza"),
        GameEmoji(emoji: "🎮", nameKey: "EmojiGamepad"),
        GameEmoji(emoji: "🚀", nameKey: "EmojiRocket")
    ]
    
    /// Pro difficulty emoji set (100 emojis).
    ///
    /// Massive collection spanning 7 thematic categories, providing extreme variety
    /// and challenge. With 100 unique emojis to track, Pro mode tests memory,
    /// recognition speed, and concentration.
    ///
    /// ## Categories Breakdown
    /// - **Faces & Emotions** (24): Various facial expressions and emotional states
    /// - **Creatures & Fantasy** (15): Supernatural beings and mythical creatures
    /// - **Animals** (16): Diverse real-world animals from mammals to marine life
    /// - **Food & Drinks** (15): Culinary items from fruits to prepared dishes
    /// - **Sports & Activities** (10): Athletic equipment and competitive sports
    /// - **Transportation & Travel** (10): Vehicles from rockets to sailboats
    /// - **Nature, Weather & Objects** (10+): Natural phenomena and symbolic items
    ///
    /// This extensive set ensures that even experienced players face continuous challenge.
    static let proEmojis: [GameEmoji] = [
        // Faces & Emotions (24)
        GameEmoji(emoji: "😀", nameKey: "EmojiGrinning"),
        GameEmoji(emoji: "😂", nameKey: "EmojiLaughing"),
        GameEmoji(emoji: "😍", nameKey: "EmojiHeart"),
        GameEmoji(emoji: "🤔", nameKey: "EmojiThinking"),
        GameEmoji(emoji: "😎", nameKey: "EmojiCool"),
        GameEmoji(emoji: "🤯", nameKey: "EmojiMindBlown"),
        GameEmoji(emoji: "🥳", nameKey: "EmojiParty"),
        GameEmoji(emoji: "😴", nameKey: "EmojiSleepy"),
        GameEmoji(emoji: "🤑", nameKey: "EmojiMoney"),
        GameEmoji(emoji: "🤠", nameKey: "EmojiCowboy"),
        GameEmoji(emoji: "🤡", nameKey: "EmojiClown"),
        GameEmoji(emoji: "😇", nameKey: "EmojiAngel"),
        GameEmoji(emoji: "😈", nameKey: "EmojiDevil"),
        GameEmoji(emoji: "🥶", nameKey: "EmojiFreezing"),
        GameEmoji(emoji: "🥵", nameKey: "EmojiHot"),
        GameEmoji(emoji: "🤢", nameKey: "EmojiNauseated"),
        GameEmoji(emoji: "🤓", nameKey: "EmojiNerd"),
        GameEmoji(emoji: "🧐", nameKey: "EmojiMonocle"),
        GameEmoji(emoji: "😱", nameKey: "EmojiScreaming"),
        GameEmoji(emoji: "🤐", nameKey: "EmojiZipper"),
        GameEmoji(emoji: "🥺", nameKey: "EmojiPleading"),
        GameEmoji(emoji: "😭", nameKey: "EmojiCrying"),
        GameEmoji(emoji: "😤", nameKey: "EmojiSteam"),
        GameEmoji(emoji: "🤪", nameKey: "EmojiZany"),
        
        // Creatures & Fantasy (15)
        GameEmoji(emoji: "👻", nameKey: "EmojiGhost"),
        GameEmoji(emoji: "👽", nameKey: "EmojiAlien"),
        GameEmoji(emoji: "🤖", nameKey: "EmojiRobot"),
        GameEmoji(emoji: "🎃", nameKey: "EmojiPumpkin"),
        GameEmoji(emoji: "💀", nameKey: "EmojiSkull"),
        GameEmoji(emoji: "👹", nameKey: "EmojiOgre"),
        GameEmoji(emoji: "👺", nameKey: "EmojiGoblin"),
        GameEmoji(emoji: "🦄", nameKey: "EmojiUnicorn"),
        GameEmoji(emoji: "🐉", nameKey: "EmojiDragon"),
        GameEmoji(emoji: "🦖", nameKey: "EmojiDino"),
        GameEmoji(emoji: "🐙", nameKey: "EmojiOctopus"),
        GameEmoji(emoji: "🦑", nameKey: "EmojiSquid"),
        GameEmoji(emoji: "🦈", nameKey: "EmojiShark"),
        GameEmoji(emoji: "🐊", nameKey: "EmojiCrocodile"),
        GameEmoji(emoji: "🦎", nameKey: "EmojiLizard"),
        
        // Animals (16)
        GameEmoji(emoji: "🐶", nameKey: "EmojiDog"),
        GameEmoji(emoji: "🐱", nameKey: "EmojiCat"),
        GameEmoji(emoji: "🐭", nameKey: "EmojiMouse"),
        GameEmoji(emoji: "🐼", nameKey: "EmojiPanda"),
        GameEmoji(emoji: "🦁", nameKey: "EmojiLion"),
        GameEmoji(emoji: "🐯", nameKey: "EmojiTiger"),
        GameEmoji(emoji: "🐸", nameKey: "EmojiFrog"),
        GameEmoji(emoji: "🦊", nameKey: "EmojiFox"),
        GameEmoji(emoji: "🐵", nameKey: "EmojiMonkey"),
        GameEmoji(emoji: "🐔", nameKey: "EmojiChicken"),
        GameEmoji(emoji: "🐧", nameKey: "EmojiPenguin"),
        GameEmoji(emoji: "🦉", nameKey: "EmojiOwl"),
        GameEmoji(emoji: "🦅", nameKey: "EmojiEagle"),
        GameEmoji(emoji: "🐺", nameKey: "EmojiWolf"),
        GameEmoji(emoji: "🐻", nameKey: "EmojiBear"),
        GameEmoji(emoji: "🐨", nameKey: "EmojiKoala"),
        
        // Food & Drinks (15)
        GameEmoji(emoji: "🍕", nameKey: "EmojiPizza"),
        GameEmoji(emoji: "🍔", nameKey: "EmojiBurger"),
        GameEmoji(emoji: "🍎", nameKey: "EmojiApple"),
        GameEmoji(emoji: "🍌", nameKey: "EmojiBanana"),
        GameEmoji(emoji: "🍇", nameKey: "EmojiGrapes"),
        GameEmoji(emoji: "🍓", nameKey: "EmojiStrawberry"),
        GameEmoji(emoji: "🍉", nameKey: "EmojiWatermelon"),
        GameEmoji(emoji: "🍪", nameKey: "EmojiCookie"),
        GameEmoji(emoji: "🍰", nameKey: "EmojiCake"),
        GameEmoji(emoji: "🍩", nameKey: "EmojiDonut"),
        GameEmoji(emoji: "🍦", nameKey: "EmojiIceCream"),
        GameEmoji(emoji: "🌭", nameKey: "EmojiHotDog"),
        GameEmoji(emoji: "🌮", nameKey: "EmojiTaco"),
        GameEmoji(emoji: "🍣", nameKey: "EmojiSushi"),
        GameEmoji(emoji: "☕️", nameKey: "EmojiCoffee"),
        
        // Sports & Activities (10)
        GameEmoji(emoji: "⚽️", nameKey: "EmojiSoccer"),
        GameEmoji(emoji: "🏀", nameKey: "EmojiBasketball"),
        GameEmoji(emoji: "🏈", nameKey: "EmojiFootball"),
        GameEmoji(emoji: "⚾️", nameKey: "EmojiBaseball"),
        GameEmoji(emoji: "🎾", nameKey: "EmojiTennis"),
        GameEmoji(emoji: "🏐", nameKey: "EmojiVolleyball"),
        GameEmoji(emoji: "🎱", nameKey: "Emoji8Ball"),
        GameEmoji(emoji: "🏓", nameKey: "EmojiPingPong"),
        GameEmoji(emoji: "🥊", nameKey: "EmojiBoxing"),
        GameEmoji(emoji: "🎳", nameKey: "EmojiBowling"),
        
        // Transportation & Travel (10)
        GameEmoji(emoji: "🚀", nameKey: "EmojiRocket"),
        GameEmoji(emoji: "✈️", nameKey: "EmojiAirplane"),
        GameEmoji(emoji: "🚗", nameKey: "EmojiCar"),
        GameEmoji(emoji: "🚕", nameKey: "EmojiTaxi"),
        GameEmoji(emoji: "🚌", nameKey: "EmojiBus"),
        GameEmoji(emoji: "🚁", nameKey: "EmojiHelicopter"),
        GameEmoji(emoji: "🚂", nameKey: "EmojiTrain"),
        GameEmoji(emoji: "🛸", nameKey: "EmojiUFO"),
        GameEmoji(emoji: "🚢", nameKey: "EmojiShip"),
        GameEmoji(emoji: "⛵️", nameKey: "EmojiSailboat"),
        
        // Nature & Weather (10)
        GameEmoji(emoji: "🌸", nameKey: "EmojiCherryBlossom"),
        GameEmoji(emoji: "🌺", nameKey: "EmojiHibiscus"),
        GameEmoji(emoji: "🌻", nameKey: "EmojiSunflower"),
        GameEmoji(emoji: "🌹", nameKey: "EmojiRose"),
        GameEmoji(emoji: "🌲", nameKey: "EmojiTree"),
        GameEmoji(emoji: "🍁", nameKey: "EmojiMapleLeaf"),
        GameEmoji(emoji: "🌵", nameKey: "EmojiCactus"),
        GameEmoji(emoji: "☃️", nameKey: "EmojiSnowman"),
        GameEmoji(emoji: "🌊", nameKey: "EmojiWave"),
        GameEmoji(emoji: "⛱️", nameKey: "EmojiBeachUmbrella"),
        
        // Objects, Symbols & More (10)
        GameEmoji(emoji: "💩", nameKey: "EmojiPoop"),
        GameEmoji(emoji: "🔥", nameKey: "EmojiFire"),
        GameEmoji(emoji: "⭐️", nameKey: "EmojiStar"),
        GameEmoji(emoji: "💎", nameKey: "EmojiDiamond"),
        GameEmoji(emoji: "👑", nameKey: "EmojiCrown"),
        GameEmoji(emoji: "🎯", nameKey: "EmojiTarget"),
        GameEmoji(emoji: "🎮", nameKey: "EmojiGamepad"),
        GameEmoji(emoji: "🎲", nameKey: "EmojiDice"),
        GameEmoji(emoji: "🎪", nameKey: "EmojiTent"),
        GameEmoji(emoji: "🎉", nameKey: "EmojiConfetti"),
        GameEmoji(emoji: "⚡️", nameKey: "EmojiLightning"),
        GameEmoji(emoji: "💥", nameKey: "EmojiBoom"),
        GameEmoji(emoji: "💫", nameKey: "EmojiDizzy"),
        GameEmoji(emoji: "🌈", nameKey: "EmojiRainbow"),
        GameEmoji(emoji: "🌙", nameKey: "EmojiMoon"),
        GameEmoji(emoji: "☀️", nameKey: "EmojiSun"),
        GameEmoji(emoji: "❤️", nameKey: "EmojiRedHeart"),
        GameEmoji(emoji: "💚", nameKey: "EmojiGreenHeart"),
        GameEmoji(emoji: "💙", nameKey: "EmojiBlueHeart"),
        GameEmoji(emoji: "💜", nameKey: "EmojiPurpleHeart")
    ]
}

// MARK: - Game Shape Model

/// Represents a geometric shape item used in Shapes game mode.
///
/// `GameShape` pairs a Unicode shape character with a localization key for its name.
/// Players must match shape names (text like "Circle" or "Star") with their
/// corresponding geometric shapes (●, ★).
///
/// ## Difficulty Levels
/// - **Standard Mode**: 12 common, easily distinguishable shapes
/// - **Pro Mode**: 21 shapes including variations and outlines
///
/// ## Shape Variety
/// Shapes include:
/// - Basic geometry: Circle, Square, Triangle
/// - Card suits: Heart, Diamond, Spade, Club
/// - Polygons: Pentagon, Hexagon
/// - Directional variations: Triangle Up/Down/Left/Right
/// - Filled vs. Outlined: ● vs. ○, ★ vs. ☆
///
/// ## Example
/// ```swift
/// let circle = GameShape(shape: "●", nameKey: "ShapeCircle")
/// // Player sees "Circle" text and must find the ● shape
/// ```
struct GameShape: GameItem {
    /// Unique identifier for this shape item
    let id = UUID()
    
    /// Unicode character representing the shape (e.g., "●", "■", "▲", "★")
    let shape: String
    
    /// Localization key for the shape's name (e.g., "ShapeCircle", "ShapeStar")
    let nameKey: String
    
    /// Compares shapes by their name key rather than Unicode characters.
    ///
    /// This ensures semantic equality based on the shape's identity,
    /// not its specific Unicode representation.
    ///
    /// - Parameters:
    ///   - lhs: Left-hand side shape
    ///   - rhs: Right-hand side shape
    /// - Returns: `true` if both shapes have the same nameKey
    static func == (lhs: GameShape, rhs: GameShape) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    /// Standard difficulty shape set (12 shapes).
    ///
    /// Collection of well-known, visually distinct shapes that are easy to
    /// differentiate at a glance. Includes basic geometry, card suits, and polygons.
    ///
    /// Perfect for introducing players to shape recognition gameplay without
    /// overwhelming them with similar-looking variations.
    static let standardShapes: [GameShape] = [
        GameShape(shape: "●", nameKey: "ShapeCircle"),
        GameShape(shape: "■", nameKey: "ShapeSquare"),
        GameShape(shape: "▲", nameKey: "ShapeTriangle"),
        GameShape(shape: "★", nameKey: "ShapeStar"),
        GameShape(shape: "♦", nameKey: "ShapeDiamond"),
        GameShape(shape: "♥", nameKey: "ShapeHeart"),
        GameShape(shape: "⬟", nameKey: "ShapePentagon"),
        GameShape(shape: "⬢", nameKey: "ShapeHexagon"),
        GameShape(shape: "▼", nameKey: "ShapeTriangleDown"),
        GameShape(shape: "○", nameKey: "ShapeCircleOutline"),
        GameShape(shape: "♠", nameKey: "ShapeSpade"),
        GameShape(shape: "♣", nameKey: "ShapeClub")
    ]
    
    /// Pro difficulty shape set (21 shapes).
    ///
    /// Extended collection with additional variations and subtle differences:
    /// - All 12 standard shapes
    /// - Directional triangles (up, down, left, right)
    /// - Size variations (small vs. large squares)
    /// - Filled vs. outlined shapes (★ vs. ☆, ● vs. ○)
    /// - Additional symbols (Plus, Bullseye, Circled Star)
    ///
    /// The increased variety and similar-looking shapes (e.g., different triangle
    /// orientations) make Pro mode significantly more challenging, requiring
    /// careful attention to detail.
    static let proShapes: [GameShape] = [
        // Basic shapes
        GameShape(shape: "●", nameKey: "ShapeCircle"),
        GameShape(shape: "■", nameKey: "ShapeSquare"),
        GameShape(shape: "▲", nameKey: "ShapeTriangle"),
        GameShape(shape: "★", nameKey: "ShapeStar"),
        GameShape(shape: "♦", nameKey: "ShapeDiamond"),
        GameShape(shape: "♥", nameKey: "ShapeHeart"),
        GameShape(shape: "⬟", nameKey: "ShapePentagon"),
        GameShape(shape: "⬢", nameKey: "ShapeHexagon"),
        GameShape(shape: "▼", nameKey: "ShapeTriangleDown"),
        GameShape(shape: "○", nameKey: "ShapeCircleOutline"),
        
        // Additional pro shapes
        GameShape(shape: "◼", nameKey: "ShapeSquareSmall"),
        GameShape(shape: "▶", nameKey: "ShapeTriangleRight"),
        GameShape(shape: "◀", nameKey: "ShapeTriangleLeft"),
        GameShape(shape: "♠", nameKey: "ShapeSpade"),
        GameShape(shape: "♣", nameKey: "ShapeClub"),
        GameShape(shape: "☆", nameKey: "ShapeStarEmpty"),
        GameShape(shape: "✪", nameKey: "ShapeStarCircled"),
        GameShape(shape: "◉", nameKey: "ShapeBullseye"),
        GameShape(shape: "⬛", nameKey: "ShapeSquareLarge"),
        GameShape(shape: "⬜", nameKey: "ShapeSquareWhite"),
        GameShape(shape: "✚", nameKey: "ShapePlus")
    ]
}

// MARK: - Game Flag Model

/// Represents a country flag item used in Flags game mode.
///
/// `GameFlag` pairs a Unicode flag emoji with a localization key for the country name.
/// Players must match country names (text like "USA" or "Japan") with their
/// corresponding flag emojis (🇺🇸, 🇯🇵).
///
/// ## Difficulty Levels
/// - **Standard Mode**: 20 well-known countries from major regions
/// - **Pro Mode**: 60 countries with global coverage
///
/// ## Regional Coverage (Pro Mode)
/// - **Americas**: USA, Canada, Brazil, Mexico, Argentina, etc.
/// - **Europe**: UK, Germany, France, Spain, Italy, Scandinavia, Eastern Europe
/// - **Asia**: Japan, China, India, Korea, Southeast Asia
/// - **Oceania**: Australia, New Zealand
/// - **Africa**: South Africa, Egypt, Nigeria, Kenya
/// - **Middle East**: Israel, Turkey
///
/// Flags provide educational value while testing visual recognition skills,
/// as many flags share similar colors and patterns.
///
/// ## Example
/// ```swift
/// let usa = GameFlag(emoji: "🇺🇸", nameKey: "FlagUSA")
/// // Player sees "USA" text and must find the 🇺🇸 flag
/// ```
struct GameFlag: GameItem {
    /// Unique identifier for this flag item
    let id = UUID()
    
    /// Unicode flag emoji for the country (e.g., "🇺🇸", "🇯🇵", "🇬🇧")
    let emoji: String
    
    /// Localization key for the country name (e.g., "FlagUSA", "FlagJapan")
    let nameKey: String
    
    /// Compares flags by their name key rather than emoji unicode.
    ///
    /// This ensures semantic equality based on which country the flag represents,
    /// not its specific Unicode encoding.
    ///
    /// - Parameters:
    ///   - lhs: Left-hand side flag
    ///   - rhs: Right-hand side flag
    /// - Returns: `true` if both flags have the same nameKey
    static func == (lhs: GameFlag, rhs: GameFlag) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    /// Standard difficulty flag set (20 countries).
    ///
    /// Carefully selected collection of the world's most recognizable and
    /// politically significant countries, ensuring broad geographical representation:
    /// - Major Western powers (USA, UK, Germany, France)
    /// - Asian giants (China, Japan, India)
    /// - G7/G20 members
    /// - Countries with distinctive flag designs
    ///
    /// These flags are generally well-known and easier to distinguish, making
    /// them suitable for players new to the Flags mode.
    static let standardFlags: [GameFlag] = [
        GameFlag(emoji: "🇺🇸", nameKey: "FlagUSA"),
        GameFlag(emoji: "🇬🇧", nameKey: "FlagUK"),
        GameFlag(emoji: "🇩🇪", nameKey: "FlagGermany"),
        GameFlag(emoji: "🇫🇷", nameKey: "FlagFrance"),
        GameFlag(emoji: "🇪🇸", nameKey: "FlagSpain"),
        GameFlag(emoji: "🇮🇹", nameKey: "FlagItaly"),
        GameFlag(emoji: "🇯🇵", nameKey: "FlagJapan"),
        GameFlag(emoji: "🇨🇳", nameKey: "FlagChina"),
        GameFlag(emoji: "🇨🇦", nameKey: "FlagCanada"),
        GameFlag(emoji: "🇦🇺", nameKey: "FlagAustralia"),
        GameFlag(emoji: "🇧🇷", nameKey: "FlagBrazil"),
        GameFlag(emoji: "🇲🇽", nameKey: "FlagMexico"),
        GameFlag(emoji: "🇮🇳", nameKey: "FlagIndia"),
        GameFlag(emoji: "🇦🇹", nameKey: "FlagAustria"),
        GameFlag(emoji: "🇨🇭", nameKey: "FlagSwitzerland"),
        GameFlag(emoji: "🇳🇱", nameKey: "FlagNetherlands"),
        GameFlag(emoji: "🇸🇪", nameKey: "FlagSweden"),
        GameFlag(emoji: "🇰🇷", nameKey: "FlagSouthKorea"),
        GameFlag(emoji: "🇷🇺", nameKey: "FlagRussia"),
        GameFlag(emoji: "🇵🇹", nameKey: "FlagPortugal")
    ]
    
    /// Pro difficulty flag set (60 countries).
    ///
    /// Comprehensive global coverage with 60 countries across all continents,
    /// tripling the challenge of standard mode. Includes:
    ///
    /// **All 20 standard countries** plus 40 additional flags organized by region:
    ///
    /// - **European Countries** (15 additional):
    ///   Greece, Nordic countries, Eastern Europe, Balkans
    ///   Many European flags share similar horizontal tricolor patterns
    ///
    /// - **Americas** (10 additional):
    ///   South American countries (Argentina, Chile, Colombia, Peru, etc.)
    ///   Central American and Caribbean nations
    ///
    /// - **Asia & Oceania** (10 additional):
    ///   Southeast Asian nations (Thailand, Vietnam, Philippines, Indonesia, etc.)
    ///   South Asian countries (Pakistan, Bangladesh, Sri Lanka)
    ///   New Zealand
    ///
    /// - **Africa & Middle East** (5 additional):
    ///   Major African nations (South Africa, Egypt, Nigeria, Kenya)
    ///   Middle Eastern representation (Israel)
    ///
    /// The sheer variety and similar color schemes (many red-white-blue tricolors)
    /// create significant difficulty, testing both memory and pattern recognition.
    static let proFlags: [GameFlag] = [
        // Standard flags (20)
        GameFlag(emoji: "🇺🇸", nameKey: "FlagUSA"),
        GameFlag(emoji: "🇬🇧", nameKey: "FlagUK"),
        GameFlag(emoji: "🇩🇪", nameKey: "FlagGermany"),
        GameFlag(emoji: "🇫🇷", nameKey: "FlagFrance"),
        GameFlag(emoji: "🇪🇸", nameKey: "FlagSpain"),
        GameFlag(emoji: "🇮🇹", nameKey: "FlagItaly"),
        GameFlag(emoji: "🇯🇵", nameKey: "FlagJapan"),
        GameFlag(emoji: "🇨🇳", nameKey: "FlagChina"),
        GameFlag(emoji: "🇨🇦", nameKey: "FlagCanada"),
        GameFlag(emoji: "🇦🇺", nameKey: "FlagAustralia"),
        GameFlag(emoji: "🇧🇷", nameKey: "FlagBrazil"),
        GameFlag(emoji: "🇲🇽", nameKey: "FlagMexico"),
        GameFlag(emoji: "🇮🇳", nameKey: "FlagIndia"),
        GameFlag(emoji: "🇦🇹", nameKey: "FlagAustria"),
        GameFlag(emoji: "🇨🇭", nameKey: "FlagSwitzerland"),
        GameFlag(emoji: "🇳🇱", nameKey: "FlagNetherlands"),
        GameFlag(emoji: "🇸🇪", nameKey: "FlagSweden"),
        GameFlag(emoji: "🇰🇷", nameKey: "FlagSouthKorea"),
        GameFlag(emoji: "🇷🇺", nameKey: "FlagRussia"),
        GameFlag(emoji: "🇵🇹", nameKey: "FlagPortugal"),
        
        // European countries (15)
        GameFlag(emoji: "🇬🇷", nameKey: "FlagGreece"),
        GameFlag(emoji: "🇳🇴", nameKey: "FlagNorway"),
        GameFlag(emoji: "🇩🇰", nameKey: "FlagDenmark"),
        GameFlag(emoji: "🇫🇮", nameKey: "FlagFinland"),
        GameFlag(emoji: "🇵🇱", nameKey: "FlagPoland"),
        GameFlag(emoji: "🇹🇷", nameKey: "FlagTurkey"),
        GameFlag(emoji: "🇮🇪", nameKey: "FlagIreland"),
        GameFlag(emoji: "🇧🇪", nameKey: "FlagBelgium"),
        GameFlag(emoji: "🇨🇿", nameKey: "FlagCzechia"),
        GameFlag(emoji: "🇭🇺", nameKey: "FlagHungary"),
        GameFlag(emoji: "🇷🇴", nameKey: "FlagRomania"),
        GameFlag(emoji: "🇺🇦", nameKey: "FlagUkraine"),
        GameFlag(emoji: "🇭🇷", nameKey: "FlagCroatia"),
        GameFlag(emoji: "🇸🇰", nameKey: "FlagSlovakia"),
        GameFlag(emoji: "🇧🇬", nameKey: "FlagBulgaria"),
        
        // Americas (10)
        GameFlag(emoji: "🇦🇷", nameKey: "FlagArgentina"),
        GameFlag(emoji: "🇨🇱", nameKey: "FlagChile"),
        GameFlag(emoji: "🇨🇴", nameKey: "FlagColombia"),
        GameFlag(emoji: "🇵🇪", nameKey: "FlagPeru"),
        GameFlag(emoji: "🇻🇪", nameKey: "FlagVenezuela"),
        GameFlag(emoji: "🇪🇨", nameKey: "FlagEcuador"),
        GameFlag(emoji: "🇺🇾", nameKey: "FlagUruguay"),
        GameFlag(emoji: "🇨🇷", nameKey: "FlagCostaRica"),
        GameFlag(emoji: "🇨🇺", nameKey: "FlagCuba"),
        GameFlag(emoji: "🇵🇦", nameKey: "FlagPanama"),
        
        // Asia & Oceania (10)
        GameFlag(emoji: "🇹🇭", nameKey: "FlagThailand"),
        GameFlag(emoji: "🇻🇳", nameKey: "FlagVietnam"),
        GameFlag(emoji: "🇵🇭", nameKey: "FlagPhilippines"),
        GameFlag(emoji: "🇸🇬", nameKey: "FlagSingapore"),
        GameFlag(emoji: "🇲🇾", nameKey: "FlagMalaysia"),
        GameFlag(emoji: "🇮🇩", nameKey: "FlagIndonesia"),
        GameFlag(emoji: "🇳🇿", nameKey: "FlagNewZealand"),
        GameFlag(emoji: "🇵🇰", nameKey: "FlagPakistan"),
        GameFlag(emoji: "🇧🇩", nameKey: "FlagBangladesh"),
        GameFlag(emoji: "🇱🇰", nameKey: "FlagSriLanka"),
        
        // Africa & Middle East (5)
        GameFlag(emoji: "🇿🇦", nameKey: "FlagSouthAfrica"),
        GameFlag(emoji: "🇪🇬", nameKey: "FlagEgypt"),
        GameFlag(emoji: "🇳🇬", nameKey: "FlagNigeria"),
        GameFlag(emoji: "🇰🇪", nameKey: "FlagKenya"),
        GameFlag(emoji: "🇮🇱", nameKey: "FlagIsrael")
    ]
}

// MARK: - Game Number Model

/// Represents a number item used in Numbers game mode.
///
/// `GameNumber` pairs an integer value with a localization key for its name.
/// Players must match number words (text like "Five" or "Twenty") with their
/// corresponding numeric digits (5, 20).
///
/// ## Difficulty Levels
/// - **Standard Mode**: Numbers 0-12 (13 numbers total)
/// - **Pro Mode**: Numbers 0-99 (100 numbers total)
///
/// ## Design Philosophy
/// Numbers mode is designed to be:
/// - **Accessible**: Even beginners can recognize single/double digit numbers
/// - **Educational**: Reinforces number recognition and reading
/// - **Scalable**: Pro mode dramatically increases the mental challenge
///
/// Standard mode (0-12) keeps the cognitive load manageable with a small set
/// of familiar numbers. Pro mode (0-99) creates extreme difficulty by requiring
/// players to track and distinguish 100 different number combinations under
/// time pressure.
///
/// ## Example
/// ```swift
/// let five = GameNumber(value: 5, nameKey: "Number5")
/// // Player sees "Five" text and must find the "5" digit
/// ```
struct GameNumber: GameItem {
    /// Unique identifier for this number item
    let id = UUID()
    
    /// The numeric value to display (e.g., 0, 5, 42, 99)
    let value: Int
    
    /// Localization key for the number's word form (e.g., "Number0", "Number5", "Number99")
    let nameKey: String
    
    /// Compares numbers by their name key rather than numeric values.
    ///
    /// This ensures semantic equality based on the number's identity as a game item,
    /// maintaining consistency with other GameItem types.
    ///
    /// - Parameters:
    ///   - lhs: Left-hand side number
    ///   - rhs: Right-hand side number
    /// - Returns: `true` if both numbers have the same nameKey
    static func == (lhs: GameNumber, rhs: GameNumber) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    /// Standard difficulty number set (0-12, 13 numbers total).
    ///
    /// Includes:
    /// - Single digits: 0-9 (10 numbers)
    /// - Teen numbers: 10, 11, 12 (3 numbers)
    ///
    /// This range is familiar to all players and keeps the cognitive load
    /// manageable even at higher game speeds. The set is small enough that
    /// players can scan and identify numbers quickly.
    ///
    /// Numbers are generated programmatically to ensure consistency and
    /// maintainability.
    static let standardNumbers: [GameNumber] = {
        return (0...12).map { num in
            GameNumber(value: num, nameKey: "Number\(num)")
        }
    }()
    
    /// Pro difficulty number set (0-99, 100 numbers total).
    ///
    /// Complete range of two-digit numbers including:
    /// - Single digits: 0-9
    /// - Teens: 10-19
    /// - Tens: 20, 30, 40, etc.
    /// - All combinations: 21, 37, 58, 99, etc.
    ///
    /// With 100 unique numbers to track, Pro mode creates extreme cognitive
    /// challenge. Players must:
    /// - Rapidly scan large grids for specific numbers
    /// - Distinguish similar-looking numbers (68 vs 86, 17 vs 71)
    /// - Maintain focus under increasing time pressure
    ///
    /// This makes Numbers Pro mode one of the most demanding game modes,
    /// suitable only for experienced players seeking maximum challenge.
    ///
    /// Numbers are generated programmatically from 0 to 99.
    static let proNumbers: [GameNumber] = {
        return (0...99).map { num in
            GameNumber(value: num, nameKey: "Number\(num)")
        }
    }()
}
