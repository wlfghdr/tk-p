//
//  Localization.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation

// MARK: - Localization Helper

/// Retrieves a localized string for the specified key and language.
///
/// This is a simple dictionary-based localization function that maps string keys to
/// translations in multiple languages. It's used throughout the app to provide German
/// and English localizations.
///
/// The function uses a large dictionary containing translations for:
/// - Game UI elements (buttons, labels, etc.)
/// - Game modes and settings
/// - Color names
/// - Shape names
/// - Country flag names
/// - Number names (0-99 in words)
/// - Emoji names and descriptions
/// - Achievements and Game Center strings
/// - Donation/tip jar content
///
/// ## Usage Example
/// ```swift
/// // Get localized string in German (default)
/// let title = L("Title") // Returns "Timekiller"
///
/// // Get localized string in English
/// let title = L("Title", language: "en") // Returns "Timekiller"
/// ```
///
/// - Parameters:
///   - key: The localization key to look up
///   - language: The language code ("de" for German, "en" for English). Defaults to "de".
/// - Returns: The localized string if found, otherwise returns the key itself as a fallback
///
/// - Note: This function uses inline translations rather than string catalogs or .strings files.
///   For a production app at scale, consider migrating to Xcode's String Catalogs for better tooling.
func L(_ key: String, language: String = "de") -> String {
    /// Master dictionary containing all translations for the app.
    ///
    /// Structure: `[Key: [LanguageCode: Translation]]`
    /// - Keys are English identifiers used throughout the codebase
    /// - Each key maps to a dictionary of language codes ("de", "en")
    /// - Language codes map to the translated string
    ///
    /// The translations are organized into logical sections:
    /// - Game UI: Core interface elements
    /// - Settings: User preferences and configuration
    /// - Colors: Color names for the color matching game mode
    /// - Shapes: Shape names for the shape matching game mode  
    /// - Flags: Country names for flag matching game mode
    /// - Numbers: Number names (written form) for number mode
    /// - Emojis: Emoji descriptions for emoji matching mode
    /// - Achievements: All achievement names and descriptions
    /// - Game Center: Online leaderboard and connectivity strings
    /// - Donations: Tip jar and support messages
    let translations: [String: [String: String]] = [
        // Game UI
        "Title": ["de": "Timekiller", "en": "Timekiller"],
        "Start": ["de": "Start", "en": "Start"],
        "Pause": ["de": "Pause", "en": "Pause"],
        "Resume": ["de": "Weiter", "en": "Resume"],
        "Quit": ["de": "Ende", "en": "Quit"],
        "Settings": ["de": "Einstellungen", "en": "Settings"],
        "Highscores": ["de": "Highscores", "en": "Highscores"],
        "Score": ["de": "Punkte", "en": "Score"],
        "Level": ["de": "Level", "en": "Level"],
        "Round": ["de": "Runde", "en": "Round"],
        "TotalScore": ["de": "Gesamt", "en": "Total"],
        "LevelScore": ["de": "Level", "en": "Level"],
        "Done": ["de": "Fertig", "en": "Done"],
        "Tap": ["de": "Tippe auf", "en": "Tap"],
        "Continue": ["de": "Weiter", "en": "Next"],
        // Level Complete & Next Level Info
        "LevelComplete": ["de": "Abgeschlossen!", "en": "Complete!"],
        "ScorePerLevel": ["de": "Score pro Level", "en": "Score per Level"],
        "NextLevelPreview": ["de": "Nächstes Level", "en": "Next Level"],
        "NextLevelInfo_GridSize": ["de": "Größeres Spielfeld", "en": "Larger Grid"],
        "NextLevelInfo_MultipleAnswers": ["de": "Mehrere richtige Antworten finden", "en": "Find Multiple Correct Answers"],
        "NextLevelInfo_TimeReduction": ["de": "Zeit wird verkürzt", "en": "Time Reduced"],
        "NextLevelInfo_GridSize_2x2": ["de": "Spielfeld: 2×2 (4 Kacheln)", "en": "Grid: 2×2 (4 Tiles)"],
        "NextLevelInfo_GridSize_2x4": ["de": "Spielfeld: 2×4 (8 Kacheln)", "en": "Grid: 2×4 (8 Tiles)"],
        "NextLevelInfo_GridSize_3x5": ["de": "Spielfeld: 3×5 (15 Kacheln)", "en": "Grid: 3×5 (15 Tiles)"],
        "NextLevelInfo_KeepGoing": ["de": "Weiter so!", "en": "Keep Going!"],
        "NextLevelInfo_DoubleAnswers": ["de": "Finde 2 richtige Antworten", "en": "Find 2 Correct Answers"],
        "NextLevelInfo_TripleAnswers": ["de": "Finde 3 richtige Antworten", "en": "Find 3 Correct Answers"],
        "NextLevelInfo_QuadAnswers": ["de": "Finde 4 richtige Antworten", "en": "Find 4 Correct Answers"],
        "NextLevelInfo_MultipleCorrectAnswers": ["de": "Finde %d richtige Antworten", "en": "Find %d Correct Answers"],
        
        "Example": ["de": "Beispiel", "en": "Example"],
        "Theme": ["de": "Theme", "en": "Theme"],
        "ThemeSystem": ["de": "System", "en": "System"],
        "ThemeLight": ["de": "Hell", "en": "Light"],
        "ThemeDark": ["de": "Dunkel", "en": "Dark"],
        
        // Summary View
        "GameOver": ["de": "Spiel Beendet", "en": "Game Over"],
        "YourScore": ["de": "Deine Punktzahl", "en": "Your Score"],
        "ReachedLevel": ["de": "Erreichtes Level", "en": "Reached Level"],
        "Restart": ["de": "Neustart", "en": "Restart"],
        
        // Settings
        "PlayerName": ["de": "Spielername", "en": "Player Name"],
        "Language": ["de": "Sprache", "en": "Language"],
        "German": ["de": "Deutsch", "en": "German"],
        "English": ["de": "Englisch", "en": "English"],
        "GameMode": ["de": "Spielmodus", "en": "Game Mode"],
        "ProMode": ["de": "Pro-Modus", "en": "Pro Mode"],
        "PointsMultiplier": ["de": "Punkte", "en": "Points"],
        "Colors": ["de": "Farben", "en": "Colors"],
        "Numbers": ["de": "Zahlen", "en": "Numbers"],
        "Shapes": ["de": "Formen", "en": "Shapes"],
        "Emojis": ["de": "Emojis", "en": "Emojis"],
        
        // Sound & Haptics Settings
        "Sound": ["de": "Sound", "en": "Sound"],
        "Haptics": ["de": "Haptik", "en": "Haptics"],
        "Feedback": ["de": "Feedback", "en": "Feedback"],
        
        // Highscores
        "NoHighscores": ["de": "Keine Highscores", "en": "No Highscores"],
        "TopScores": ["de": "Top 3", "en": "Top 3"],
        "ClearAll": ["de": "Alle löschen", "en": "Clear All"],
        "Delete": ["de": "Löschen", "en": "Delete"],
        
        // Instructions
        "InstructionTitle": ["de": "Wie wird gespielt?", "en": "How to Play?"],
        "InstructionText": ["de": "Tippe auf die Kachel, deren Text zur richtigen Farbe passt!", "en": "Tap the tile whose text matches the correct color!"],
        "InstructionTextColors": ["de": "Tippe auf die Kachel, deren Text zur Hintergrundfarbe passt! Beispiel: Wenn \"Blau\" auf blauem Hintergrund steht, ist das richtig!", "en": "Tap the tile where the text matches the background color! Example: If \"Blue\" is on a blue background, that's correct!"],
        "InstructionTextShapes": ["de": "Tippe auf die Kachel, deren Text zur Form passt! Die Formen werden bei jedem Spiel neu gemischt.", "en": "Tap the tile where the text matches the shape! Shapes are randomized each game."],
        "InstructionTextFlags": ["de": "Tippe auf die Kachel, deren Text zur Flagge passt! Die Flaggen werden bei jedem Spiel neu gemischt.", "en": "Tap the tile where the text matches the flag! Flags are randomized each game."],
        "InstructionTextEmojis": ["de": "Tippe auf die Kachel, deren Text zum Emoji passt! Die Emojis werden bei jedem Spiel neu gemischt.", "en": "Tap the tile where the text matches the emoji! Emojis are randomized each game."],
        
        // Colors
        "Red": ["de": "Rot", "en": "Red"],
        "Blue": ["de": "Blau", "en": "Blue"],
        "Green": ["de": "Grün", "en": "Green"],
        "Yellow": ["de": "Gelb", "en": "Yellow"],
        "Orange": ["de": "Orange", "en": "Orange"],
        "Purple": ["de": "Lila", "en": "Purple"],
        "Brown": ["de": "Braun", "en": "Brown"],
        "Cyan": ["de": "Cyan", "en": "Cyan"],
        "Gray": ["de": "Grau", "en": "Gray"],
        "Indigo": ["de": "Indigo", "en": "Indigo"],
        "Mint": ["de": "Mint", "en": "Mint"],
        "Teal": ["de": "Türkis", "en": "Teal"],
        "Pink": ["de": "Rosa", "en": "Pink"],
        "Violet": ["de": "Violett", "en": "Violet"],
        "Tan": ["de": "Beige", "en": "Tan"],
        "Silver": ["de": "Silber", "en": "Silver"],
        
        // Shapes
        "ShapeCircle": ["de": "Kreis", "en": "Circle"],
        "ShapeSquare": ["de": "Quadrat", "en": "Square"],
        "ShapeTriangle": ["de": "Dreieck", "en": "Triangle"],
        "ShapeStar": ["de": "Stern", "en": "Star"],
        "ShapeDiamond": ["de": "Raute", "en": "Diamond"],
        "ShapeHeart": ["de": "Herz", "en": "Heart"],
        "ShapePentagon": ["de": "Fünfeck", "en": "Pentagon"],
        "ShapeHexagon": ["de": "Sechseck", "en": "Hexagon"],
        "ShapeTriangleDown": ["de": "Dreieck unten", "en": "Triangle Down"],
        "ShapeCircleOutline": ["de": "Kreis-Umriss", "en": "Circle Outline"],
        "ShapeSquareSmall": ["de": "Kleines Quadrat", "en": "Small Square"],
        "ShapeTriangleRight": ["de": "Dreieck rechts", "en": "Triangle Right"],
        "ShapeTriangleLeft": ["de": "Dreieck links", "en": "Triangle Left"],
        "ShapeSpade": ["de": "Pik", "en": "Spade"],
        "ShapeClub": ["de": "Kreuz", "en": "Club"],
        "ShapeStarEmpty": ["de": "Leerer Stern", "en": "Empty Star"],
        "ShapeStarCircled": ["de": "Stern im Kreis", "en": "Star Circled"],
        "ShapeBullseye": ["de": "Zielscheibe", "en": "Bullseye"],
        "ShapeSquareLarge": ["de": "Großes Quadrat", "en": "Large Square"],
        "ShapeSquareWhite": ["de": "Weißes Quadrat", "en": "White Square"],
        "ShapePlus": ["de": "Plus", "en": "Plus"],
        
        // Game Modes
        "ModeColors": ["de": "Farben", "en": "Colors"],
        "ModeNumbers": ["de": "Zahlen", "en": "Numbers"],
        "ModeShapes": ["de": "Formen", "en": "Shapes"],
        "ModeFlags": ["de": "Flaggen", "en": "Flags"],
        "ModeEmojis": ["de": "Emojis", "en": "Emojis"],
        
        // Country Flags
        "FlagUSA": ["de": "USA", "en": "USA"],
        "FlagUK": ["de": "Vereinigtes Königreich", "en": "United Kingdom"],
        "FlagGermany": ["de": "Deutschland", "en": "Germany"],
        "FlagFrance": ["de": "Frankreich", "en": "France"],
        "FlagSpain": ["de": "Spanien", "en": "Spain"],
        "FlagItaly": ["de": "Italien", "en": "Italy"],
        "FlagJapan": ["de": "Japan", "en": "Japan"],
        "FlagChina": ["de": "China", "en": "China"],
        "FlagCanada": ["de": "Kanada", "en": "Canada"],
        "FlagAustralia": ["de": "Australien", "en": "Australia"],
        "FlagBrazil": ["de": "Brasilien", "en": "Brazil"],
        "FlagMexico": ["de": "Mexiko", "en": "Mexico"],
        "FlagIndia": ["de": "Indien", "en": "India"],
        "FlagAustria": ["de": "Österreich", "en": "Austria"],
        "FlagSwitzerland": ["de": "Schweiz", "en": "Switzerland"],
        "FlagNetherlands": ["de": "Niederlande", "en": "Netherlands"],
        "FlagSweden": ["de": "Schweden", "en": "Sweden"],
        "FlagSouthKorea": ["de": "Südkorea", "en": "South Korea"],
        "FlagRussia": ["de": "Russland", "en": "Russia"],
        "FlagPortugal": ["de": "Portugal", "en": "Portugal"],
        "FlagGreece": ["de": "Griechenland", "en": "Greece"],
        "FlagNorway": ["de": "Norwegen", "en": "Norway"],
        "FlagDenmark": ["de": "Dänemark", "en": "Denmark"],
        "FlagFinland": ["de": "Finnland", "en": "Finland"],
        "FlagPoland": ["de": "Polen", "en": "Poland"],
        "FlagTurkey": ["de": "Türkei", "en": "Turkey"],
        "FlagArgentina": ["de": "Argentinien", "en": "Argentina"],
        "FlagChile": ["de": "Chile", "en": "Chile"],
        "FlagColombia": ["de": "Kolumbien", "en": "Colombia"],
        "FlagSouthAfrica": ["de": "Südafrika", "en": "South Africa"],
        "FlagEgypt": ["de": "Ägypten", "en": "Egypt"],
        "FlagNigeria": ["de": "Nigeria", "en": "Nigeria"],
        "FlagIndonesia": ["de": "Indonesien", "en": "Indonesia"],
        "FlagThailand": ["de": "Thailand", "en": "Thailand"],
        "FlagVietnam": ["de": "Vietnam", "en": "Vietnam"],
        "FlagPhilippines": ["de": "Philippinen", "en": "Philippines"],
        "FlagSingapore": ["de": "Singapur", "en": "Singapore"],
        "FlagMalaysia": ["de": "Malaysia", "en": "Malaysia"],
        "FlagIreland": ["de": "Irland", "en": "Ireland"],
        "FlagBelgium": ["de": "Belgien", "en": "Belgium"],
        "FlagCzechia": ["de": "Tschechien", "en": "Czechia"],
        "FlagHungary": ["de": "Ungarn", "en": "Hungary"],
        "FlagRomania": ["de": "Rumänien", "en": "Romania"],
        "FlagUkraine": ["de": "Ukraine", "en": "Ukraine"],
        "FlagNewZealand": ["de": "Neuseeland", "en": "New Zealand"],
        "FlagCroatia": ["de": "Kroatien", "en": "Croatia"],
        "FlagSlovakia": ["de": "Slowakei", "en": "Slovakia"],
        "FlagBulgaria": ["de": "Bulgarien", "en": "Bulgaria"],
        "FlagPeru": ["de": "Peru", "en": "Peru"],
        "FlagVenezuela": ["de": "Venezuela", "en": "Venezuela"],
        "FlagEcuador": ["de": "Ecuador", "en": "Ecuador"],
        "FlagUruguay": ["de": "Uruguay", "en": "Uruguay"],
        "FlagCostaRica": ["de": "Costa Rica", "en": "Costa Rica"],
        "FlagCuba": ["de": "Kuba", "en": "Cuba"],
        "FlagPanama": ["de": "Panama", "en": "Panama"],
        "FlagPakistan": ["de": "Pakistan", "en": "Pakistan"],
        "FlagBangladesh": ["de": "Bangladesch", "en": "Bangladesh"],
        "FlagSriLanka": ["de": "Sri Lanka", "en": "Sri Lanka"],
        "FlagKenya": ["de": "Kenia", "en": "Kenya"],
        "FlagIsrael": ["de": "Israel", "en": "Israel"],
        
        // Numbers (0-99)
        "Number0": ["de": "null", "en": "zero"],
        "Number1": ["de": "eins", "en": "one"],
        "Number2": ["de": "zwei", "en": "two"],
        "Number3": ["de": "drei", "en": "three"],
        "Number4": ["de": "vier", "en": "four"],
        "Number5": ["de": "fünf", "en": "five"],
        "Number6": ["de": "sechs", "en": "six"],
        "Number7": ["de": "sieben", "en": "seven"],
        "Number8": ["de": "acht", "en": "eight"],
        "Number9": ["de": "neun", "en": "nine"],
        "Number10": ["de": "zehn", "en": "ten"],
        "Number11": ["de": "elf", "en": "eleven"],
        "Number12": ["de": "zwölf", "en": "twelve"],
        "Number13": ["de": "dreizehn", "en": "thirteen"],
        "Number14": ["de": "vierzehn", "en": "fourteen"],
        "Number15": ["de": "fünfzehn", "en": "fifteen"],
        "Number16": ["de": "sechzehn", "en": "sixteen"],
        "Number17": ["de": "siebzehn", "en": "seventeen"],
        "Number18": ["de": "achtzehn", "en": "eighteen"],
        "Number19": ["de": "neunzehn", "en": "nineteen"],
        "Number20": ["de": "zwanzig", "en": "twenty"],
        "Number21": ["de": "einundzwanzig", "en": "twenty-one"],
        "Number22": ["de": "zweiundzwanzig", "en": "twenty-two"],
        "Number23": ["de": "dreiundzwanzig", "en": "twenty-three"],
        "Number24": ["de": "vierundzwanzig", "en": "twenty-four"],
        "Number25": ["de": "fünfundzwanzig", "en": "twenty-five"],
        "Number26": ["de": "sechsundzwanzig", "en": "twenty-six"],
        "Number27": ["de": "siebenundzwanzig", "en": "twenty-seven"],
        "Number28": ["de": "achtundzwanzig", "en": "twenty-eight"],
        "Number29": ["de": "neunundzwanzig", "en": "twenty-nine"],
        "Number30": ["de": "dreißig", "en": "thirty"],
        "Number31": ["de": "einunddreißig", "en": "thirty-one"],
        "Number32": ["de": "zweiunddreißig", "en": "thirty-two"],
        "Number33": ["de": "dreiunddreißig", "en": "thirty-three"],
        "Number34": ["de": "vierunddreißig", "en": "thirty-four"],
        "Number35": ["de": "fünfunddreißig", "en": "thirty-five"],
        "Number36": ["de": "sechsunddreißig", "en": "thirty-six"],
        "Number37": ["de": "siebenunddreißig", "en": "thirty-seven"],
        "Number38": ["de": "achtunddreißig", "en": "thirty-eight"],
        "Number39": ["de": "neununddreißig", "en": "thirty-nine"],
        "Number40": ["de": "vierzig", "en": "forty"],
        "Number41": ["de": "einundvierzig", "en": "forty-one"],
        "Number42": ["de": "zweiundvierzig", "en": "forty-two"],
        "Number43": ["de": "dreiundvierzig", "en": "forty-three"],
        "Number44": ["de": "vierundvierzig", "en": "forty-four"],
        "Number45": ["de": "fünfundvierzig", "en": "forty-five"],
        "Number46": ["de": "sechsundvierzig", "en": "forty-six"],
        "Number47": ["de": "siebenundvierzig", "en": "forty-seven"],
        "Number48": ["de": "achtundvierzig", "en": "forty-eight"],
        "Number49": ["de": "neunundvierzig", "en": "forty-nine"],
        "Number50": ["de": "fünfzig", "en": "fifty"],
        "Number51": ["de": "einundfünfzig", "en": "fifty-one"],
        "Number52": ["de": "zweiundfünfzig", "en": "fifty-two"],
        "Number53": ["de": "dreiundfünfzig", "en": "fifty-three"],
        "Number54": ["de": "vierundfünfzig", "en": "fifty-four"],
        "Number55": ["de": "fünfundfünfzig", "en": "fifty-five"],
        "Number56": ["de": "sechsundfünfzig", "en": "fifty-six"],
        "Number57": ["de": "siebenundfünfzig", "en": "fifty-seven"],
        "Number58": ["de": "achtundfünfzig", "en": "fifty-eight"],
        "Number59": ["de": "neunundfünfzig", "en": "fifty-nine"],
        "Number60": ["de": "sechzig", "en": "sixty"],
        "Number61": ["de": "einundsechzig", "en": "sixty-one"],
        "Number62": ["de": "zweiundsechzig", "en": "sixty-two"],
        "Number63": ["de": "dreiundsechzig", "en": "sixty-three"],
        "Number64": ["de": "vierundsechzig", "en": "sixty-four"],
        "Number65": ["de": "fünfundsechzig", "en": "sixty-five"],
        "Number66": ["de": "sechsundsechzig", "en": "sixty-six"],
        "Number67": ["de": "siebenundsechzig", "en": "sixty-seven"],
        "Number68": ["de": "achtundsechzig", "en": "sixty-eight"],
        "Number69": ["de": "neunundsechzig", "en": "sixty-nine"],
        "Number70": ["de": "siebzig", "en": "seventy"],
        "Number71": ["de": "einundsiebzig", "en": "seventy-one"],
        "Number72": ["de": "zweiundsiebzig", "en": "seventy-two"],
        "Number73": ["de": "dreiundsiebzig", "en": "seventy-three"],
        "Number74": ["de": "vierundsiebzig", "en": "seventy-four"],
        "Number75": ["de": "fünfundsiebzig", "en": "seventy-five"],
        "Number76": ["de": "sechsundsiebzig", "en": "seventy-six"],
        "Number77": ["de": "siebenundsiebzig", "en": "seventy-seven"],
        "Number78": ["de": "achtundsiebzig", "en": "seventy-eight"],
        "Number79": ["de": "neunundsiebzig", "en": "seventy-nine"],
        "Number80": ["de": "achtzig", "en": "eighty"],
        "Number81": ["de": "einundachtzig", "en": "eighty-one"],
        "Number82": ["de": "zweiundachtzig", "en": "eighty-two"],
        "Number83": ["de": "dreiundachtzig", "en": "eighty-three"],
        "Number84": ["de": "vierundachtzig", "en": "eighty-four"],
        "Number85": ["de": "fünfundachtzig", "en": "eighty-five"],
        "Number86": ["de": "sechsundachtzig", "en": "eighty-six"],
        "Number87": ["de": "siebenundachtzig", "en": "eighty-seven"],
        "Number88": ["de": "achtundachtzig", "en": "eighty-eight"],
        "Number89": ["de": "neunundachtzig", "en": "eighty-nine"],
        "Number90": ["de": "neunzig", "en": "ninety"],
        "Number91": ["de": "einundneunzig", "en": "ninety-one"],
        "Number92": ["de": "zweiundneunzig", "en": "ninety-two"],
        "Number93": ["de": "dreiundneunzig", "en": "ninety-three"],
        "Number94": ["de": "vierundneunzig", "en": "ninety-four"],
        "Number95": ["de": "fünfundneunzig", "en": "ninety-five"],
        "Number96": ["de": "sechsundneunzig", "en": "ninety-six"],
        "Number97": ["de": "siebenundneunzig", "en": "ninety-seven"],
        "Number98": ["de": "achtundneunzig", "en": "ninety-eight"],
        "Number99": ["de": "neunundneunzig", "en": "ninety-nine"],
        
        // Emojis - Faces & Emotions
        "EmojiGrinning": ["de": "Grinsend", "en": "Grinning"],
        "EmojiLaughing": ["de": "Lachend", "en": "Laughing"],
        "EmojiHeart": ["de": "Herzaugen", "en": "Heart Eyes"],
        "EmojiThinking": ["de": "Denkend", "en": "Thinking"],
        "EmojiCool": ["de": "Cool", "en": "Cool"],
        "EmojiMindBlown": ["de": "Kopfexplosion", "en": "Mind Blown"],
        "EmojiParty": ["de": "Party", "en": "Party"],
        "EmojiSleepy": ["de": "Schlafend", "en": "Sleepy"],
        "EmojiMoney": ["de": "Geld", "en": "Money"],
        "EmojiCowboy": ["de": "Cowboy", "en": "Cowboy"],
        "EmojiClown": ["de": "Clown", "en": "Clown"],
        "EmojiAngel": ["de": "Engel", "en": "Angel"],
        "EmojiDevil": ["de": "Teufel", "en": "Devil"],
        "EmojiFreezing": ["de": "Frierend", "en": "Freezing"],
        "EmojiHot": ["de": "Heiß", "en": "Hot"],
        "EmojiNauseated": ["de": "Übel", "en": "Nauseated"],
        "EmojiNerd": ["de": "Nerd", "en": "Nerd"],
        "EmojiMonocle": ["de": "Monokel", "en": "Monocle"],
        "EmojiScreaming": ["de": "Schreiend", "en": "Screaming"],
        "EmojiZipper": ["de": "Reißverschluss", "en": "Zipper"],
        "EmojiPleading": ["de": "Flehend", "en": "Pleading"],
        "EmojiCrying": ["de": "Weinend", "en": "Crying"],
        "EmojiSteam": ["de": "Dampf aus Nase", "en": "Steam from Nose"],
        "EmojiZany": ["de": "Verrückt", "en": "Zany"],
        
        // Emojis - Creatures & Fantasy
        "EmojiGhost": ["de": "Geist", "en": "Ghost"],
        "EmojiAlien": ["de": "Alien", "en": "Alien"],
        "EmojiRobot": ["de": "Roboter", "en": "Robot"],
        "EmojiPumpkin": ["de": "Kürbis", "en": "Pumpkin"],
        "EmojiSkull": ["de": "Totenkopf", "en": "Skull"],
        "EmojiOgre": ["de": "Oger", "en": "Ogre"],
        "EmojiGoblin": ["de": "Goblin", "en": "Goblin"],
        "EmojiUnicorn": ["de": "Einhorn", "en": "Unicorn"],
        "EmojiDragon": ["de": "Drache", "en": "Dragon"],
        "EmojiDino": ["de": "Dino", "en": "Dino"],
        "EmojiOctopus": ["de": "Oktopus", "en": "Octopus"],
        "EmojiSquid": ["de": "Tintenfisch", "en": "Squid"],
        "EmojiShark": ["de": "Hai", "en": "Shark"],
        "EmojiCrocodile": ["de": "Krokodil", "en": "Crocodile"],
        "EmojiLizard": ["de": "Eidechse", "en": "Lizard"],
        
        // Emojis - Animals
        "EmojiDog": ["de": "Hund", "en": "Dog"],
        "EmojiCat": ["de": "Katze", "en": "Cat"],
        "EmojiMouse": ["de": "Maus", "en": "Mouse"],
        "EmojiPanda": ["de": "Panda", "en": "Panda"],
        "EmojiLion": ["de": "Löwe", "en": "Lion"],
        "EmojiTiger": ["de": "Tiger", "en": "Tiger"],
        "EmojiFrog": ["de": "Frosch", "en": "Frog"],
        "EmojiFox": ["de": "Fuchs", "en": "Fox"],
        "EmojiMonkey": ["de": "Affe", "en": "Monkey"],
        "EmojiChicken": ["de": "Huhn", "en": "Chicken"],
        "EmojiPenguin": ["de": "Pinguin", "en": "Penguin"],
        "EmojiOwl": ["de": "Eule", "en": "Owl"],
        "EmojiEagle": ["de": "Adler", "en": "Eagle"],
        "EmojiWolf": ["de": "Wolf", "en": "Wolf"],
        "EmojiBear": ["de": "Bär", "en": "Bear"],
        "EmojiKoala": ["de": "Koala", "en": "Koala"],
        
        // Emojis - Objects & Symbols
        "EmojiPoop": ["de": "Kackhaufen", "en": "Poop"],
        "EmojiFire": ["de": "Feuer", "en": "Fire"],
        "EmojiStar": ["de": "Stern", "en": "Star"],
        "EmojiDiamond": ["de": "Diamant", "en": "Diamond"],
        "EmojiCrown": ["de": "Krone", "en": "Crown"],
        "EmojiTarget": ["de": "Zielscheibe", "en": "Target"],
        "EmojiGamepad": ["de": "Controller", "en": "Gamepad"],
        "EmojiDice": ["de": "Würfel", "en": "Dice"],
        "EmojiTent": ["de": "Zirkuszelt", "en": "Circus Tent"],
        "EmojiRocket": ["de": "Rakete", "en": "Rocket"],
        "EmojiLightning": ["de": "Blitz", "en": "Lightning"],
        "EmojiBoom": ["de": "Knall", "en": "Boom"],
        "EmojiDizzy": ["de": "Schwindelig", "en": "Dizzy"],
        "EmojiRainbow": ["de": "Regenbogen", "en": "Rainbow"],
        "EmojiMoon": ["de": "Mond", "en": "Moon"],
        "EmojiSun": ["de": "Sonne", "en": "Sun"],
        "EmojiPizza": ["de": "Pizza", "en": "Pizza"],
        "EmojiBurger": ["de": "Burger", "en": "Burger"],
        "EmojiConfetti": ["de": "Konfetti", "en": "Confetti"],
        "EmojiRedHeart": ["de": "Rotes Herz", "en": "Red Heart"],
        "EmojiGreenHeart": ["de": "Grünes Herz", "en": "Green Heart"],
        "EmojiBlueHeart": ["de": "Blaues Herz", "en": "Blue Heart"],
        "EmojiPurpleHeart": ["de": "Lila Herz", "en": "Purple Heart"],
        
        // Emojis - Food & Drinks
        "EmojiApple": ["de": "Apfel", "en": "Apple"],
        "EmojiBanana": ["de": "Banane", "en": "Banana"],
        "EmojiGrapes": ["de": "Trauben", "en": "Grapes"],
        "EmojiStrawberry": ["de": "Erdbeere", "en": "Strawberry"],
        "EmojiWatermelon": ["de": "Wassermelone", "en": "Watermelon"],
        "EmojiCookie": ["de": "Keks", "en": "Cookie"],
        "EmojiCake": ["de": "Kuchen", "en": "Cake"],
        "EmojiDonut": ["de": "Donut", "en": "Donut"],
        "EmojiIceCream": ["de": "Eis", "en": "Ice Cream"],
        "EmojiHotDog": ["de": "Hot Dog", "en": "Hot Dog"],
        "EmojiTaco": ["de": "Taco", "en": "Taco"],
        "EmojiSushi": ["de": "Sushi", "en": "Sushi"],
        "EmojiCoffee": ["de": "Kaffee", "en": "Coffee"],
        
        // Emojis - Sports & Activities
        "EmojiSoccer": ["de": "Fußball", "en": "Soccer"],
        "EmojiBasketball": ["de": "Basketball", "en": "Basketball"],
        "EmojiFootball": ["de": "Football", "en": "Football"],
        "EmojiBaseball": ["de": "Baseball", "en": "Baseball"],
        "EmojiTennis": ["de": "Tennis", "en": "Tennis"],
        "EmojiVolleyball": ["de": "Volleyball", "en": "Volleyball"],
        "Emoji8Ball": ["de": "Billard", "en": "8 Ball"],
        "EmojiPingPong": ["de": "Tischtennis", "en": "Ping Pong"],
        "EmojiBoxing": ["de": "Boxen", "en": "Boxing"],
        "EmojiBowling": ["de": "Bowling", "en": "Bowling"],
        
        // Emojis - Transportation & Travel
        "EmojiAirplane": ["de": "Flugzeug", "en": "Airplane"],
        "EmojiCar": ["de": "Auto", "en": "Car"],
        "EmojiTaxi": ["de": "Taxi", "en": "Taxi"],
        "EmojiBus": ["de": "Bus", "en": "Bus"],
        "EmojiHelicopter": ["de": "Hubschrauber", "en": "Helicopter"],
        "EmojiTrain": ["de": "Zug", "en": "Train"],
        "EmojiUFO": ["de": "UFO", "en": "UFO"],
        "EmojiShip": ["de": "Schiff", "en": "Ship"],
        "EmojiSailboat": ["de": "Segelboot", "en": "Sailboat"],
        
        // Emojis - Nature & Weather
        "EmojiCherryBlossom": ["de": "Kirschblüte", "en": "Cherry Blossom"],
        "EmojiHibiscus": ["de": "Hibiskus", "en": "Hibiscus"],
        "EmojiSunflower": ["de": "Sonnenblume", "en": "Sunflower"],
        "EmojiRose": ["de": "Rose", "en": "Rose"],
        "EmojiTree": ["de": "Baum", "en": "Tree"],
        "EmojiMapleLeaf": ["de": "Ahornblatt", "en": "Maple Leaf"],
        "EmojiCactus": ["de": "Kaktus", "en": "Cactus"],
        "EmojiSnowman": ["de": "Schneemann", "en": "Snowman"],
        "EmojiWave": ["de": "Welle", "en": "Wave"],
        "EmojiBeachUmbrella": ["de": "Sonnenschirm", "en": "Beach Umbrella"],
        
        // Achievements - NEW SYSTEM (18 Achievements)
        // Early Achievements (3) - Level 5
        "AchievementColorCadet": ["de": "Farb-Kadett", "en": "Color Cadet"],
        "AchievementColorCadetExplanation": ["de": "Erreiche Level 5 in Farben Standard", "en": "Reach Level 5 in Colors Standard"],
        "AchievementShapeNovice": ["de": "Form-Anfänger", "en": "Shape Novice"],
        "AchievementShapeNoviceExplanation": ["de": "Erreiche Level 5 in Formen Standard", "en": "Reach Level 5 in Shapes Standard"],
        "AchievementEmojiApprentice": ["de": "Emoji-Lehrling", "en": "Emoji Apprentice"],
        "AchievementEmojiApprenticeExplanation": ["de": "Erreiche Level 5 in Emojis Standard", "en": "Reach Level 5 in Emojis Standard"],
        
        // Unlocking Achievements (4)
        "AchievementPolygonProdigy": ["de": "Polygon-Profi", "en": "Polygon Prodigy"],
        "AchievementPolygonProdigyExplanation": ["de": "Erreiche Level 10 in Farben Standard – Schaltet Formen-Modus frei", "en": "Reach Level 10 in Colors Standard – Unlocks Shapes Mode"],
        "AchievementFlagDropper": ["de": "Flag Dropper", "en": "Flag Dropper"],
        "AchievementFlagDropperExplanation": ["de": "Erreiche Level 15 in Farben Standard – Schaltet Flaggen-Modus frei", "en": "Reach Level 15 in Colors Standard – Unlocks Flags Mode"],
        "AchievementSmileySummoner": ["de": "Smiley-Beschwörer", "en": "Smiley Summoner"],
        "AchievementSmileySummonerExplanation": ["de": "Erreiche Level 20 in Farben Standard – Schaltet Emoji-Modus frei", "en": "Reach Level 20 in Colors Standard – Unlocks Emoji Mode"],
        "AchievementUltraInstinct": ["de": "Ultra Instinkt", "en": "Ultra Instinct"],
        "AchievementUltraInstinctExplanation": ["de": "Erreiche Level 30 in einem Standard-Modus – Schaltet Pro-Modus frei", "en": "Reach Level 30 in any Standard Mode – Unlocks Pro Mode"],
        
        // Intermediate Achievements (3 - Level 15)
        "AchievementRainbowWrangler": ["de": "Regenbogen-Bändiger", "en": "Rainbow Wrangler"],
        "AchievementRainbowWranglerExplanation": ["de": "Erreiche Level 15 in Farben Standard", "en": "Reach Level 15 in Colors Standard"],
        "AchievementTriangleTamer": ["de": "Dreieck-Zähmer", "en": "Triangle Tamer"],
        "AchievementTriangleTamerExplanation": ["de": "Erreiche Level 15 in Formen Standard", "en": "Reach Level 15 in Shapes Standard"],
        "AchievementEmojiEnthusiast": ["de": "Emoji-Enthusiast", "en": "Emoji Enthusiast"],
        "AchievementEmojiEnthusiastExplanation": ["de": "Erreiche Level 15 in Emojis Standard", "en": "Reach Level 15 in Emojis Standard"],
        
        // Advanced Achievements (3 - Level 25)
        "AchievementColorVirtuoso": ["de": "Farb-Virtuose", "en": "Color Virtuoso"],
        "AchievementColorVirtuosoExplanation": ["de": "Erreiche Level 25 in Farben Standard", "en": "Reach Level 25 in Colors Standard"],
        "AchievementShapeMaster": ["de": "Form-Meister", "en": "Shape Master"],
        "AchievementShapeMasterExplanation": ["de": "Erreiche Level 25 in Formen Standard", "en": "Reach Level 25 in Shapes Standard"],
        "AchievementEmojiExpert": ["de": "Emoji-Experte", "en": "Emoji Expert"],
        "AchievementEmojiExpertExplanation": ["de": "Erreiche Level 25 in Emojis Standard", "en": "Reach Level 25 in Emojis Standard"],
        
        // Numbers Achievements (2)
        "AchievementCountOnMe": ["de": "Auf mich zählen", "en": "Count on Me"],
        "AchievementCountOnMeExplanation": ["de": "Erreiche Level 10 in Zahlen Standard", "en": "Reach Level 10 in Numbers Standard"],
        "AchievementNumberCruncher": ["de": "Zahlenfresser", "en": "Number Cruncher"],
        "AchievementNumberCruncherExplanation": ["de": "Erreiche Level 25 in Zahlen Standard", "en": "Reach Level 25 in Numbers Standard"],
        
        // Flags Achievement (1)
        "AchievementFlagNerd": ["de": "Flag Nerd", "en": "Flag Nerd"],
        "AchievementFlagNerdExplanation": ["de": "Erreiche Level 20 in Flaggen Standard", "en": "Reach Level 20 in Flags Standard"],
        
        // Mastery Achievements (3 - Level 30 Standard)
        "AchievementChromaticChampion": ["de": "Chromatischer Champion", "en": "Chromatic Champion"],
        "AchievementChromaticChampionExplanation": ["de": "Erreiche Level 30 in Farben Standard", "en": "Reach Level 30 in Colors Standard"],
        "AchievementGeometryGenius": ["de": "Geometrie-Genie", "en": "Geometry Genius"],
        "AchievementGeometryGeniusExplanation": ["de": "Erreiche Level 30 in Formen Standard", "en": "Reach Level 30 in Shapes Standard"],
        "AchievementEmojiOverlord": ["de": "Emoji-Oberherr", "en": "Emoji Overlord"],
        "AchievementEmojiOverlordExplanation": ["de": "Erreiche Level 30 in Emojis Standard", "en": "Reach Level 30 in Emojis Standard"],
        
        // Pro Mastery Achievements (3 - Level 30 Pro)
        "AchievementRainbowAnnihilator": ["de": "Regenbogen-Vernichter", "en": "Rainbow Annihilator"],
        "AchievementRainbowAnnihilatorExplanation": ["de": "Erreiche Level 30 in Farben Pro", "en": "Reach Level 30 in Colors Pro"],
        "AchievementShapeSorcerer": ["de": "Formen-Zauberer Supremo", "en": "Shape Sorcerer Supreme"],
        "AchievementShapeSorcererExplanation": ["de": "Erreiche Level 30 in Formen Pro", "en": "Reach Level 30 in Shapes Pro"],
        "AchievementEmojiApocalypse": ["de": "Emoji-Apokalypse", "en": "Emoji Apocalypse"],
        "AchievementEmojiApocalypseExplanation": ["de": "Erreiche Level 30 in Emojis Pro", "en": "Reach Level 30 in Emojis Pro"],
        
        // Ultimate Achievement (1)
        "AchievementTheUnkillable": ["de": "Der Unsterbliche", "en": "The Unkillable"],
        "AchievementTheUnkillableExplanation": ["de": "Erreiche Level 30 in allen 10 Modi", "en": "Reach Level 30 in all 10 modes"],
        
        // Achievement UI
        "NewAchievement": ["de": "Neue Errungenschaft!", "en": "New Achievement!"],
        "AchievementsEarned": ["de": "Errungenschaften", "en": "Achievements Earned"],
        "Locked": ["de": "Gesperrt", "en": "Locked"],
        "UnlockBy": ["de": "Freischalten durch:", "en": "Unlock by:"],
        "UnlockMessage": ["de": "Werde zum", "en": "Become"],
        "Achievements": ["de": "Errungenschaften", "en": "Achievements"],
        "AchievementsProgress": ["de": "Fortschritt", "en": "Progress"],
        "UnlockingAchievements": ["de": "Freischaltungen", "en": "Unlocking Achievements"],
        "EarlyAchievements": ["de": "Frühe Erfolge", "en": "Early Achievements"],
        "IntermediateAchievements": ["de": "Fortgeschritten", "en": "Intermediate"],
        "AdvancedAchievements": ["de": "Experten", "en": "Advanced"],
        "MasteryAchievements": ["de": "Meisterschaft", "en": "Mastery"],
        "ProMasteryAchievements": ["de": "Pro-Meisterschaft", "en": "Pro Mastery"],
        "UltimateAchievement": ["de": "Ultimativ", "en": "Ultimate"],
        
        // Dev Mode
        "DevMode": ["de": "🔧 Dev-Modus", "en": "🔧 Dev Mode"],
        "DevModeActive": ["de": "🔧 Dev-Modus Aktiv", "en": "🔧 Dev Mode Active"],
        "DevModeDescription": ["de": "Alle Features freigeschaltet", "en": "All features unlocked"],
        "DeveloperMode": ["de": "Entwickler-Modus", "en": "Developer Mode"],
        "StartLevel": ["de": "Start-Level", "en": "Start Level"],
        "DevModeInfo": ["de": "Entwickler-Features:", "en": "Developer Features:"],
        "DevModeFeature1": ["de": "Highscore-Button = Auto-Solve", "en": "Highscore Button = Auto-Solve"],
        "DevModeFeature2": ["de": "Start-Level anpassen", "en": "Adjust Start Level"],
        
        // Player Selection
        "SelectPlayer": ["de": "Spieler wählen", "en": "Select Player"],
        "CreateNewPlayer": ["de": "Neuen Spieler erstellen", "en": "Create New Player"],
        "EnterPlayerName": ["de": "Namen eingeben", "en": "Enter Name"],
        "ExistingPlayers": ["de": "Vorhandene Spieler", "en": "Existing Players"],
        "NewPlayer": ["de": "Neuer Spieler", "en": "New Player"],
        "SwitchPlayer": ["de": "Spieler wechseln", "en": "Switch Player"],
        "AchievementsCount": ["de": "Errungenschaften", "en": "Achievements"],
        "NoAchievements": ["de": "Keine Errungenschaften", "en": "No Achievements"],
        "DeletePlayer": ["de": "Spieler löschen", "en": "Delete Player"],
        "DeletePlayerConfirmation": ["de": "Spieler löschen?", "en": "Delete Player?"],
        "DeletePlayerMessage": ["de": "Möchtest du diesen Spieler und alle Errungenschaften wirklich löschen?", "en": "Do you really want to delete this player and all achievements?"],
        "Cancel": ["de": "Abbrechen", "en": "Cancel"],
        
        // About Section
        "About": ["de": "Über", "en": "About"],
        "Version": ["de": "Version", "en": "Version"],
        
        // Game Center
        "GameCenter": ["de": "Game Center", "en": "Game Center"],
        "OnlineMode": ["de": "Online-Modus", "en": "Online Mode"],
        "Status": ["de": "Status", "en": "Status"],
        "Connected": ["de": "Verbunden", "en": "Connected"],
        "NotConnected": ["de": "Nicht verbunden", "en": "Not Connected"],
        "GameCenterDescription": ["de": "Aktiviere den Online-Modus, um deine Highscores und Erfolge mit Game Center zu synchronisieren.", "en": "Enable online mode to sync your highscores and achievements with Game Center."],
        "GameCenterPlayer": ["de": "Game Center Spieler", "en": "Game Center Player"],
        "OnlineLeaderboards": ["de": "Online-Bestenlisten", "en": "Online Leaderboards"],
        "LocalHighscores": ["de": "Lokale Highscores", "en": "Local Highscores"],
        "ViewGlobalLeaderboards": ["de": "Weltweite Bestenliste", "en": "View Global Leaderboards"],
        "CompeteWithPlayers": ["de": "Tritt gegen Spieler weltweit an", "en": "Compete with players worldwide"],
        "ViewGameCenterAchievements": ["de": "Game Center Erfolge", "en": "Game Center Achievements"],
        "TrackYourProgress": ["de": "Verfolge deinen Fortschritt", "en": "Track your progress"],
        "GameCenterNotConnected": ["de": "Nicht mit Game Center verbunden", "en": "Not Connected to Game Center"],
        "EnableInSettings": ["de": "In den Einstellungen aktivieren", "en": "Enable in Settings"],
        "Leaderboard": ["de": "Bestenliste", "en": "Leaderboard"],
        "JoinGlobalLeaderboards": ["de": "Weltweiten Bestenlisten beitreten", "en": "Join Global Leaderboards"],
        "EnableGameCenterInSettings": ["de": "Game Center in Einstellungen aktivieren", "en": "Enable Game Center in Settings"],
        "TapToEnableGameCenter": ["de": "Tippen, um Game Center zu aktivieren", "en": "Tap to enable Game Center"],
        "CompeteWorldwide": ["de": "Messe dich mit Spielern weltweit", "en": "Compete with players worldwide"],
        
        // UI Hints
        "TapSettingsToChangeMode": ["de": "Tippe auf Einstellungen, um Modus zu ändern", "en": "Tap Settings to change mode"],
        
        // Difficulty & Mode Selection
        "Difficulty": ["de": "Schwierigkeit", "en": "Difficulty"],
        "StandardMode": ["de": "Standard", "en": "Standard"],
        "ProModeDescriptionColors": ["de": "16 statt 10 Farben", "en": "16 instead of 10 colors"],
        "ProModeDescriptionNumbers": ["de": "0-99 statt 0-12 Zahlen", "en": "0-99 instead of 0-12 numbers"],
        "ProModeDescriptionShapes": ["de": "21 statt 12 Formen", "en": "21 instead of 12 shapes"],
        "ProModeDescriptionFlags": ["de": "60 statt 20 Flaggen", "en": "60 instead of 20 flags"],
        "ProModeDescriptionEmojis": ["de": "100 statt 20 Emojis", "en": "100 instead of 20 emojis"],
        
        // Donation / Tip Jar
        "Donate": ["de": "Spenden", "en": "Donate"],
        "Retry": ["de": "Erneut versuchen", "en": "Retry"],
        "SupportFreeApp": ["de": "App-Entwicklung unterstützen", "en": "Support free app dev"],
        "SupportTimekiller": ["de": "Timekiller unterstützen", "en": "Support Timekiller"],
        "ChooseYourTip": ["de": "Wähle deinen Tipp", "en": "Choose your tip"],
        "ThanksForSupport": ["de": "Danke für deine Unterstützung! 💝\nDu hilfst, diese App werbefrei und kostenlos zu halten.", "en": "Thanks for your support! 💝\nYou help keep this app ad-free and free."],
        "DonationThankYou": ["de": "Vielen Dank! 🎉", "en": "Thank you so much! 🎉"],
        "DonationThankYouMessage": ["de": "Deine Unterstützung hilft, Timekiller kostenlos, werbefrei und offen weiterzuentwickeln!", "en": "Your support helps keep Timekiller free, ad-free, and open for everyone!"],
        "DonationUnavailableTitle": ["de": "Spenden nicht verfügbar", "en": "Donations unavailable"],
        "DonationUnavailableMessage": ["de": "Spendenoptionen sind derzeit nicht verfügbar.", "en": "Donation options aren’t available right now."],
        "DonationUnavailableReviewNote": ["de": "Das kann passieren, solange In-App-Käufe noch auf die App-Store-Prüfung warten oder noch nicht zum Verkauf freigegeben sind. Bitte später erneut versuchen.", "en": "This may happen while In-App Purchases are still pending App Store review or not yet approved for sale. Please try again later."],
        
        // Donation Tiers
        "DonationCoffee": ["de": "Kaffee", "en": "Coffee"],
        "DonationCoffeeDesc": ["de": "Ein Kaffee für den Entwickler", "en": "A coffee for the developer"],
        "DonationBeer": ["de": "Bier", "en": "Beer"],
        "DonationBeerDesc": ["de": "Ein kaltes Bier nach der Arbeit", "en": "A cold beer after work"],
        "DonationPizza": ["de": "Pizza", "en": "Pizza"],
        "DonationPizzaDesc": ["de": "Eine ganze Pizza – wie großzügig!", "en": "A whole pizza – how generous!"],
        "DonationWine": ["de": "Weinflasche", "en": "Wine Bottle"],
        "DonationWineDesc": ["de": "Stilvoll! Eine edle Flasche", "en": "Classy! A fine bottle"],
        "DonationSubscription": ["de": "Dev-Abo", "en": "Dev Subscription"],
        "DonationSubscriptionDesc": ["de": "Du finanzierst einen Monat Entwicklung!", "en": "You're funding a month of development!"],
        "DonationSportscar": ["de": "Sportwagen-Traum", "en": "Sportscar Dream"],
        "DonationSportscarDesc": ["de": "Okay, wow. Du bist unglaublich!", "en": "Okay, wow. You're incredible!"],
        
        // Fun donation prompts for Game Over screen
        "DonateGameOver1": ["de": "Knapp daneben! Die kostenlose App unterstützen? ☕", "en": "Close one! Support free app development? ☕"],
        "DonateGameOver2": ["de": "Game over... aber du kannst helfen, die App werbefrei zu halten! 💝", "en": "Game over... but you can help keep the app ad-free! 💝"],
        "DonateGameOver3": ["de": "Nochmal versuchen? Apps ohne Abo verdienen auch Liebe! 🍕", "en": "Another try? Apps without subscriptions deserve love too! 🍕"],
        "DonateGameOver4": ["de": "Tapfer gekämpft! Hilf, kostenlose Apps zu ermöglichen! ⚡", "en": "You fought bravely! Help keep free apps possible! ⚡"],
        
        // Fun donation prompts for Highscore screen
        "DonateHighscore1": ["de": "Du bist ein Champion! Hilf, die App kostenlos zu halten 🎉", "en": "You're a champion! Help keep the app free 🎉"],
        "DonateHighscore2": ["de": "Highscorer = Free App Supporter? 🏆", "en": "High scorer = Free App Supporter? 🏆"],
        "DonateHighscore3": ["de": "Legendenstatus erreicht! Ohne Werbung, ohne Abo – aber mit deiner Unterstützung? 💖", "en": "Legend status achieved! No ads, no subscription – but with your support? 💖"]
    ]
    
    // Look up the translation for the requested language, fall back to the key if not found
    return translations[key]?[language] ?? key
}

// MARK: - Helper Functions

/// Retrieves a localized name for game content (colors, shapes, emojis, etc.).
///
/// This is a convenience wrapper around the `L()` function specifically for translating
/// content names used in game modes. It provides clearer semantics when translating
/// game content versus UI strings.
///
/// - Parameters:
///   - nameKey: The localization key for the content name (e.g., "Red", "ShapeCircle", "EmojiDog")
///   - language: The language code ("de" or "en")
/// - Returns: The localized content name
///
/// ## Example
/// ```swift
/// let colorName = localizedContentName("Red", language: "en") // Returns "Red"
/// let shapeName = localizedContentName("ShapeCircle", language: "de") // Returns "Kreis"
/// ```
func localizedContentName(_ nameKey: String, language: String) -> String {
    return L(nameKey, language: language)
}

/// Retrieves a localized color name.
///
/// This is a legacy compatibility function that wraps `L()` for color name lookups.
/// It's maintained for backward compatibility with older parts of the codebase.
///
/// - Parameters:
///   - nameKey: The localization key for the color (e.g., "Red", "Blue", "Green")
///   - language: The language code ("de" or "en")
/// - Returns: The localized color name
///
/// - Note: New code should prefer `localizedContentName()` for clearer semantics.
///
/// ## Example
/// ```swift
/// let colorName = localizedColorName("Blue", language: "de") // Returns "Blau"
/// ```
func localizedColorName(_ nameKey: String, language: String) -> String {
    return L(nameKey, language: language)
}
