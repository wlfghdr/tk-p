//
//  Logger+Timekiller.swift
//  Timekiller
//
//  Created on 07.01.26.
//

import Foundation
import OSLog

/// Centralized logging configuration for Timekiller.
///
/// This extension provides domain-specific loggers for different subsystems
/// of the app, following Apple's unified logging best practices.
///
/// ## Benefits of OSLog / Logger
/// - **Performance**: Highly optimized, minimal overhead
/// - **Privacy**: Automatic data redaction in production
/// - **Filtering**: Filter by subsystem, category, and level in Console.app
/// - **Persistence**: Logs survive app termination (system-managed)
/// - **Instruments**: Integration with Xcode profiling tools
///
/// ## Log Levels
/// - `.debug` - Verbose development info (not persisted to disk, stripped in release)
/// - `.info` - General informational messages
/// - `.notice` - Notable events (default level, persisted to disk)
/// - `.error` - Error conditions that need attention
/// - `.fault` - Critical failures requiring immediate action
///
/// ## Privacy Levels
/// - `.public` - Visible in logs (use for non-sensitive data)
/// - `.private` - Redacted in logs (default, use for user data)
/// - `.sensitive` - Extra redaction (use for highly sensitive data)
/// - `.auto` - System decides based on type
///
/// ## Usage Examples
/// ```swift
/// // Authentication success
/// Logger.gameCenter.info("User authenticated successfully")
///
/// // Error with public context
/// Logger.gameCenter.error("Failed to sync: \(error.localizedDescription, privacy: .public)")
///
/// // Info with private user data
/// Logger.game.info("Player \(name, privacy: .private) completed level \(level)")
///
/// // Structured logging with metadata
/// Logger.achievements.notice("Achievement unlocked", metadata: [
///     "id": "\(achievementID)",
///     "player": "\(playerName, privacy: .private)"
/// ])
///
/// // Debug logging (automatically excluded from release builds)
/// Logger.game.debug("Detailed state: \(gameState)")
/// ```
///
/// ## Viewing Logs
/// ### Console.app (macOS)
/// 1. Open Console.app
/// 2. Connect your device or simulator
/// 3. Filter by subsystem: `ai.wulf.timekiller`
/// 4. Filter by category: e.g., `GameCenter`, `IAP`, etc.
///
/// ### Xcode Console
/// Logs appear in Xcode's console during debugging with timestamps and metadata.
///
/// ### Instruments
/// Use the "Logging" instrument to profile log volume and performance impact.
///
/// ## Best Practices
/// ✅ **Do:**
/// - Use appropriate log levels for severity
/// - Mark user data as `.private`
/// - Keep messages concise and searchable
/// - Use structured metadata for rich context
///
/// ❌ **Don't:**
/// - Log sensitive data as `.public`
/// - Create excessive log noise (use appropriate levels)
/// - Log in tight loops (use sampling or aggregation)
/// - Include emojis or special characters (breaks filtering)
///
/// - Note: All loggers share the same subsystem but use different categories
///   for easy filtering and organization.
extension Logger {
    /// Subsystem identifier for all Timekiller logs.
    ///
    /// This identifies all logs as coming from the Timekiller app, allowing
    /// you to filter all app logs in Console.app by subsystem.
    private static let subsystem = Bundle.main.bundleIdentifier ?? "ai.wulf.timekiller"
    
    // MARK: - Game Center Integration
    
    /// Logger for Game Center integration (authentication, leaderboards, achievements).
    ///
    /// Use this logger for all Game Center-related operations including:
    /// - User authentication and sign-in
    /// - Leaderboard score submission and loading
    /// - Achievement reporting and syncing
    /// - Cloud save synchronization
    /// - Player profile management
    ///
    /// ## Example Usage
    /// ```swift
    /// // Authentication
    /// Logger.gameCenter.info("Starting authentication")
    /// Logger.gameCenter.notice("User authenticated", metadata: ["playerID": "\(playerID, privacy: .private)"])
    /// Logger.gameCenter.error("Authentication failed: \(error.localizedDescription, privacy: .public)")
    ///
    /// // Score submission
    /// Logger.gameCenter.notice("Score submitted", metadata: [
    ///     "score": "\(score)",
    ///     "leaderboard": "\(leaderboardID)"
    /// ])
    ///
    /// // Sync operations
    /// Logger.gameCenter.info("Starting sync for player: \(playerName, privacy: .private)")
    /// Logger.gameCenter.notice("Sync completed", metadata: ["duration": "\(duration)s"])
    /// ```
    static let gameCenter = Logger(subsystem: subsystem, category: "GameCenter")
    
    // MARK: - In-App Purchases
    
    /// Logger for in-app purchase and donation handling.
    ///
    /// Use this logger for all StoreKit-related operations including:
    /// - Product loading and availability
    /// - Purchase initiation and completion
    /// - Transaction verification
    /// - Purchase restoration
    /// - StoreKit errors and failures
    ///
    /// ## Example Usage
    /// ```swift
    /// // Product loading
    /// Logger.iap.info("Loading products")
    /// Logger.iap.notice("Products loaded", metadata: ["count": "\(products.count)"])
    /// Logger.iap.error("Failed to load products: \(error.localizedDescription, privacy: .public)")
    ///
    /// // Purchase flow
    /// Logger.iap.info("Purchase initiated", metadata: ["productID": "\(productID)"])
    /// Logger.iap.notice("Purchase completed successfully", metadata: ["product": "\(productID)"])
    /// Logger.iap.warning("Purchase cancelled by user")
    /// Logger.iap.fault("Transaction verification failed: \(error.localizedDescription, privacy: .public)")
    /// ```
    static let iap = Logger(subsystem: subsystem, category: "IAP")
    
    // MARK: - Haptic & Audio Feedback
    
    /// Logger for haptic and audio feedback.
    ///
    /// Use this logger for all feedback-related operations including:
    /// - Audio session configuration
    /// - Sound playback
    /// - Haptic generation
    /// - Feedback settings changes
    /// - System capability detection
    ///
    /// ## Example Usage
    /// ```swift
    /// // Setup
    /// Logger.feedback.info("Configuring audio session")
    /// Logger.feedback.error("Audio session setup failed: \(error.localizedDescription, privacy: .public)")
    ///
    /// // Feedback triggers
    /// Logger.feedback.debug("Triggering feedback: \(type)")
    /// Logger.feedback.warning("Haptic generation unavailable on this device")
    ///
    /// // Settings
    /// Logger.feedback.info("Sound enabled: \(isEnabled)")
    /// ```
    static let feedback = Logger(subsystem: subsystem, category: "Feedback")
    
    // MARK: - Achievement System
    
    /// Logger for achievement and progression tracking.
    ///
    /// Use this logger for all achievement-related operations including:
    /// - Achievement unlocking
    /// - Progress tracking
    /// - Condition checking
    /// - Mode unlocking
    /// - Player progression
    ///
    /// ## Example Usage
    /// ```swift
    /// // Achievement unlocking
    /// Logger.achievements.notice("Achievement unlocked", metadata: [
    ///     "id": "\(achievementID)",
    ///     "player": "\(playerName, privacy: .private)"
    /// ])
    ///
    /// // Progress tracking
    /// Logger.achievements.info("Level completed", metadata: [
    ///     "mode": "\(mode)",
    ///     "level": "\(level)",
    ///     "isPro": "\(isPro)"
    /// ])
    ///
    /// // Mode unlocking
    /// Logger.achievements.notice("Mode unlocked", metadata: [
    ///     "mode": "\(mode)",
    ///     "trigger": "\(triggerAchievement)"
    /// ])
    /// ```
    static let achievements = Logger(subsystem: subsystem, category: "Achievements")
    
    // MARK: - High Score Management
    
    /// Logger for high score management.
    ///
    /// Use this logger for all highscore-related operations including:
    /// - Score recording
    /// - Leaderboard updates
    /// - Entry deletion
    /// - Personal best tracking
    ///
    /// ## Example Usage
    /// ```swift
    /// // Score recording
    /// Logger.highscores.notice("New score added", metadata: [
    ///     "score": "\(score)",
    ///     "player": "\(playerName, privacy: .private)",
    ///     "level": "\(maxLevel)",
    ///     "mode": "\(gameMode)"
    /// ])
    ///
    /// // Personal best
    /// Logger.highscores.info("New personal best", metadata: [
    ///     "previous": "\(oldBest)",
    ///     "new": "\(newBest)"
    /// ])
    ///
    /// // Management
    /// Logger.highscores.info("Cleared all scores")
    /// ```
    static let highscores = Logger(subsystem: subsystem, category: "Highscores")
    
    // MARK: - Game State & Session
    
    /// Logger for game state and session management.
    ///
    /// Use this logger for all gameplay-related events including:
    /// - Game start/stop
    /// - Level progression
    /// - Round completion
    /// - Lives and mistakes
    /// - Time warnings
    /// - Mode switching
    ///
    /// ## Example Usage
    /// ```swift
    /// // Session lifecycle
    /// Logger.game.info("Game started", metadata: [
    ///     "mode": "\(gameMode)",
    ///     "level": "\(level)",
    ///     "isPro": "\(isPro)"
    /// ])
    ///
    /// Logger.game.notice("Level completed", metadata: [
    ///     "level": "\(level)",
    ///     "score": "\(score)",
    ///     "timeRemaining": "\(timeRemaining)"
    /// ])
    ///
    /// Logger.game.info("Game ended", metadata: [
    ///     "finalScore": "\(score)",
    ///     "maxLevel": "\(maxLevel)",
    ///     "reason": "\(endReason)"
    /// ])
    ///
    /// // Gameplay events
    /// Logger.game.debug("Round started: \(roundNumber)")
    /// Logger.game.debug("Correct tap: \(tileID)")
    /// Logger.game.warning("Wrong tap: lives remaining = \(lives)")
    /// Logger.game.error("Time expired: \(timeRemaining)s")
    /// ```
    static let game = Logger(subsystem: subsystem, category: "Game")
    
    // MARK: - Data Persistence & Storage
    
    /// Logger for data persistence and migration.
    ///
    /// Use this logger for all data storage operations including:
    /// - UserDefaults read/write
    /// - Data encoding/decoding
    /// - Migration from legacy formats
    /// - Backup and restore
    /// - Storage failures
    ///
    /// ## Example Usage
    /// ```swift
    /// // Persistence
    /// Logger.storage.debug("Saving achievement data")
    /// Logger.storage.info("Data saved successfully")
    /// Logger.storage.error("Failed to encode data: \(error.localizedDescription, privacy: .public)")
    ///
    /// // Migration
    /// Logger.storage.info("Starting legacy data migration")
    /// Logger.storage.notice("Migration completed", metadata: [
    ///     "achievements": "\(count)",
    ///     "duration": "\(duration)s"
    /// ])
    ///
    /// // Errors
    /// Logger.storage.fault("Data corruption detected: \(details, privacy: .public)")
    /// ```
    static let storage = Logger(subsystem: subsystem, category: "Storage")
    
    // MARK: - Application Lifecycle
    
    /// Logger for general app lifecycle events.
    ///
    /// Use this logger for app-wide events including:
    /// - Launch and termination
    /// - Scene transitions
    /// - Player switching
    /// - Settings changes
    /// - Background/foreground transitions
    ///
    /// ## Example Usage
    /// ```swift
    /// // Lifecycle
    /// Logger.app.info("App launched")
    /// Logger.app.info("Entering background")
    /// Logger.app.info("Returning to foreground")
    ///
    /// // Player management
    /// Logger.app.info("Player created", metadata: ["name": "\(name, privacy: .private)"])
    /// Logger.app.info("Switched player", metadata: [
    ///     "from": "\(oldPlayer, privacy: .private)",
    ///     "to": "\(newPlayer, privacy: .private)"
    /// ])
    ///
    /// // Settings
    /// Logger.app.info("Settings changed", metadata: [
    ///     "setting": "\(settingName)",
    ///     "value": "\(newValue)"
    /// ])
    /// ```
    static let app = Logger(subsystem: subsystem, category: "App")
}

// MARK: - Convenience Extensions

extension Logger {
    /// Logs a message with structured metadata as a dictionary.
    ///
    /// This provides a convenient way to log structured data without manually
    /// constructing interpolated strings. The metadata is properly formatted
    /// for Console.app filtering and analysis.
    ///
    /// - Parameters:
    ///   - level: The log level (info, notice, error, etc.)
    ///   - message: The base message to log
    ///   - metadata: Dictionary of key-value pairs providing additional context
    ///
    /// ## Example
    /// ```swift
    /// Logger.game.log(level: .notice, "Level completed", metadata: [
    ///     "level": "\(level)",
    ///     "score": "\(score)",
    ///     "time": "\(time)"
    /// ])
    /// ```
    func log(level: OSLogType, _ message: String, metadata: [String: String] = [:]) {
        if metadata.isEmpty {
            self.log(level: level, "\(message)")
        } else {
            let metadataString = metadata
                .map { "\($0)=\($1)" }
                .joined(separator: ", ")
            self.log(level: level, "\(message) [\(metadataString)]")
        }
    }
    
    /// Formats an array of achievement IDs for logging, limiting the output to prevent excessive message size.
    ///
    /// This method takes an array of achievement IDs and returns a formatted string that includes:
    /// - The first 3 achievement IDs (or fewer if less than 3 exist)
    /// - A count of remaining IDs if there are more than 3
    ///
    /// This prevents log messages from becoming excessively long when many achievements are unlocked at once.
    ///
    /// - Parameter achievementIDs: Array of achievement identifier strings
    /// - Returns: A formatted string suitable for logging (e.g., "id1, id2, id3 (+2 more)")
    ///
    /// ## Example
    /// ```swift
    /// let achievements = ["color_cadet", "polygon_prodigy", "flag_dropper", "smiley_summoner", "ultra_instinct"]
    /// let formatted = Logger.formatAchievementIDs(achievements)
    /// // Returns: "color_cadet, polygon_prodigy, flag_dropper (+2 more)"
    /// Logger.achievements.notice("Achievements unlocked: count=\(achievements.count), ids=\(formatted)")
    /// ```
    static func formatAchievementIDs(_ achievementIDs: [String]) -> String {
        let preview = achievementIDs.prefix(3).joined(separator: ", ")
        let moreCount = max(0, achievementIDs.count - 3)
        let suffix = moreCount > 0 ? " (+\(moreCount) more)" : ""
        return "\(preview)\(suffix)"
    }
}
