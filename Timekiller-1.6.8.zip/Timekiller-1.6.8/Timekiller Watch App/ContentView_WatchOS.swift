//
//  ContentView.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI
import OSLog

// MARK: - Main Content View for watchOS

/// The primary game view for watchOS, optimized for Apple Watch's compact display.
///
/// `ContentView_WatchOS` provides a streamlined version of the Timekiller game experience
/// tailored specifically for Apple Watch. It maintains feature parity with the iOS version
/// while adapting the UI for the smaller screen and different interaction patterns of watchOS.
///
/// ## watchOS-Specific Optimizations
///
/// ### Fixed Grid Size
/// Unlike iOS (which scales grid size by level), watchOS **always uses a 2×2 grid** (4 tiles).
/// This ensures:
/// - Tiles are always large enough to tap comfortably
/// - Game remains playable on 38mm-49mm watch faces
/// - Consistent gameplay experience across all Apple Watch models
///
/// ### Compact UI Design
/// All UI elements are designed for space efficiency:
/// - **Header**: Two-line compact display with level, round, timer, and score
/// - **Grid**: Minimal padding (6pt vs 12pt on iOS)
/// - **Text**: Smaller fonts (9pt-11pt vs 12pt-16pt on iOS)
/// - **Progress Indicators**: Dots instead of full progress bars where possible
///
/// ### Simplified Interactions
/// - **No Pause on Background**: watchOS doesn't have the same app lifecycle notifications
/// - **Single Correct Tile**: Only one correct answer per round (no multi-find rounds)
/// - **Faster Timeouts**: Same base time (8s) but game feels snappier due to fewer tiles
///
/// ## Shared Features with iOS
/// Despite platform differences, watchOS maintains these core features:
/// - All 5 game modes (Colors, Numbers, Shapes, Flags, Emojis)
/// - Pro mode with 16-item variety and 1.5× multiplier
/// - Achievement system with local tracking
/// - Same scoring formula and difficulty progression
/// - Level completion celebrations
/// - Highscore persistence
/// - Dev mode support
///
/// ## Architecture
/// - **Observable State**: Uses SwiftUI's `@State` for reactive updates
/// - **Persistence**: Leverages `@AppStorage` for cross-session settings
/// - **No Game Center**: watchOS version uses local storage only (no online features)
/// - **Shared Logic**: Uses same `GameMode`, `GameItems`, and `FeedbackManager` as iOS
///
/// ## User Experience Philosophy
/// The watchOS version prioritizes **glanceability** and **quick sessions**:
/// - Players can complete a round in 8 seconds
/// - Clear visual feedback for correct/wrong taps
/// - Minimal scrolling required during gameplay
/// - Easy pause/resume for interruptions
///
/// ## Performance Considerations
/// - Animated backgrounds use `reduceMotion` detection for battery savings
/// - Timer intervals optimized for Watch's refresh rate
/// - Minimal memory footprint (no cached images or heavy resources)
///
/// ## Example
/// ```swift
/// // In your watchOS app structure
/// @main
/// struct Timekiller_watchOSApp: App {
///     var body: some Scene {
///         WindowGroup {
///             ContentView_WatchOS()
///         }
///     }
/// }
/// ```
///
/// - Note: This view is watchOS-only. For iOS/iPadOS, use `ContentView_iOS` which
///   provides the full-featured experience with dynamic grid sizes and Game Center support.
struct ContentView_WatchOS: View {
    // MARK: - App Storage (Settings)
    @AppStorage("tk_playerName") private var playerName: String = "Player"
    @AppStorage("tk_language") private var appLanguage: String = Self.defaultLanguage()
    // Grid size fixed to 2x2 for watchOS
    private let gridSize: GridSize = .grid2x2
    @AppStorage("tk_theme") private var appTheme: String = "system"  // system, light, dark
    @AppStorage("tk_startLevel") private var startLevel: Int = 1  // Which level to start at
    @AppStorage("tk_proMode") private var proMode: Bool = false  // Pro mode: 16 colors instead of 8
    @AppStorage("tk_gameMode") private var gameModeRaw: String = GameMode.colors.rawValue  // Game mode
    @AppStorage("tk_soundEnabled") private var soundEnabled: Bool = true  // Sound feedback
    @AppStorage("tk_hapticsEnabled") private var hapticsEnabled: Bool = true  // Haptic feedback
    
    // MARK: - Environment
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    
    // MARK: - Constants
    private let roundsPerLevel: Int = 6  // 6 rounds per level
    
    // MARK: - State
    @State private var highscoreStore = HighscoreStore()
    @State private var achievementStore = AchievementStore()
    @State private var feedbackManager = FeedbackManager.shared
    @State private var isPlaying = false
    @State private var showSettings = false
    @State private var showHighscores = false
    @State private var showSummary = false
    @State private var showLevelComplete = false
    @State private var isLowTimeWarningTriggered = false  // Track if warning was triggered
    @State private var showPlayerSelection = false  // Player selection sheet
    @State private var showLockAlert = false
    @State private var lockAlertMessage = ""
    
    // Game State
    @State private var level: Int = 1
    @State private var round: Int = 0
    @State private var totalScore: Int = 0
    @State private var levelScore: Int = 0
    @State private var levelScores: [Int: Int] = [:]  // Track score per level
    @State private var tiles: [TileData] = []
    @State private var timer: Timer?
    @State private var scoreDelta: Int? = nil
    @State private var timeRemaining: Double = 0
    @State private var timerProgress: Double = 1.0
    @State private var sessionShapes: [GameShape] = []  // Randomized shape set for this game session
    @State private var sessionFlags: [GameFlag] = []  // Randomized flag set for this game session
    @State private var sessionEmojis: [GameEmoji] = []  // Randomized emoji set for this game session
    @State private var consecutiveTimeouts: Int = 0  // Track consecutive timeouts
    @State private var consecutiveWrongTaps: Int = 0  // Track consecutive wrong taps
    @State private var newAchievementsThisRun: [String] = []  // Track achievements earned in current game
    @State private var mistakesThisLevel: Int = 0  // Track mistakes (timeouts or wrong taps) in current level
    
    // MARK: - Computed Properties
    private var gameMode: GameMode {
        GameMode(rawValue: gameModeRaw) ?? .colors
    }
    
    private var availableColors: [GameColor] {
        proMode ? GameColor.proColors : GameColor.standardColors
    }
    
    private var availableShapes: [GameShape] {
        // Return the randomized session shapes if they exist, otherwise the full set
        if !sessionShapes.isEmpty {
            return sessionShapes
        }
        return proMode ? GameShape.proShapes : GameShape.standardShapes
    }
    
    private var availableEmojis: [GameEmoji] {
        // Return the randomized session emojis if they exist, otherwise the full set
        if !sessionEmojis.isEmpty {
            return sessionEmojis
        }
        return proMode ? GameEmoji.proEmojis : GameEmoji.standardEmojis
    }
    
    private var availableFlags: [GameFlag] {
        // Return the randomized session flags if they exist, otherwise the full set
        if !sessionFlags.isEmpty {
            return sessionFlags
        }
        return proMode ? GameFlag.proFlags : GameFlag.standardFlags
    }
    
    private var availableNumbers: [GameNumber] {
        return proMode ? GameNumber.proNumbers : GameNumber.standardNumbers
    }
    
    private var availableItems: Int {
        switch gameMode {
        case .colors:
            return availableColors.count
        case .numbers:
            return availableNumbers.count
        case .shapes:
            return availableShapes.count
        case .flags:
            return availableFlags.count
        case .emojis:
            return availableEmojis.count
        }
    }
    
    private var currentRoundDuration: Double {
        // Use the same baseTimeForLevel function as iOS, but adapted for 2x2 grid
        // watchOS always uses 2x2 grid, so we use the base time for that grid size
        let baseDuration: Double = 8.0  // 4 tiles: 8 seconds (same as iOS 2x2)
        
        // No time reduction for levels 1-24 (same as iOS)
        if level < 25 {
            return baseDuration
        }
        
        // From level 25 onwards: 5% reduction per level (same as iOS)
        let levelsAbove24 = level - 24
        let reductionFactor = pow(0.95, Double(levelsAbove24))
        return baseDuration * reductionFactor
    }
    
    /// Calculate score for the current round using the new simplified system (same as iOS)
    /// Base Points = 10 per round
    /// Level Bonus = level × 5
    /// Time Bonus = seconds remaining × 10
    /// Pro Multiplier = 1.5 (if Pro Mode, otherwise 1.0)
    /// Round Score = (Base + Level Bonus + Time Bonus) × Pro Multiplier
    private func calculateRoundScore(secondsRemaining: Double) -> Int {
        let basePoints = 10
        let levelBonus = level * 5
        let timeBonus = Int(secondsRemaining.rounded()) * 10
        
        let subtotal = basePoints + levelBonus + timeBonus
        let proMultiplier: Double = proMode ? 1.5 : 1.0
        
        return Int(Double(subtotal) * proMultiplier)
    }
    
    private var colorScheme: ColorScheme? {
        switch appTheme {
        case "light": return .light
        case "dark": return .dark
        default: return nil  // system
        }
    }
    
    // Dev Mode: Check if player name is "Wulf" (case-insensitive)
    private var isDevMode: Bool {
        let normalized = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.caseInsensitiveCompare("Wulf") == .orderedSame
    }
    
    // MARK: - Computed Properties for Display
    private var displayLevel: Int {
        // Show the configured start level if game hasn't started yet
        if !isPlaying && round == 0 {
            return startLevel
        }
        return level
    }
    
    // MARK: - Body
    var body: some View {
        NavigationStack {
            ZStack {
                // Animated background
                AnimatedBackgroundView_WatchOS(
                    colorScheme: colorScheme,
                    gameMode: gameMode,
                    reduceMotion: reduceMotion,
                    isPlaying: isPlaying
                )
                
                // Main Content
                if isPlaying {
                    // Playing: Minimal header, maximize grid visibility
                    VStack(spacing: 4) {
                        compactHeaderView
                        
                        VStack(spacing: 6) {
                            gridView
                                .transition(.scale.combined(with: .opacity))
                            
                            // Time Progress Bar (thinner for watchOS)
                            GeometryReader { geometry in
                                ZStack(alignment: .leading) {
                                    Rectangle()
                                        .fill(Color.gray.opacity(0.3))
                                        .frame(height: 4)
                                    
                                    Rectangle()
                                        .fill(timerProgress > 0.3 ? Color.green : Color.red)
                                        .frame(width: geometry.size.width * timerProgress, height: 4)
                                        .animation(.linear(duration: 0.1), value: timerProgress)
                                }
                                .cornerRadius(2)
                            }
                            .frame(height: 4)
                        }
                        
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal, 6)
                    .padding(.top, 2)
                } else {
                    // Not playing: Everything scrolls including header
                    startPromptView
                }
                
                // Score Delta Overlay
                if let delta = scoreDelta {
                    scoreDeltaOverlay(delta: delta)
                }
                
                // Level Complete Overlay
                if showLevelComplete {
                    levelCompleteOverlay
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    // Only show settings button on start screen (not during gameplay or pause)
                    if !isPlaying && round == 0 {
                        Button {
                            showSettings = true
                        } label: {
                            Image(systemName: "gear")
                                .imageScale(.small)
                        }
                    }
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    // Hide play/pause button when level complete screen is showing
                    if round > 0 && !showLevelComplete {
                        Button {
                            // Dev Mode: Auto-solve on pause button tap during gameplay (invisible)
                            if isDevMode && isPlaying {
                                autoSolveRound()
                            } else if isPlaying {
                                pauseGame()
                            } else {
                                startGame()
                            }
                        } label: {
                            Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                                .imageScale(.small)
                        }
                    } else if !showLevelComplete {
                        // Show highscores button on start screen
                        Button {
                            showHighscores = true
                        } label: {
                            Image(systemName: "list.number")
                                .imageScale(.small)
                        }
                    }
                }
            }
            .sheet(isPresented: $showSettings) {
                SettingsView_WatchOS(
                    playerName: $playerName,
                    appLanguage: $appLanguage,
                    appTheme: $appTheme,
                    proMode: $proMode,
                    gameModeRaw: $gameModeRaw,
                    soundEnabled: $soundEnabled,
                    hapticsEnabled: $hapticsEnabled,
                    startLevel: $startLevel,
                    showPlayerSelection: $showPlayerSelection,
                    achievementStore: achievementStore
                )
            }
            .onChange(of: soundEnabled) { _, newValue in
                feedbackManager.soundEnabled = newValue
                Logger.app.info("Sound setting changed: \(newValue)")
            }
            .onChange(of: hapticsEnabled) { _, newValue in
                feedbackManager.hapticsEnabled = newValue
                Logger.app.info("Haptics setting changed: \(newValue)")
            }
            .onChange(of: proMode) { _, newValue in
                if isPlaying || round > 0 {
                    resetGame()
                }
                Logger.app.info("Pro mode changed: \(newValue) (gameMode: \(gameMode.rawValue))")
            }
            .onChange(of: gameModeRaw) { _, newValue in
                if isPlaying || round > 0 {
                    resetGame()
                }
                Logger.app.info("Game mode changed: \(newValue) (isPro: \(proMode))")
            }
            .onChange(of: appLanguage) { _, newValue in
                if isPlaying || round > 0 {
                    resetGame()
                }
                Logger.app.info("Language changed: \(newValue)")
            }
            .sheet(isPresented: $showHighscores) {
                NavigationStack {
                    HighscoreView_WatchOS(
                        store: highscoreStore,
                        language: appLanguage,
                        achievementStore: achievementStore,
                        playerName: playerName
                    )
                        .navigationTitle(L("Highscores", language: appLanguage))
                        .navigationBarTitleDisplayMode(.inline)
                }
            }
            .sheet(isPresented: $showSummary) {
                SummaryView_WatchOS(
                    level: level,
                    totalScore: totalScore,
                    levelScores: levelScores,
                    highscoreStore: highscoreStore,
                    language: appLanguage,
                    onRestart: {
                        showSummary = false
                        resetGame()
                    },
                    newAchievements: newAchievementsThisRun,
                    achievementStore: achievementStore,
                    playerName: playerName
                )
                .interactiveDismissDisabled()  // Prevent swipe-to-dismiss
            }
            .sheet(isPresented: $showPlayerSelection) {
                PlayerNameSelectionView_WatchOS(
                    playerName: $playerName,
                    achievementStore: achievementStore,
                    language: appLanguage
                )
            }
        }
        .preferredColorScheme(colorScheme)
        .alert(L("Locked", language: appLanguage), isPresented: $showLockAlert) {
            Button(L("Done", language: appLanguage), role: .cancel) { }
        } message: {
            Text(lockAlertMessage)
        }
        .onAppear {
            // Sync feedback manager settings on appear
            feedbackManager.soundEnabled = soundEnabled
            feedbackManager.hapticsEnabled = hapticsEnabled
            
            // Initialize achievement store with current player
            achievementStore.currentPlayerName = playerName
            
            Logger.app.info("WatchOS ContentView appeared")
            Logger.app.info("Current player: \(playerName, privacy: .private), gameMode: \(gameMode.rawValue), isPro: \(proMode)")
            
            // Validate current selections and reset to defaults if locked
            validateSelections()
        }
        .onChange(of: playerName) { _, newValue in
            // Update achievement store when player name changes
            achievementStore.currentPlayerName = newValue
            
            Logger.app.info("Player name changed: \(newValue, privacy: .private)")
            
            // Reset game if playing
            if isPlaying || round > 0 {
                resetGame()
            }
            
            // Revalidate selections for new player
            validateSelections()
        }
    }
    
    // MARK: - Compact Header View for watchOS
    private var compactHeaderView: some View {
        // Two rows for better visual hierarchy while staying compact
        VStack(spacing: 3) {
            // Top row: Level badge and round progress
            HStack(spacing: 4) {
                // Level badge with gradient
                HStack(spacing: 2) {
                    Image(systemName: "mountain.2.fill")
                        .font(.system(size: 8))
                    Text("L\(level)")
                        .font(.system(size: 11, weight: .bold))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(8)
                
                // Round progress dots (mini)
                HStack(spacing: 2) {
                    ForEach(1...roundsPerLevel, id: \.self) { roundNum in
                        Circle()
                            .fill(roundNum <= round ? Color.blue : Color.gray.opacity(0.3))
                            .frame(width: 4, height: 4)
                            .scaleEffect(roundNum == round && !reduceMotion ? 1.2 : 1.0)
                    }
                }
                .animation(reduceMotion ? .none : .spring(response: 0.3, dampingFraction: 0.6), value: round)
                
                Spacer(minLength: 2)
                
                // Timer indicator (simplified for space)
                HStack(spacing: 2) {
                    Image(systemName: "timer")
                        .font(.system(size: 8))
                        .foregroundStyle(timerProgress > 0.25 ? Color.green : Color.red)
                    Text(String(format: "%.1f", timeRemaining))
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundStyle(timerProgress > 0.25 ? Color.primary : Color.red)
                }
            }
            
            // Bottom row: Score with badges
            HStack(spacing: 4) {
                // Total score
                Text("\(totalScore)")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                    .contentTransition(.numericText())
                
                Spacer(minLength: 2)
                
                // Pro/Mode badges (if applicable)
                if proMode {
                    Image(systemName: "brain.head.profile")
                        .font(.system(size: 8))
                        .foregroundStyle(.white)
                        .padding(3)
                        .background(Circle().fill(Color.purple))
                }
                
                if gameMode == .shapes {
                    Text("⬟")
                        .font(.system(size: 8))
                        .padding(2)
                        .background(Circle().fill(Color.teal.opacity(0.3)))
                }
                
                if gameMode == .emojis {
                    Text("😀")
                        .font(.system(size: 8))
                        .padding(2)
                        .background(Circle().fill(Color.purple.opacity(0.3)))
                }
            }
        }
        .padding(.horizontal, 4)
        .padding(.vertical, 3)
        .background(
            RoundedRectangle(cornerRadius: 6)
                .fill(Color.black.opacity(0.15))
        )
        .cornerRadius(4)
    }
    
    // MARK: - Grid View
    private var gridView: some View {
        // Fixed 2x2 grid for watchOS
        let columns = Array(repeating: GridItem(.flexible(), spacing: 6), count: 2)
        
        return LazyVGrid(columns: columns, spacing: 6) {
            ForEach(tiles.indices, id: \.self) { index in
                let tile = tiles[index]
                Button {
                    handleTileTap(tile: tile)
                } label: {
                    ZStack {
                        Rectangle()
                            .fill(tile.backgroundColor)
                            .cornerRadius(6)
                            .shadow(radius: 1)
                        
                        VStack(spacing: 1) {
                            // Show emoji if in emoji mode
                            if let emoji = tile.visualContent {
                                Text(emoji)
                                    .font(.system(size: 20))
                            }
                            
                            // Show text label
                            Text(localizedContentName(tile.displayContent.nameKey, language: appLanguage))
                                .font(.system(size: 9, weight: .bold))
                                .foregroundStyle(textColorForTile(tile))
                                .multilineTextAlignment(.center)
                                .minimumScaleFactor(0.4)
                                .lineLimit(2)
                        }
                        .padding(3)
                    }
                    .frame(maxWidth: .infinity, minHeight: 55)
                }
                .buttonStyle(.plain)
            }
        }
    }
    
    // MARK: - Start Prompt View
    private var startPromptView: some View {
        ScrollView {
            VStack(spacing: 10) {
                // Only show header on normal start screen, not on pause screen
                if round == 0 || isPlaying {
                    compactHeaderView
                }
                
                // If game is paused (round > 0 but not playing), show pause screen
                if round > 0 && !isPlaying {
                    pauseScreenView
                } else {
                    // Normal start screen
                    startScreenView
                }
            }
            .padding(.horizontal, 6)
            .padding(.top, 2)
        }
    }
    
    private var pauseScreenView: some View {
        VStack(spacing: 12) {
            // Level & Round Info (compact)
            HStack(spacing: 4) {
                // Level badge
                HStack(spacing: 2) {
                    Image(systemName: "mountain.2.fill")
                        .font(.system(size: 8))
                    Text("L\(level)")
                        .font(.system(size: 11, weight: .bold))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(8)
                
                // Round progress dots (mini)
                HStack(spacing: 2) {
                    ForEach(1...roundsPerLevel, id: \.self) { roundNum in
                        Circle()
                            .fill(roundNum <= round ? Color.blue : Color.gray.opacity(0.3))
                            .frame(width: 4, height: 4)
                    }
                }
                
                Spacer()
                
                Text("\(round)/\(roundsPerLevel)")
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 6)
            .background(Color.gray.opacity(0.2))
            .cornerRadius(8)
            
            // Scores (compact)
            HStack(spacing: 8) {
                // Total Score
                VStack(spacing: 2) {
                    Text(L("TotalScore", language: appLanguage))
                        .font(.system(size: 9))
                        .foregroundStyle(.secondary)
                    Text("\(totalScore)")
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                }
                .frame(maxWidth: .infinity)
                
                // Level Score
                VStack(spacing: 2) {
                    Text(L("LevelScore", language: appLanguage))
                        .font(.system(size: 9))
                        .foregroundStyle(.secondary)
                    Text("\(levelScore)")
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundStyle(levelScore >= 0 ? Color.green : Color.red)
                }
                .frame(maxWidth: .infinity)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 8)
            .background(Color.gray.opacity(0.2))
            .cornerRadius(8)
            
            // Buttons - directly visible, no scrolling needed
            VStack(spacing: 8) {
                // Resume Button
                Button {
                    startGame()
                } label: {
                    HStack {
                        Image(systemName: "play.fill")
                        Text(L("Resume", language: appLanguage))
                    }
                    .font(.headline.bold())
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color.accentColor)
                    .cornerRadius(10)
                }
                .buttonStyle(.plain)
                
                // Quit Button
                Button {
                    quitGame()
                } label: {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                        Text(L("Quit", language: appLanguage))
                    }
                    .font(.caption.bold())
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color.red.opacity(0.8))
                    .cornerRadius(10)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 4)
    }
    
    private var startScreenView: some View {
        VStack(spacing: 8) {
            // Game info (compact - minimal padding)
            VStack(spacing: 2) {
                HStack(spacing: 6) {
                    Image(systemName: gameModeIcon)
                        .font(.caption)
                    Text(L(gameMode.nameKey, language: appLanguage))
                        .font(.caption.bold())
                }
                
                Text(proMode ? L("ProMode", language: appLanguage) : L("StandardMode", language: appLanguage))
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 4)
            
            // Play Button
            Button {
                startGame()
            } label: {
                HStack {
                    Image(systemName: "play.fill")
                    Text(L("Start", language: appLanguage))
                }
                .font(.headline.bold())
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(Color.accentColor)
                .cornerRadius(12)
            }
            .buttonStyle(.plain)
            
            // Settings hint
            Text(L("TapSettingsToChangeMode", language: appLanguage))
                .font(.system(size: 9))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
    }
    
    private var gameModeIcon: String {
        switch gameMode {
        case .colors:
            return "paintpalette.fill"
        case .numbers:
            return "number.square.fill"
        case .shapes:
            return "star.square.fill"
        case .flags:
            return "flag.fill"
        case .emojis:
            return "face.smiling.fill"
        }
    }
    
    // MARK: - Level Complete Overlay (compact for watchOS)
    private var levelCompleteOverlay: some View {
        ZStack {
            Color.black.opacity(0.85)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Scrollable content
                ScrollView {
                    VStack(spacing: 10) {
                        // Celebration Icon (reduced spacing)
                        Image(systemName: "star.fill")
                            .font(.system(size: 32))
                            .foregroundStyle(.yellow)
                            .shadow(color: .yellow.opacity(0.5), radius: 8)
                            .padding(.top, 8)
                        
                        // Level Complete Text
                        VStack(spacing: 2) {
                            Text("\(L("Level", language: appLanguage)) \(level - 1)")
                                .font(.system(size: 10))
                                .foregroundStyle(.white)
                            
                            Text(L("LevelComplete", language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.white)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }
                        
                        // Score for this level
                        VStack(spacing: 4) {
                            Text(L("LevelScore", language: appLanguage))
                                .font(.system(size: 9))
                                .foregroundStyle(.white.opacity(0.8))
                            
                            if let previousLevelScore = levelScores[level - 1] {
                                Text("\(previousLevelScore > 0 ? "+" : "")\(previousLevelScore)")
                                    .font(.system(size: 24, weight: .bold, design: .rounded))
                                    .foregroundStyle(previousLevelScore > 0 ? Color.green : Color.red)
                            }
                        }
                        .padding(.vertical, 8)
                        .padding(.horizontal, 12)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(8)
                        
                        // Show new achievements if any
                        if !newAchievementsThisRun.isEmpty {
                            VStack(spacing: 6) {
                                Text(L("NewAchievement", language: appLanguage))
                                    .font(.caption.bold())
                                    .foregroundStyle(.white)
                                
                                ForEach(Achievement.all.filter { newAchievementsThisRun.contains($0.id) }, id: \.id) { achievement in
                                    HStack(spacing: 6) {
                                        Text(achievement.iconEmoji)
                                            .font(.system(size: 18))
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(L(achievement.nameKey, language: appLanguage))
                                                .font(.system(size: 9, weight: .bold))
                                                .foregroundStyle(.white)
                                            Text(L(achievement.explanationKey, language: appLanguage))
                                                .font(.system(size: 8))
                                                .foregroundStyle(.white.opacity(0.8))
                                                .lineLimit(2)
                                        }
                                    }
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 6)
                                    .background(Color.white.opacity(0.15))
                                    .cornerRadius(8)
                                }
                            }
                            .padding(.horizontal, 8)
                        }
                        
                        // Extra bottom padding for scroll content
                        Color.clear.frame(height: 8)
                    }
                    .padding(.horizontal, 12)
                }
                
                // Fixed buttons at bottom
                VStack(spacing: 0) {
                    Divider()
                        .background(Color.white.opacity(0.3))
                    
                    HStack(spacing: 8) {
                        // Continue Button
                        Button {
                            withAnimation {
                                showLevelComplete = false
                                startNextLevel()
                            }
                        } label: {
                            HStack(spacing: 4) {
                                Text(L("Continue", language: appLanguage))
                                Image(systemName: "arrow.right")
                            }
                            .font(.caption.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                            .background(Color.accentColor)
                            .cornerRadius(8)
                        }
                        .buttonStyle(.plain)
                        
                        // Quit Button (icon only)
                        Button {
                            withAnimation {
                                showLevelComplete = false
                                // Don't call quitGame()/endGameEarly() which would save levelScore again
                                // Just finalize and show summary
                                isPlaying = false
                                invalidateTimer()
                                
                                // Calculate final score from positive levels only
                                let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
                                highscoreStore.add(score: finalScore, playerName: playerName, maxLevel: level - 1, achievementIDs: newAchievementsThisRun, gameMode: gameMode.rawValue, isPro: proMode)
                                totalScore = finalScore
                                feedbackManager.trigger(.gameOver)
                                showSummary = true
                            }
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .font(.caption.bold())
                                .foregroundStyle(.white)
                                .frame(width: 40)
                                .padding(.vertical, 8)
                                .background(Color.red.opacity(0.8))
                                .cornerRadius(8)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 8)
                    .padding(.top, 8)
                    .padding(.bottom, 4)
                    .background(Color.black.opacity(0.3))
                }
                .edgesIgnoringSafeArea(.bottom)
            }
        }
        .transition(.scale.combined(with: .opacity))
    }
    
    // MARK: - Score Delta Overlay (compact for watchOS)
    private func scoreDeltaOverlay(delta: Int) -> some View {
        VStack(spacing: 4) {
            // Animated Icon
            Image(systemName: delta > 0 ? "checkmark.circle.fill" : "xmark.circle.fill")
                .font(.system(size: 30))
                .foregroundStyle(delta > 0 ? Color.green : Color.red)
                .shadow(color: (delta > 0 ? Color.green : Color.red).opacity(0.5), radius: 10)
            
            // Score Delta
            Text(delta > 0 ? "+\(delta)" : "\(delta)")
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .foregroundStyle(delta > 0 ? Color.green : Color.red)
                .shadow(color: (delta > 0 ? Color.green : Color.red).opacity(0.3), radius: 6)
        }
        .scaleEffect(reduceMotion ? 1.1 : 1.2)
        .transition(reduceMotion ? .opacity : .scale.combined(with: .opacity))
        .animation(reduceMotion ? .easeInOut(duration: 0.2) : .spring(response: 0.4, dampingFraction: 0.6), value: scoreDelta)
    }
    
    // MARK: - Dev Mode Helper
    private func autoSolveRound() {
        guard isDevMode && isPlaying else { return }
        
        // Find the correct tile (for watchOS, there's only one correct tile)
        if let correctTile = tiles.first(where: { $0.isCorrect }) {
            handleTileTap(tile: correctTile)
        }
    }
    
    // MARK: - Game Logic
    private func startGame() {
        isPlaying = true
        if round > 0 {
            // Resume from pause: provide start/resume feedback
            Logger.game.info("Game resumed from pause: level=\(level), round=\(round), totalScore=\(totalScore)")
            feedbackManager.trigger(.gameStart)
        }
        if round == 0 {
            level = isDevMode ? startLevel : 1  // Dev Mode: Start at configured level
            totalScore = 0
            levelScore = 0
            levelScores = [:]
            consecutiveTimeouts = 0  // Reset timeout counter
            consecutiveWrongTaps = 0  // Reset wrong tap counter
            newAchievementsThisRun = []  // Reset achievements for new game
            mistakesThisLevel = 0  // Reset mistakes counter
            
            Logger.game.info("Game started: mode=\(gameMode.rawValue), isPro=\(proMode), startLevel=\(level), playerName=\(playerName, privacy: .private), isDevMode=\(isDevMode)")
            
            // Randomize shapes/flags/emoji selection at start of new game
            if gameMode == .shapes {
                let sourceShapes = proMode ? GameShape.proShapes : GameShape.standardShapes
                sessionShapes = sourceShapes.shuffled()
                sessionFlags = []  // Clear flags for shapes mode
                sessionEmojis = []  // Clear emojis for shapes mode
            } else if gameMode == .flags {
                let sourceFlags = proMode ? GameFlag.proFlags : GameFlag.standardFlags
                sessionFlags = sourceFlags.shuffled()
                sessionShapes = []  // Clear shapes for flags mode
                sessionEmojis = []  // Clear emojis for flags mode
            } else if gameMode == .emojis {
                let sourceEmojis = proMode ? GameEmoji.proEmojis : GameEmoji.standardEmojis
                sessionEmojis = sourceEmojis.shuffled()
                sessionShapes = []  // Clear shapes for emoji mode
                sessionFlags = []  // Clear flags for emoji mode
            } else {
                sessionShapes = []  // Clear for color/number modes
                sessionFlags = []  // Clear for color/number modes
                sessionEmojis = []  // Clear for color/number modes
            }
            
            feedbackManager.trigger(.gameStart)
            nextRound()
        }
        startTimer()
    }
    
    private func pauseGame() {
        Logger.game.info("Game paused: level=\(level), round=\(round), totalScore=\(totalScore)")
        isPlaying = false
        invalidateTimer()
        
        // Generate new tiles to prevent cheating
        // Keep the same round number but generate new tiles
        round -= 1  // Decrement because nextRound() will increment it again
        nextRound()
    }
    
    private func resetGame() {
        Logger.game.info("Game reset: previousLevel=\(level), previousTotalScore=\(totalScore)")
        level = 1
        round = 0
        totalScore = 0
        levelScore = 0
        levelScores = [:]
        tiles = []
        sessionShapes = []  // Clear session shapes
        sessionFlags = []  // Clear session flags
        sessionEmojis = []  // Clear session emojis
        consecutiveTimeouts = 0  // Reset timeout counter
        consecutiveWrongTaps = 0  // Reset wrong tap counter
        newAchievementsThisRun = []  // Reset achievements
        mistakesThisLevel = 0  // Reset mistakes counter
        invalidateTimer()
    }
    
    private func startNextLevel() {
        round = 0
        levelScore = 0
        consecutiveTimeouts = 0  // Reset timeout counter for new level
        consecutiveWrongTaps = 0  // Reset wrong tap counter for new level
        mistakesThisLevel = 0  // Reset mistakes counter for new level
        isPlaying = true
        feedbackManager.trigger(.gameStart)
        nextRound()
        startTimer()
    }
    
    private func nextRound() {
        round += 1
        
        // Check if level is complete
        if round > roundsPerLevel {
            endLevel()
            return
        }
        
        // Fixed 2x2 grid for watchOS = 4 tiles
        let tileCount = 4
        
        switch gameMode {
        case .colors:
            generateColorTiles(count: tileCount)
        case .numbers:
            generateNumberTiles(count: tileCount)
        case .shapes:
            generateShapeTiles(count: tileCount)
        case .flags:
            generateFlagTiles(count: tileCount)
        case .emojis:
            generateEmojiTiles(count: tileCount)
        }
    }
    
    private func generateColorTiles(count: Int) {
        // Select colors for tiles
        var selectedColors: [GameColor] = []
        if count <= availableColors.count {
            let shuffled = availableColors.shuffled()
            selectedColors = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedColors.append(availableColors.randomElement()!)
            }
        }
        
        // Pick one index as the correct one
        let correctIdx = Int.random(in: 0..<count)
        
        // Create labels: one correct, rest incorrect
        var labelArray = [GameColor](repeating: selectedColors[0], count: count)
        labelArray[correctIdx] = selectedColors[correctIdx]
        
        for i in 0..<count where i != correctIdx {
            let tileColorKey = selectedColors[i].nameKey
            let candidates = availableColors.filter { $0.nameKey != tileColorKey }
            if let choice = candidates.randomElement() {
                labelArray[i] = choice
            } else {
                labelArray[i] = availableColors.randomElement()!
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .color(labelArray[i]),
                backgroundContent: .color(selectedColors[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateNumberTiles(count: Int) {
        // Select numbers for tiles
        var selectedNumbers: [GameNumber] = []
        if count <= availableNumbers.count {
            let shuffled = availableNumbers.shuffled()
            selectedNumbers = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedNumbers.append(availableNumbers.randomElement()!)
            }
        }
        
        // Pick one index as the correct one
        let correctIdx = Int.random(in: 0..<count)
        
        // Create labels: one correct, rest incorrect
        var labelArray = [GameNumber](repeating: selectedNumbers[0], count: count)
        labelArray[correctIdx] = selectedNumbers[correctIdx]
        
        for i in 0..<count where i != correctIdx {
            let tileNumberKey = selectedNumbers[i].nameKey
            let candidates = availableNumbers.filter { $0.nameKey != tileNumberKey }
            if let choice = candidates.randomElement() {
                labelArray[i] = choice
            } else {
                labelArray[i] = availableNumbers.randomElement()!
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .number(labelArray[i]),
                backgroundContent: .number(selectedNumbers[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateShapeTiles(count: Int) {
        // Select shapes for tiles
        var selectedShapes: [GameShape] = []
        if count <= availableShapes.count {
            let shuffled = availableShapes.shuffled()
            selectedShapes = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedShapes.append(availableShapes.randomElement()!)
            }
        }
        
        // Pick one index as the correct one
        let correctIdx = Int.random(in: 0..<count)
        
        // Create labels: one correct, rest incorrect
        var labelArray = [GameShape](repeating: selectedShapes[0], count: count)
        labelArray[correctIdx] = selectedShapes[correctIdx]
        
        for i in 0..<count where i != correctIdx {
            let tileShapeKey = selectedShapes[i].nameKey
            let candidates = availableShapes.filter { $0.nameKey != tileShapeKey }
            if let choice = candidates.randomElement() {
                labelArray[i] = choice
            } else {
                labelArray[i] = availableShapes.randomElement()!
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .shape(labelArray[i]),
                backgroundContent: .shape(selectedShapes[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateFlagTiles(count: Int) {
        // Select flags for tiles
        var selectedFlags: [GameFlag] = []
        if count <= availableFlags.count {
            let shuffled = availableFlags.shuffled()
            selectedFlags = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedFlags.append(availableFlags.randomElement()!)
            }
        }
        
        // Pick one index as the correct one
        let correctIdx = Int.random(in: 0..<count)
        
        // Create labels: one correct, rest incorrect
        var labelArray = [GameFlag](repeating: selectedFlags[0], count: count)
        labelArray[correctIdx] = selectedFlags[correctIdx]
        
        for i in 0..<count where i != correctIdx {
            let tileFlagKey = selectedFlags[i].nameKey
            let candidates = availableFlags.filter { $0.nameKey != tileFlagKey }
            if let choice = candidates.randomElement() {
                labelArray[i] = choice
            } else {
                labelArray[i] = availableFlags.randomElement()!
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .flag(labelArray[i]),
                backgroundContent: .flag(selectedFlags[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateEmojiTiles(count: Int) {
        // Select emojis for tiles
        var selectedEmojis: [GameEmoji] = []
        if count <= availableEmojis.count {
            let shuffled = availableEmojis.shuffled()
            selectedEmojis = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedEmojis.append(availableEmojis.randomElement()!)
            }
        }
        
        // Pick one index as the correct one
        let correctIdx = Int.random(in: 0..<count)
        
        // Create labels: one correct, rest incorrect
        var labelArray = [GameEmoji](repeating: selectedEmojis[0], count: count)
        labelArray[correctIdx] = selectedEmojis[correctIdx]
        
        for i in 0..<count where i != correctIdx {
            let tileEmojiKey = selectedEmojis[i].nameKey
            let candidates = availableEmojis.filter { $0.nameKey != tileEmojiKey }
            if let choice = candidates.randomElement() {
                labelArray[i] = choice
            } else {
                labelArray[i] = availableEmojis.randomElement()!
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .emoji(labelArray[i]),
                backgroundContent: .emoji(selectedEmojis[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func endLevel() {
        invalidateTimer()
        isPlaying = false
        
        // Store the score for this level
        levelScores[level] = levelScore
        
        Logger.game.notice("Level completed: level=\(level), levelScore=\(levelScore), totalScore=\(totalScore), mistakes=\(mistakesThisLevel)")
        
        // Track level completion for achievements (only if level completed successfully)
        if levelScore > 0 {
            achievementStore.markLevelCompletion(level: level, mode: gameMode, isPro: proMode)
            let newAchievements = achievementStore.checkAndUnlockAchievements()
            newAchievementsThisRun.append(contentsOf: newAchievements)
            
            if !newAchievements.isEmpty {
                Logger.achievements.notice("Achievements unlocked: count=\(newAchievements.count), ids=\(Logger.formatAchievementIDs(newAchievements))")
            }
        }
        
        if levelScore <= 0 {
            // Game Over - calculate total from positive levels only
            let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
            highscoreStore.add(score: finalScore, playerName: playerName, maxLevel: level, achievementIDs: newAchievementsThisRun, gameMode: gameMode.rawValue, isPro: proMode)
            totalScore = finalScore  // Update display score
            Logger.game.info("Game ended: reason=negativeScore, level=\(level), finalScore=\(finalScore), maxLevel=\(level)")
            feedbackManager.trigger(.gameOver)
            showSummary = true
        } else {
            // Add positive score to total
            totalScore += levelScore
            
            // Trigger level complete feedback
            feedbackManager.trigger(.levelComplete)
            
            // Show level complete screen
            level += 1
            withAnimation {
                showLevelComplete = true
            }
        }
    }
    
    private func handleTileTap(tile: TileData) {
        // Provide immediate tap feedback for responsiveness
        feedbackManager.trigger(.tileTap)
        
        let isCorrect = tile.isCorrect
        
        // Use new simplified scoring system (same as iOS)
        let points = calculateRoundScore(secondsRemaining: timeRemaining)
        
        if isCorrect {
            // Reset both counters on correct tap
            consecutiveTimeouts = 0
            consecutiveWrongTaps = 0
            levelScore += points
            showScoreDelta(points)
            
            // Trigger positive feedback
            feedbackManager.trigger(.correctTap)
        } else {
            // Wrong tap - increment mistake counter
            mistakesThisLevel += 1
            
            levelScore -= points
            showScoreDelta(-points)
            
            // Trigger negative feedback
            feedbackManager.trigger(.wrongTap)
            
            // Check if this is the second mistake (game over)
            if mistakesThisLevel >= 2 {
                // End the game immediately on second mistake
                invalidateTimer()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.endGameEarly()
                }
                return
            } else {
                // First mistake - continue playing but show warning
                // Continue to next round after brief pause
            }
        }
        
        // Pause briefly for feedback
        invalidateTimer()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            if self.isPlaying {
                self.nextRound()
                self.startTimer()
            }
        }
    }
    
    private func showScoreDelta(_ delta: Int) {
        scoreDelta = delta
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            scoreDelta = nil
        }
    }
    
    private func startTimer() {
        invalidateTimer()
        timeRemaining = currentRoundDuration
        timerProgress = 1.0
        isLowTimeWarningTriggered = false  // Reset warning flag
        
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
            if self.isPlaying {
                self.timeRemaining -= 0.05
                self.timerProgress = max(0, self.timeRemaining / self.currentRoundDuration)
                
                // Trigger warning when time drops below 25% (only once per round)
                if self.timerProgress < 0.25 && !self.isLowTimeWarningTriggered {
                    self.isLowTimeWarningTriggered = true
                    self.feedbackManager.trigger(.timeWarning)
                }
                
                if self.timeRemaining <= 0 {
                    self.handleTimeout()
                }
            }
        }
    }
    
    private func handleTimeout() {
        // Trigger timeout feedback
        feedbackManager.trigger(.timeout)
        
        // Increment mistake counter
        mistakesThisLevel += 1
        
        Logger.game.error("Round timeout: level=\(level), round=\(round), mistakesThisLevel=\(mistakesThisLevel)")
        
        // Check if this is the second mistake (game over)
        if mistakesThisLevel >= 2 {
            Logger.game.error("Game over: two mistakes in level (timeout)")
            // Game ends on second mistake
            endGameEarly()
        } else {
            // First mistake - continue to next round after brief pause
            invalidateTimer()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                if self.isPlaying {
                    self.nextRound()
                    self.startTimer()
                }
            }
        }
    }
    
    private func endGameEarly() {
        invalidateTimer()
        isPlaying = false
        
        // Store the score for this level
        levelScores[level] = levelScore
        
        // Calculate final score from positive levels only
        let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
        highscoreStore.add(score: finalScore, playerName: playerName, maxLevel: level, achievementIDs: newAchievementsThisRun, gameMode: gameMode.rawValue, isPro: proMode)
        totalScore = finalScore
        
        Logger.game.info("Game ended early: reason=mistakes, level=\(level), round=\(round), finalScore=\(finalScore), maxLevel=\(level)")
        
        feedbackManager.trigger(.gameOver)
        showSummary = true
    }
    
    private func quitGame() {
        endGameEarly()
    }
    
    private func invalidateTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    // MARK: - Helper Functions
    private static func defaultLanguage() -> String {
        // Get the first preferred language from the system
        if let preferredLanguage = Locale.preferredLanguages.first {
            // Check if it starts with "de" for German
            if preferredLanguage.hasPrefix("de") {
                return "de"
            }
        }
        // Default to English for all other languages
        return "en"
    }
    
    static func defaultPlayerName() -> String {
        return "Player"
    }
    
    private func localizedContentName(_ nameKey: String, language: String) -> String {
        return L(nameKey, language: language)
    }
    
    private func textColorForTile(_ tile: TileData) -> Color {
        switch tile.backgroundContent {
        case .color(_):
            // For color tiles, use black text
            return .black.opacity(0.8)
        case .number(_), .shape(_), .emoji(_), .flag(_):
            // For number, shape, emoji and flag tiles, use primary color (adapts to dark/light mode)
            return .primary
        }
    }
    
    // MARK: - Unlock Alert Helpers
    
    private func validateSelections() {
        // Check if current mode is locked
        if !achievementStore.isModeUnlocked(mode: gameMode, isPro: false, playerName: playerName) {
            gameModeRaw = GameMode.colors.rawValue
        }
        
        // Check if Pro mode is locked
        if proMode && !achievementStore.isModeUnlocked(mode: gameMode, isPro: true, playerName: playerName) {
            proMode = false
        }
    }
    
    private func showUnlockAlert(for mode: GameMode) {
        // Find the achievement that unlocks this mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .mode(let unlockMode) = unlocked, unlockMode == mode.rawValue {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
    
    private func showUnlockAlert(forProMode: Bool) {
        // Find the achievement that unlocks Pro mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .proMode = unlocked {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
}

// MARK: - Settings View moved to SettingsView_WatchOS.swift

// MARK: - Summary View moved to SummaryView_WatchOS.swift

// MARK: - Highscore List View moved to HighscoreView_WatchOS.swift

// MARK: - Preview
#Preview {
    ContentView_WatchOS()
}

// MARK: - Achievement Overview View moved to AchievementView_WatchOS.swift

// MARK: - Player Name Selection View moved to PlayerSelectionView_WatchOS.swift

// MARK: - Animated Background moved to AnimatedBackgroundView_WatchOS.swift

