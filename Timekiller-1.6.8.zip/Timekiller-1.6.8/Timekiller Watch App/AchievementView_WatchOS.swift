//
//  AchievementView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI

// MARK: - Achievement Overview View (watchOS optimized)

/// Displays all game achievements organized by difficulty and purpose.
///
/// `AchievementView_WatchOS` presents a comprehensive, scrollable list of all 19 achievements
/// available in the game, grouped into logical categories. Each achievement shows its unlock
/// status, emoji icon, name, and explanation text.
///
/// ## Achievement Categories
///
/// Achievements are organized into 7 sections based on unlock level and purpose:
///
/// ### 1. Early Achievements (Level 5)
/// **First milestone achievements to encourage new players**
///
/// Includes:
/// - Standard Level 5 achievements for each mode (Colors, Shapes, Flags, Emojis)
/// - "Count on Me" (Numbers Level 10) - grouped here as early number achievement
///
/// Purpose: Introduce achievement system, provide early wins
///
/// ### 2. Unlocking Achievements (Levels 10, 20, 30)
/// **Special achievements that unlock new content**
///
/// Four achievements total:
/// - **Polygon Prodigy** (Level 10 Colors): Unlocks Shapes mode
/// - **Flag Dropper** (Level 20 Colors): Unlocks Flags mode
/// - **Smiley Summoner** (Level 20 Shapes): Unlocks Emojis mode
/// - **Ultra Instinct** (Level 30 any mode): Unlocks Pro mode
///
/// Purpose: Gate advanced content, encourage progression
///
/// ### 3. Intermediate Achievements (Level 15)
/// **Mid-game milestones**
///
/// Includes:
/// - Level 15 achievements for modes that have them
/// - Excludes unlocking achievements
///
/// Purpose: Maintain engagement during mid-game
///
/// ### 4. Advanced Achievements (Levels 20-25)
/// **High-skill milestones**
///
/// Includes:
/// - Level 20 and 25 achievements for all modes
/// - Excludes the unlocking achievements from level 20
///
/// Purpose: Challenge skilled players
///
/// ### 5. Mastery Achievements (Level 30 Standard)
/// **Standard mode completion badges**
///
/// Requirements:
/// - Reach level 30 in any mode
/// - Standard mode only (not Pro)
///
/// Purpose: Recognize mode mastery without Pro requirement
///
/// ### 6. Pro Mastery Achievements (Level 30 Pro)
/// **Expert-level completion badges**
///
/// Requirements:
/// - Reach level 30 in any mode
/// - Pro mode required
///
/// Purpose: Recognize ultimate skill and dedication
///
/// ### 7. Ultimate Achievement
/// **Legendary completionist badge**
///
/// Requirement:
/// - Reach level 30 in ALL modes (standard or pro, any combination)
///
/// Purpose: Final challenge for completionists
///
/// ## Achievement Display
///
/// Each achievement row shows:
///
/// ### Visual Elements
/// - **Emoji Icon** (left, 20pt): Thematic representation
///   - Full color if unlocked
///   - Grayscale + 50% opacity if locked
/// - **Name** (top, 9pt bold): Short title
///   - Primary color if unlocked
///   - Secondary color if locked
/// - **Explanation** (bottom, 8pt): How to unlock it
///   - Secondary color, 2-line maximum
/// - **Status Icon** (right):
///   - Green checkmark (unlocked)
///   - Gray lock (locked)
///
/// ## Unlock Status Logic
///
/// Status determined by `achievementStore.isUnlocked(achievement.id)`:
/// - Checks current player's progress via `@AppStorage`
/// - Compares against unlock conditions (level reached, mode, Pro status)
/// - Updates automatically when achievements are earned
///
/// ## Achievement Filtering
///
/// Each section uses computed properties to filter `Achievement.all`:
///
/// ```swift
/// // Example: Early achievements
/// Achievement.all.filter { achievement in
///     if case .reachLevel(5, _, false) = achievement.unlockCondition {
///         return true
///     }
///     return achievement.id == "count_on_me"  // Special case
/// }
/// ```
///
/// Filters support:
/// - Level requirements
/// - Mode requirements
/// - Pro mode requirements
/// - Special content unlocks
/// - Multiple mode completion
///
/// ## watchOS-Specific Optimizations
///
/// ### Compact Display
/// - Small fonts: 9pt names, 8pt descriptions
/// - Small icons: 20pt emoji, 8pt SF Symbols
/// - Tight spacing: 2-6pt vertical gaps
/// - Line limits: 2 lines for descriptions
///
/// ### List Performance
/// - Uses SwiftUI's native List for optimal scrolling
/// - Lazy rendering (only visible items)
/// - Efficient filtering with cached computed properties
/// - No animations or expensive operations
///
/// ### Visual Clarity
/// - Section headers use localized keys
/// - Consistent color coding (green = unlocked, gray = locked)
/// - Grayscale effect for locked achievements
/// - High contrast text colors
///
/// ## Localization
///
/// All text uses localization system:
/// - Section headers: L("EarlyAchievements", language: language)
/// - Achievement names: L(achievement.nameKey, language: language)
/// - Explanations: L(achievement.explanationKey, language: language)
///
/// Supports: English (en), German (de)
///
/// ## Data Flow
///
/// ### Input
/// - `language: String`: Current app language
/// - `playerName: String`: Current player (for per-player tracking)
/// - `achievementStore: AchievementStore`: Tracks unlock status
///
/// ### Output
/// - Read-only display (no user interaction except scrolling)
/// - Achievement store updates happen during gameplay
///
/// ## Integration with Game
///
/// Achievements unlock automatically during gameplay:
/// 1. Player completes level
/// 2. `ContentView_WatchOS` checks unlock conditions
/// 3. Calls `achievementStore.markLevelCompletion(...)`
/// 4. Store checks `Achievement.all` for matches
/// 5. Updates `@AppStorage` with new unlocks
/// 6. This view reflects changes automatically
///
/// ## Example Usage
/// ```swift
/// // In HighscoreView_WatchOS or Settings
/// Button {
///     showAchievements = true
/// } label: {
///     HStack {
///         Image(systemName: "trophy.fill")
///         Text("Achievements")
///     }
/// }
/// .sheet(isPresented: $showAchievements) {
///     NavigationStack {
///         AchievementView_WatchOS(
///             language: appLanguage,
///             playerName: playerName,
///             achievementStore: achievementStore
///         )
///         .navigationTitle("Achievements")
///     }
/// }
/// ```
///
/// ## Accessibility
/// - All text respects Dynamic Type
/// - VoiceOver reads: "Achievement name, explanation, unlocked/locked"
/// - Color differences supplemented with icons and text
/// - Standard List navigation with Digital Crown
///
/// ## Performance Characteristics
/// - **Filtering**: O(n) per section, computed once
/// - **Memory**: ~2KB for all achievement data
/// - **Rendering**: Lazy (only visible rows)
/// - **Updates**: Automatic via `@ObservableObject` store
///
/// - Note: This is the watchOS version. For iOS, use `AchievementView_iOS` which
///   provides larger touch targets and more detailed unlock information.
struct AchievementView_WatchOS: View {
    let language: String
    let playerName: String
    let achievementStore: AchievementStore
    
    var body: some View {
        List {
            // Early Achievements (Level 5)
            Section {
                ForEach(earlyAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("EarlyAchievements", language: language))
            }
            
            // Unlocking Achievements (Level 10, 20, 30)
            Section {
                ForEach(unlockingAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("UnlockingAchievements", language: language))
            }
            
            // Intermediate Achievements (Level 15)
            Section {
                ForEach(intermediateAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("IntermediateAchievements", language: language))
            }
            
            // Advanced Achievements (Level 25)
            Section {
                ForEach(advancedAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("AdvancedAchievements", language: language))
            }
            
            // Mastery Achievements (Level 30 Standard)
            Section {
                ForEach(masteryAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("MasteryAchievements", language: language))
            }
            
            // Pro Mastery Achievements (Level 30 Pro)
            Section {
                ForEach(proMasteryAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("ProMasteryAchievements", language: language))
            }
            
            // Ultimate Achievement
            Section {
                ForEach(ultimateAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("UltimateAchievement", language: language))
            }
        }
    }
    
    // MARK: - Helper Views
    
    @ViewBuilder
    private func achievementRow(achievement: Achievement) -> some View {
        let isUnlocked = achievementStore.isUnlocked(achievement.id)
        
        HStack(spacing: 6) {
            Text(achievement.iconEmoji)
                .font(.system(size: 20))
                .grayscale(isUnlocked ? 0 : 1)
                .opacity(isUnlocked ? 1 : 0.5)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(L(achievement.nameKey, language: language))
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(isUnlocked ? .primary : .secondary)
                
                Text(L(achievement.explanationKey, language: language))
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            
            Spacer()
            
            if isUnlocked {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.green)
                    .font(.caption2)
            } else {
                Image(systemName: "lock.fill")
                    .foregroundStyle(.secondary)
                    .font(.caption2)
            }
        }
        .padding(.vertical, 2)
    }
    
    // MARK: - Achievement Groupings
    
    private var earlyAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(5, _, false) = achievement.unlockCondition {
                return true
            }
            // Include Numbers Level 10 achievement
            if achievement.id == "count_on_me" {
                return true
            }
            return false
        }
    }
    
    private var unlockingAchievements: [Achievement] {
        ["polygon_prodigy", "flag_dropper", "smiley_summoner", "ultra_instinct"].compactMap { id in
            Achievement.all.first { $0.id == id }
        }
    }
    
    private var intermediateAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            // Include level 10 and level 15 achievements (but not the unlocking ones)
            if case .reachLevel(let level, _, false) = achievement.unlockCondition {
                return (level == 15) && achievement.unlocksContent == nil
            }
            return false
        }
    }
    
    private var advancedAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            // Include level 20 and level 25 achievements (but not the unlocking ones)
            if case .reachLevel(let level, _, false) = achievement.unlockCondition {
                return (level == 20 || level == 25) && achievement.unlocksContent == nil
            }
            return false
        }
    }
    
    private var masteryAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(30, _, false) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var proMasteryAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(30, _, true) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var ultimateAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevelInAllModes = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
}

// MARK: - Preview
#Preview {
    NavigationStack {
        AchievementView_WatchOS(
            language: "en",
            playerName: "Player",
            achievementStore: AchievementStore()
        )
        .navigationTitle("Achievements")
        .navigationBarTitleDisplayMode(.inline)
    }
}
