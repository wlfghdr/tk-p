//
//  PlayerSelectionView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI
import OSLog

// MARK: - Player Name Selection View (watchOS optimized)

/// A compact player profile management interface optimized for Apple Watch.
///
/// `PlayerNameSelectionView_WatchOS` provides the same player switching functionality
/// as the iOS version but with a simplified, Watch-optimized layout. It enables multiple
/// users to share an Apple Watch while maintaining separate achievement progress.
///
/// ## Core Features
///
/// ### 1. Player List Display
/// Shows all existing players with:
/// - **Player Name**: Caption-sized bold text (watchOS typography)
/// - **Achievement Count**: 9pt system font (more compact than iOS)
/// - **Current Player Indicator**: Small green checkmark (caption2 font)
/// - **Swipe to Delete**: Trailing swipe action (same as iOS)
///
/// ### 2. Player Selection
/// Tapping any player row:
/// 1. Sets that player as active
/// 2. Updates `AchievementStore.currentPlayerName`
/// 3. Dismisses the sheet automatically
/// 4. **Note**: Unlike iOS, does NOT reset game mode/Pro mode (watchOS has no binding for these)
///
/// ### 3. New Player Creation
/// Two-step compact flow:
/// 1. Tap "Create New Player" button → Shows text field (caption font)
/// 2. Enter name + tap checkmark → Player created and selected
///
/// Validation:
/// - Name cannot be empty (checkmark disabled)
/// - Whitespace is trimmed automatically
/// - Uses `AchievementStore.createPlayer()`
///
/// ### 4. Player Deletion
/// Same swipe-to-delete as iOS:
/// - Confirmation alert before deleting
/// - Auto-switches if deleting current player
/// - Cannot delete all players (creates "Player" as fallback)
///
/// ## watchOS Optimizations
///
/// ### Typography
/// - **Player Name**: `.caption.bold()` (vs `.body.bold()` on iOS)
/// - **Achievement Count**: `.system(size: 9)` (vs `.caption` on iOS)
/// - **Section Headers**: System default (smaller than iOS)
///
/// ### Layout
/// - **Compact Spacing**: 2pt in player rows (vs 4pt on iOS)
/// - **Smaller Icons**: `.caption2` size (vs `.title2` on iOS)
/// - **Vertical Layout**: Text field stacked with buttons (vs horizontal HStack on iOS)
///
/// ### Simplified Sections
/// Each section is extracted to computed properties:
/// - `existingPlayersSection`: List of players
/// - `newPlayerSection`: Create player UI
/// - `playerRow(player:)`: Individual player display
/// - `newPlayerInputView`: Text field + buttons
/// - `createPlayerButton`: Initial create button
///
/// This improves readability and reduces nesting on small screens.
///
/// ## Data Flow
///
/// ### Initialization
/// ```swift
/// PlayerNameSelectionView_WatchOS(
///     playerName: $playerName,
///     achievementStore: achievementStore,
///     language: appLanguage
/// )
/// ```
///
/// **Key Difference from iOS**: No bindings for `gameModeRaw` or `proMode`.
/// watchOS version does not reset game settings when switching players.
///
/// ### Player List Management
/// - `existingPlayersList`: State array from `AchievementStore.getAllPlayerNames()`
/// - `refreshPlayerList()`: Called on appear, after create, after delete
/// - Same behavior as iOS version
///
/// ## User Experience
///
/// ### Navigation
/// - Presented as a sheet from Settings
/// - Inline navigation title (smaller than large title)
/// - Auto-dismisses when player is selected
///
/// ### Visual Feedback
/// - Green checkmark for current player
/// - Red delete button on swipe
/// - Checkmark/X buttons in caption font
/// - Vertical spacing optimized for 40mm-49mm displays
///
/// ### Digital Crown
/// - Scrollable list works with Digital Crown
/// - Text entry uses Scribble/Dictation input
/// - Swipe gestures work naturally
///
/// ## Layout Structure (Simplified)
/// ```
/// NavigationStack
///   List
///     existingPlayersSection  (if !empty)
///     newPlayerSection
/// ```
///
/// All section complexity is hidden in computed properties for cleaner code.
///
/// ## State Management
/// Same state properties as iOS:
/// - `newPlayerName`: Text field input
/// - `showingNewPlayerInput`: Toggle button/text field
/// - `showingDeleteConfirmation`: Delete alert
/// - `playerToDelete`: Player pending deletion
/// - `existingPlayersList`: Cached player list
///
/// ## Helper Functions
/// Identical implementations to iOS version:
/// - `refreshPlayerList()`: Loads player names
/// - `selectPlayer(_:)`: Activates a player
/// - `createNewPlayer()`: Creates and selects new player
/// - `deletePlayer(_:)`: Removes player with safety checks
///
/// ## Platform Considerations
/// - **watchOS Only**: This is the Watch-optimized version
/// - **No Game Center**: watchOS version uses local storage only
/// - **Simplified Settings**: Fewer game configuration options than iOS
///
/// ## Accessibility
/// - VoiceOver reads player names and counts
/// - Button actions are clearly labeled
/// - Text input supports watchOS dictation
/// - Swipe actions have accessible labels
///
/// - Note: For the full-featured iOS version, see `PlayerNameSelectionView_iOS` which
///   includes game mode/Pro mode reset logic and more detailed layouts.
struct PlayerNameSelectionView_WatchOS: View {
    @Binding var playerName: String
    let achievementStore: AchievementStore
    let language: String
    
    @Environment(\.dismiss) private var dismiss
    
    @State private var newPlayerName: String = ""
    @State private var showingNewPlayerInput: Bool = false
    @State private var showingDeleteConfirmation: Bool = false
    @State private var playerToDelete: String? = nil
    @State private var existingPlayersList: [String] = []
    
    var body: some View {
        NavigationStack {
            List {
                // Existing players section
                if !existingPlayersList.isEmpty {
                    existingPlayersSection
                }
                
                // Create new player section
                newPlayerSection
            }
            .navigationTitle(L("SelectPlayer", language: language))
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                refreshPlayerList()
            }
            .alert(L("DeletePlayerConfirmation", language: language), isPresented: $showingDeleteConfirmation) {
                Button(L("Cancel", language: language), role: .cancel) {
                    playerToDelete = nil
                }
                Button(L("Delete", language: language), role: .destructive) {
                    if let player = playerToDelete {
                        deletePlayer(player)
                    }
                    playerToDelete = nil
                }
            } message: {
                Text(L("DeletePlayerMessage", language: language))
            }
        }
    }
    
    // MARK: - Section Views
    
    private var existingPlayersSection: some View {
        Section {
            ForEach(existingPlayersList, id: \.self) { player in
                playerRow(player: player)
            }
        } header: {
            Text(L("ExistingPlayers", language: language))
        }
    }
    
    private func playerRow(player: String) -> some View {
        Button {
            selectPlayer(player)
        } label: {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(player)
                        .font(.caption.bold())
                    
                    let count = achievementStore.getAchievementCount(for: player)
                    if count > 0 {
                        Text("\(count) \(L("AchievementsCount", language: language))")
                            .font(.system(size: 9))
                            .foregroundStyle(.secondary)
                    } else {
                        Text(L("NoAchievements", language: language))
                            .font(.system(size: 9))
                            .foregroundStyle(.secondary)
                    }
                }
                
                Spacer()
                
                if player == playerName {
                    Image(systemName: "checkmark")
                        .foregroundStyle(.green)
                        .font(.caption2)
                }
            }
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button(role: .destructive) {
                playerToDelete = player
                showingDeleteConfirmation = true
            } label: {
                Label(L("Delete", language: language), systemImage: "trash")
            }
        }
    }
    
    private var newPlayerSection: some View {
        Section {
            if showingNewPlayerInput {
                newPlayerInputView
            } else {
                createPlayerButton
            }
        } header: {
            Text(L("NewPlayer", language: language))
        }
    }
    
    private var newPlayerInputView: some View {
        VStack(spacing: 6) {
            TextField(L("EnterPlayerName", language: language), text: $newPlayerName)
                .font(.caption)
            
            HStack(spacing: 8) {
                Button {
                    createNewPlayer()
                } label: {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                }
                .disabled(newPlayerName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                
                Button {
                    showingNewPlayerInput = false
                    newPlayerName = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.red)
                }
            }
        }
    }
    
    private var createPlayerButton: some View {
        Button {
            showingNewPlayerInput = true
        } label: {
            HStack {
                Image(systemName: "plus.circle.fill")
                    .font(.caption)
                Text(L("CreateNewPlayer", language: language))
                    .font(.caption)
            }
        }
    }
    
    // MARK: - Helper Functions
    
    /// Refreshes the player list from achievement store.
    ///
    /// Called when:
    /// - View appears
    /// - Player is created
    /// - Player is deleted
    ///
    /// Updates `existingPlayersList` state with current player names.
    private func refreshPlayerList() {
        existingPlayersList = achievementStore.getAllPlayerNames()
    }
    
    /// Selects a player and dismisses the sheet.
    ///
    /// This function:
    /// 1. Updates the binding to set active player
    /// 2. Syncs achievement store's current player
    /// 3. Dismisses the player selection sheet
    ///
    /// **Note**: Unlike iOS version, does not reset game mode or Pro mode settings.
    /// watchOS version keeps all settings when switching players.
    ///
    /// - Parameter player: Name of player to activate
    private func selectPlayer(_ player: String) {
        Logger.app.info("Player selected in watchOS: \(player, privacy: .private)")
        playerName = player
        achievementStore.currentPlayerName = player
        dismiss()
    }
    
    /// Creates a new player profile and selects it.
    ///
    /// This function performs the following steps:
    /// 1. **Validation**: Trims whitespace and checks for empty name
    /// 2. **Creation**: Calls `achievementStore.createPlayer(name:)` to initialize profile
    /// 3. **Selection**: Sets new player as active in both binding and store
    /// 4. **UI Update**: Refreshes player list to show new entry
    /// 5. **Cleanup**: Resets input field and hides text entry UI
    /// 6. **Dismissal**: Auto-dismisses sheet after 0.1s delay
    ///
    /// The delay ensures parent view receives binding update before sheet dismisses.
    ///
    /// ## New Player Initialization
    /// When a player is created:
    /// - Empty achievement dictionary is created in AppStorage
    /// - No achievements are unlocked by default
    /// - Player starts with standard mode and level 1
    /// - Settings persist independently per player
    ///
    /// - Precondition: `newPlayerName` must not be empty after trimming
    private func createNewPlayer() {
        let trimmedName = newPlayerName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else {
            Logger.app.warning("Attempted to create player with empty name in watchOS")
            return
        }
        
        Logger.app.info("Creating new player in watchOS: \(trimmedName, privacy: .private)")
        
        // Use AchievementStore's createPlayer method
        achievementStore.createPlayer(name: trimmedName)
        
        // Select the new player immediately
        playerName = trimmedName
        achievementStore.currentPlayerName = trimmedName
        
        // Refresh the list to show the new player
        refreshPlayerList()
        
        // Reset input
        newPlayerName = ""
        showingNewPlayerInput = false
        
        // Dismiss after a short delay to ensure the parent view updates
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            dismiss()
        }
    }
    
    /// Deletes a player profile with safety checks.
    ///
    /// This function handles three scenarios:
    ///
    /// ### Scenario 1: Deleting a Different Player
    /// - Simply removes player from achievement store
    /// - Current player remains unchanged
    /// - List updates to reflect deletion
    ///
    /// ### Scenario 2: Deleting Current Player (With Others)
    /// - Switches to first remaining player in list
    /// - Updates both binding and achievement store
    /// - Then deletes the original player
    /// - Prevents "no active player" state
    ///
    /// ### Scenario 3: Deleting Last Player
    /// - Creates default "Player" profile
    /// - Sets as active player
    /// - Then deletes the original player
    /// - Ensures app always has at least one player
    ///
    /// ## Achievement Data
    /// When a player is deleted:
    /// - Their achievement dictionary is removed from AppStorage
    /// - Highscores attributed to them remain in history
    /// - Deletion is permanent and cannot be undone
    ///
    /// - Parameter player: Name of player to delete
    private func deletePlayer(_ player: String) {
        // If deleting the current player, switch to a different player or create default
        if player == playerName {
            let remainingPlayers = existingPlayersList.filter { $0 != player }
            if let firstPlayer = remainingPlayers.first {
                playerName = firstPlayer
                achievementStore.currentPlayerName = firstPlayer
            } else {
                // No players left, create default "Player"
                playerName = "Player"
                achievementStore.currentPlayerName = "Player"
                achievementStore.createPlayer(name: "Player")
            }
        }
        
        // Delete the player
        achievementStore.deletePlayer(name: player)
        
        // Refresh the list
        refreshPlayerList()
    }
}

// MARK: - Preview
#Preview {
    PlayerNameSelectionView_WatchOS(
        playerName: .constant("Player"),
        achievementStore: AchievementStore(),
        language: "en"
    )
}
