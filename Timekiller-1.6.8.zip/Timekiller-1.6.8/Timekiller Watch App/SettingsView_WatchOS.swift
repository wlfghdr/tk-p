//
//  SettingsView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI
import OSLog

// MARK: - Settings View (watchOS optimized)

/// Comprehensive settings screen optimized for Apple Watch's compact display.
///
/// `SettingsView_WatchOS` provides access to all game configuration options in a
/// scrollable, sectioned list format. It includes game mode selection, difficulty
/// settings, feedback preferences, player management, appearance customization,
/// language selection, and developer mode features.
///
/// ## Settings Sections
///
/// ### 1. Developer Mode Section (Conditional)
/// **Only visible when player name is "Wulf" (case-insensitive)**
///
/// Features:
/// - **Status Indicator**: Orange checkmark showing Dev Mode is active
/// - **Start Level Picker**: Choose starting level from 1-30 (bypasses normal progression)
/// - **Feature List**: Documents two Dev Mode capabilities:
///   1. Auto-solve: Tap pause button during gameplay to solve current round
///   2. Custom start level: Begin game at any level
///
/// This section is completely hidden for non-developer players.
///
/// ### 2. Game Mode Section
/// **Select which game type to play**
///
/// Available modes:
/// - **Colors**: Match color names to colored backgrounds
/// - **Numbers**: Match number words to numeric backgrounds
/// - **Shapes**: Match shape names to geometric shapes (locked initially)
/// - **Flags**: Match country names to flag emojis (locked initially)
/// - **Emojis**: Match emoji names to emoji characters (locked initially)
///
/// Locked modes show:
/// - Lock icon (🔒)
/// - Grayed out appearance (60% opacity)
/// - Alert with unlock requirements when tapped
///
/// Unlocked modes show:
/// - Full color and opacity
/// - Checkmark when selected (blue)
/// - Highlighted background when selected (blue, 15% opacity)
///
/// ### 3. Difficulty Section
/// **Toggle Pro Mode for increased challenge**
///
/// Pro Mode changes:
/// - 16 items instead of 8 (Colors, Shapes, Flags, Emojis modes)
/// - 1-20 instead of 1-10 (Numbers mode)
/// - 1.5× score multiplier
/// - Must be unlocked by achievement
///
/// Display:
/// - **Locked**: Shows lock icon, tapping displays unlock requirements
/// - **Unlocked**: Toggle switch with mode-specific description
///
/// Description adapts to current game mode:
/// - "8 → 16 colors" (Colors)
/// - "10 → 20 numbers" (Numbers)
/// - "8 → 16 shapes" (Shapes)
/// - "8 → 16 flags" (Flags)
/// - "8 → 16 emojis" (Emojis)
///
/// ### 4. Feedback Section
/// **Control sensory feedback during gameplay**
///
/// - **Sound Toggle**: Enable/disable sound effects (correct/wrong/timeout)
/// - **Haptics Toggle**: Enable/disable haptic feedback (vibrations)
///
/// Both settings persist across sessions and sync with `FeedbackManager`.
///
/// ### 5. Player Section
/// **Manage current player identity**
///
/// Features:
/// - **Name TextField**: Edit current player name
///   - Auto-trims whitespace while typing
///   - Sets default "Player" on submit if empty
///   - Affects achievement tracking and highscore attribution
/// - **Switch Player Button**: Opens player selection sheet
///   - Allows switching between existing players
///   - Each player has separate achievement progress
///
/// ### 6. Theme Section
/// **Control app appearance**
///
/// Options:
/// - **System** (default): Follows watchOS appearance settings
/// - **Light**: Always use light mode
/// - **Dark**: Always use dark mode
///
/// Picker-style selection, changes take effect immediately.
///
/// ### 7. Language Section
/// **Select app language**
///
/// Options:
/// - **German** (Deutsch)
/// - **English**
///
/// Picker-style selection. Changing language:
/// - Updates all UI text immediately
/// - Resets current game if one is in progress
/// - Persists across app launches
///
/// ### 8. About Section
/// **Display app version information**
///
/// Shows: "Version 1.0 (1)" format
/// - First number: Marketing version (CFBundleShortVersionString)
/// - Second number: Build number (CFBundleVersion)
///
/// ## Lock Alert System
///
/// When user taps locked feature:
/// 1. Finds achievement that unlocks the feature
/// 2. Extracts achievement name and explanation
/// 3. Formats message: "Unlock by [emoji] [name] – [explanation]"
/// 4. Displays in system alert with "Done" button
///
/// Example: "Unlock by 🔺 Polygon Prodigy – Reach level 10 in Colors mode."
///
/// ## watchOS-Specific Optimizations
///
/// ### Compact Layout
/// - Uses SwiftUI List for native watchOS scrolling
/// - Inline title display mode (saves vertical space)
/// - Small fonts: 9-10pt for primary text, 7-8pt for secondary
/// - Tight vertical spacing throughout
///
/// ### Touch Targets
/// - Custom buttons with 8-10pt padding (easier to tap)
/// - Standard toggles and pickers use native watchOS sizing
/// - Mode selection cards are 44pt minimum height
///
/// ### Navigation
/// - Full-screen modal presentation
/// - Dismiss gesture (swipe right) always available
/// - No nested navigation (all settings on one scrollable screen)
///
/// ## State Management
///
/// All settings use `@Binding` to parent view's `@AppStorage`:
/// - Changes save automatically to UserDefaults
/// - Persist across app launches
/// - Sync between multiple views
///
/// Bindings:
/// - `playerName`: tk_playerName
/// - `appLanguage`: tk_language (de/en)
/// - `appTheme`: tk_theme (system/light/dark)
/// - `proMode`: tk_proMode (Bool)
/// - `gameModeRaw`: tk_gameMode (String)
/// - `soundEnabled`: tk_soundEnabled (Bool)
/// - `hapticsEnabled`: tk_hapticsEnabled (Bool)
/// - `startLevel`: tk_startLevel (1-30)
///
/// ## Side Effects
///
/// Changing certain settings triggers game reset:
/// - **Pro Mode**: Toggle requires restart
/// - **Game Mode**: Changing mode requires restart
/// - **Language**: Changing language requires restart
/// - **Player Name**: Changing player requires restart
///
/// This prevents mid-game configuration conflicts.
///
/// ## Dev Mode Detection
///
/// Checks if player name (trimmed, case-insensitive) equals "Wulf":
/// - If true: Shows Dev Mode section, enables special features
/// - If false: Hides Dev Mode section entirely
///
/// ## Example Usage
/// ```swift
/// // In ContentView_WatchOS
/// .sheet(isPresented: $showSettings) {
///     SettingsView_WatchOS(
///         playerName: $playerName,
///         appLanguage: $appLanguage,
///         appTheme: $appTheme,
///         proMode: $proMode,
///         gameModeRaw: $gameModeRaw,
///         soundEnabled: $soundEnabled,
///         hapticsEnabled: $hapticsEnabled,
///         startLevel: $startLevel,
///         showPlayerSelection: $showPlayerSelection,
///         achievementStore: achievementStore
///     )
/// }
/// ```
///
/// ## Accessibility
/// - All controls respect Dynamic Type
/// - Color-coded elements include text labels
/// - Standard SwiftUI controls for VoiceOver compatibility
/// - Clear visual hierarchy with proper contrast
///
/// ## Performance
/// - Minimal state changes (most settings are bindings)
/// - Lazy List rendering
/// - No animations or expensive computations
/// - Efficient lock status checks
///
/// - Note: This is the watchOS version. For iOS, use `SettingsView_iOS` which
///   provides additional settings like grid size and Game Center integration.
struct SettingsView_WatchOS: View {
    @Binding var playerName: String
    @Binding var appLanguage: String
    @Binding var appTheme: String
    @Binding var proMode: Bool
    @Binding var gameModeRaw: String
    @Binding var soundEnabled: Bool
    @Binding var hapticsEnabled: Bool
    @Binding var startLevel: Int
    @Binding var showPlayerSelection: Bool
    let achievementStore: AchievementStore
    
    @Environment(\.dismiss) private var dismiss
    @State private var showLockAlert = false
    @State private var lockAlertMessage = ""
    
    // MARK: - Computed Properties
    
    private var gameMode: GameMode {
        GameMode(rawValue: gameModeRaw) ?? .colors
    }
    
    // Dev Mode check (case-insensitive)
    private var isDevMode: Bool {
        let normalized = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.caseInsensitiveCompare("Wulf") == .orderedSame
    }
    
    private var appVersion: String {
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
        let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "Unknown"
        return "\(version) (\(build))"
    }
    
    private var proModeDescription: String {
        switch gameMode {
        case .colors:
            return L("ProModeDescriptionColors", language: appLanguage)
        case .numbers:
            return L("ProModeDescriptionNumbers", language: appLanguage)
        case .shapes:
            return L("ProModeDescriptionShapes", language: appLanguage)
        case .flags:
            return L("ProModeDescriptionFlags", language: appLanguage)
        case .emojis:
            return L("ProModeDescriptionEmojis", language: appLanguage)
        }
    }
    
    // MARK: - Body
    
    var body: some View {
        NavigationStack {
            List {
                // Dev Mode Section (only visible when Dev Mode is active)
                if isDevMode {
                    devModeSection
                }
                
                gameModeSection
                
                difficultySection
                
                feedbackSection
                
                playerSection
                
                themeSection
                
                languageSection
                
                aboutSection
            }
            .navigationTitle(L("Settings", language: appLanguage))
            .navigationBarTitleDisplayMode(.inline)
            .alert(L("Locked", language: appLanguage), isPresented: $showLockAlert) {
                Button(L("Done", language: appLanguage), role: .cancel) { }
            } message: {
                Text(lockAlertMessage)
            }
            .onDisappear {
                // Set default name when leaving settings with empty field
                setDefaultNameIfEmpty()
            }
        }
    }
    
    // MARK: - Section Views
    
    private var devModeSection: some View {
        Section {
            // Dev Mode Status
            HStack {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.orange)
                    .font(.caption)
                Text(L("DevModeActive", language: appLanguage))
                    .font(.caption.bold())
                    .foregroundStyle(.orange)
            }
            
            // Start Level Picker
            Picker(L("StartLevel", language: appLanguage), selection: $startLevel) {
                ForEach(1...30, id: \.self) { level in
                    Text("\(level)").tag(level)
                }
            }
            
            // Dev Mode Info
            VStack(alignment: .leading, spacing: 4) {
                Text(L("DevModeInfo", language: appLanguage))
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
                Text("• \(L("DevModeFeature1", language: appLanguage))")
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                Text("• \(L("DevModeFeature2", language: appLanguage))")
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 2)
        } header: {
            Text(L("DeveloperMode", language: appLanguage))
        }
    }
    
    private var gameModeSection: some View {
        Section {
            // Custom mode picker with lock support
            VStack(alignment: .leading, spacing: 6) {
                Text(L("GameMode", language: appLanguage))
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                
                ForEach(GameMode.allCases) { mode in
                    let isLocked = !achievementStore.isModeUnlocked(mode: mode, isPro: false, playerName: playerName)
                    let isSelected = gameModeRaw == mode.rawValue
                    
                    Button {
                        if !isLocked {
                            gameModeRaw = mode.rawValue
                        } else {
                            showUnlockAlert(for: mode)
                        }
                    } label: {
                        HStack(spacing: 4) {
                            if isLocked {
                                Image(systemName: "lock.fill")
                                    .font(.system(size: 8))
                            }
                            Text(L(mode.nameKey, language: appLanguage))
                                .font(.caption)
                            Spacer()
                            if isSelected {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 8))
                                    .foregroundStyle(.blue)
                            }
                        }
                        .padding(.vertical, 8)
                        .padding(.horizontal, 10)
                        .background(
                            isSelected ? Color.blue.opacity(0.15) : Color.clear
                        )
                        .cornerRadius(6)
                        .foregroundStyle(isLocked ? .secondary : .primary)
                        .opacity(isLocked ? 0.6 : 1.0)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
    
    private var difficultySection: some View {
        Section {
            let isProLocked = !achievementStore.isModeUnlocked(mode: gameMode, isPro: true, playerName: playerName)
            
            if isProLocked {
                Button {
                    showUnlockAlert(forProMode: true)
                } label: {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(L("ProMode", language: appLanguage))
                                .font(.caption)
                            Text(proModeDescription)
                                .font(.system(size: 9))
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "lock.fill")
                            .font(.system(size: 8))
                            .foregroundStyle(.secondary)
                    }
                }
            } else {
                Toggle(isOn: $proMode) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(L("ProMode", language: appLanguage))
                            .font(.caption)
                        Text(proModeDescription)
                            .font(.system(size: 9))
                            .foregroundStyle(.secondary)
                    }
                }
            }
        } header: {
            Text(L("Difficulty", language: appLanguage))
        }
    }
    
    private var feedbackSection: some View {
        Section {
            Toggle(L("Sound", language: appLanguage), isOn: $soundEnabled)
            Toggle(L("Haptics", language: appLanguage), isOn: $hapticsEnabled)
        } header: {
            Text(L("Feedback", language: appLanguage))
        }
    }
    
    private var playerSection: some View {
        Section {
            TextField(L("PlayerName", language: appLanguage), text: $playerName)
                .font(.caption)
                .onChange(of: playerName) { oldValue, newValue in
                    // Only trim whitespace, don't set default while typing
                    let trimmed = newValue.trimmingCharacters(in: .whitespaces)
                    if !trimmed.isEmpty && trimmed != newValue {
                        Logger.app.debug("Player name trimmed in settings: from '\(newValue, privacy: .private)' to '\(trimmed, privacy: .private)'")
                        playerName = trimmed
                    }
                }
                .onSubmit {
                    // Set default name when user submits (presses return) with empty field
                    Logger.app.debug("Player name submitted in settings: \(playerName, privacy: .private)")
                    setDefaultNameIfEmpty()
                }
            
            // Switch player button
            Button {
                showPlayerSelection = true
                dismiss()
            } label: {
                HStack {
                    Image(systemName: "person.2.fill")
                        .font(.caption)
                    Text(L("SwitchPlayer", language: appLanguage))
                        .font(.caption)
                }
            }
        } header: {
            Text(L("PlayerName", language: appLanguage))
        }
    }
    
    private var themeSection: some View {
        Section {
            Picker(L("Theme", language: appLanguage), selection: $appTheme) {
                Text(L("ThemeSystem", language: appLanguage)).tag("system")
                Text(L("ThemeLight", language: appLanguage)).tag("light")
                Text(L("ThemeDark", language: appLanguage)).tag("dark")
            }
        }
    }
    
    private var languageSection: some View {
        Section {
            Picker(L("Language", language: appLanguage), selection: $appLanguage) {
                Text(L("German", language: appLanguage)).tag("de")
                Text(L("English", language: appLanguage)).tag("en")
            }
        }
    }
    
    private var aboutSection: some View {
        Section {
            HStack {
                Text(L("Version", language: appLanguage))
                    .font(.caption)
                Spacer()
                Text(appVersion)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        } header: {
            Text(L("About", language: appLanguage))
        }
    }
    
    // MARK: - Helper Functions
    
    private func setDefaultNameIfEmpty() {
        let trimmed = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            playerName = ContentView_WatchOS.defaultPlayerName()
        }
    }
    
    private func showUnlockAlert(for mode: GameMode) {
        // Find the achievement that unlocks this mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .mode(let unlockMode) = unlocked, unlockMode == mode.rawValue {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
    
    private func showUnlockAlert(forProMode: Bool) {
        // Find the achievement that unlocks Pro mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .proMode = unlocked {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
}

// MARK: - Preview
#Preview {
    SettingsView_WatchOS(
        playerName: .constant("Player"),
        appLanguage: .constant("en"),
        appTheme: .constant("system"),
        proMode: .constant(false),
        gameModeRaw: .constant(GameMode.colors.rawValue),
        soundEnabled: .constant(true),
        hapticsEnabled: .constant(true),
        startLevel: .constant(1),
        showPlayerSelection: .constant(false),
        achievementStore: AchievementStore()
    )
}
