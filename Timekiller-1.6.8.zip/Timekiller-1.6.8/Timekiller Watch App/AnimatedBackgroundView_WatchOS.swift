//
//  AnimatedBackgroundView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI

// MARK: - Pre-computed shape data for better performance

/// Data structure representing a single animated shape in the watchOS background.
///
/// `FloatingShapeData` pre-computes all random values needed for a background shape
/// to avoid expensive random calculations during animation frames. This is the watchOS
/// version, optimized for smaller screens and lower power consumption.
///
/// ## Properties
/// - `id`: Unique identifier for SwiftUI's `ForEach`
/// - `shapeSize`: Diameter of the shape (40-90 points, smaller than iOS)
/// - `startX/Y`: Initial position in view coordinates
/// - `offsetX/Y`: Maximum travel distance for animation (reduced range for Watch)
/// - `duration`: How long one animation cycle takes (12-22 seconds)
/// - `delay`: Stagger delay for this shape (0.8s intervals)
/// - `variant`: Type selector (0 = emoji, 1 = colored circle)
/// - `color`: Pre-selected color for circle shapes
/// - `emoji`: Pre-selected emoji for emoji shapes
/// - `shapeType`: Sub-type identifier (reserved for future use)
///
/// ## watchOS Optimizations
/// Compared to iOS version:
/// - Fewer shapes (6 vs 8)
/// - Smaller size range (40-90 vs 90-180)
/// - Shorter travel distances (±70/±120 vs ±170/±280)
/// - Simpler variant selection (alternating vs modulo 3)
struct FloatingShapeData: Identifiable {
    let id: Int
    let shapeSize: CGFloat
    let startX: CGFloat
    let startY: CGFloat
    let offsetX: CGFloat
    let offsetY: CGFloat
    let duration: Double
    let delay: Double
    let variant: Int
    let color: Color
    let emoji: String
    let shapeType: Int
}

// MARK: - Animated Background (watchOS)

/// A battery-efficient animated background optimized for Apple Watch displays.
///
/// `AnimatedBackgroundView_WatchOS` provides the same visual experience as the iOS version
/// but with watchOS-specific optimizations: fewer shapes, smaller sizes, shorter animations,
/// and more aggressive power saving.
///
/// ## Visual Layers (Bottom to Top)
///
/// 1. **Base Gradient**: Two-color vertical gradient
///    - **Dark Mode**: Deep blacks (0.08/0.04 RGB)
///    - **Light Mode**: Off-whites (0.97/0.93 RGB)
///    - Same colors as iOS for consistency
///
/// 2. **Material Overlay**: `.ultraThinMaterial`
///    - Blurs content and adds translucency
///    - Adapts to system appearance automatically
///
/// 3. **Floating Shapes** (only when `!isPlaying && !reduceMotion`)
///    - 6 shapes total (vs 8 on iOS)
///    - Alternating between emojis and colored circles
///    - Blur radius: 4pt (emojis), 20pt (circles)
///    - Opacity: 0.3 (dark), 0.2 (light) - slightly lower than iOS
///    - Slower animation (16 seconds vs 20 seconds) for smoother motion
///
/// ## watchOS-Specific Optimizations
///
/// ### Reduced Complexity
/// - **Fewer Shapes**: 6 instead of 8 (25% less rendering load)
/// - **Smaller Sizes**: 40-90pt instead of 90-180pt (fits better on Watch)
/// - **Shorter Travel**: ±70/±120 instead of ±170/±280 (less screen area to cover)
///
/// ### Battery Efficiency
/// - **No Background Continuation**: Stops immediately when scene becomes inactive
/// - **Faster Stop**: No fade-out animation, just stops (saves CPU)
/// - **Smart Resume**: Only restarts when scene is active AND not playing
///
/// ### Performance Gains
/// - Pre-computed shape data (no runtime random calculations)
/// - Linear animation for GPU acceleration
/// - Automatic cleanup on view disappear
/// - No unnecessary re-renders during gameplay
///
/// ## Animation Control
/// The view pauses/resumes based on:
/// - **isPlaying**: When `true`, shapes stop (gameplay screen is visible)
/// - **reduceMotion**: When `true`, animations are disabled (accessibility)
/// - **scenePhase**: Only animates when app is `.active`
///
/// ## Color Palette
/// Simplified to 10 colors (vs 12 on iOS):
/// - Primary: red, blue, green, yellow
/// - Secondary: purple, orange, pink, cyan
/// - Tertiary: indigo, teal
///
/// Removed: mint, brown (less visible on Watch displays)
///
/// ## Emoji Selection
/// Reduced to 6 emojis (vs 12 on iOS):
/// - 🎨 (art palette)
/// - ⭐️ (star)
/// - 🎯 (target)
/// - ✨ (sparkles)
/// - 🌟 (glowing star)
/// - 🎪 (circus tent)
///
/// Chosen for visibility and relevance to game themes.
///
/// ## Lifecycle
/// - **onAppear**: Pre-computes shape data, starts animation if appropriate
/// - **onChange(scenePhase)**: Restarts animation when app becomes active (if not playing)
/// - **onChange(isPlaying)**: Restarts animation when returning to start screen
///
/// ## Usage
/// ```swift
/// ZStack {
///     AnimatedBackgroundView_WatchOS(
///         colorScheme: appColorScheme,
///         gameMode: currentGameMode,
///         reduceMotion: reduceMotion,
///         isPlaying: isGameActive
///     )
///     
///     // Your watchOS content here
/// }
/// ```
///
/// ## Performance Characteristics
/// - **Memory**: ~2KB per shape × 6 = ~12KB
/// - **CPU**: <1% on Apple Watch Series 4+ when animating
/// - **Battery Impact**: Negligible (animation stops during gameplay)
///
/// - Note: This is the watchOS-specific version. For iOS, use `AnimatedBackgroundView`
///   which has more shapes and complexity suitable for larger screens.
struct AnimatedBackgroundView_WatchOS: View {
    @Environment(\.colorScheme) var systemColorScheme
    @Environment(\.scenePhase) var scenePhase
    
    let colorScheme: ColorScheme?
    let gameMode: GameMode
    let reduceMotion: Bool
    let isPlaying: Bool  // Add this parameter to know when to pause/resume
    
    @State private var animationPhase: CGFloat = 0
    @State private var shapeData: [FloatingShapeData] = []
    
    private var effectiveColorScheme: ColorScheme {
        colorScheme ?? systemColorScheme
    }
    
    var body: some View {
        ZStack {
            // Base gradient
            baseGradient
            
            // Material overlay in the middle
            Rectangle()
                .fill(.ultraThinMaterial)
            
            // Floating shapes layer - ABOVE material
            // Only show animated shapes when NOT playing
            if !isPlaying && !reduceMotion && !shapeData.isEmpty {
                GeometryReader { geometry in
                    // Use ForEach with individual views for better animation support
                    ForEach(shapeData) { data in
                        Group {
                            if data.variant == 0 {
                                // Emoji
                                Text(data.emoji)
                                    .font(.system(size: data.shapeSize * 0.6))
                            } else {
                                // Colored circle
                                Circle()
                                    .fill(data.color)
                                    .frame(width: data.shapeSize, height: data.shapeSize)
                            }
                        }
                        .blur(radius: data.variant == 0 ? 4 : 20)
                        .opacity(effectiveColorScheme == .dark ? 0.3 : 0.2)
                        .offset(
                            x: data.startX + (animationPhase * data.offsetX),
                            y: data.startY + (animationPhase * data.offsetY)
                        )
                    }
                }
            }
        }
        .ignoresSafeArea()
        .onAppear {
            // Pre-compute shape data once when appearing
            if shapeData.isEmpty {
                computeShapeData()
            }
            // Start animation when view appears
            if !isPlaying && !reduceMotion {
                startAnimation()
            }
        }
        .onChange(of: scenePhase) { _, newPhase in
            // Restart animation when app becomes active and shapes are visible
            if newPhase == .active && !isPlaying && !reduceMotion {
                startAnimation()
            }
        }
        .onChange(of: isPlaying) { _, newValue in
            // Restart animation when returning to start screen (shapes become visible)
            if !newValue && !reduceMotion {
                startAnimation()
            }
        }
    }
    
    // MARK: - Component Views
    
    private var baseGradient: some View {
        LinearGradient(
            colors: [
                effectiveColorScheme == .dark ? Color(red: 0.08, green: 0.09, blue: 0.11) : Color(red: 0.97, green: 0.97, blue: 0.98),
                effectiveColorScheme == .dark ? Color(red: 0.04, green: 0.05, blue: 0.06) : Color(red: 0.93, green: 0.94, blue: 0.96)
            ],
            startPoint: .top,
            endPoint: .bottom
        )
    }
    
    // MARK: - Animation Logic
    
    private func computeShapeData() {
        // Pre-compute random values once instead of during render
        let emojis = ["🎨", "⭐️", "🎯", "✨", "🌟", "🎪"]
        let colors: [Color] = [.red, .blue, .green, .yellow, .purple, .orange, .pink, .cyan, .indigo, .teal]
        
        // Reduce from 10 to 6 shapes for better performance
        shapeData = (0..<6).map { index in
            FloatingShapeData(
                id: index,
                shapeSize: CGFloat.random(in: 40...90),
                startX: CGFloat.random(in: -30...200),
                startY: CGFloat.random(in: -30...250),
                offsetX: CGFloat.random(in: -70...70),
                offsetY: CGFloat.random(in: -120...120),
                duration: Double.random(in: 12...22),
                delay: Double(index) * 0.8,
                variant: index % 2,
                color: colors[index % colors.count],
                emoji: emojis[index % emojis.count],
                shapeType: index % 4
            )
        }
    }
    
    private func startAnimation() {
        // Reset and restart animation with slower, smoother duration
        animationPhase = 0
        withAnimation(.linear(duration: 16).repeatForever(autoreverses: true)) {
            animationPhase = 1
        }
    }
    
    private var allColors: [Color] {
        // Mix all colors
        [.red, .blue, .green, .yellow, .purple, .orange, .pink, .cyan, .indigo, .teal]
    }
}

// MARK: - Preview
#Preview {
    AnimatedBackgroundView_WatchOS(
        colorScheme: nil,
        gameMode: .colors,
        reduceMotion: false,
        isPlaying: false
    )
}
