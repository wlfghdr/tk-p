//
//  HighscoreView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI

// MARK: - Highscore List View (watchOS optimized)

/// Displays local highscores and provides access to achievements on Apple Watch.
///
/// `HighscoreView_WatchOS` is a compact, scrollable list view optimized for watchOS
/// that shows all saved highscores for the current player. It also serves as the
/// gateway to the achievement overview screen.
///
/// ## Screen Layout
///
/// ### Achievement Button Section (Top)
/// - Prominently displayed at the top for easy access
/// - Yellow trophy icon for visual recognition
/// - Tapping opens achievement overview in a modal sheet
///
/// ### Local Highscores Section (Main)
/// - Displays all highscore entries in reverse chronological order (newest first)
/// - Shows "No highscores" message when list is empty
/// - Each entry is rendered as a custom card with multiple information layers
///
/// ## Highscore Entry Display
///
/// Each highscore entry shows:
///
/// ### Primary Row
/// - **Player Name** (left, bold): Who earned this score
/// - **Score Value** (right, bold, color-coded): Points earned (green if positive, red if negative)
///
/// ### Metadata Row
/// - **Date**: When the score was achieved (format: day, month, year, hour, minute)
/// - **Level**: Maximum level reached ("Level X", colored in tint color)
/// - **Game Mode**: Icon + name + "Pro" badge (if applicable)
/// - Separated by bullet points (•) for readability
///
/// ### Achievements Row (Conditional)
/// - Only shown when achievements were earned during this game
/// - Each achievement displayed as a compact badge
/// - Shows emoji icon, name, and truncated explanation
/// - Dark semi-transparent background for visual separation
///
/// ## watchOS-Specific Optimizations
///
/// ### Compact Typography
/// - Player names: 11pt bold
/// - Scores: 11pt bold (color-coded)
/// - Metadata: 7-9pt regular
/// - Achievement names: 8pt bold
/// - Achievement descriptions: 7pt (1 line max)
///
/// ### Space Efficiency
/// - Uses SwiftUI's native List for optimal scrolling performance
/// - Tight vertical spacing (4-6pt) between elements
/// - Bullet separators (•) instead of pipes (|) for better readability
/// - Icon-only secondary elements where possible
///
/// ### Visual Hierarchy
/// - Primary information (name, score) is largest and boldest
/// - Metadata uses secondary color for de-emphasis
/// - Achievement badges have distinct background color
/// - Consistent color coding: green = positive, red = negative, tint = level
///
/// ## Game Mode Display
///
/// Game modes are identified by:
/// - **Icon**: SF Symbol representing the mode
///   - Colors: paintpalette.fill
///   - Numbers: number.square.fill
///   - Shapes: star.square.fill
///   - Flags: flag.fill
///   - Emojis: face.smiling.fill
/// - **Name**: Localized mode name
/// - **Pro Badge**: Orange "Pro" label if Pro mode was used
///
/// ## Achievement Integration
///
/// When a highscore entry includes achievements:
/// 1. Filters `Achievement.all` by IDs in `entry.achievementIDs`
/// 2. Renders each achievement as a compact badge
/// 3. Shows emoji (14pt), name (8pt bold), and description (7pt, 1 line)
/// 4. Uses semi-transparent dark background for visual grouping
///
/// ## Navigation & Modal Sheets
///
/// ### Achievement Sheet
/// - Triggered by tapping achievement button
/// - Presents `AchievementView_WatchOS` in a NavigationStack
/// - Shows all achievements with unlock status
/// - User can dismiss by swiping down or using back button
///
/// ## Data Sources
///
/// - `store: HighscoreStore`: Provides `entries` array of all saved scores
/// - `achievementStore: AchievementStore`: Tracks achievement unlock status
/// - `playerName: String`: Current player (used by achievement store)
/// - `language: String`: Current app language for localization
///
/// ## Empty State
///
/// When no highscores exist:
/// - Shows localized "No highscores" message
/// - Uses secondary color and italic text
/// - Encourages user to play first game
///
/// ## Example Usage
/// ```swift
/// // In ContentView_WatchOS toolbar
/// Button {
///     showHighscores = true
/// } label: {
///     Image(systemName: "list.number")
/// }
/// .sheet(isPresented: $showHighscores) {
///     NavigationStack {
///         HighscoreView_WatchOS(
///             store: highscoreStore,
///             language: appLanguage,
///             achievementStore: achievementStore,
///             playerName: playerName
///         )
///         .navigationTitle("Highscores")
///         .navigationBarTitleDisplayMode(.inline)
///     }
/// }
/// ```
///
/// ## Accessibility
/// - All text respects Dynamic Type settings
/// - Clear visual hierarchy with proper contrast ratios
/// - Color information supplemented with text labels
/// - Standard List behavior for VoiceOver compatibility
///
/// ## Performance
/// - Uses `ForEach` with `id: \.id` for efficient updates
/// - Lazy rendering through SwiftUI's List
/// - Pre-filtered achievement arrays
/// - No expensive animations or real-time calculations
///
/// - Note: This is the watchOS version. For iOS, use `HighscoreView_iOS` which
///   provides more detailed statistics and includes Game Center integration.
struct HighscoreView_WatchOS: View {
    let store: HighscoreStore
    let language: String
    let achievementStore: AchievementStore
    let playerName: String
    
    @State private var showAchievements = false
    
    var body: some View {
        List {
            // Achievement Overview Button (moved to top)
            Section {
                Button {
                    showAchievements = true
                } label: {
                    HStack {
                        Image(systemName: "trophy.fill")
                            .foregroundStyle(.yellow)
                            .font(.caption)
                        Text(L("Achievements", language: language))
                            .font(.caption.bold())
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundStyle(.secondary)
                            .font(.caption2)
                    }
                }
            }
            
            // Local Highscores Section
            Section {
                if store.entries.isEmpty {
                    Text(L("NoHighscores", language: language))
                        .foregroundStyle(.secondary)
                        .italic()
                        .font(.caption)
                } else {
                    ForEach(store.entries) { entry in
                        highscoreEntryView(for: entry)
                    }
                }
            } header: {
                Text(L("LocalHighscores", language: language))
            }
        }
        .sheet(isPresented: $showAchievements) {
            NavigationStack {
                AchievementView_WatchOS(
                    language: language,
                    playerName: playerName,
                    achievementStore: achievementStore
                )
                    .navigationTitle(L("Achievements", language: language))
                    .navigationBarTitleDisplayMode(.inline)
            }
        }
    }
    
    // MARK: - Helper Views
    
    @ViewBuilder
    private func highscoreEntryView(for entry: HighscoreEntry) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            // Player name and score
            HStack {
                Text(entry.playerName)
                    .font(.caption.bold())
                Spacer()
                Text("\(entry.score)")
                    .font(.caption.bold())
                    .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
            }
            
            // Date and level info
            HStack(spacing: 6) {
                Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
                Text("•")
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
                Text("Level \(entry.maxLevel)")
                    .font(.system(size: 9))
                    .foregroundStyle(.tint)
                Text("•")
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
                // Game mode indicator
                HStack(spacing: 2) {
                    Image(systemName: gameModeIcon(for: entry.gameMode))
                        .font(.system(size: 8))
                    Text(L(gameModeNameKey(for: entry.gameMode), language: language))
                        .font(.system(size: 9))
                    if entry.isPro {
                        Text("Pro")
                            .font(.system(size: 7, weight: .bold))
                            .foregroundStyle(.orange)
                    }
                }
                .foregroundStyle(.secondary)
            }
            
            // Show achievements earned in this run
            if !entry.achievementIDs.isEmpty {
                achievementsView(for: entry)
            }
        }
    }
    
    @ViewBuilder
    private func achievementsView(for entry: HighscoreEntry) -> some View {
        let achievements = Achievement.all.filter { entry.achievementIDs.contains($0.id) }
        
        VStack(alignment: .leading, spacing: 4) {
            ForEach(achievements, id: \.id) { achievement in
                achievementBadgeView(achievement: achievement)
            }
        }
        .padding(.top, 2)
    }
    
    @ViewBuilder
    private func achievementBadgeView(achievement: Achievement) -> some View {
        HStack(spacing: 4) {
            Text(achievement.iconEmoji)
                .font(.system(size: 14))
            VStack(alignment: .leading, spacing: 1) {
                Text(L(achievement.nameKey, language: language))
                    .font(.system(size: 8, weight: .bold))
                Text(L(achievement.explanationKey, language: language))
                    .font(.system(size: 7))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
        }
        .padding(4)
        .background(Color.black.opacity(0.15))
        .cornerRadius(4)
    }
    
    // Helper functions for game mode display
    private func gameModeIcon(for mode: String) -> String {
        switch mode {
        case "colors": return "paintpalette.fill"
        case "numbers": return "number.square.fill"
        case "shapes": return "star.square.fill"
        case "flags": return "flag.fill"
        case "emojis": return "face.smiling.fill"
        default: return "questionmark.circle"
        }
    }
    
    private func gameModeNameKey(for mode: String) -> String {
        switch mode {
        case "colors": return "ModeColors"
        case "numbers": return "ModeNumbers"
        case "shapes": return "ModeShapes"
        case "flags": return "ModeFlags"
        case "emojis": return "ModeEmojis"
        default: return "ModeColors"
        }
    }
}

// MARK: - Preview
#Preview {
    NavigationStack {
        HighscoreView_WatchOS(
            store: HighscoreStore(),
            language: "en",
            achievementStore: AchievementStore(),
            playerName: "Player"
        )
        .navigationTitle("Highscores")
        .navigationBarTitleDisplayMode(.inline)
    }
}
