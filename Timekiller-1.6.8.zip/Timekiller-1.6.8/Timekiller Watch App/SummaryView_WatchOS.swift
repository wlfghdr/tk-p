//
//  SummaryView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI

// MARK: - Summary View (watchOS optimized)

/// Post-game summary screen optimized for Apple Watch's compact display.
///
/// `SummaryView_WatchOS` displays game-over statistics and achievements in a scrollable
/// format designed for watchOS. It provides a comprehensive breakdown of the player's
/// performance while maintaining quick access to key actions.
///
/// ## Display Sections
///
/// ### Stats Section (Always Visible)
/// - **Level Reached**: The highest level completed before game over
/// - **Total Score**: Combined positive scores from all completed levels
///
/// ### Achievements Section (Conditional)
/// - Only shown when `newAchievements` is not empty
/// - Displays achievement icon, name, and explanation
/// - Compact card layout optimized for watch screen
///
/// ### Level Scores Section (Conditional)
/// - Only shown when `levelScores` is not empty
/// - Breakdown of points earned/lost per level
/// - Color-coded: green for positive, red for negative
///
/// ### Top Scores Section (Conditional)
/// - Only shown when highscore store has entries
/// - Quick preview of top 3 highscores
/// - Includes player name, date, level, game mode, and Pro status
///
/// ## Layout Strategy
///
/// ### Two-Area Design
/// The view is split into two main areas:
///
/// 1. **Scrollable Content Area** (top)
///    - Contains all game statistics and information
///    - User can scroll to see everything
///    - Has extra bottom padding for comfortable scrolling
///
/// 2. **Fixed Action Buttons** (bottom)
///    - Always visible, never scrolls
///    - Separated by divider with semi-transparent background
///    - Two buttons: "Done" (primary) and "Highscores" (secondary icon button)
///
/// This ensures critical actions are always accessible without scrolling.
///
/// ## Navigation Behavior
///
/// - **Non-Dismissible**: User cannot swipe to dismiss (controlled dismissal only)
/// - **Navigation Bar Hidden**: Custom header in scrollable area replaces nav bar
/// - **Sheet Presentation**: Shows highscores in a modal sheet when requested
///
/// ## watchOS-Specific Optimizations
///
/// ### Compact Fonts
/// - Stats: 8pt labels, 24-30pt values
/// - Achievements: 9pt names, 8pt descriptions, 24pt emoji icons
/// - Level scores: 10pt text
/// - Top scores: 10pt names, 7-9pt metadata
///
/// ### Space Efficiency
/// - Combined level/score display (side-by-side instead of stacked)
/// - Icon-only secondary button (highscores)
/// - Tight spacing: 8-12pt between sections
/// - Compact padding: 4-8pt within sections
///
/// ### Visual Hierarchy
/// - Important info uses bold, larger text
/// - Secondary info uses `.secondary` color
/// - Color-coded scores (green/red) for quick recognition
/// - Divider separates fixed buttons from scroll content
///
/// ## Data Flow
///
/// ### Input Parameters
/// - `level`: Final level reached before game over
/// - `totalScore`: Computed from positive level scores only
/// - `levelScores`: Dictionary mapping level number to score earned
/// - `highscoreStore`: Reference to persistent highscore storage
/// - `language`: Current app language for localization
/// - `onRestart`: Closure called when user taps "Done" button
/// - `newAchievements`: Array of achievement IDs earned in this game
/// - `achievementStore`: Reference to achievement tracking system
/// - `playerName`: Current player's name
///
/// ### User Actions
/// - **Done Button**: Calls `onRestart()` closure, returns to start screen
/// - **Highscores Button**: Presents modal sheet with full highscore list
///
/// ## Example Usage
/// ```swift
/// // In ContentView_WatchOS
/// .sheet(isPresented: $showSummary) {
///     SummaryView_WatchOS(
///         level: currentLevel,
///         totalScore: finalScore,
///         levelScores: levelScoresDictionary,
///         highscoreStore: highscoreStore,
///         language: appLanguage,
///         onRestart: {
///             showSummary = false
///             resetGame()
///         },
///         newAchievements: achievementsEarned,
///         achievementStore: achievementStore,
///         playerName: playerName
///     )
///     .interactiveDismissDisabled()
/// }
/// ```
///
/// ## Accessibility
/// - All text scales with Dynamic Type
/// - Color-coded information also has text indicators
/// - Scrollable content respects user's motion preferences
/// - Clear visual hierarchy with proper contrast
///
/// ## Performance
/// - Lazy loading for sections (only renders visible content)
/// - Pre-filtered achievement lists (computed once)
/// - Efficient dictionary lookups for level scores
/// - No animations or expensive effects
///
/// - Note: This is the watchOS version. For iOS, use `SummaryView_iOS` which
///   provides more detailed statistics and larger touch targets.
struct SummaryView_WatchOS: View {
    let level: Int
    let totalScore: Int
    let levelScores: [Int: Int]
    let highscoreStore: HighscoreStore
    let language: String
    let onRestart: () -> Void
    let newAchievements: [String]
    let achievementStore: AchievementStore
    let playerName: String
    
    @State private var showHighscores = false
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Scrollable content area
                ScrollView {
                    VStack(spacing: 12) {
                        // Level Reached and Final Score - Combined for compactness
                        statsSection
                        
                        // New Achievements Section
                        if !newAchievements.isEmpty {
                            achievementsSection
                        }
                        
                        // Level Scores Breakdown
                        if !levelScores.isEmpty {
                            levelScoresSection
                        }
                        
                        // Quick preview of top highscores
                        if !highscoreStore.entries.isEmpty {
                            topScoresSection
                        }
                        
                        // Extra bottom padding for scroll content
                        Color.clear.frame(height: 8)
                    }
                    .padding(8)
                }
                
                // Fixed action buttons at bottom
                VStack(spacing: 0) {
                    Divider()
                    
                    actionButtonsSection
                        .padding(.horizontal, 8)
                        .padding(.vertical, 8)
                        .background(Color.black.opacity(0.3))
                }
            }
            .navigationTitle(L("GameOver", language: language))
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true)
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showHighscores) {
                NavigationStack {
                    HighscoreView_WatchOS(
                        store: highscoreStore,
                        language: language,
                        achievementStore: achievementStore,
                        playerName: playerName
                    )
                        .navigationTitle(L("Highscores", language: language))
                        .navigationBarTitleDisplayMode(.inline)
                }
            }
        }
    }
    
    // MARK: - Section Views
    
    private var statsSection: some View {
        HStack(alignment: .top, spacing: 12) {
            // Level Reached
            VStack(spacing: 4) {
                Text(L("ReachedLevel", language: language))
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                    .minimumScaleFactor(0.5)
                    .lineLimit(1)
                Text("\(level)")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .foregroundStyle(.tint)
            }
            .frame(maxWidth: .infinity)
            
            // Final Score
            VStack(spacing: 4) {
                Text(L("TotalScore", language: language))
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                    .minimumScaleFactor(0.5)
                    .lineLimit(1)
                Text("\(totalScore)")
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                    .minimumScaleFactor(0.6)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
        }
        .padding(8)
        .background(Color.black.opacity(0.2))
        .cornerRadius(8)
    }
    
    private var achievementsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(L("AchievementsEarned", language: language))
                .font(.caption.bold())
            
            ForEach(Achievement.all.filter { newAchievements.contains($0.id) }, id: \.id) { achievement in
                achievementRow(achievement: achievement)
            }
        }
        .padding(8)
        .background(Color.black.opacity(0.2))
        .cornerRadius(8)
    }
    
    private func achievementRow(achievement: Achievement) -> some View {
        HStack(spacing: 8) {
            Text(achievement.iconEmoji)
                .font(.system(size: 24))
            VStack(alignment: .leading, spacing: 2) {
                Text(L(achievement.nameKey, language: language))
                    .font(.system(size: 9, weight: .bold))
                Text(L(achievement.explanationKey, language: language))
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            Spacer()
        }
        .padding(6)
        .background(Color.black.opacity(0.15))
        .cornerRadius(8)
    }
    
    private var levelScoresSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(L("ScorePerLevel", language: language))
                .font(.caption.bold())
            
            ForEach(levelScores.keys.sorted(), id: \.self) { levelNum in
                if let score = levelScores[levelNum] {
                    levelScoreRow(levelNum: levelNum, score: score)
                }
            }
        }
        .padding(8)
        .background(Color.black.opacity(0.2))
        .cornerRadius(8)
    }
    
    private func levelScoreRow(levelNum: Int, score: Int) -> some View {
        HStack {
            Text("\(L("Level", language: language)) \(levelNum):")
                .font(.system(size: 10))
            Spacer()
            Text("\(score > 0 ? "+" : "")\(score)")
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(score > 0 ? Color.green : Color.red)
        }
        .padding(.horizontal, 8)
    }
    
    private var actionButtonsSection: some View {
        HStack(spacing: 8) {
            // Done Button
            Button {
                onRestart()
            } label: {
                HStack(spacing: 4) {
                    Image(systemName: "checkmark.circle.fill")
                    Text(L("Done", language: language))
                }
                .font(.caption.bold())
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(Color.accentColor)
                .cornerRadius(8)
            }
            .buttonStyle(.plain)
            
            // Highscores Button (icon only)
            Button {
                showHighscores = true
            } label: {
                Image(systemName: "list.number")
                    .font(.caption.bold())
                    .foregroundStyle(.white)
                    .frame(width: 40)
                    .padding(.vertical, 8)
                    .background(Color.orange)
                    .cornerRadius(8)
            }
            .buttonStyle(.plain)
        }
    }
    
    private var topScoresSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(L("TopScores", language: language))
                .font(.caption.bold())
            
            ForEach(highscoreStore.entries.prefix(3)) { entry in
                topScoreRow(entry: entry)
            }
        }
        .padding(8)
        .background(Color.black.opacity(0.2))
        .cornerRadius(8)
    }
    
    private func topScoreRow(entry: HighscoreEntry) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(entry.playerName)
                    .font(.system(size: 10, weight: .bold))
                HStack(spacing: 4) {
                    Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                        .font(.system(size: 7))
                        .foregroundStyle(.secondary)
                    Text("•")
                        .font(.system(size: 7))
                        .foregroundStyle(.secondary)
                    Text("Level \(entry.maxLevel)")
                        .font(.system(size: 8))
                        .foregroundStyle(.secondary)
                    Text("•")
                        .font(.system(size: 7))
                        .foregroundStyle(.secondary)
                    // Game mode indicator
                    HStack(spacing: 2) {
                        Image(systemName: gameModeIcon(for: entry.gameMode))
                            .font(.system(size: 7))
                        Text(L(gameModeNameKey(for: entry.gameMode), language: language))
                            .font(.system(size: 7))
                        if entry.isPro {
                            Text("Pro")
                                .font(.system(size: 6, weight: .bold))
                                .foregroundStyle(.orange)
                        }
                    }
                    .foregroundStyle(.secondary)
                }
            }
            
            Spacer()
            
            Text("\(entry.score)")
                .font(.caption.bold())
                .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
        }
        .padding(.horizontal, 8)
    }
    
    // Helper functions for game mode display
    private func gameModeIcon(for mode: String) -> String {
        switch mode {
        case "colors": return "paintpalette.fill"
        case "numbers": return "number.square.fill"
        case "shapes": return "star.square.fill"
        case "flags": return "flag.fill"
        case "emojis": return "face.smiling.fill"
        default: return "questionmark.circle"
        }
    }
    
    private func gameModeNameKey(for mode: String) -> String {
        switch mode {
        case "colors": return "ModeColors"
        case "numbers": return "ModeNumbers"
        case "shapes": return "ModeShapes"
        case "flags": return "ModeFlags"
        case "emojis": return "ModeEmojis"
        default: return "ModeColors"
        }
    }
}

// MARK: - Preview
#Preview {
    SummaryView_WatchOS(
        level: 5,
        totalScore: 450,
        levelScores: [1: 100, 2: 120, 3: 110, 4: 120],
        highscoreStore: HighscoreStore(),
        language: "en",
        onRestart: {},
        newAchievements: [],
        achievementStore: AchievementStore(),
        playerName: "Player"
    )
}
