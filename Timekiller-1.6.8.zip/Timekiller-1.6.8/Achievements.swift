//
//  Achievements.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation
import SwiftUI
import OSLog

// MARK: - Achievement System

/// Represents a specific achievement milestone that players can unlock through gameplay.
///
/// Achievements are earned by meeting specific conditions, such as reaching a certain level
/// in a particular game mode. Some achievements unlock new game modes or features when earned.
///
/// Each achievement includes:
/// - A unique identifier for tracking unlocked status
/// - Localization keys for displaying the name and explanation in multiple languages
/// - An emoji icon for visual representation
/// - Unlock conditions that determine when the achievement is earned
///
/// ## Example
/// ```swift
/// let achievement = Achievement(
///     id: "color_cadet",
///     nameKey: "AchievementColorCadet",
///     iconEmoji: "🎨",
///     explanationKey: "AchievementColorCadetExplanation",
///     unlockCondition: .reachLevel(5, mode: "colors", isPro: false)
/// )
/// ```
struct Achievement: Identifiable, Codable, Equatable {
    /// Unique identifier for this achievement (snake_case format)
    let id: String
    
    /// Localization key for the achievement's display name
    let nameKey: String
    
    /// Emoji icon representing this achievement
    let iconEmoji: String
    
    /// Localization key for the achievement's description/explanation
    let explanationKey: String
    
    /// Condition that must be met to unlock this achievement
    let unlockCondition: UnlockCondition
    
    /// Defines the conditions under which an achievement is unlocked.
    ///
    /// There are two types of unlock conditions:
    /// - **Mode-specific**: Reach a certain level in a specific game mode and difficulty
    /// - **Ultimate**: Reach a certain level across all game mode/difficulty combinations
    enum UnlockCondition: Codable, Equatable {
        /// Unlock by reaching a specific level in a particular mode and difficulty
        /// - Parameters:
        ///   - level: The minimum level that must be reached
        ///   - mode: The game mode identifier (e.g., "colors", "shapes", "emojis")
        ///   - isPro: Whether this is for Pro difficulty (`true`) or Normal difficulty (`false`)
        case reachLevel(Int, mode: String, isPro: Bool)
        
        /// Unlock by reaching a specific level in ALL game modes (both Normal and Pro)
        /// This is the ultimate achievement requiring mastery across all 10 mode combinations
        /// - Parameter level: The minimum level that must be reached in every mode
        case reachLevelInAllModes(Int)
    }
    
    /// Determines what content or feature this achievement unlocks, if any.
    ///
    /// Most achievements are purely for progression tracking and don't unlock anything.
    /// However, certain key achievements unlock new game modes or features:
    /// - **polygon_prodigy**: Unlocks the Shapes game mode
    /// - **flag_dropper**: Unlocks the Flags game mode
    /// - **smiley_summoner**: Unlocks the Emojis game mode
    /// - **ultra_instinct**: Unlocks Pro difficulty mode
    ///
    /// - Returns: The unlocked content type, or `nil` if this achievement doesn't unlock anything
    var unlocksContent: UnlockedContent? {
        // Only specific achievements unlock content, not all achievements at that level
        switch id {
        case "polygon_prodigy":
            return .mode("shapes")
        case "flag_dropper":
            return .mode("flags")
        case "smiley_summoner":
            return .mode("emojis")
        case "ultra_instinct":
            return .proMode
        default:
            return nil
        }
    }
    
    /// Represents content or features that can be unlocked by achievements.
    enum UnlockedContent {
        /// Unlocks a new game mode (e.g., "shapes", "flags", "emojis")
        case mode(String)
        
        /// Unlocks Pro difficulty mode across all game modes
        case proMode
    }
}

// MARK: - Player Achievement Data

/// Stores achievement and level progression data for a single player.
///
/// Each player has their own separate achievement tracking, allowing multiple players
/// to maintain independent progress. This structure stores:
/// - Which achievements have been unlocked
/// - The highest level completed in each game mode/difficulty combination
///
/// Level completions are tracked using a key format: `"mode_isPro"` 
/// Examples: `"colors_false"`, `"shapes_true"`, `"emojis_false"`
struct PlayerAchievementData: Codable {
    /// Set of achievement IDs that this player has unlocked
    var unlockedAchievementIDs: Set<String>
    
    /// Maps mode/difficulty combinations to the highest level completed
    /// Key format: `"mode_isPro"` (e.g., `"colors_false"`, `"shapes_true"`)
    /// Value: highest level number reached (e.g., 15 means player completed level 15)
    var levelCompletions: [String: Int]
    
    /// Creates a new player with no achievements or progress
    init() {
        self.unlockedAchievementIDs = []
        self.levelCompletions = [:]
    }
}

/// Tracks player progression, unlocked achievements, and manages achievement checking.
///
/// `AchievementStore` is the central manager for achievement and progression data in the game.
/// It provides a multi-player system where each player has independent achievement tracking,
/// level progression, and unlocked content.
///
/// ## Key Features
/// - **Multi-player support**: Multiple players can maintain separate progress
/// - **Per-player achievement tracking**: Each player unlocks achievements independently
/// - **Level progression tracking**: Monitors highest level reached in each mode/difficulty
/// - **Mode unlock system**: Determines which game modes are available based on progress
/// - **Persistent storage**: Automatically saves/loads data using UserDefaults
/// - **Legacy migration**: Seamlessly migrates from old global achievement system
/// - **Dev mode**: Special player "Wulf" has everything unlocked for testing
///
/// ## Player Management
/// Players are identified by name (String). The `currentPlayerName` property determines
/// whose data is being accessed. All operations (checking unlocks, marking completions, etc.)
/// apply to the current player.
///
/// ## Mode Unlock System
/// Game modes and difficulties are unlocked based on level progression:
/// - **Colors & Numbers**: Always unlocked
/// - **Shapes**: Unlock at level 10 in any standard mode
/// - **Flags**: Unlock at level 15 in any standard mode
/// - **Emojis**: Unlock at level 20 in any standard mode
/// - **Pro Mode**: Unlock at level 30 in any standard mode
///
/// ## Storage Keys
/// - `tk_achievements_per_player`: Per-player achievement data (current system)
/// - `tk_players`: List of all created players
/// - `tk_achievements`: Legacy global achievements (migrated automatically)
/// - `tk_achievement_progress`: Legacy global progress (migrated automatically)
///
/// ## Example Usage
/// ```swift
/// let store = AchievementStore()
///
/// // Create/switch players
/// store.createPlayer(name: "Alice")
/// store.currentPlayerName = "Alice"
///
/// // Track level completion
/// store.markLevelCompletion(level: 10, mode: .colors, isPro: false)
///
/// // Check for newly unlocked achievements
/// let newAchievements = store.checkAndUnlockAchievements()
///
/// // Check if a mode is unlocked
/// if store.isModeUnlocked(mode: .shapes, isPro: false) {
///     // Player can access Shapes mode
/// }
/// ```
@Observable
class AchievementStore {
    /// UserDefaults key for storing per-player achievement data (current system)
    private let storageKey = "tk_achievements_per_player"
    
    /// UserDefaults key for storing the list of all created players
    private let playersStorageKey = "tk_players"
    
    /// UserDefaults key for legacy global achievement data (pre-multi-player system)
    private let legacyStorageKey = "tk_achievements"
    
    /// UserDefaults key for legacy global progress data (pre-multi-player system)
    private let legacyProgressKey = "tk_achievement_progress"
    
    /// Dictionary mapping player names to their achievement data
    /// Key: player name (String), Value: player's achievements and progress
    private var playerAchievements: [String: PlayerAchievementData] = [:]
    
    /// Set of all created player names (persisted separately from achievement data)
    private var players: Set<String> = []
    
    /// The name of the currently active player whose data is being accessed
    /// Changing this property switches the player context for all operations
    var currentPlayerName: String = "Player" {
        didSet {
            if oldValue != self.currentPlayerName {
                Logger.app.info("Player switched from \(oldValue, privacy: .private) to \(self.currentPlayerName, privacy: .private) with \(self.getAchievementCount(for: self.currentPlayerName)) achievements")
                
                // Ensure new player exists in the player list
                if !self.players.contains(self.currentPlayerName) {
                    self.createPlayer(name: self.currentPlayerName)
                }
            }
        }
    }
    
    /// IDs of unlocked achievements for the current player.
    ///
    /// This computed property provides read/write access to the current player's unlocked
    /// achievements. Modifying this set automatically creates player data if it doesn't exist.
    ///
    /// - Returns: A set of achievement IDs (e.g., `"color_cadet"`, `"ultra_instinct"`)
    var unlockedAchievementIDs: Set<String> {
        get {
            return self.playerAchievements[self.currentPlayerName]?.unlockedAchievementIDs ?? []
        }
        set {
            if self.playerAchievements[self.currentPlayerName] == nil {
                self.playerAchievements[self.currentPlayerName] = PlayerAchievementData()
            }
            self.playerAchievements[self.currentPlayerName]?.unlockedAchievementIDs = newValue
        }
    }
    
    /// Level completion progress for the current player.
    ///
    /// This dictionary tracks the highest level reached in each mode/difficulty combination.
    /// Key format: `"mode_isPro"` (e.g., `"colors_false"`, `"shapes_true"`)
    /// Value: highest level number completed (e.g., 15)
    ///
    /// Modifying this dictionary automatically creates player data if it doesn't exist.
    ///
    /// ## Example
    /// ```swift
    /// // Player reached level 15 in Colors Normal mode
    /// store.levelCompletions["colors_false"] = 15
    ///
    /// // Player reached level 10 in Shapes Pro mode
    /// store.levelCompletions["shapes_true"] = 10
    /// ```
    var levelCompletions: [String: Int] {
        get {
            return self.playerAchievements[self.currentPlayerName]?.levelCompletions ?? [:]
        }
        set {
            if self.playerAchievements[self.currentPlayerName] == nil {
                self.playerAchievements[self.currentPlayerName] = PlayerAchievementData()
            }
            self.playerAchievements[self.currentPlayerName]?.levelCompletions = newValue
        }
    }
    
    /// Initializes the achievement store and loads persisted data.
    ///
    /// This initializer:
    /// 1. Loads per-player achievement data from UserDefaults
    /// 2. Loads the list of all created players
    /// 3. Migrates legacy global achievement data if this is first launch after update
    /// 4. Ensures the default player ("Player") exists in the player list
    init() {
        self.load()
        self.loadPlayers()
        
        // Ensure current player exists in the player list
        if !self.players.contains(self.currentPlayerName) {
            self.createPlayer(name: self.currentPlayerName)
        }
    }
    
    /// Returns a sorted array of all player names.
    ///
    /// This includes all players who have been created, even if they have no achievements yet.
    ///
    /// - Returns: Alphabetically sorted array of player names
    func getAllPlayerNames() -> [String] {
        return Array(players).sorted()
    }
    
    /// Returns the number of achievements unlocked by a specific player.
    ///
    /// - Parameter playerName: The name of the player to query
    /// - Returns: The count of unlocked achievements, or 0 if player doesn't exist
    func getAchievementCount(for playerName: String) -> Int {
        return playerAchievements[playerName]?.unlockedAchievementIDs.count ?? 0
    }
    
    /// Checks whether a player profile exists.
    ///
    /// - Parameter name: The player name to check
    /// - Returns: `true` if the player exists, `false` otherwise
    func playerExists(name: String) -> Bool {
        return players.contains(name)
    }
    
    /// Creates a new player profile and persists it immediately.
    ///
    /// This method:
    /// 1. Trims whitespace from the name
    /// 2. Validates that the name is not empty
    /// 3. Adds the player to the player list
    /// 4. Saves the player list to UserDefaults
    /// 5. Initializes empty achievement data for the player
    ///
    /// If the player already exists, this is a no-op (idempotent).
    ///
    /// - Parameter name: The name for the new player (will be trimmed)
    func createPlayer(name: String) {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else {
            Logger.app.warning("Attempted to create player with empty name")
            return
        }
        
        players.insert(trimmedName)
        savePlayers()
        
        Logger.app.info("Player created: \(trimmedName, privacy: .private)")
        
        // Initialize empty achievement data for the player if not exists
        if playerAchievements[trimmedName] == nil {
            playerAchievements[trimmedName] = PlayerAchievementData()
            save()
        }
    }
    
    /// Deletes a player and all their achievement data permanently.
    ///
    /// This removes:
    /// - The player from the player list
    /// - All achievement and level progression data for this player
    ///
    /// Changes are persisted immediately to UserDefaults.
    ///
    /// - Parameter name: The name of the player to delete
    /// - Warning: This operation cannot be undone
    func deletePlayer(name: String) {
        Logger.app.info("Player deleted: \(name, privacy: .private) with \(self.getAchievementCount(for: name)) achievements")
        
        players.remove(name)
        playerAchievements.removeValue(forKey: name)
        savePlayers()
        save()
    }
    
    /// Checks if Dev Mode is active for a specific player.
    ///
    /// Dev Mode is activated when the player name is "Wulf" (case-insensitive). In Dev Mode:
    /// - All game modes are unlocked
    /// - All difficulties are unlocked
    /// - No level restrictions apply
    ///
    /// This is useful for testing and development purposes.
    ///
    /// - Parameter playerName: The player name to check (defaults to current player if not specified)
    /// - Returns: `true` if the player name is "Wulf", `false` otherwise
    func isDevMode(playerName: String) -> Bool {
        let normalized = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.caseInsensitiveCompare("Wulf") == .orderedSame
    }
    
    /// Checks if a specific achievement is unlocked for the current player.
    ///
    /// - Parameter achievementID: The achievement ID to check (e.g., `"color_cadet"`)
    /// - Returns: `true` if unlocked, `false` otherwise
    func isUnlocked(_ achievementID: String) -> Bool {
        return unlockedAchievementIDs.contains(achievementID)
    }
    
    /// Determines if a game mode and difficulty combination is unlocked for the current player.
    ///
    /// The unlock system is based on level progression in any standard mode:
    /// - **Colors & Numbers (Normal)**: Always unlocked (starter modes)
    /// - **Shapes (Normal)**: Unlocked when reaching level 10 in any standard mode
    /// - **Flags (Normal)**: Unlocked when reaching level 15 in any standard mode
    /// - **Emojis (Normal)**: Unlocked when reaching level 20 in any standard mode
    /// - **Pro Mode (all modes)**: Unlocked when reaching level 30 in any standard mode
    ///
    /// Dev Mode (player name "Wulf") bypasses all unlock requirements.
    ///
    /// - Parameters:
    ///   - mode: The game mode to check (`.colors`, `.numbers`, `.shapes`, `.flags`, `.emojis`)
    ///   - isPro: Whether to check Pro difficulty (`true`) or Normal difficulty (`false`)
    ///   - playerName: Optional player name to check for Dev Mode. Defaults to empty string (uses current player).
    /// - Returns: `true` if the mode/difficulty is unlocked, `false` otherwise
    ///
    /// ## Example
    /// ```swift
    /// // Check if Shapes mode is available
    /// if store.isModeUnlocked(mode: .shapes, isPro: false) {
    ///     // Player can access Shapes Normal mode
    /// }
    ///
    /// // Check if Pro mode is available for Colors
    /// if store.isModeUnlocked(mode: .colors, isPro: true) {
    ///     // Player can access Colors Pro mode
    /// }
    /// ```
    func isModeUnlocked(mode: GameMode, isPro: Bool, playerName: String = "") -> Bool {
        // Dev Mode: Everything is unlocked
        if isDevMode(playerName: playerName) {
            return true
        }
        
        // Colors and Numbers modes are always unlocked
        if (mode == .colors || mode == .numbers) && !isPro {
            return true
        }
        
        // Get highest level reached across all standard modes
        let highestStandardLevel = max(
            getHighestLevel(mode: .colors, isPro: false),
            getHighestLevel(mode: .numbers, isPro: false),
            getHighestLevel(mode: .shapes, isPro: false),
            getHighestLevel(mode: .flags, isPro: false),
            getHighestLevel(mode: .emojis, isPro: false)
        )
        
        // Check for shapes mode unlock (need to reach level 10)
        if mode == .shapes && !isPro {
            let unlocked = highestStandardLevel >= 10
            Logger.achievements.info("Shapes mode unlock check: \(unlocked), highest level: \(highestStandardLevel), required: 10")
            return unlocked
        }
        
        // Check for flags mode unlock (need to reach level 15)
        if mode == .flags && !isPro {
            let unlocked = highestStandardLevel >= 15
            Logger.achievements.info("Flags mode unlock check: \(unlocked), highest level: \(highestStandardLevel), required: 15")
            return unlocked
        }
        
        // Check for emoji mode unlock (need to reach level 20)
        if mode == .emojis && !isPro {
            let unlocked = highestStandardLevel >= 20
            Logger.achievements.info("Emoji mode unlock check: \(unlocked), highest level: \(highestStandardLevel), required: 20")
            return unlocked
        }
        
        // Check for Pro mode unlock (need to reach level 30 in any standard mode)
        if isPro {
            let unlocked = highestStandardLevel >= 30
            Logger.achievements.info("Pro mode unlock check: \(unlocked), highest level: \(highestStandardLevel), required: 30, mode: \(mode.rawValue)")
            return unlocked
        }
        
        return false
    }
    
    /// Returns the highest level reached for a specific mode and difficulty.
    ///
    /// This queries the current player's level completion progress for the given mode/difficulty.
    ///
    /// - Parameters:
    ///   - mode: The game mode to query
    ///   - isPro: Whether to query Pro difficulty (`true`) or Normal difficulty (`false`)
    /// - Returns: The highest level number completed (e.g., 15), or 0 if never played
    ///
    /// ## Example
    /// ```swift
    /// let highestLevel = store.getHighestLevel(mode: .colors, isPro: false)
    /// print("Highest Colors Normal level: \(highestLevel)")
    /// ```
    func getHighestLevel(mode: GameMode, isPro: Bool) -> Int {
        let key = "\(mode.rawValue)_\(isPro)"
        return levelCompletions[key] ?? 0
    }
    
    /// Records that the current player completed a specific level.
    ///
    /// This method:
    /// 1. Constructs the mode/difficulty key (e.g., `"colors_false"`)
    /// 2. Compares the new level to the current highest level
    /// 3. Updates the highest level if the new level is greater
    /// 4. Persists the change to UserDefaults
    ///
    /// Completing a lower level than previously achieved has no effect (no downgrade).
    ///
    /// - Parameters:
    ///   - level: The level number that was completed
    ///   - mode: The game mode where the level was completed
    ///   - isPro: Whether this was Pro difficulty (`true`) or Normal difficulty (`false`)
    ///
    /// ## Example
    /// ```swift
    /// // Player just completed level 12 in Colors Normal mode
    /// store.markLevelCompletion(level: 12, mode: .colors, isPro: false)
    /// ```
    func markLevelCompletion(level: Int, mode: GameMode, isPro: Bool) {
        let key = "\(mode.rawValue)_\(isPro)"
        let currentHighest = levelCompletions[key] ?? 0
        if level > currentHighest {
            Logger.achievements.info("New highest level reached: \(level) in \(mode.rawValue) (isPro: \(isPro)), previous: \(currentHighest)")
            levelCompletions[key] = level
        }
        save()
    }
    
    /// Checks the current player's progress and unlocks any newly earned achievements.
    ///
    /// This method iterates through all defined achievements and checks if their unlock
    /// conditions are now met based on the current player's level progression. Any
    /// achievements that are newly unlocked are:
    /// 1. Added to the player's unlocked achievements set
    /// 2. Returned in the result array
    /// 3. Persisted to UserDefaults
    ///
    /// Achievements already unlocked are skipped (idempotent operation).
    ///
    /// This should be called after level completion to detect newly earned achievements.
    ///
    /// - Returns: An array of achievement IDs that were newly unlocked (e.g., `["color_cadet", "ultra_instinct"]`)
    ///
    /// ## Achievement Conditions
    /// - **reachLevel**: Player must have completed the specified level in the specified mode/difficulty
    /// - **reachLevelInAllModes**: Player must have completed the specified level in ALL 10 mode/difficulty combinations
    ///
    /// ## Example
    /// ```swift
    /// // After completing a level
    /// store.markLevelCompletion(level: 10, mode: .colors, isPro: false)
    ///
    /// // Check for achievements
    /// let newAchievements = store.checkAndUnlockAchievements()
    /// if !newAchievements.isEmpty {
    ///     print("Unlocked: \(newAchievements)")
    ///     // Show celebration UI
    /// }
    /// ```
    func checkAndUnlockAchievements() -> [String] {
        var newlyUnlocked: [String] = []
        
        for achievement in Achievement.all {
            // Skip if already unlocked
            if isUnlocked(achievement.id) {
                continue
            }
            
            // Check if conditions are met
            let shouldUnlock: Bool
            switch achievement.unlockCondition {
            case .reachLevel(let requiredLevel, let mode, let isPro):
                let key = "\(mode)_\(isPro)"
                let highestLevel = levelCompletions[key] ?? 0
                shouldUnlock = highestLevel >= requiredLevel
                
            case .reachLevelInAllModes(let requiredLevel):
                // Check if all 10 mode combinations reached the required level (5 modes × 2 difficulties)
                let allModes: [(String, Bool)] = [
                    ("colors", false), ("numbers", false), ("shapes", false), ("flags", false), ("emojis", false),
                    ("colors", true), ("numbers", true), ("shapes", true), ("flags", true), ("emojis", true)
                ]
                shouldUnlock = allModes.allSatisfy { mode, isPro in
                    let key = "\(mode)_\(isPro)"
                    return (levelCompletions[key] ?? 0) >= requiredLevel
                }
            }
            
            if shouldUnlock {
                Logger.achievements.notice("Achievement unlocked: \(achievement.id) \(achievement.iconEmoji) for player \(self.currentPlayerName, privacy: .private)")
                
                unlockedAchievementIDs.insert(achievement.id)
                newlyUnlocked.append(achievement.id)
            }
        }
        
        if !newlyUnlocked.isEmpty {
            Logger.achievements.info("Achievements check completed: \(newlyUnlocked.count) new, \(self.unlockedAchievementIDs.count) total")
            save()
        }
        
        return newlyUnlocked
    }
    
    // MARK: - Persistence
    
    /// Saves the current per-player achievement data to UserDefaults.
    ///
    /// This method encodes the entire `playerAchievements` dictionary (all players' data)
    /// and persists it to UserDefaults under the key `tk_achievements_per_player`.
    ///
    /// - Note: Called automatically after any modification to achievement data
    private func save() {
        // Save per-player achievements
        if let encoded = try? JSONEncoder().encode(playerAchievements) {
            UserDefaults.standard.set(encoded, forKey: storageKey)
            Logger.storage.debug("Achievement data saved successfully")
        } else {
            Logger.storage.error("Failed to encode achievement data")
        }
    }
    
    /// Saves the list of all created players to UserDefaults.
    ///
    /// This method encodes the `players` set as an array and persists it to UserDefaults
    /// under the key `tk_players`.
    ///
    /// The player list is stored separately from achievement data to efficiently list
    /// all players without loading their full achievement history.
    ///
    /// - Note: Called automatically after creating or deleting players
    private func savePlayers() {
        // Save player list
        if let encoded = try? JSONEncoder().encode(Array(players)) {
            UserDefaults.standard.set(encoded, forKey: playersStorageKey)
        }
    }
    
    /// Loads per-player achievement data from UserDefaults.
    ///
    /// This method attempts to load the current multi-player achievement system data.
    /// If no data exists (first launch or fresh install), it falls back to migrating
    /// legacy global achievement data.
    ///
    /// - Note: Called automatically during initialization
    private func load() {
        // Try to load per-player achievements first
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let decoded = try? JSONDecoder().decode([String: PlayerAchievementData].self, from: data) {
            playerAchievements = decoded
            Logger.storage.info("Achievement data loaded successfully: \(self.playerAchievements.count) players")
            return
        }
        
        // If no per-player data exists, migrate from old global storage
        Logger.storage.info("No per-player achievement data found, attempting legacy migration")
        migrateLegacyAchievements()
    }
    
    /// Loads the list of created players from UserDefaults.
    ///
    /// This method:
    /// 1. Attempts to load the persisted player list
    /// 2. Ensures all players with achievement data are in the player list (migration)
    /// 3. Saves the player list if any additions were made
    ///
    /// This ensures that even after migration, all players are properly tracked in the player list.
    ///
    /// - Note: Called automatically during initialization
    private func loadPlayers() {
        // Try to load player list
        if let data = UserDefaults.standard.data(forKey: playersStorageKey),
           let decoded = try? JSONDecoder().decode([String].self, from: data) {
            players = Set(decoded)
            Logger.storage.info("Player list loaded: \(self.players.count) players")
        } else {
            Logger.storage.debug("No player list found in storage")
        }
        
        // Ensure all players with achievement data are in the player list (migration)
        var addedPlayers = 0
        for playerName in playerAchievements.keys {
            if !players.contains(playerName) {
                players.insert(playerName)
                addedPlayers += 1
            }
        }
        
        if addedPlayers > 0 {
            Logger.storage.info("Added \(addedPlayers) players from achievement data to player list")
        }
        
        // Save player list if we added any from achievement data
        if !players.isEmpty {
            savePlayers()
        }
    }
    
    // MARK: - Legacy Migration
    
    /// Migrates achievement data from the old global system to the new per-player system.
    ///
    /// This migration runs automatically on first launch after updating from the old version.
    /// It converts:
    /// - **Old system**: Single global achievement list and level 5 completion flags
    /// - **New system**: Per-player achievements with detailed level progression
    ///
    /// ## Migration Process
    /// 1. Loads old unlocked achievements from `tk_achievements`
    /// 2. Loads old level 5 completion flags from `tk_achievement_progress`
    /// 3. Converts old data format to new format:
    ///    - Old: `"2x2_colors_false" -> true` (completed level 5)
    ///    - New: `"colors_false" -> 5` (highest level reached)
    /// 4. Assigns all migrated data to the default player ("Player")
    /// 5. Persists the migrated data
    ///
    /// If no legacy data exists, this is a no-op.
    ///
    /// - Note: This migration preserves player progress when upgrading from version 1.x to 2.x
    private func migrateLegacyAchievements() {
        Logger.storage.info("Starting legacy achievement data migration")
        var legacyData = PlayerAchievementData()
        var migratedAchievements = 0
        var migratedLevels = 0
        
        // Load old unlocked achievements
        if let data = UserDefaults.standard.data(forKey: legacyStorageKey),
           let decoded = try? JSONDecoder().decode([String].self, from: data) {
            legacyData.unlockedAchievementIDs = Set(decoded)
            migratedAchievements = decoded.count
            Logger.storage.debug("Migrated \(migratedAchievements) achievements from legacy storage")
        }
        
        // Load old progress - convert old level5Completions to new format
        if let data = UserDefaults.standard.data(forKey: legacyProgressKey),
           let decoded = try? JSONDecoder().decode([String: Bool].self, from: data) {
            // Old format: "2x2_colors_false" -> true
            // New format: "colors_false" -> 5 (level completed)
            // For migration, we'll extract the mode and isPro, set highest to 5 if completed
            for (key, completed) in decoded where completed {
                let parts = key.split(separator: "_")
                if parts.count == 3 {
                    let mode = String(parts[1])
                    let isPro = parts[2] == "true"
                    let newKey = "\(mode)_\(isPro)"
                    // Set to 5 since old system only tracked level 5 completions
                    let currentMax = legacyData.levelCompletions[newKey] ?? 0
                    legacyData.levelCompletions[newKey] = max(currentMax, 5)
                    migratedLevels += 1
                }
            }
            Logger.storage.debug("Migrated \(migratedLevels) level completions from legacy storage")
        }
        
        // If we found any legacy data, migrate it to the default player
        if !legacyData.unlockedAchievementIDs.isEmpty || !legacyData.levelCompletions.isEmpty {
            playerAchievements["Player"] = legacyData
            players.insert("Player")
            save()  // Save migrated data
            savePlayers()
            Logger.storage.notice("Legacy migration completed: achievements=\(migratedAchievements), levels=\(migratedLevels), assigned to default player")
        } else {
            Logger.storage.info("No legacy data found to migrate")
        }
    }
}

// MARK: - Achievement Definitions

/// Provides the complete list of all available achievements in the game.
///
/// This extension on `Achievement` defines all 22 achievements organized into categories:
///
/// ## Achievement Categories
/// 1. **Early Achievements (3)** - Level 5 in each starter mode
///    - Introduces players to the achievement system
///    - Easy to unlock to encourage progression
///
/// 2. **Unlocking Achievements (4)** - Special achievements that unlock content
///    - `polygon_prodigy` (Level 10): Unlocks Shapes mode
///    - `flag_dropper` (Level 15): Unlocks Flags mode
///    - `smiley_summoner` (Level 20): Unlocks Emojis mode
///    - `ultra_instinct` (Level 30): Unlocks Pro mode
///
/// 3. **Intermediate Achievements (3)** - Level 15 milestones
///    - Moderate challenge for engaged players
///
/// 4. **Advanced Achievements (3)** - Level 25 milestones
///    - Requires significant skill and dedication
///
/// 5. **Numbers & Flags (3)** - Special mode achievements
///    - Celebrates mastery of specific modes
///
/// 6. **Mastery Achievements (3)** - Level 30 in standard modes
///    - Demonstrates expert-level gameplay
///
/// 7. **Pro Mastery (3)** - Level 30 in Pro difficulty
///    - Ultimate challenge for hardcore players
///
/// 8. **Ultimate Achievement (1)** - The Unkillable
///    - Reach level 30 in ALL 10 mode/difficulty combinations
///    - The pinnacle of achievement
///
/// All achievements use localization keys for internationalization support.
extension Achievement {
    /// All 22 achievements available in the game, organized by difficulty and purpose.
    static let all: [Achievement] = [
        // Early Achievements (3) - Level 5
        Achievement(
            id: "color_cadet",
            nameKey: "AchievementColorCadet",
            iconEmoji: "🎨",
            explanationKey: "AchievementColorCadetExplanation",
            unlockCondition: .reachLevel(5, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "shape_novice",
            nameKey: "AchievementShapeNovice",
            iconEmoji: "🔺",
            explanationKey: "AchievementShapeNoviceExplanation",
            unlockCondition: .reachLevel(5, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_apprentice",
            nameKey: "AchievementEmojiApprentice",
            iconEmoji: "😊",
            explanationKey: "AchievementEmojiApprenticeExplanation",
            unlockCondition: .reachLevel(5, mode: "emojis", isPro: false)
        ),
        
        // Unlocking Achievements (3) - These unlock new modes
        Achievement(
            id: "polygon_prodigy",
            nameKey: "AchievementPolygonProdigy",
            iconEmoji: "🔷",
            explanationKey: "AchievementPolygonProdigyExplanation",
            unlockCondition: .reachLevel(10, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "flag_dropper",
            nameKey: "AchievementFlagDropper",
            iconEmoji: "🚩",
            explanationKey: "AchievementFlagDropperExplanation",
            unlockCondition: .reachLevel(15, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "smiley_summoner",
            nameKey: "AchievementSmileySummoner",
            iconEmoji: "😎",
            explanationKey: "AchievementSmileySummonerExplanation",
            unlockCondition: .reachLevel(20, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "ultra_instinct",
            nameKey: "AchievementUltraInstinct",
            iconEmoji: "🔥",
            explanationKey: "AchievementUltraInstinctExplanation",
            unlockCondition: .reachLevel(30, mode: "colors", isPro: false)
        ),
        
        // Intermediate Achievements (3) - Level 15
        Achievement(
            id: "rainbow_wrangler",
            nameKey: "AchievementRainbowWrangler",
            iconEmoji: "🌈",
            explanationKey: "AchievementRainbowWranglerExplanation",
            unlockCondition: .reachLevel(15, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "triangle_tamer",
            nameKey: "AchievementTriangleTamer",
            iconEmoji: "📐",
            explanationKey: "AchievementTriangleTamerExplanation",
            unlockCondition: .reachLevel(15, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_enthusiast",
            nameKey: "AchievementEmojiEnthusiast",
            iconEmoji: "🤩",
            explanationKey: "AchievementEmojiEnthusiastExplanation",
            unlockCondition: .reachLevel(15, mode: "emojis", isPro: false)
        ),
        
        // Advanced Achievements (3) - Level 25
        Achievement(
            id: "color_virtuoso",
            nameKey: "AchievementColorVirtuoso",
            iconEmoji: "🎭",
            explanationKey: "AchievementColorVirtuosoExplanation",
            unlockCondition: .reachLevel(25, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "shape_master",
            nameKey: "AchievementShapeMaster",
            iconEmoji: "⬢",
            explanationKey: "AchievementShapeMasterExplanation",
            unlockCondition: .reachLevel(25, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_expert",
            nameKey: "AchievementEmojiExpert",
            iconEmoji: "😎",
            explanationKey: "AchievementEmojiExpertExplanation",
            unlockCondition: .reachLevel(25, mode: "emojis", isPro: false)
        ),
        
        // Numbers Achievements (2) - Fun and accessible
        Achievement(
            id: "count_on_me",
            nameKey: "AchievementCountOnMe",
            iconEmoji: "🔢",
            explanationKey: "AchievementCountOnMeExplanation",
            unlockCondition: .reachLevel(10, mode: "numbers", isPro: false)
        ),
        Achievement(
            id: "number_cruncher",
            nameKey: "AchievementNumberCruncher",
            iconEmoji: "🧮",
            explanationKey: "AchievementNumberCruncherExplanation",
            unlockCondition: .reachLevel(25, mode: "numbers", isPro: false)
        ),
        
        // Flags Achievement (1)
        Achievement(
            id: "flag_nerd",
            nameKey: "AchievementFlagNerd",
            iconEmoji: "🌍",
            explanationKey: "AchievementFlagNerdExplanation",
            unlockCondition: .reachLevel(20, mode: "flags", isPro: false)
        ),
        
        // Mastery Achievements (3) - Level 30 Standard
        Achievement(
            id: "chromatic_champion",
            nameKey: "AchievementChromaticChampion",
            iconEmoji: "🎨",
            explanationKey: "AchievementChromaticChampionExplanation",
            unlockCondition: .reachLevel(30, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "geometry_genius",
            nameKey: "AchievementGeometryGenius",
            iconEmoji: "🔷",
            explanationKey: "AchievementGeometryGeniusExplanation",
            unlockCondition: .reachLevel(30, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_overlord",
            nameKey: "AchievementEmojiOverlord",
            iconEmoji: "😄",
            explanationKey: "AchievementEmojiOverlordExplanation",
            unlockCondition: .reachLevel(30, mode: "emojis", isPro: false)
        ),
        
        // Pro Mastery Achievements (3) - Level 30 Pro
        Achievement(
            id: "rainbow_annihilator",
            nameKey: "AchievementRainbowAnnihilator",
            iconEmoji: "🔥🌈",
            explanationKey: "AchievementRainbowAnnihilatorExplanation",
            unlockCondition: .reachLevel(30, mode: "colors", isPro: true)
        ),
        Achievement(
            id: "shape_sorcerer",
            nameKey: "AchievementShapeSorcerer",
            iconEmoji: "🔥📐",
            explanationKey: "AchievementShapeSorcererExplanation",
            unlockCondition: .reachLevel(30, mode: "shapes", isPro: true)
        ),
        Achievement(
            id: "emoji_apocalypse",
            nameKey: "AchievementEmojiApocalypse",
            iconEmoji: "🔥😈",
            explanationKey: "AchievementEmojiApocalypseExplanation",
            unlockCondition: .reachLevel(30, mode: "emojis", isPro: true)
        ),
        
        // Ultimate Achievement (1)
        Achievement(
            id: "the_unkillable",
            nameKey: "AchievementTheUnkillable",
            iconEmoji: "💀",
            explanationKey: "AchievementTheUnkillableExplanation",
            unlockCondition: .reachLevelInAllModes(30)
        )
    ]
}
