//
//  HighscoreModels.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation
import SwiftUI
import OSLog

// MARK: - Highscore Models

/// Represents a single highscore entry from a completed game session.
///
/// Each entry captures comprehensive information about a gameplay session including:
/// - Player identification
/// - Score and level achieved
/// - Game mode and difficulty
/// - Achievements unlocked during the session
/// - Date/time of the achievement
///
/// Highscore entries are immutable once created and stored in a `HighscoreStore`.
/// They support backwards compatibility through custom decoding to handle migrations
/// from earlier versions that lacked certain fields.
///
/// ## Example
/// ```swift
/// let entry = HighscoreEntry(
///     playerName: "Alice",
///     score: 2500,
///     maxLevel: 15,
///     achievementIDs: ["color_cadet", "polygon_prodigy"],
///     gameMode: "colors",
///     isPro: false
/// )
/// ```
struct HighscoreEntry: Identifiable, Codable {
    /// Unique identifier for this highscore entry
    let id: UUID
    
    /// Name of the player who achieved this score
    let playerName: String
    
    /// Total score earned during the game session
    let score: Int
    
    /// Maximum level reached during this game session
    let maxLevel: Int
    
    /// Timestamp when this score was achieved
    let date: Date
    
    /// Array of achievement IDs that were unlocked during this game session
    /// Example: `["color_cadet", "polygon_prodigy"]`
    let achievementIDs: [String]
    
    /// Game mode identifier (e.g., "colors", "shapes", "emojis", "flags", "numbers")
    let gameMode: String
    
    /// Whether Pro difficulty was active during this game session
    let isPro: Bool
    
    /// Creates a new highscore entry with all specified parameters.
    ///
    /// - Parameters:
    ///   - id: Unique identifier (defaults to a new UUID)
    ///   - playerName: Name of the player who achieved this score
    ///   - score: Total score earned
    ///   - maxLevel: Maximum level reached (defaults to 1)
    ///   - date: When the score was achieved (defaults to current date/time)
    ///   - achievementIDs: Achievement IDs unlocked during this session (defaults to empty)
    ///   - gameMode: Game mode identifier (defaults to "colors")
    ///   - isPro: Whether Pro difficulty was active (defaults to false)
    init(id: UUID = UUID(), playerName: String, score: Int, maxLevel: Int = 1, date: Date = Date(), achievementIDs: [String] = [], gameMode: String = "colors", isPro: Bool = false) {
        self.id = id
        self.playerName = playerName
        self.score = score
        self.maxLevel = maxLevel
        self.date = date
        self.achievementIDs = achievementIDs
        self.gameMode = gameMode
        self.isPro = isPro
    }
    
    /// Custom decoder that handles backward compatibility with older data formats.
    ///
    /// This initializer ensures that highscore entries saved in older versions of the app
    /// (which lacked `achievementIDs`, `gameMode`, or `isPro` fields) can still be loaded.
    ///
    /// Missing fields are populated with sensible defaults:
    /// - `achievementIDs`: Empty array
    /// - `gameMode`: "colors"
    /// - `isPro`: false
    ///
    /// - Parameter decoder: The decoder to read data from
    /// - Throws: DecodingError if required fields are missing or malformed
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        playerName = try container.decode(String.self, forKey: .playerName)
        score = try container.decode(Int.self, forKey: .score)
        maxLevel = try container.decode(Int.self, forKey: .maxLevel)
        date = try container.decode(Date.self, forKey: .date)
        // Handle missing achievementIDs for backward compatibility
        achievementIDs = (try? container.decode([String].self, forKey: .achievementIDs)) ?? []
        // Handle missing gameMode and isPro for backward compatibility
        gameMode = (try? container.decode(String.self, forKey: .gameMode)) ?? "colors"
        isPro = (try? container.decode(Bool.self, forKey: .isPro)) ?? false
    }
}

// MARK: - Highscore Store

/// Manages the persistent storage and retrieval of highscore entries.
///
/// `HighscoreStore` maintains a leaderboard of the top 10 scores across all players,
/// game modes, and difficulties. It provides automatic sorting, persistence via
/// UserDefaults, and operations for adding, deleting, and clearing scores.
///
/// ## Key Features
/// - **Top 10 Leaderboard**: Automatically maintains only the highest 10 scores
/// - **Automatic Sorting**: Scores are always sorted from highest to lowest
/// - **Persistent Storage**: Scores are saved to UserDefaults and survive app restarts
/// - **Backward Compatibility**: Handles migration from older data formats
///
/// ## Storage
/// Scores are stored in UserDefaults under the key `"tk_highscores"` as JSON-encoded data.
///
/// ## Example Usage
/// ```swift
/// let store = HighscoreStore()
///
/// // Add a new score
/// store.add(
///     score: 2500,
///     playerName: "Alice",
///     maxLevel: 15,
///     achievementIDs: ["color_cadet"],
///     gameMode: "colors",
///     isPro: false
/// )
///
/// // Access all scores
/// for entry in store.entries {
///     print("\(entry.playerName): \(entry.score)")
/// }
///
/// // Clear all scores
/// store.clear()
/// ```
@Observable
class HighscoreStore {
    /// UserDefaults key for storing highscore entries
    private let storageKey = "tk_highscores"
    
    /// Maximum number of highscore entries to keep (top 10)
    private let maxEntries = 10
    
    /// Array of highscore entries, sorted from highest to lowest score
    /// This array is automatically kept sorted and trimmed to `maxEntries`
    var entries: [HighscoreEntry] = []
    
    /// Initializes the highscore store and loads persisted entries from UserDefaults.
    init() {
        load()
    }
    
    /// Adds a new highscore entry to the leaderboard.
    ///
    /// This method:
    /// 1. Creates a new `HighscoreEntry` with the provided information
    /// 2. Appends it to the entries array
    /// 3. Sorts all entries by score (descending)
    /// 4. Trims the array to keep only the top 10 scores
    /// 5. Persists the updated leaderboard to UserDefaults
    ///
    /// If the new score is not in the top 10, it will be automatically removed.
    ///
    /// - Parameters:
    ///   - score: Total score earned during the game session
    ///   - playerName: Name of the player who achieved this score
    ///   - maxLevel: Maximum level reached during the session (defaults to 1)
    ///   - achievementIDs: Achievement IDs unlocked during the session (defaults to empty)
    ///   - gameMode: Game mode identifier (defaults to "colors")
    ///   - isPro: Whether Pro difficulty was active (defaults to false)
    ///
    /// ## Example
    /// ```swift
    /// store.add(
    ///     score: 3500,
    ///     playerName: "Bob",
    ///     maxLevel: 20,
    ///     achievementIDs: ["color_cadet", "ultra_instinct"],
    ///     gameMode: "colors",
    ///     isPro: true
    /// )
    /// ```
    func add(score: Int, playerName: String, maxLevel: Int = 1, achievementIDs: [String] = [], gameMode: String = "colors", isPro: Bool = false) {
        let newEntry = HighscoreEntry(playerName: playerName, score: score, maxLevel: maxLevel, achievementIDs: achievementIDs, gameMode: gameMode, isPro: isPro)
        entries.append(newEntry)
        entries.sort { $0.score > $1.score }
        
        Logger.highscores.notice("New score added: score=\(score), player=\(playerName, privacy: .private), level=\(maxLevel), mode=\(gameMode), pro=\(isPro)")
        
        // Keep only top 10
        if entries.count > maxEntries {
            entries = Array(entries.prefix(maxEntries))
        }
        
        save()
    }
    
    /// Deletes highscore entries at the specified index positions.
    ///
    /// This method removes entries from the leaderboard and persists the change.
    ///
    /// - Parameter offsets: An IndexSet containing the positions of entries to delete
    ///
    /// ## Example
    /// ```swift
    /// // Used with SwiftUI List's onDelete
    /// List {
    ///     ForEach(store.entries) { entry in
    ///         Text("\(entry.playerName): \(entry.score)")
    ///     }
    ///     .onDelete(perform: store.delete)
    /// }
    /// ```
    func delete(at offsets: IndexSet) {
        entries.remove(atOffsets: offsets)
        save()
    }
    
    /// Removes all highscore entries from the leaderboard.
    ///
    /// This method clears the entire leaderboard and persists the empty state.
    /// This operation cannot be undone.
    ///
    /// ## Example
    /// ```swift
    /// // Clear all highscores
    /// store.clear()
    /// ```
    func clear() {
        entries.removeAll()
        Logger.highscores.info("Cleared all scores")
        save()
    }
    
    // MARK: - Persistence
    
    /// Saves the current highscore entries to UserDefaults.
    ///
    /// This method encodes the `entries` array as JSON and persists it to UserDefaults
    /// under the key `"tk_highscores"`.
    ///
    /// - Note: Called automatically after any modification to the entries array
    private func save() {
        if let encoded = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(encoded, forKey: storageKey)
            Logger.storage.debug("Highscore data saved successfully")
        } else {
            Logger.storage.error("Failed to encode highscore data")
        }
    }
    
    /// Loads persisted highscore entries from UserDefaults.
    ///
    /// This method attempts to decode the entries array from UserDefaults.
    /// If no data exists (fresh install) or decoding fails, the entries array
    /// remains empty.
    ///
    /// The custom decoder in `HighscoreEntry` handles backward compatibility
    /// with older data formats.
    ///
    /// - Note: Called automatically during initialization
    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey) else {
            Logger.storage.debug("No highscore data found in storage")
            return
        }
        
        guard let decoded = try? JSONDecoder().decode([HighscoreEntry].self, from: data) else {
            Logger.storage.error("Failed to decode highscore data")
            return
        }
        
        entries = decoded
        Logger.storage.info("Highscore data loaded successfully: \(self.entries.count) entries")
    }
}
