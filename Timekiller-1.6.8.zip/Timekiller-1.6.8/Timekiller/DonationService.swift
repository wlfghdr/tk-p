//
//  DonationService.swift
//  Timekiller
//
//  Created on 01.01.26.
//

#if os(iOS)
import Foundation
import StoreKit
import OSLog

/// Service for managing donation/tip jar In-App Purchases using StoreKit 2.
///
/// This service handles the complete lifecycle of consumable In-App Purchases that act as
/// a tip jar for the app. It loads available products from the App Store, manages purchase
/// transactions, and verifies purchases to ensure they are legitimate.
///
/// The service is marked with `@Observable` to enable seamless integration with SwiftUI views,
/// automatically updating the UI when properties change.
///
/// - Note: This service is only available on iOS, as indicated by the `#if os(iOS)` conditional compilation.
/// - Important: Products must be configured in App Store Connect with matching product identifiers
///   defined in `DonationProduct.rawValue`.
@Observable
class DonationService {
    
    // MARK: - Published Properties
    
    /// Array of available donation products loaded from the App Store.
    /// Products are sorted by price in ascending order after loading.
    private(set) var products: [Product] = []
    
    /// Set of product identifiers that have been purchased by the user.
    /// For consumable products (donations), this is typically not persisted between sessions.
    private(set) var purchasedProductIDs: Set<String> = []
    
    /// Indicates whether the service is currently loading products from the App Store.
    /// Used to show loading indicators in the UI.
    private(set) var isLoading: Bool = false
    
    /// Error message if product loading fails, otherwise `nil`.
    /// This provides user-friendly error messages that can be displayed in the UI.
    private(set) var error: String? = nil

    /// Indicates that StoreKit returned no products for the expected identifiers.
    /// This is common when In-App Purchases are not yet available for the current environment.
    private(set) var noProductsAvailable: Bool = false
    
    // MARK: - Initialization
    
    /// Initializes the donation service and automatically begins loading products.
    ///
    /// The initializer creates a detached `Task` to load products asynchronously,
    /// ensuring the initialization doesn't block the main thread. Products will be
    /// available once the async loading completes.
    init() {
        Task {
            await loadProducts()
        }
    }
    
    // MARK: - Product Loading
    
    /// Loads available donation products from the App Store.
    ///
    /// This method queries the App Store for all products defined in `DonationProduct.allCases`,
    /// using their raw values as product identifiers. Once loaded, products are sorted by price
    /// in ascending order for consistent display.
    ///
    /// The method updates `isLoading` to `true` at the start and `false` upon completion,
    /// allowing UI to display loading states. If an error occurs, it's stored in the `error`
    /// property and also logged to the console with an emoji prefix for easy debugging.
    ///
    /// - Note: This method must be called on the main actor to ensure thread safety when
    ///   updating observable properties.
    @MainActor
    func loadProducts() async {
        // Begin loading and clear any previous errors
        isLoading = true
        error = nil
        noProductsAvailable = false
        
        do {
            // Extract product identifiers from all donation tiers
            let productIDs = DonationProduct.allCases.map(\.rawValue)
            Logger.iap.debug("Loading IAP products: \(productIDs.joined(separator: ", "), privacy: .public)")
            
            // Query the App Store for products matching these identifiers
            products = try await Product.products(for: Set(productIDs))
            
            // Sort products by price (ascending) for consistent UI presentation
            products.sort { $0.price < $1.price }

            if products.isEmpty {
                let expectedIDs = Set(productIDs)
                let returnedIDs = Set(products.map(\.id))
                let missing = expectedIDs.subtracting(returnedIDs).sorted()
                Logger.iap.warning("No IAP products returned from StoreKit. Missing IDs: \(missing.joined(separator: ", "), privacy: .public)")
                noProductsAvailable = true
            } else {
                Logger.iap.info("Loaded \(self.products.count) IAP products")
            }
            
            // Loading complete
            isLoading = false
        } catch {
            // Store user-friendly error message
            self.error = "Failed to load products: \(error.localizedDescription)"
            isLoading = false
            noProductsAvailable = false
            
            // Log detailed error for debugging
            Logger.iap.error("Failed to load products: \(error.localizedDescription, privacy: .public)")
        }
    }
    
    // MARK: - Purchase Management
    
    /// Initiates a purchase transaction for the specified donation product.
    ///
    /// This method handles the complete purchase flow:
    /// 1. Initiates the purchase through StoreKit
    /// 2. Handles different purchase result states (success, cancelled, pending)
    /// 3. Verifies the transaction to ensure legitimacy
    /// 4. Finishes the transaction immediately (since donations are consumable)
    ///
    /// For successful purchases, the transaction is verified and then finished, which tells
    /// StoreKit that the purchase has been processed. For consumable products like donations,
    /// there's no persistent entitlement to track.
    ///
    /// - Parameter product: The `Product` instance to purchase (obtained from the `products` array)
    /// - Returns: `true` if the purchase was successful, `false` if cancelled or pending
    /// - Throws: An error if the purchase or verification fails
    ///
    /// - Note: This method must be called on the main actor to ensure UI updates happen
    ///   on the main thread.
    @MainActor
    func purchase(_ product: Product) async throws -> Bool {
        // Initiate the purchase transaction
        let result = try await product.purchase()
        
        // Handle the purchase result based on its state
        switch result {
        case .success(let verification):
            // Purchase succeeded - now verify the transaction is legitimate
            let transaction = try checkVerified(verification)
            
            // For consumable products (donations), immediately finish the transaction
            // This tells StoreKit we've processed the purchase and it can be consumed
            await transaction.finish()
            
            Logger.iap.notice("Purchase successful: \(product.id)")
            return true
            
        case .userCancelled:
            // User cancelled the purchase dialog - not an error, just inform caller
            Logger.iap.info("User cancelled purchase")
            return false
            
        case .pending:
            // Purchase is pending (e.g., awaiting parental approval)
            Logger.iap.info("Purchase pending")
            return false
            
        @unknown default:
            // Handle any future cases added to StoreKit
            Logger.iap.warning("Unknown purchase result")
            return false
        }
    }
    
    // MARK: - Transaction Verification
    
    /// Verifies that a transaction is legitimate and hasn't been tampered with.
    ///
    /// StoreKit 2 provides automatic cryptographic verification of transactions to ensure
    /// they're authentic and originated from the App Store. This method unwraps the
    /// `VerificationResult` and either returns the verified transaction or throws an error
    /// if verification fails.
    ///
    /// - Parameter result: The `VerificationResult` to check
    /// - Returns: The verified transaction if legitimate
    /// - Throws: The verification error if the transaction is unverified
    ///
    /// - Important: Always verify transactions before granting access to purchased content
    ///   to prevent unauthorized access.
    private func checkVerified<T>(_ result: VerificationResult<T>) throws -> T {
        switch result {
        case .unverified(_, let error):
            // Verification failed - transaction may be fraudulent
            throw error
        case .verified(let safe):
            // Verification succeeded - transaction is legitimate
            return safe
        }
    }
    
    // MARK: - Helper Methods
    
    /// Returns the localized, formatted price string for a product.
    ///
    /// This uses the `displayPrice` property from StoreKit, which automatically
    /// formats the price according to the user's locale and the product's storefront.
    /// For example: "$0.99", "€0.99", "¥100", etc.
    ///
    /// - Parameter product: The product to get the formatted price for
    /// - Returns: A localized, formatted price string
    func formattedPrice(for product: Product) -> String {
        product.displayPrice
    }
    
    /// Retrieves a specific product by its donation type.
    ///
    /// This is a convenience method to look up products from the `products` array
    /// by their `DonationProduct` enum case, rather than by raw product ID string.
    ///
    /// - Parameter donationType: The donation tier to look up
    /// - Returns: The matching `Product` if found, otherwise `nil`
    ///
    /// - Note: Returns `nil` if products haven't been loaded yet or if the specific
    ///   product is not available in the current storefront.
    func product(for donationType: DonationProduct) -> Product? {
        products.first { $0.id == donationType.rawValue }
    }
}
#endif
