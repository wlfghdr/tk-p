//
//  DonationViews.swift
//  Timekiller
//
//  Created on 01.01.26.
//

#if os(iOS)
import SwiftUI
import StoreKit
import OSLog

// MARK: - Donate Button

/// A customizable button that opens the in-app donation/tip interface.
///
/// `DonateButton` provides a non-intrusive way for users to optionally support
/// the development of Timekiller through in-app purchases. The button adapts its
/// appearance based on context (icon-only vs with text).
///
/// ## Button Styles
///
/// ### Icon Only (`.iconOnly`)
/// - Pink heart icon (❤️)
/// - Title2 font size
/// - Transparent background
/// - Minimal footprint
/// - Best for: Toolbars, compact spaces
///
/// ### With Text (`.withText`)
/// - Pink heart icon + text label
/// - Caption font size
/// - Ultra-thin material background
/// - Rounded rectangle container (8pt radius)
/// - Custom text support via `customText` parameter
/// - Best for: Prominent placements, call-to-action areas
///
/// ## Usage
/// ```swift
/// // Icon only (toolbar)
/// DonateButton(language: "en", style: .iconOnly)
///
/// // With text (start screen)
/// DonateButton(
///     language: "en",
///     style: .withText,
///     customText: "Support this free app"
/// )
/// ```
///
/// ## Behavior
/// Tapping the button presents `DonationSheet` as a modal sheet, which displays:
/// - Available donation tiers
/// - StoreKit purchase flow
/// - Thank you confirmation
///
/// ## Localization
/// - Default text: Localized "Donate" key
/// - Custom text: Pass via `customText` parameter (already localized)
/// - Language: Passed to sheet for full localization
///
/// - Note: iOS only. Donation feature is not available on watchOS.
struct DonateButton: View {
    let language: String
    let style: DonateButtonStyle
    let customText: String?
    
    @State private var showDonationSheet = false
    
    enum DonateButtonStyle {
        case iconOnly
        case withText
    }
    
    init(language: String, style: DonateButtonStyle = .iconOnly, customText: String? = nil) {
        self.language = language
        self.style = style
        self.customText = customText
    }
    
    var body: some View {
        Button {
            showDonationSheet = true
        } label: {
            switch style {
            case .iconOnly:
                Image(systemName: "heart.fill")
                    .foregroundStyle(.pink)
                    .font(.title2)
            case .withText:
                HStack(spacing: 6) {
                    Image(systemName: "heart.fill")
                        .foregroundStyle(.pink)
                        .font(.caption)
                    Text(customText ?? L("Donate", language: language))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(.ultraThinMaterial)
                )
            }
        }
        .sheet(isPresented: $showDonationSheet) {
            DonationSheet(language: language)
        }
    }
}

// MARK: - Donation Sheet

/// A full-screen modal interface for selecting and purchasing donation tiers.
///
/// `DonationSheet` presents a beautiful, user-friendly interface that explains
/// the optional nature of donations and displays available tip amounts as in-app
/// purchases. It integrates with StoreKit 2 for seamless payment processing.
///
/// ## Layout Structure
///
/// ### Header Section
/// - Large heart emoji (❤️, 60pt)
/// - "Support Timekiller" title (bold)
/// - "Choose Your Tip" subtitle (secondary color)
/// - Top padding for visual breathing room
///
/// ### Products Grid
/// Three-column layout displaying donation tiers:
/// - Small, Medium, Large (or other configured tiers)
/// - Each tier shows: Emoji, Name, Price
/// - Styled as cards with secondary background
/// - Accent color outline for emphasis
///
/// **Loading State**: Shows `ProgressView` while fetching from App Store
/// **Error State**: Shows exclamation triangle + error message + Retry button
///
/// ### Footer Section
/// - "Thanks for your support" message (caption, secondary)
/// - Link to GitHub discussions for feature requests
///
/// ### Action Buttons
/// - **Close Button (Top Right)**: X icon, dismisses sheet
///
/// ## Purchase Flow
///
/// 1. User taps a donation tier card
/// 2. `handlePurchase(_:)` is called
/// 3. `isPurchasing` becomes `true` (disables all buttons)
/// 4. `donationService.purchase(product)` is called
/// 5. System payment sheet appears
/// 6. On success: `showThankYou` becomes `true`
/// 7. Thank you overlay is displayed
/// 8. User taps "Done" → overlay + sheet both dismiss
///
/// ## Thank You Overlay
///
/// Full-screen overlay displayed after successful purchase:
/// - Black semi-transparent backdrop (0.4 opacity)
/// - Card with regular material background
/// - Party popper emoji (🎉, 80pt)
/// - "Thank You!" title
/// - Personalized thank you message
/// - "Done" button (dismisses overlay + sheet)
///
/// ## Error Handling
///
/// ### Product Loading Errors
/// - Displayed in products section
/// - Shows orange exclamation triangle
/// - Error message in secondary text
/// - "Retry" button reloads products
///
/// ### Purchase Errors
/// - Caught in `handlePurchase(_:)` do-catch
/// - Printed to console (for debugging)
/// - No user-facing error (StoreKit handles UI)
///
/// ## Data Flow
///
/// ### Initialization
/// ```swift
/// DonationSheet(
///     language: appLanguage,
///     donationService: donationService
/// )
/// ```
///
/// ### State Management
/// - `isPurchasing`: Disables buttons during purchase flow
/// - `showThankYou`: Controls thank you overlay visibility
/// - `donationService.isLoading`: Controls product loading state
/// - `donationService.error`: Holds product loading error message
///
/// ### Product Retrieval
/// Products are loaded via `DonationService`:
/// - Fetched from App Store on service initialization
/// - Cached for the lifetime of the service
/// - Filtered by `DonationProduct.allCases` enum
///
/// ## StoreKit Integration
///
/// Uses StoreKit 2 APIs:
/// - `Product`: Represents each donation tier
/// - `Product.purchase()`: Initiates purchase flow
/// - `Product.displayPrice`: Localized price string
///
/// ## Localization
///
/// All text is localized via `L()` helper:
/// - "SupportTimekiller"
/// - "ChooseYourTip"
/// - "ThanksForSupport"
/// - "DonationThankYou"
/// - "DonationThankYouMessage"
/// - "Done"
///
/// Product names are also localized via `L(tier.nameKey, language:)`.
///
/// ## GitHub Link
///
/// Includes a `Link` to GitHub discussions:
/// - URL: `https://github.com/wlfghdr/tk-p`
/// - Text: "Discuss wishes & ideas"
/// - Blue color (standard link appearance)
/// - Opens in Safari when tapped
///
/// ## Accessibility
///
/// - All buttons have clear labels
/// - Product cards are tappable with full context
/// - Prices are read aloud correctly
/// - Loading/error states are announced
///
/// - Note: iOS only. Donation feature uses StoreKit which is not available on watchOS.
struct DonationSheet: View {
    let language: String
    @State private var donationService = DonationService()
    
    @Environment(\.dismiss) private var dismiss
    @State private var isPurchasing = false
    @State private var showThankYou = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                ScrollView {
                    VStack(spacing: 24) {
                        // Header
                        VStack(spacing: 8) {
                            Text("❤️")
                                .font(.system(size: 60))
                            Text(L("SupportTimekiller", language: language))
                                .font(.title.bold())
                            Text(L("ChooseYourTip", language: language))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.top, 20)
                        
                        // Products Grid
                        if donationService.isLoading {
                            ProgressView()
                                .padding(40)
                        } else if donationService.noProductsAvailable {
                            VStack(spacing: 12) {
                                Image(systemName: "exclamationmark.triangle")
                                    .font(.largeTitle)
                                    .foregroundStyle(.orange)
                                Text(L("DonationUnavailableTitle", language: language))
                                    .font(.headline)
                                Text(L("DonationUnavailableMessage", language: language))
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                                Text(L("DonationUnavailableReviewNote", language: language))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                                Button(L("Retry", language: language)) {
                                    Task {
                                        await donationService.loadProducts()
                                    }
                                }
                                .buttonStyle(.borderedProminent)
                            }
                            .padding(40)
                        } else if let error = donationService.error {
                            VStack(spacing: 12) {
                                Image(systemName: "exclamationmark.triangle")
                                    .font(.largeTitle)
                                    .foregroundStyle(.orange)
                                Text(error)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                                Button(L("Retry", language: language)) {
                                    Task {
                                        await donationService.loadProducts()
                                    }
                                }
                                .buttonStyle(.borderedProminent)
                            }
                            .padding(40)
                        } else {
                            LazyVGrid(columns: [
                                GridItem(.flexible()),
                                GridItem(.flexible()),
                                GridItem(.flexible())
                            ], spacing: 16) {
                                ForEach(DonationProduct.allCases) { tier in
                                    if let product = donationService.product(for: tier) {
                                        DonationTierCard(
                                            product: product,
                                            tier: tier,
                                            language: language,
                                            isPurchasing: isPurchasing,
                                            onPurchase: {
                                                await handlePurchase(product)
                                            }
                                        )
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                        
                        // Footer message
                        Text(L("ThanksForSupport", language: language))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .padding(.top, 8)
                            .padding(.bottom, 20)
                        
                        // Link to GitHub for feature requests
                        Link(destination: URL(string: "https://github.com/wlfghdr/tk-p")!) {
                            HStack(spacing: 6) {
                                Image(systemName: "bubble.left.and.bubble.right")
                                    .font(.caption)
                                Text("Discuss wishes & ideas")
                                    .font(.caption)
                            }
                            .foregroundStyle(.blue)
                        }
                        .padding(.bottom, 20)
                    }
                }
                
                // Thank You Overlay
                if showThankYou {
                    thankYouOverlay
                }
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }
    
    private var thankYouOverlay: some View {
        ZStack {
            Color.black.opacity(0.4)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("🎉")
                    .font(.system(size: 80))
                Text(L("DonationThankYou", language: language))
                    .font(.title.bold())
                    .multilineTextAlignment(.center)
                Text(L("DonationThankYouMessage", language: language))
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                
                Button {
                    showThankYou = false
                    dismiss()
                } label: {
                    Text(L("Done", language: language))
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.accentColor)
                        .cornerRadius(12)
                }
                .padding(.top, 10)
            }
            .padding(30)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(.regularMaterial)
            )
            .padding(40)
        }
    }
    
    @MainActor
    private func handlePurchase(_ product: Product) async {
        isPurchasing = true
        
        do {
            let success = try await donationService.purchase(product)
            if success {
                // Show thank you message
                showThankYou = true
            }
        } catch {
            Logger.iap.error("Purchase error: \(error.localizedDescription, privacy: .public)")
        }
        
        isPurchasing = false
    }
}

// MARK: - Donation Tier Card

/// A single card representing one donation tier option.
///
/// `DonationTierCard` displays a donation tier (Small, Medium, Large) as a tappable
/// card with emoji, name, and price. It integrates with StoreKit to initiate purchases.
///
/// ## Visual Design
///
/// ### Layout (Vertical Stack)
/// 1. **Emoji**: Large icon representing tier (40pt system font)
/// 2. **Name**: Tier name in caption bold font (e.g., "Small Tip")
/// 3. **Price**: App Store price in title3 bold green font (e.g., "$0.99")
///
/// ### Styling
/// - Secondary system background color
/// - 12pt corner radius
/// - Accent color outline (0.3 opacity, 1pt width)
/// - Vertical padding: 16pt
/// - Full width of grid column
/// - Center-aligned text
///
/// ### Text Adaptations
/// - Name supports 2 lines with line limit
/// - Minimum scale factor: 0.8 (prevents awkward truncation)
/// - Multiline text centered
///
/// ## Behavior
///
/// ### Purchase Flow
/// 1. User taps card
/// 2. `onPurchase()` async closure is called
/// 3. Parent view (`DonationSheet`) handles StoreKit interaction
/// 4. Card is disabled during purchase (`isPurchasing` state)
///
/// ### Button Style
/// - `.plain` button style (no default system styling)
/// - Custom appearance via card design
/// - Maintains full custom visual design
///
/// ## Parameters
/// - `product`: StoreKit `Product` object with price info
/// - `tier`: `DonationProduct` enum case (Small/Medium/Large)
/// - `language`: Language code for localization
/// - `isPurchasing`: Whether any purchase is in progress
/// - `onPurchase`: Async closure to call when tapped
///
/// ## Localization
/// - **Name**: Retrieved via `L(tier.nameKey, language:)`
/// - **Price**: Retrieved via `product.displayPrice` (StoreKit localizes automatically)
///
/// ## Tier Properties
/// Each `DonationProduct` enum case provides:
/// - `emoji`: Visual icon (e.g., ☕️, 🍕, 🎁)
/// - `nameKey`: Localization key (e.g., "DonationSmall")
///
/// ## Accessibility
/// - Button is labeled with tier name
/// - Price is read aloud correctly
/// - Disabled state is announced when `isPurchasing`
/// - Full card is tappable (not just text)
///
/// ## Usage
/// ```swift
/// DonationTierCard(
///     product: storeProduct,
///     tier: .small,
///     language: "en",
///     isPurchasing: false,
///     onPurchase: {
///         await handlePurchase(storeProduct)
///     }
/// )
/// ```
///
/// - Note: This card is designed for use in a `LazyVGrid` with 3 columns,
///   as implemented in `DonationSheet`.
struct DonationTierCard: View {
    let product: Product
    let tier: DonationProduct
    let language: String
    let isPurchasing: Bool
    let onPurchase: () async -> Void
    
    var body: some View {
        Button {
            Task {
                await onPurchase()
            }
        } label: {
            VStack(spacing: 12) {
                Text(tier.emoji)
                    .font(.system(size: 40))
                
                Text(L(tier.nameKey, language: language))
                    .font(.caption.bold())
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
                
                Text(product.displayPrice)
                    .font(.title3.bold())
                    .foregroundStyle(.green)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(.secondarySystemBackground))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.accentColor.opacity(0.3), lineWidth: 1)
            )
        }
        .disabled(isPurchasing)
        .buttonStyle(.plain)
    }
}

#endif
