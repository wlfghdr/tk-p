//
//  AchievementView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI

// MARK: - Achievement View

/// Displays all game achievements organized by difficulty and purpose for iOS/iPadOS.
///
/// `AchievementView_iOS` presents a comprehensive, scrollable list of all 19 achievements
/// available in the game, grouped into logical categories. Each achievement shows its unlock
/// status, emoji icon, name, and explanation text with larger touch targets and more spacious
/// layout optimized for iPhone and iPad displays.
///
/// ## Achievement Categories
///
/// Achievements are organized into 7 sections based on unlock level and purpose:
///
/// ### 1. Early Achievements (Level 5)
/// **First milestone achievements to encourage new players**
///
/// Includes:
/// - Standard Level 5 achievements for each mode (Colors, Shapes, Flags, Emojis)
/// - "Count on Me" (Numbers Level 10) - grouped here as early number achievement
///
/// Purpose: Introduce achievement system, provide early wins, build momentum
///
/// Example achievements:
/// - 🎨 "Chromatic Novice" - Reach level 5 in Colors mode
/// - 🔢 "Count on Me" - Reach level 10 in Numbers mode
///
/// ### 2. Unlocking Achievements (Levels 10, 20, 30)
/// **Special achievements that unlock new content**
///
/// Four critical achievements that gate advanced features:
/// - **🔺 Polygon Prodigy** (Level 10 Colors): Unlocks Shapes mode
/// - **🚩 Flag Dropper** (Level 20 Colors): Unlocks Flags mode
/// - **😊 Smiley Summoner** (Level 20 Shapes): Unlocks Emojis mode
/// - **🧠 Ultra Instinct** (Level 30 any mode): Unlocks Pro mode globally
///
/// Purpose: Progressive unlock system, encourage mastery before advancing
///
/// Design rationale:
/// - Players must master Colors before accessing Shapes/Flags
/// - Shapes mastery required for Emojis (most challenging mode)
/// - Pro mode requires high-level competency in any standard mode
///
/// ### 3. Intermediate Achievements (Level 15)
/// **Mid-game milestones**
///
/// Includes:
/// - Level 15 achievements for modes that have them
/// - Excludes unlocking achievements (those are in section 2)
///
/// Purpose: Maintain engagement during mid-game, bridge early → advanced
///
/// ### 4. Advanced Achievements (Levels 20-25)
/// **High-skill milestones**
///
/// Includes:
/// - Level 20 and 25 achievements for all modes
/// - Excludes the unlocking achievements from level 20
///
/// Purpose: Challenge skilled players, recognize sustained excellence
///
/// ### 5. Mastery Achievements (Level 30 Standard)
/// **Standard mode completion badges**
///
/// Requirements:
/// - Reach level 30 in any mode
/// - Standard mode only (not Pro)
///
/// Purpose: Recognize mode mastery without Pro requirement, inclusive achievement
///
/// Example: "Color Champion" - Complete 30 levels in standard Colors mode
///
/// ### 6. Pro Mastery Achievements (Level 30 Pro)
/// **Expert-level completion badges**
///
/// Requirements:
/// - Reach level 30 in any mode
/// - Pro mode required (16 items, 1.5× multiplier)
///
/// Purpose: Recognize ultimate skill and dedication, prestige badges
///
/// Example: "Prismatic Master" - Complete 30 levels in Pro Colors mode
///
/// Difficulty increase in Pro mode:
/// - 2× item variety (16 vs 8)
/// - Faster cognitive load
/// - More similar-looking items
/// - Requires sustained focus
///
/// ### 7. Ultimate Achievement
/// **Legendary completionist badge**
///
/// Requirement:
/// - Reach level 30 in ALL 5 modes (Colors, Numbers, Shapes, Flags, Emojis)
/// - Can be any combination of standard/pro
///
/// Purpose: Final challenge for completionists, pinnacle recognition
///
/// Achievement: 🏆 "Master of All Modes" - Reach level 30 in all 5 game modes
///
/// Time investment: Estimated 10-20 hours of focused gameplay
///
/// ## Achievement Display
///
/// Each achievement row shows (iOS layout):
///
/// ### Visual Elements
/// - **Emoji Icon** (left, 40pt): Large, thematic representation
///   - Full color + scale 1.0 if unlocked
///   - Grayscale + opacity 0.5 if locked
/// - **Text Stack** (center):
///   - **Name** (top, 14pt subheadline bold): Short, memorable title
///     - Primary color if unlocked
///     - Secondary color if locked
///   - **Explanation** (bottom, 12pt caption): How to unlock it
///     - Secondary color, no line limit
/// - **Status Icon** (right):
///   - Green checkmark circle (unlocked)
///   - Gray lock (locked)
///
/// ### Spacing & Layout
/// - Row padding: 4pt vertical (more spacious than watchOS 2pt)
/// - Icon size: 40pt (double watchOS 20pt)
/// - Horizontal spacing: 12pt (double watchOS 6pt)
/// - Comfortable for finger taps on iPhone/iPad
///
/// ## Unlock Status Logic
///
/// Status determined by `achievementStore.isUnlocked(achievement.id)`:
///
/// Check process:
/// 1. Retrieves current player's achievement data from `@AppStorage`
/// 2. Looks up player's completion records by mode/level/pro
/// 3. Compares against achievement's `unlockCondition`
/// 4. Returns boolean: unlocked or locked
///
/// Conditions supported:
/// - `.reachLevel(level, mode, isPro)` - Single mode completion
/// - `.reachLevelInAllModes(level)` - Multi-mode completion
///
/// Updates automatically when:
/// - Level is completed during gameplay
/// - `ContentView_iOS` calls `achievementStore.markLevelCompletion(...)`
/// - Store checks all achievements and unlocks matching ones
///
/// ## Achievement Filtering
///
/// Each section uses computed properties to filter `Achievement.all`:
///
/// ```swift
/// // Example: Early achievements
/// private var earlyAchievements: [Achievement] {
///     Achievement.all.filter { achievement in
///         // Level 5 achievements
///         if case .reachLevel(5, _, false) = achievement.unlockCondition {
///             return true
///         }
///         // Special case: Numbers Level 10
///         if achievement.id == "count_on_me" {
///             return true
///         }
///         return false
///     }
/// }
/// ```
///
/// Filtering logic:
/// - Pattern matching on `UnlockCondition` enum
/// - Checks level, mode, pro status
/// - Excludes achievements that unlock content (separated into their own section)
/// - Uses achievement ID for special cases
///
/// Benefits:
/// - Computed once per render
/// - Cached by SwiftUI
/// - Efficient pattern matching (O(n) where n = 19)
///
/// ## iOS-Specific Optimizations
///
/// ### Spacious Layout
/// - Large fonts: 14pt names (subheadline.bold), 12pt descriptions (caption)
/// - Large icons: 40pt emoji, title2-sized SF Symbols
/// - Comfortable spacing: 12pt horizontal, 4pt vertical
/// - No line limits on explanations (full text visible)
///
/// ### List Performance
/// - Uses SwiftUI's native List for optimal scrolling
/// - Lazy rendering (only visible items rendered)
/// - Efficient filtering with cached computed properties
/// - No animations or expensive operations during scroll
///
/// ### Visual Clarity
/// - Section headers use localized keys with prominent styling
/// - Consistent color coding (green = unlocked, gray = locked)
/// - Grayscale filter on locked achievements (clear visual distinction)
/// - High contrast text colors (WCAG AA compliant)
///
/// ### Touch Targets
/// - Minimum 44pt tap height (iOS Human Interface Guidelines)
/// - Full row is tappable (though no action on tap - view-only)
/// - Spacing prevents accidental taps
/// - Works well with VoiceOver double-tap
///
/// ## Localization
///
/// All text uses localization system with `L()` function:
///
/// - **Section headers**: `L("EarlyAchievements", language: language)`
/// - **Achievement names**: `L(achievement.nameKey, language: language)`
/// - **Explanations**: `L(achievement.explanationKey, language: language)`
///
/// Supported languages:
/// - English (en) - Default
/// - German (de) - Complete translation
///
/// Localization keys stored in:
/// - `Localizable.strings` (iOS/watchOS)
/// - Loaded from main bundle
/// - Fallback to English if key missing
///
/// ## Data Flow
///
/// ### Input Parameters
/// - `language: String`: Current app language ("en" or "de")
/// - `playerName: String`: Current player (for per-player tracking)
/// - `achievementStore: AchievementStore`: Tracks unlock status
///
/// ### Output
/// - Read-only display (no user interaction except scrolling)
/// - Achievement store updates happen during gameplay (not in this view)
///
/// ### State Management
/// - No local `@State` variables (stateless view)
/// - Observes `achievementStore` for unlock status
/// - Re-renders when achievement store publishes changes
///
/// ## Integration with Game
///
/// Achievements unlock automatically during gameplay:
///
/// 1. **Player completes level** → Game ends with positive score
/// 2. **ContentView checks** → Calls `achievementStore.markLevelCompletion(level:mode:isPro:)`
/// 3. **Store evaluates** → Checks all 19 achievements against completion
/// 4. **Matches unlock** → Updates `@AppStorage` with new unlocked achievement IDs
/// 5. **View reflects** → This view automatically shows updated status
/// 6. **Notification shows** → ContentView displays achievement toast
///
/// Flow is automatic and requires no manual intervention.
///
/// ## Achievement Progression Path
///
/// Typical player journey through achievements:
///
/// **Early Game (Levels 1-10)**
/// - 🎨 Chromatic Novice (L5 Colors)
/// - 🔺 Polygon Prodigy (L10 Colors) → **Unlocks Shapes**
/// - 🔢 Count on Me (L10 Numbers)
///
/// **Mid Game (Levels 11-20)**
/// - 🎨 Color Connoisseur (L15 Colors)
/// - 🚩 Flag Dropper (L20 Colors) → **Unlocks Flags**
/// - 🔺 Shape Shifter (L15 Shapes)
/// - 😊 Smiley Summoner (L20 Shapes) → **Unlocks Emojis**
///
/// **Advanced Game (Levels 21-30)**
/// - Various L25 achievements
/// - 🧠 Ultra Instinct (L30 any mode) → **Unlocks Pro Mode**
/// - Standard L30 mastery badges
///
/// **Expert Game (Pro Mode)**
/// - Pro L30 mastery badges (requires Pro mode)
///
/// **Completionist**
/// - 🏆 Master of All Modes (L30 in all 5 modes)
///
/// ## Example Usage
///
/// ```swift
/// // In HighscoreView_iOS or Settings
/// Button {
///     showAchievements = true
/// } label: {
///     HStack {
///         Image(systemName: "trophy.fill")
///             .foregroundStyle(.yellow)
///         Text("Achievements")
///     }
/// }
/// .sheet(isPresented: $showAchievements) {
///     NavigationStack {
///         AchievementView_iOS(
///             language: appLanguage,
///             playerName: playerName,
///             achievementStore: achievementStore
///         )
///         .navigationTitle("Achievements")
///         .navigationBarTitleDisplayMode(.large)
///     }
/// }
/// ```
///
/// ## Accessibility
///
/// ### VoiceOver Support
/// - Each row reads: "Achievement name, explanation, unlocked" or "locked"
/// - Section headers announce category
/// - List navigation with swipe gestures
/// - Emoji icons have text descriptions
///
/// ### Dynamic Type
/// - All text scales with user's font size preference
/// - Layout adapts to larger text sizes
/// - No text truncation at default sizes
///
/// ### Color Contrast
/// - Primary text: High contrast (WCAG AA)
/// - Secondary text: Medium contrast (still readable)
/// - Green checkmark: Sufficient contrast on light/dark backgrounds
/// - Grayscale effect: Clear visual distinction without relying solely on color
///
/// ### Reduce Motion
/// - No animations in this view
/// - Respects user's motion preferences globally
///
/// ## Performance Characteristics
///
/// - **Filtering**: O(n) per section where n = 19, computed once per render
/// - **Memory**: ~3KB for all achievement data (19 achievements × ~150 bytes each)
/// - **Rendering**: Lazy (only visible rows rendered by List)
/// - **Updates**: Automatic via `@ObservableObject` store
/// - **Scrolling**: 60fps on all devices (native List implementation)
///
/// ## Testing Considerations
///
/// When testing achievement display:
/// 1. **Empty state**: New player with no achievements unlocked
/// 2. **Partial unlock**: Player with some but not all achievements
/// 3. **Fully unlocked**: Player who completed everything
/// 4. **Language switching**: Toggle between English/German
/// 5. **Player switching**: Different players have different progress
/// 6. **Dark mode**: Check contrast and readability
/// 7. **Large text**: Enable accessibility text sizes
/// 8. **VoiceOver**: Navigate entire list with screen reader
///
/// ## Design Rationale
///
/// ### Why 7 sections?
/// - **Cognitive chunking**: Easier to process than one long list
/// - **Progressive disclosure**: Early → Ultimate creates sense of journey
/// - **Visual hierarchy**: Clear separation of achievement types
/// - **Scanability**: Users can quickly find what they're looking for
///
/// ### Why separate "Unlocking Achievements"?
/// - **Functional importance**: These achievements have gameplay impact
/// - **Player guidance**: Shows what to aim for next
/// - **Clear gating**: Transparent about locked content requirements
///
/// ### Why include level in section names?
/// - **Clarity**: Players know what to expect in each section
/// - **Motivation**: Shows progression ladder
/// - **Organization**: Natural grouping by difficulty
///
/// - Note: This is the iOS/iPadOS version. For watchOS, use `AchievementView_WatchOS`
///   which has more compact layout (20pt icons, 9pt text, tighter spacing) optimized
///   for Apple Watch's smaller display.
struct AchievementView_iOS: View {
    let language: String
    let playerName: String
    let achievementStore: AchievementStore
    
    var body: some View {
        List {
            // Early Achievements (Level 5)
            Section {
                ForEach(earlyAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("EarlyAchievements", language: language))
            }
            
            // Unlocking Achievements (Level 10, 20, 30)
            Section {
                ForEach(unlockingAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("UnlockingAchievements", language: language))
            }
            
            // Intermediate Achievements (Level 15)
            Section {
                ForEach(intermediateAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("IntermediateAchievements", language: language))
            }
            
            // Advanced Achievements (Level 25)
            Section {
                ForEach(advancedAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("AdvancedAchievements", language: language))
            }
            
            // Mastery Achievements (Level 30 Standard)
            Section {
                ForEach(masteryAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("MasteryAchievements", language: language))
            }
            
            // Pro Mastery Achievements (Level 30 Pro)
            Section {
                ForEach(proMasteryAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("ProMasteryAchievements", language: language))
            }
            
            // Ultimate Achievement
            Section {
                ForEach(ultimateAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("UltimateAchievement", language: language))
            }
        }
    }
    
    private func achievementRow(achievement: Achievement) -> some View {
        let isUnlocked = achievementStore.isUnlocked(achievement.id)
        
        return HStack(spacing: 12) {
            Text(achievement.iconEmoji)
                .font(.system(size: 40))
                .grayscale(isUnlocked ? 0 : 1)
                .opacity(isUnlocked ? 1 : 0.5)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(L(achievement.nameKey, language: language))
                    .font(.subheadline.bold())
                    .foregroundStyle(isUnlocked ? .primary : .secondary)
                
                Text(L(achievement.explanationKey, language: language))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
            
            if isUnlocked {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.green)
            } else {
                Image(systemName: "lock.fill")
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
    
    // Achievement groupings
    private var earlyAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(5, _, false) = achievement.unlockCondition {
                return true
            }
            // Include Numbers Level 10 achievement
            if achievement.id == "count_on_me" {
                return true
            }
            return false
        }
    }
    
    private var unlockingAchievements: [Achievement] {
        ["polygon_prodigy", "flag_dropper", "smiley_summoner", "ultra_instinct"].compactMap { id in
            Achievement.all.first { $0.id == id }
        }
    }
    
    private var intermediateAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            // Include level 10 and level 15 achievements (but not the unlocking ones)
            if case .reachLevel(let level, _, false) = achievement.unlockCondition {
                return (level == 15) && achievement.unlocksContent == nil
            }
            return false
        }
    }
    
    private var advancedAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            // Include level 20 and level 25 achievements (but not the unlocking ones)
            if case .reachLevel(let level, _, false) = achievement.unlockCondition {
                return (level == 20 || level == 25) && achievement.unlocksContent == nil
            }
            return false
        }
    }
    
    private var masteryAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(30, _, false) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var proMasteryAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(30, _, true) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var ultimateAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevelInAllModes = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
}
