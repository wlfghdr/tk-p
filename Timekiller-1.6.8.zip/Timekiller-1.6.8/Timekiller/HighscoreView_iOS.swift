//
//  HighscoreView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI
import GameKit
import OSLog

// MARK: - Highscore View

/// Displays local highscores, Game Center integration, and achievement access.
///
/// `HighscoreView_iOS` serves as the central hub for viewing player accomplishments and
/// competitive features. It combines local highscore history, optional Game Center
/// leaderboards, achievement tracking, and donation prompts into a cohesive interface.
///
/// ## Core Sections
///
/// ### 1. Donation Section (iOS Only)
/// Displays a randomized message encouraging optional tips to support development:
/// - Rotating prompt text for variety
/// - Integrated `DonateButton` with visual styling
/// - Non-intrusive placement at top of list
/// - Never blocks access to actual features
///
/// ### 2. Game Center Section
/// Dynamically adapts based on Game Center state:
///
/// **Not Enabled** (Default):
/// - Promotional card explaining global leaderboards
/// - "Enable" button to activate Game Center
/// - Gradient styling to catch attention
/// - Loading state during authentication
///
/// **Enabled but Not Authenticated**:
/// - Warning indicator with exclamation icon
/// - Message directing to Settings to sign in
/// - Clear explanation of why features are unavailable
///
/// **Authenticated** (Active):
/// - "View Global Leaderboards" button → Platform-specific leaderboards
/// - "View Achievements" button → Game Center achievement progress
/// - Trophy and star icons for visual distinction
/// - Descriptive subtitles explaining each feature
///
/// ### 3. Local Achievements Section
/// - Single button to access full achievement overview
/// - Badge count indication (future enhancement)
/// - Always accessible regardless of Game Center status
///
/// ### 4. Local Highscores Section
/// Displays chronologically ordered highscore entries:
/// - **Player Name**: Primary identifier (local or Game Center name)
/// - **Score**: Large, color-coded (green for positive, red for negative)
/// - **Metadata**: Date/time, max level reached, game mode icon
/// - **Pro Badge**: Orange tag if Pro mode was enabled
/// - **Achievements**: Inline display of achievements earned during that game
///
/// Empty state shows "No highscores" message when list is empty.
///
/// ## Game Center Integration
///
/// ### Platform-Specific Leaderboards
/// Timekiller uses separate leaderboards for iOS and watchOS:
/// - **iOS**: `timekiller_ios_{mode}_{pro}` (e.g., `timekiller_ios_colors_pro`)
/// - **watchOS**: `timekiller_watchos_{mode}_{pro}`
///
/// This separation ensures fair competition since:
/// - iOS has larger grids (up to 3×5) vs watchOS (fixed 2×2)
/// - Screen size affects difficulty and playability
/// - Input methods differ (precise touch vs wrist taps)
///
/// ### Leaderboard Discovery
/// The view automatically selects the appropriate leaderboard ID based on:
/// 1. Current platform (iOS vs watchOS)
/// 2. Last played game mode
/// 3. Last played Pro mode setting
///
/// If no matching leaderboard is found, the button is disabled gracefully.
///
/// ### Achievement Display
/// Shows both:
/// - **Local Achievements**: Tracked in `AchievementStore`, always visible
/// - **Game Center Achievements**: Synced to iCloud, progress tracked globally
///
/// ## Data Flow
///
/// ### Initialization
/// Requires these dependencies:
/// ```swift
/// HighscoreView_iOS(
///     store: highscoreStore,              // Local highscore persistence
///     language: appLanguage,               // Localization key
///     achievementStore: achievementStore,  // Achievement tracking
///     playerName: effectivePlayerName,     // Current player identifier
///     gameCenterManager: gameCenterManager // Game Center state and actions
/// )
/// ```
///
/// ### Game Center Enable Flow
/// 1. User taps "Enable Game Center" promotional card
/// 2. `isEnablingGameCenter` state becomes `true` (shows loading spinner)
/// 3. `gameCenterManager.enable()` triggers authentication UI
/// 4. System presents Game Center sign-in sheet
/// 5. On completion, loading state resets and UI updates automatically
///
/// ## UI Patterns
///
/// ### Adaptive Content
/// Sections show/hide based on state:
/// - Donation section: Always visible on iOS (removed on watchOS)
/// - Game Center section: Always visible, but content varies by auth state
/// - Achievements button: Always visible
/// - Highscores section: Shows empty state or list of entries
///
/// ### Visual Hierarchy
/// - **Icons**: Large (title2), colorful, instantly recognizable
/// - **Primary Text**: Headline weight, clear action verbs
/// - **Secondary Text**: Caption size, subtle color, contextual info
/// - **Badges**: Small tags with background tints for special attributes
///
/// ### Navigation
/// Uses SwiftUI sheets for modal presentations:
/// - Leaderboard → `GameCenterLeaderboardView` (UIKit wrapper)
/// - Achievements (GC) → `GameCenterAchievementsView` (UIKit wrapper)
/// - Achievements (Local) → `AchievementView_iOS` (Native SwiftUI)
///
/// ## Performance Considerations
/// - Lazy loading: List content rendered on-demand
/// - Minimal state: Only tracks modal presentation and loading states
/// - No timers or animations: Static content updates only on data changes
///
/// ## Localization
/// All visible text uses the `L()` helper with the provided `language` parameter:
/// - Section headers
/// - Button labels
/// - Achievement names and descriptions
/// - Empty state messages
/// - Game mode names
///
/// ## Example Usage
/// ```swift
/// // In a navigation stack or sheet
/// HighscoreView_iOS(
///     store: highscoreStore,
///     language: "en",
///     achievementStore: achievementStore,
///     playerName: "Player",
///     gameCenterManager: GameCenterManager.shared
/// )
/// .navigationTitle("Highscores")
/// ```
///
/// - Note: This view is iOS-specific due to Game Center UI wrappers and donation
///   integration. For watchOS, use `HighscoreView_WatchOS` which omits those features.
struct HighscoreView_iOS: View {
    let store: HighscoreStore
    let language: String
    let achievementStore: AchievementStore
    let playerName: String
    let gameCenterManager: GameCenterManager
    
    @State private var showAchievements = false
    @State private var showGameCenterLeaderboard = false
    @State private var showGameCenterAchievements = false
    @State private var isEnablingGameCenter = false
    @State private var presentedLeaderboardID: String?
    
    var body: some View {
        List {
            donationSection
            gameCenterSection
            achievementsButtonSection
            localHighscoresSection
        }
        .onAppear {
            Logger.highscores.info("Highscores view appeared - entryCount: \(store.entries.count), playerName: \(playerName, privacy: .private), gameCenterEnabled: \(gameCenterManager.isEnabled), gameCenterAuthenticated: \(gameCenterManager.isAuthenticated)")
        }
        .sheet(isPresented: $showGameCenterLeaderboard) {
            GameCenterLeaderboardView(leaderboardID: presentedLeaderboardID)
        }
        .sheet(isPresented: $showGameCenterAchievements) {
            GameCenterAchievementsView()
        }
        .sheet(isPresented: $showAchievements) {
            achievementsSheet
        }
    }
    
    // MARK: - View Components
    
    @ViewBuilder
    private var donationSection: some View {
        #if os(iOS)
        Section {
            VStack(spacing: 12) {
                let prompts = ["DonateHighscore1", "DonateHighscore2", "DonateHighscore3"]
                let randomPrompt = prompts.randomElement() ?? prompts[0]
                
                Text(L(randomPrompt, language: language))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
                
                DonateButton(language: language, style: .withText)
                    .frame(maxWidth: .infinity)
            }
            .listRowBackground(Color.clear)
            .listRowInsets(EdgeInsets(top: 12, leading: 16, bottom: 12, trailing: 16))
        }
        #endif
    }
    
    @ViewBuilder
    private var gameCenterSection: some View {
        Section {
            if gameCenterManager.isEnabled && gameCenterManager.isAuthenticated {
                authenticatedGameCenterButtons
            } else if gameCenterManager.isEnabled && !gameCenterManager.isAuthenticated {
                gameCenterWarning
            } else {
                gameCenterPromotionButton
            }
        } header: {
            if gameCenterManager.isEnabled {
                Text(L("OnlineLeaderboards", language: language))
            }
        }
    }
    
    private var authenticatedGameCenterButtons: some View {
        Group {
            leaderboardButton
            achievementsGameCenterButton
        }
    }
    
    private var leaderboardButton: some View {
        Button {
            if let leaderboardID = gameCenterManager.gameCenterLeaderboardID(.ios) {
                Logger.highscores.info("Opening Game Center leaderboard - leaderboardID: \(leaderboardID)")
                presentedLeaderboardID = leaderboardID
                showGameCenterLeaderboard = true
            }
        } label: {
            HStack {
                Image(systemName: "trophy.fill")
                    .font(.title2)
                    .foregroundStyle(.yellow)
                    .frame(width: 44)
                VStack(alignment: .leading, spacing: 4) {
                    Text(L("ViewGlobalLeaderboards", language: language))
                        .font(.headline)
                        .foregroundStyle(.primary)
                    Text(L("CompeteWithPlayers", language: language))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundStyle(.tertiary)
            }
            .padding(.vertical, 4)
        }
        .disabled(gameCenterManager.gameCenterLeaderboardID(.ios) == nil)
    }
    
    private var achievementsGameCenterButton: some View {
        Button {
            Logger.achievements.info("Opening Game Center achievements view")
            showGameCenterAchievements = true
        } label: {
            HStack {
                Image(systemName: "star.fill")
                    .font(.title2)
                    .foregroundStyle(.orange)
                    .frame(width: 44)
                VStack(alignment: .leading, spacing: 4) {
                    Text(L("ViewGameCenterAchievements", language: language))
                        .font(.headline)
                        .foregroundStyle(.primary)
                    Text(L("TrackYourProgress", language: language))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundStyle(.tertiary)
            }
            .padding(.vertical, 4)
        }
    }
    
    private var gameCenterWarning: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.title2)
                    .foregroundStyle(.orange)
                VStack(alignment: .leading, spacing: 4) {
                    Text(L("GameCenterNotConnected", language: language))
                        .font(.headline)
                    Text(L("EnableInSettings", language: language))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
        }
        .padding(.vertical, 4)
    }
    
    private var gameCenterPromotionButton: some View {
        Button {
            enableGameCenter()
        } label: {
            gameCenterPromotionContent
        }
        .buttonStyle(.plain)
        .disabled(isEnablingGameCenter)
        .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
        .listRowBackground(Color.clear)
    }
    
    private var gameCenterPromotionContent: some View {
        HStack(spacing: 12) {
            gameCenterIcon
            
            VStack(alignment: .leading, spacing: 4) {
                Text(L("JoinGlobalLeaderboards", language: language))
                    .font(.headline)
                    .foregroundStyle(.primary)
                
                Text(L("CompeteWorldwide", language: language))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
            
            gameCenterActionIndicator
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.secondarySystemBackground))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(gameCenterGradient, lineWidth: 2)
        )
    }
    
    private var gameCenterIcon: some View {
        ZStack {
            Circle()
                .fill(gameCenterGradient)
                .frame(width: 50, height: 50)
            
            Image(systemName: "globe.americas.fill")
                .font(.title3)
                .foregroundStyle(.white)
        }
    }
    
    private var gameCenterActionIndicator: some View {
        Group {
            if isEnablingGameCenter {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle())
            } else {
                Image(systemName: "arrow.right.circle.fill")
                    .font(.title2)
                    .foregroundStyle(gameCenterGradient)
            }
        }
    }
    
    private var gameCenterGradient: LinearGradient {
        LinearGradient(
            colors: [.blue, .cyan],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var achievementsButtonSection: some View {
        Section {
            Button {
                Logger.achievements.info("Opening local achievements view")
                showAchievements = true
            } label: {
                HStack {
                    Image(systemName: "trophy.fill")
                        .foregroundStyle(.yellow)
                    Text(L("Achievements", language: language))
                        .font(.headline)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundStyle(.secondary)
                }
            }
        }
    }
    
    @ViewBuilder
    private var localHighscoresSection: some View {
        Section {
            if store.entries.isEmpty {
                Text(L("NoHighscores", language: language))
                    .foregroundStyle(.secondary)
                    .italic()
            } else {
                ForEach(store.entries) { entry in
                    highscoreEntryView(entry)
                }
            }
        } header: {
            Text(L("LocalHighscores", language: language))
        }
    }
    
    private func highscoreEntryView(_ entry: HighscoreEntry) -> some View {
        VStack(spacing: 8) {
            highscoreEntryHeader(entry)
            
            if !entry.achievementIDs.isEmpty {
                achievementsForEntry(entry)
            }
        }
    }
    
    private func highscoreEntryHeader(_ entry: HighscoreEntry) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(entry.playerName)
                    .font(.headline)
                highscoreEntryMetadata(entry)
            }
            
            Spacer()
            
            Text("\(entry.score)")
                .font(.title2.bold())
                .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
        }
    }
    
    private func highscoreEntryMetadata(_ entry: HighscoreEntry) -> some View {
        HStack(spacing: 8) {
            Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                .font(.caption)
                .foregroundStyle(.secondary)
            Text("•")
                .font(.caption)
                .foregroundStyle(.secondary)
            Text("Level \(entry.maxLevel)")
                .font(.caption)
                .foregroundStyle(.tint)
            Text("•")
                .font(.caption)
                .foregroundStyle(.secondary)
            gameModeIndicator(entry)
        }
    }
    
    private func gameModeIndicator(_ entry: HighscoreEntry) -> some View {
        HStack(spacing: 2) {
            Image(systemName: gameModeIcon(for: entry.gameMode))
                .font(.caption)
            Text(L(gameModeNameKey(for: entry.gameMode), language: language))
                .font(.caption)
            if entry.isPro {
                Text("Pro")
                    .font(.caption2.bold())
                    .foregroundStyle(.orange)
                    .padding(.horizontal, 4)
                    .padding(.vertical, 1)
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(4)
            }
        }
        .foregroundStyle(.secondary)
    }
    
    private func achievementsForEntry(_ entry: HighscoreEntry) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(Achievement.all.filter { entry.achievementIDs.contains($0.id) }, id: \.id) { achievement in
                achievementBadge(achievement)
            }
        }
        .padding(.top, 4)
    }
    
    private func achievementBadge(_ achievement: Achievement) -> some View {
        HStack(spacing: 8) {
            Text(achievement.iconEmoji)
                .font(.system(size: 24))
                .frame(width: 32, alignment: .center)
            VStack(alignment: .leading, spacing: 2) {
                Text(L(achievement.nameKey, language: language))
                    .font(.caption.bold())
                Text(L(achievement.explanationKey, language: language))
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(8)
        .background(Color(.tertiarySystemBackground))
        .cornerRadius(8)
    }
    
    private var achievementsSheet: some View {
        NavigationStack {
            AchievementView_iOS(language: language, playerName: playerName, achievementStore: achievementStore)
                .navigationTitle(L("Achievements", language: language))
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button(L("Done", language: language)) {
                            showAchievements = false
                        }
                    }
                }
        }
    }
    
    private func enableGameCenter() {
        Logger.gameCenter.info("User initiated Game Center enable from highscores")
        isEnablingGameCenter = true
        gameCenterManager.enable()
        // Reset the loading state after a brief delay to allow authentication UI to appear
        Task {
            try? await Task.sleep(for: .seconds(0.5))
            isEnablingGameCenter = false
        }
    }
    
    // Helper functions for game mode display
    private func gameModeIcon(for mode: String) -> String {
        switch mode {
        case "colors": return "paintpalette.fill"
        case "numbers": return "number.square.fill"
        case "shapes": return "star.square.fill"
        case "flags": return "flag.fill"
        case "emojis": return "face.smiling.fill"
        default: return "questionmark.circle"
        }
    }
    
    private func gameModeNameKey(for mode: String) -> String {
        switch mode {
        case "colors": return "ModeColors"
        case "numbers": return "ModeNumbers"
        case "shapes": return "ModeShapes"
        case "flags": return "ModeFlags"
        case "emojis": return "ModeEmojis"
        default: return "ModeColors"
        }
    }
}

// MARK: - SwiftUI GameKit Views

/// SwiftUI wrapper for displaying Game Center leaderboards.
///
/// `GameCenterLeaderboardView` bridges UIKit's `GKGameCenterViewController` into SwiftUI,
/// allowing native Game Center leaderboard UI to be presented as a SwiftUI sheet or
/// NavigationLink destination.
///
/// ## Implementation Strategy
///
/// ### Leaderboard Overview vs Direct Access
/// This implementation uses `.leaderboards` state (overview) rather than showing a
/// specific leaderboard ID directly. This approach was chosen because:
///
/// 1. **Reliability**: Overview state is more stable across iOS versions
/// 2. **User Discovery**: Players can see all available leaderboards
/// 3. **Fallback Safety**: Never fails if a specific ID is missing
/// 4. **Apple's Recommendation**: Matches HIG guidance for Game Center
///
/// ### Why Not Direct Leaderboard Access?
/// While `GKGameCenterViewController(leaderboardID: timeScope: playerScope:)` exists,
/// it has several issues:
/// - Crashes if leaderboard ID doesn't exist or hasn't loaded yet
/// - Inconsistent behavior across iOS 14-17
/// - Poor error handling when offline
/// - Doesn't gracefully degrade
///
/// The overview approach avoids all these issues by letting Game Center handle the
/// details internally.
///
/// ## Usage
/// ```swift
/// @State private var showLeaderboard = false
///
/// Button("View Leaderboards") {
///     showLeaderboard = true
/// }
/// .sheet(isPresented: $showLeaderboard) {
///     GameCenterLeaderboardView(leaderboardID: nil)
/// }
/// ```
///
/// ## Parameters
/// - `leaderboardID`: Optional preferred leaderboard ID (currently unused but logged)
///
/// ## UIKit Integration
/// Uses `UIViewControllerRepresentable` protocol to wrap UIKit controller:
/// - **makeUIViewController**: Creates `GKGameCenterViewController` with `.leaderboards` state
/// - **updateUIViewController**: No-op (Game Center UI is self-contained)
/// - **makeCoordinator**: Creates delegate handler for dismissal
///
/// ## Dismissal Handling
/// The coordinator implements `GKGameCenterControllerDelegate` to handle when the user:
/// - Taps "Done" button
/// - Swipes to dismiss (on iOS 13+)
/// - Presses back button
///
/// The view controller dismisses itself automatically; no manual state management needed.
///
/// ## Debug Logging
/// Logs to console when:
/// - View controller is created
/// - Specific leaderboard ID is provided (for debugging)
/// - View controller is dismissed
///
/// Use these logs to verify correct initialization and dismissal flow.
///
/// - Note: Requires Game Center to be enabled and user to be authenticated. If not,
///   the view will show Game Center's built-in error state.
@available(iOS 14.0, *)
struct GameCenterLeaderboardView: UIViewControllerRepresentable {
    let leaderboardID: String?
    
    func makeUIViewController(context: Context) -> UIViewController {
        Logger.gameCenter.info("Creating GKGameCenterViewController for leaderboards")
        
        // Create the Game Center view controller with .leaderboards state
        // This shows the leaderboard overview, which works more reliably than direct leaderboard access
        let viewController = GKGameCenterViewController(state: .leaderboards)
        viewController.gameCenterDelegate = context.coordinator
        
        // If a specific leaderboard ID is provided, log it (for debugging)
        if let leaderboardID = leaderboardID {
            Logger.gameCenter.debug("Would prefer to show leaderboard: \(leaderboardID), but showing overview instead for better reliability")
        }
        
        return viewController
    }
    
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
        // No updates needed
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, GKGameCenterControllerDelegate {
        let parent: GameCenterLeaderboardView
        
        init(_ parent: GameCenterLeaderboardView) {
            self.parent = parent
        }
        
        func gameCenterViewControllerDidFinish(_ gameCenterViewController: GKGameCenterViewController) {
            Logger.gameCenter.info("Game Center view controller dismissed")
            gameCenterViewController.dismiss(animated: true)
        }
    }
}

/// SwiftUI wrapper for displaying Game Center achievements UI.
///
/// `GameCenterAchievementsView` bridges UIKit's `GKGameCenterViewController` into SwiftUI
/// specifically for the achievements screen. It presents the native Game Center interface
/// showing all achievements for the game, including:
/// - Completed achievements with unlock dates
/// - In-progress achievements with percentage completion
/// - Locked achievements with unlock requirements
/// - Achievement descriptions and point values
///
/// ## Why Use Native Game Center UI?
/// Apple's built-in achievements screen provides:
/// - **Consistent Design**: Matches system Game Center app
/// - **Automatic Updates**: Real-time sync with iCloud
/// - **Social Features**: Friend comparisons and sharing
/// - **Zero Maintenance**: No custom UI to build or update
///
/// ## Implementation
/// Uses `GKGameCenterViewController(state: .achievements)` which automatically:
/// - Loads achievement data from Game Center servers
/// - Shows loading states during fetch
/// - Handles offline scenarios gracefully
/// - Provides filtering and sorting options
/// - Includes share sheet for boasting
///
/// ## Usage
/// ```swift
/// @State private var showAchievements = false
///
/// Button("View Achievements") {
///     showAchievements = true
/// }
/// .sheet(isPresented: $showAchievements) {
///     GameCenterAchievementsView()
/// }
/// ```
///
/// ## UIKit Integration
/// - **makeUIViewController**: Creates achievement-focused Game Center view
/// - **updateUIViewController**: No-op (Game Center manages its own state)
/// - **makeCoordinator**: Handles dismissal via delegate protocol
///
/// ## Dismissal Handling
/// Automatically dismisses when user taps "Done" or swipes away. No manual
/// state management required in parent view.
///
/// ## Achievement Sync
/// This view shows achievements as reported to Game Center. To ensure local
/// achievements appear here, call `gameCenterManager.reportAchievements()` when
/// achievements are earned:
///
/// ```swift
/// let newAchievements = achievementStore.checkAndUnlockAchievements()
/// if !newAchievements.isEmpty {
///     Task {
///         await gameCenterManager.reportAchievements(newAchievements)
///     }
/// }
/// ```
///
/// - Note: Requires Game Center to be enabled and user to be authenticated. Shows
///   Game Center's error state if not signed in.
@available(iOS 14.0, *)
struct GameCenterAchievementsView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UIViewController {
        let viewController = GKGameCenterViewController(state: .achievements)
        viewController.gameCenterDelegate = context.coordinator
        return viewController
    }
    
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
        // No updates needed
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, GKGameCenterControllerDelegate {
        let parent: GameCenterAchievementsView
        
        init(_ parent: GameCenterAchievementsView) {
            self.parent = parent
        }
        
        func gameCenterViewControllerDidFinish(_ gameCenterViewController: GKGameCenterViewController) {
            gameCenterViewController.dismiss(animated: true)
        }
    }
}


