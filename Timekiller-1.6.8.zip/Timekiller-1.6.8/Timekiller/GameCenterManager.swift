//
//  GameCenterManager.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 29.12.25.
//

import Foundation
import GameKit
import SwiftUI
import Observation
import OSLog

#if os(iOS)
import UIKit
#endif

/// Manages Game Center integration including authentication, leaderboards, and achievements.
///
/// `GameCenterManager` is a singleton service that handles all interactions with Apple's Game Center
/// framework. It provides functionality for:
///
/// - **Authentication**: Authenticating users with their Game Center account
/// - **Leaderboards**: Submitting high scores to mode-specific and global leaderboards
/// - **Achievements**: Tracking and reporting achievement progress
/// - **UI Presentation**: Showing Game Center dashboard, leaderboards, and achievement views
///
/// The manager respects user preferences, allowing them to enable/disable Game Center integration
/// independently of whether they're authenticated. This provides a "local-only" mode for users
/// who prefer to play without online features.
///
/// ## Usage Example
/// ```swift
/// // Authenticate with Game Center
/// GameCenterManager.shared.authenticate()
///
/// // Submit a high score
/// GameCenterManager.shared.submitScore(1500, mode: .colors, isPro: false)
///
/// // Report an achievement
/// GameCenterManager.shared.reportAchievement("color_cadet", percentComplete: 100.0)
/// ```
///
/// - Note: The manager is marked with `@Observable` for SwiftUI integration, allowing views
///   to reactively update when authentication status or other properties change.
@Observable
final class GameCenterManager {
    
    // MARK: - Singleton
    
    /// Shared singleton instance of the Game Center manager.
    static let shared = GameCenterManager()
    
    // MARK: - State Properties
    
    /// Indicates whether the user is authenticated with Game Center.
    /// `true` if the user is signed in to Game Center on this device.
    var isAuthenticated = false
    
    /// User preference controlling whether Game Center features are enabled.
    /// Even if authenticated, the user can choose to disable online features.
    var isEnabled = false
    
    /// The authenticated Game Center local player, if available.
    /// Contains player information like display name, player ID, etc.
    var localPlayer: GKLocalPlayer?
    
    /// Error message if authentication fails, otherwise `nil`.
    /// Used to display error messages to the user.
    var authenticationError: String?
    
    /// Display name of the authenticated Game Center player.
    /// Loaded asynchronously after authentication completes.
    var gameCenterPlayerName: String?
    
    // MARK: - Leaderboard Identifiers
    
    /// Identifiers for all Game Center leaderboards used in the app.
    ///
    /// Each game mode has separate leaderboards for normal and pro difficulty.
    /// The `ios` leaderboard is a legacy global leaderboard that combines all modes.
    ///
    /// - Note: These identifiers must match the leaderboards configured in App Store Connect.
    enum LeaderboardID: String {
        /// Legacy global leaderboard combining scores from all modes
        case ios = "wulf.ai.timekiller.highscores.ios"
        
        // Mode-specific leaderboards for Colors mode
        /// Leaderboard for Colors mode in normal difficulty
        case colorsNormal = "wulf.ai.timekiller.highscores.colors"
        /// Leaderboard for Colors mode in pro difficulty
        case colorsPro = "wulf.ai.timekiller.highscores.colors.pro"
        
        // Mode-specific leaderboards for Numbers mode
        /// Leaderboard for Numbers mode in normal difficulty
        case numbersNormal = "wulf.ai.timekiller.highscores.numbers"
        /// Leaderboard for Numbers mode in pro difficulty
        case numbersPro = "wulf.ai.timekiller.highscores.numbers.pro"
        
        // Mode-specific leaderboards for Shapes mode
        /// Leaderboard for Shapes mode in normal difficulty
        case shapesNormal = "wulf.ai.timekiller.highscores.shapes"
        /// Leaderboard for Shapes mode in pro difficulty
        case shapesPro = "wulf.ai.timekiller.highscores.shapes.pro"
        
        // Mode-specific leaderboards for Flags mode
        /// Leaderboard for Flags mode in normal difficulty
        case flagsNormal = "wulf.ai.timekiller.highscores.flags"
        /// Leaderboard for Flags mode in pro difficulty
        case flagsPro = "wulf.ai.timekiller.highscores.flags.pro"
        
        // Mode-specific leaderboards for Emojis mode
        /// Leaderboard for Emojis mode in normal difficulty
        case emojisNormal = "wulf.ai.timekiller.highscores.emojis"
        /// Leaderboard for Emojis mode in pro difficulty
        case emojisPro = "wulf.ai.timekiller.highscores.emojis.pro"
    }
    
    // MARK: - Achievement Identifiers
    
    /// Identifiers for all Game Center achievements available in the app.
    ///
    /// Achievements are organized into categories based on difficulty and progression:
    /// - Early achievements for reaching level 5
    /// - Unlocking achievements that grant access to new game modes
    /// - Intermediate achievements for reaching level 15
    /// - Advanced achievements for reaching level 25
    /// - Mastery achievements for reaching level 30 in standard modes
    /// - Pro mastery achievements for reaching level 30 in pro modes
    /// - Ultimate achievement for completing everything
    ///
    /// - Note: These identifiers must match the achievements configured in App Store Connect.
    enum AchievementID: String {
        // Early Achievements (Level 5)
        /// Color Cadet - Reach level 5 in Colors Standard mode
        case colorCadet = "wulf.ai.timekiller.AchievementColorCadet"
        /// Shape Novice - Reach level 5 in Shapes Standard mode
        case shapeNovice = "wulf.ai.timekiller.AchievementShapeNovice"
        /// Emoji Apprentice - Reach level 5 in Emojis Standard mode
        case emojiApprentice = "wulf.ai.timekiller.AchievementEmojiApprentice"
        
        // Unlocking Achievements (Unlock new game modes)
        /// Polygon Prodigy - Reach level 10 in Colors Standard, unlocks Shapes mode
        case polygonProdigy = "wulf.ai.timekiller.AchievementPolygonProdigy"
        /// Smiley Summoner - Reach level 20 in Colors Standard, unlocks Emojis mode
        case smileySummoner = "wulf.ai.timekiller.AchievementSmileySummoner"
        /// Ultra Instinct - Reach level 30 in any Standard mode, unlocks Pro mode
        case ultraInstinct = "wulf.ai.timekiller.AchievementUltraInstinct"
        
        // Intermediate Achievements (Level 15)
        /// Rainbow Wrangler - Reach level 15 in Colors Standard mode
        case rainbowWrangler = "wulf.ai.timekiller.AchievementRainbowWrangler"
        /// Triangle Tamer - Reach level 15 in Shapes Standard mode
        case triangleTamer = "wulf.ai.timekiller.AchievementTriangleTamer"
        /// Emoji Enthusiast - Reach level 15 in Emojis Standard mode
        case emojiEnthusiast = "wulf.ai.timekiller.AchievementEmojiEnthusiast"
        
        // Advanced Achievements (Level 25)
        /// Color Virtuoso - Reach level 25 in Colors Standard mode
        case colorVirtuoso = "wulf.ai.timekiller.AchievementColorVirtuoso"
        /// Shape Master - Reach level 25 in Shapes Standard mode
        case shapeMaster = "wulf.ai.timekiller.AchievementShapeMaster"
        /// Emoji Expert - Reach level 25 in Emojis Standard mode
        case emojiExpert = "wulf.ai.timekiller.AchievementEmojiExpert"
        
        // Mastery Achievements (Level 30 Standard)
        /// Chromatic Champion - Reach level 30 in Colors Standard mode
        case chromaticChampion = "wulf.ai.timekiller.AchievementChromaticChampion"
        /// Geometry Genius - Reach level 30 in Shapes Standard mode
        case geometryGenius = "wulf.ai.timekiller.AchievementGeometryGenius"
        /// Emoji Overlord - Reach level 30 in Emojis Standard mode
        case emojiOverlord = "wulf.ai.timekiller.AchievementEmojiOverlord"
        
        // Pro Mastery Achievements (Level 30 Pro)
        /// Rainbow Annihilator - Reach level 30 in Colors Pro mode
        case rainbowAnnihilator = "wulf.ai.timekiller.AchievementRainbowAnnihilator"
        /// Shape Sorcerer Supreme - Reach level 30 in Shapes Pro mode
        case shapeSorcerer = "wulf.ai.timekiller.AchievementShapeSorcerer"
        /// Emoji Apocalypse - Reach level 30 in Emojis Pro mode
        case emojiApocalypse = "wulf.ai.timekiller.AchievementEmojiApocalypse"
        
        // Ultimate Achievement
        /// The Unkillable - Reach level 30 in all 10 game modes
        case theUnkillable = "wulf.ai.timekiller.AchievementTheUnkillable"
        
        /// Converts a local achievement identifier to its Game Center achievement ID.
        ///
        /// The app uses simplified local IDs (e.g., "color_cadet") internally for achievement
        /// tracking. This method maps those local IDs to the full Game Center achievement
        /// identifiers required by the Game Center API.
        ///
        /// - Parameter localID: The local achievement identifier (snake_case format)
        /// - Returns: The Game Center achievement ID string if mapping exists, otherwise `nil`
        ///
        /// ## Example
        /// ```swift
        /// let gcID = AchievementID.fromLocalID("color_cadet")
        /// // Returns "wulf.ai.timekiller.AchievementColorCadet"
        /// ```
        static func fromLocalID(_ localID: String) -> String? {
            switch localID {
            case "color_cadet": return AchievementID.colorCadet.rawValue
            case "shape_novice": return AchievementID.shapeNovice.rawValue
            case "emoji_apprentice": return AchievementID.emojiApprentice.rawValue
            case "polygon_prodigy": return AchievementID.polygonProdigy.rawValue
            case "smiley_summoner": return AchievementID.smileySummoner.rawValue
            case "ultra_instinct": return AchievementID.ultraInstinct.rawValue
            case "rainbow_wrangler": return AchievementID.rainbowWrangler.rawValue
            case "triangle_tamer": return AchievementID.triangleTamer.rawValue
            case "emoji_enthusiast": return AchievementID.emojiEnthusiast.rawValue
            case "color_virtuoso": return AchievementID.colorVirtuoso.rawValue
            case "shape_master": return AchievementID.shapeMaster.rawValue
            case "emoji_expert": return AchievementID.emojiExpert.rawValue
            case "chromatic_champion": return AchievementID.chromaticChampion.rawValue
            case "geometry_genius": return AchievementID.geometryGenius.rawValue
            case "emoji_overlord": return AchievementID.emojiOverlord.rawValue
            case "rainbow_annihilator": return AchievementID.rainbowAnnihilator.rawValue
            case "shape_sorcerer": return AchievementID.shapeSorcerer.rawValue
            case "emoji_apocalypse": return AchievementID.emojiApocalypse.rawValue
            case "the_unkillable": return AchievementID.theUnkillable.rawValue
            default: return nil
            }
        }
    }
    
    /// Private initializer to enforce singleton pattern.
    ///
    /// Loads the user's Game Center preference from UserDefaults on supported platforms.
    /// On watchOS, Game Center is explicitly disabled as it's not supported for online features.
    private init() {
        // Load user preference for Game Center
        #if os(watchOS)
        // Disable Game Center on watchOS — local highscores only
        isEnabled = false
        #else
        isEnabled = UserDefaults.standard.bool(forKey: "tk_gamecenter_enabled")
        #endif
    }
    
    // MARK: - Authentication
    
    /// Authenticates the local player with Game Center.
    ///
    /// This method initiates the Game Center authentication flow for the current device user.
    /// The authentication process varies by platform:
    ///
    /// - **iOS**: May present a view controller for sign-in if needed
    /// - **macOS/tvOS**: Handles authentication silently if already signed in
    /// - **watchOS**: Disabled entirely (returns immediately)
    ///
    /// After successful authentication, this method:
    /// - Updates `isAuthenticated` to `true`
    /// - Stores the `localPlayer` reference
    /// - Loads the player's display name into `gameCenterPlayerName`
    /// - Automatically triggers data sync from Game Center via `syncFromGameCenter()`
    ///
    /// If authentication fails, the error is stored in `authenticationError` and logged to console.
    ///
    /// - Note: This method respects the `isEnabled` preference. If Game Center is disabled,
    ///   authentication is skipped.
    /// - Important: On iOS, this may present UI modally. Ensure your view hierarchy is ready.
    ///
    /// ## Example
    /// ```swift
    /// // Authenticate when app launches
    /// GameCenterManager.shared.authenticate()
    /// ```
    func authenticate() {
        #if os(watchOS)
        // Disable Game Center on watchOS
        return
        #endif
        guard isEnabled else { return }
        
        localPlayer = GKLocalPlayer.local
        
        // Check if player is already authenticated
        if localPlayer?.isAuthenticated == true {
            isAuthenticated = true
            authenticationError = nil
            gameCenterPlayerName = localPlayer?.displayName ?? localPlayer?.alias ?? "Player"
            // Sync data from Game Center when authenticated
            Task {
                await syncFromGameCenter()
            }
            return
        }
        
        #if os(iOS)
              localPlayer?.authenticateHandler = { [weak self] (viewController: UIViewController?, error: Error?) in
                  guard let self = self else { return }
                  
                  if let error = error {
                      DispatchQueue.main.async {
                          self.isAuthenticated = false
                          self.authenticationError = error.localizedDescription
                      }
                      Logger.gameCenter.error("Authentication failed: \(error.localizedDescription, privacy: .public)")
                      return
                  }
                  
                  if let viewController = viewController {
                      // Need to present view controller
                      DispatchQueue.main.async {
                          if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                             let rootViewController = windowScene.windows.first?.rootViewController {
                              rootViewController.present(viewController, animated: true)
                          }
                      }
                  } else {
                      // No view controller and no error means authentication is done
                      DispatchQueue.main.async {
                          self.isAuthenticated = self.localPlayer?.isAuthenticated ?? false
                          self.authenticationError = nil
                          self.gameCenterPlayerName = self.localPlayer?.displayName ?? self.localPlayer?.alias ?? "Player"
                          // Sync data from Game Center after authentication
                          Task {
                              await self.syncFromGameCenter()
                          }
                      }
                  }
              }
        #else
              localPlayer?.authenticateHandler = { [weak self] (_, error) in
                  guard let self = self else { return }
                  
                  if let error = error {
                      DispatchQueue.main.async {
                          self.isAuthenticated = false
                          self.authenticationError = error.localizedDescription
                      }
                      Logger.gameCenter.error("Authentication failed: \(error.localizedDescription, privacy: .public)")
                      return
                  }
                  
                  // No UI to present on this platform; just update state
                  DispatchQueue.main.async {
                      self.isAuthenticated = self.localPlayer?.isAuthenticated ?? false
                      self.authenticationError = nil
                      self.gameCenterPlayerName = self.localPlayer?.displayName ?? self.localPlayer?.alias ?? "Player"
                      // Sync data from Game Center after authentication
                      Task {
                          await self.syncFromGameCenter()
                      }
                  }
              }
        #endif
    }
    
    /// Enables Game Center integration and initiates authentication.
    ///
    /// This method:
    /// 1. Sets `isEnabled` to `true` and persists the preference
    /// 2. Calls `authenticate()` to begin the sign-in flow
    ///
    /// Use this when the user opts in to Game Center features from your app's settings.
    ///
    /// - Note: On watchOS, this method explicitly disables Game Center and saves that preference,
    ///   as online features are not supported on that platform.
    ///
    /// ## Example
    /// ```swift
    /// // User toggles Game Center on in settings
    /// if gameCenterEnabled {
    ///     GameCenterManager.shared.enable()
    /// }
    /// ```
    func enable() {
        #if os(watchOS)
        // Game Center is disabled on watchOS — force local highscores only
        isEnabled = false
        UserDefaults.standard.set(false, forKey: "tk_gamecenter_enabled")
        return
        #endif
        isEnabled = true
        UserDefaults.standard.set(true, forKey: "tk_gamecenter_enabled")
        authenticate()
    }
    
    /// Disables Game Center integration.
    ///
    /// This method:
    /// 1. Sets `isEnabled` to `false` and persists the preference
    /// 2. Sets `isAuthenticated` to `false` (local state only, doesn't sign out)
    /// 3. Clears the cached `gameCenterPlayerName`
    ///
    /// After calling this, all Game Center operations (score submission, achievement reporting,
    /// leaderboard loading) will be skipped. The app returns to local-only mode.
    ///
    /// - Note: This does **not** sign the user out of Game Center system-wide. It only disables
    ///   Game Center integration within this app.
    ///
    /// ## Example
    /// ```swift
    /// // User disables Game Center in settings
    /// if !gameCenterEnabled {
    ///     GameCenterManager.shared.disable()
    /// }
    /// ```
    func disable() {
        isEnabled = false
        UserDefaults.standard.set(false, forKey: "tk_gamecenter_enabled")
        isAuthenticated = false
        gameCenterPlayerName = nil
    }
    
    // MARK: - Leaderboards
    
    /// Submits a score to the appropriate Game Center leaderboard(s).
    ///
    /// This method automatically determines which leaderboards to submit to based on the game
    /// mode and difficulty:
    /// - Mode-specific leaderboard (e.g., Colors Normal, Shapes Pro)
    /// - Legacy global iOS leaderboard (for backwards compatibility)
    ///
    /// The method encodes game mode and pro status into the leaderboard entry's context field
    /// for later retrieval and filtering.
    ///
    /// - Parameters:
    ///   - score: The score to submit (higher is better)
    ///   - gameMode: The game mode identifier (e.g., "colors", "numbers", "shapes", "flags", "emojis")
    ///   - isPro: Whether this score is from Pro difficulty (`true`) or Normal (`false`)
    ///   - platform: The platform identifier for leaderboard selection (defaults to `.currentPlatform`)
    ///
    /// - Note: This is an async operation. Errors are logged to console but do not throw.
    /// - Important: Requires `isEnabled` and `isAuthenticated` to be `true`, otherwise returns early.
    /// - Warning: On watchOS, this method returns immediately without submitting (online features disabled).
    ///
    /// ## Context Encoding
    /// The context value encodes metadata about the score:
    /// - Game mode: 0 (colors), 1 (numbers), 2 (shapes), 3 (flags), 4 (emojis)
    /// - Pro flag: +1000 if Pro mode, +0 if Normal
    /// - Example: Colors Pro = 0 + 1000 = 1000, Shapes Normal = 2 + 0 = 2
    ///
    /// ## Example
    /// ```swift
    /// // Submit a score of 2500 for Colors Pro mode
    /// await GameCenterManager.shared.submitScore(2500, gameMode: "colors", isPro: true)
    /// ```
    func submitScore(_ score: Int, gameMode: String = "colors", isPro: Bool = false, platform: Platform = .currentPlatform) async {
        #if os(watchOS)
        // Online highscores disabled on watchOS
        return
        #endif
        guard isEnabled && isAuthenticated else { 
            Logger.gameCenter.warning("Cannot submit score - enabled: \(self.isEnabled), authenticated: \(self.isAuthenticated)")
            return 
        }
        
        // Determine which leaderboards to submit to
        var leaderboardIDs: [String] = []
        
        // Add legacy global leaderboard (for backwards compatibility)
        switch platform {
        case .ios, .currentPlatform:
            #if os(iOS)
            leaderboardIDs.append(LeaderboardID.ios.rawValue)
            #endif
        }
        
        // Add mode-specific leaderboard
        let modeSpecificLeaderboard: LeaderboardID?
        switch (gameMode, isPro) {
        case ("colors", false):
            modeSpecificLeaderboard = .colorsNormal
        case ("colors", true):
            modeSpecificLeaderboard = .colorsPro
        case ("numbers", false):
            modeSpecificLeaderboard = .numbersNormal
        case ("numbers", true):
            modeSpecificLeaderboard = .numbersPro
        case ("shapes", false):
            modeSpecificLeaderboard = .shapesNormal
        case ("shapes", true):
            modeSpecificLeaderboard = .shapesPro
        case ("flags", false):
            modeSpecificLeaderboard = .flagsNormal
        case ("flags", true):
            modeSpecificLeaderboard = .flagsPro
        case ("emojis", false):
            modeSpecificLeaderboard = .emojisNormal
        case ("emojis", true):
            modeSpecificLeaderboard = .emojisPro
        default:
            modeSpecificLeaderboard = nil
        }
        
        if let modeLeaderboard = modeSpecificLeaderboard {
            leaderboardIDs.append(modeLeaderboard.rawValue)
        }
        
        guard !leaderboardIDs.isEmpty else {
            Logger.gameCenter.warning("No leaderboards found for mode: \(gameMode), pro: \(isPro)")
            return
        }
        
        Logger.gameCenter.info("Submitting score \(score) to \(leaderboardIDs.count) leaderboards")
        
        // Create context value from gameMode and isPro
        // We encode the game mode and pro status into the context field
        // Context format: [gameMode enum value (0-4)] + [isPro flag (0 or 1000)]
        let gameModeValue: Int
        switch gameMode {
        case "colors": gameModeValue = 0
        case "numbers": gameModeValue = 1
        case "shapes": gameModeValue = 2
        case "flags": gameModeValue = 3
        case "emojis": gameModeValue = 4
        default: gameModeValue = 0
        }
        
        let context = gameModeValue + (isPro ? 1000 : 0)
        
        GKLeaderboard.submitScore(score, context: context, player: GKLocalPlayer.local, leaderboardIDs: leaderboardIDs) { error in
            if let error = error {
                Logger.gameCenter.error("Failed to submit score: \(error.localizedDescription, privacy: .public)")
            } else {
                Logger.gameCenter.notice("Score submitted successfully: \(score) to \(leaderboardIDs.count) leaderboards (mode: \(gameMode), pro: \(isPro))")
            }
        }
    }
    
    /// Loads entries from a specific Game Center leaderboard.
    ///
    /// This method fetches leaderboard entries based on the specified parameters, including
    /// both the local player's entry and a range of global entries.
    ///
    /// - Parameters:
    ///   - leaderboardID: The leaderboard to load (use `LeaderboardID` enum values)
    ///   - playerScope: Whether to load global or friends-only scores (default: `.global`)
    ///   - timeScope: Time period to load scores from (default: `.allTime`)
    ///   - range: Which ranks to fetch (default: top 25, i.e., ranks 1-25)
    ///
    /// - Returns: An array of `GKLeaderboard.Entry` objects containing score data and player info.
    ///   The first entry (if present) is the local player's entry, followed by global entries.
    ///   Returns an empty array if loading fails or if Game Center is disabled/unauthenticated.
    ///
    /// - Note: This is an async operation that uses continuations to bridge GameKit's callback API.
    /// - Important: Requires `isEnabled` and `isAuthenticated` to be `true`.
    /// - Warning: On watchOS, this method returns an empty array immediately.
    ///
    /// ## Example
    /// ```swift
    /// // Load top 10 scores for Colors Normal mode
    /// let entries = await GameCenterManager.shared.loadLeaderboard(
    ///     leaderboardID: .colorsNormal,
    ///     range: NSRange(location: 1, length: 10)
    /// )
    ///
    /// for entry in entries {
    ///     print("\(entry.player.displayName): \(entry.score)")
    /// }
    /// ```
    func loadLeaderboard(leaderboardID: LeaderboardID, playerScope: GKLeaderboard.PlayerScope = .global, timeScope: GKLeaderboard.TimeScope = .allTime, range: NSRange = NSRange(location: 1, length: 25)) async -> [GKLeaderboard.Entry] {
        #if os(watchOS)
        // Online highscores disabled on watchOS
        return []
        #endif
        guard isEnabled && isAuthenticated else {
            Logger.gameCenter.warning("Cannot load leaderboard - enabled: \(self.isEnabled), authenticated: \(self.isAuthenticated)")
            return []
        }
        
        Logger.gameCenter.info("Loading leaderboard: \(leaderboardID.rawValue)")
        
        return await withCheckedContinuation { continuation in
            GKLeaderboard.loadLeaderboards(IDs: [leaderboardID.rawValue]) { leaderboards, error in
                guard let leaderboard = leaderboards?.first, error == nil else {
                    if let error = error {
                        Logger.gameCenter.error("Failed to load leaderboard: \(error.localizedDescription, privacy: .public)")
                    } else {
                        Logger.gameCenter.error("No leaderboard found for ID: \(leaderboardID.rawValue)")
                    }
                    continuation.resume(returning: [])
                    return
                }
                
                Logger.gameCenter.debug("Leaderboard loaded, fetching entries...")
                
                leaderboard.loadEntries(for: playerScope, timeScope: timeScope, range: range) { local, entries, totalPlayerCount, error in
                    if let error = error {
                        Logger.gameCenter.error("Failed to load leaderboard entries: \(error.localizedDescription, privacy: .public)")
                        continuation.resume(returning: [])
                        return
                    }
                    
                    Logger.gameCenter.debug("Leaderboard data loaded - totalPlayers: \(totalPlayerCount), localScore: \(local?.score ?? -1), localRank: \(local?.rank ?? -1), entriesCount: \(entries?.count ?? 0)")
                    
                    var result: [GKLeaderboard.Entry] = []
                    if let localEntry = local {
                        result.append(localEntry)
                    }
                    if let entries = entries {
                        result.append(contentsOf: entries)
                    }
                    
                    Logger.gameCenter.debug("Returning \(result.count) total entries")
                    continuation.resume(returning: result)
                }
            }
        }
    }
    
    /// Returns the Game Center leaderboard ID string for use with SwiftUI's `.gameCenter()` modifier.
    ///
    /// This method checks authentication status and returns the leaderboard ID if the user
    /// is enabled and authenticated. Use this with SwiftUI's native Game Center presentation.
    ///
    /// - Parameter leaderboardID: The leaderboard identifier to display
    /// - Returns: The leaderboard ID string if available, otherwise `nil` if not authenticated
    ///
    /// ## Example
    /// ```swift
    /// struct LeaderboardView: View {
    ///     @State private var showLeaderboard = false
    ///
    ///     var body: some View {
    ///         Button("Show Leaderboard") {
    ///             showLeaderboard = true
    ///         }
    ///         .gameCenter(
    ///             isPresented: $showLeaderboard,
    ///             leaderboardID: GameCenterManager.shared.gameCenterLeaderboardID(.colorsNormal)
    ///         )
    ///     }
    /// }
    /// ```
    @MainActor
    func gameCenterLeaderboardID(_ leaderboardID: LeaderboardID) -> String? {
        guard isEnabled && isAuthenticated else { return nil }
        return leaderboardID.rawValue
    }
    
    // MARK: - Achievements
    
    /// Reports a single achievement's progress to Game Center.
    ///
    /// This method maps a local achievement identifier (snake_case format like `"color_cadet"`)
    /// to its corresponding Game Center achievement ID and reports it with the specified completion
    /// percentage.
    ///
    /// - Parameters:
    ///   - localID: The local achievement identifier (e.g., `"color_cadet"`, `"ultra_instinct"`)
    ///   - percentComplete: The completion percentage (0.0 to 100.0). Defaults to 100.0 for fully unlocked.
    ///
    /// - Note: If `percentComplete` is 100.0, Game Center will show a completion banner to the user.
    /// - Important: Requires `isEnabled` and `isAuthenticated` to be `true`.
    /// - Warning: On watchOS, this method returns immediately without reporting.
    ///
    /// ## Example
    /// ```swift
    /// // Report a fully unlocked achievement
    /// await GameCenterManager.shared.reportAchievement("color_cadet", percentComplete: 100.0)
    ///
    /// // Report partial progress
    /// await GameCenterManager.shared.reportAchievement("chromatic_champion", percentComplete: 50.0)
    /// ```
    func reportAchievement(localID: String, percentComplete: Double = 100.0) async {
        #if os(watchOS)
        // Achievements reporting to Game Center disabled on watchOS
        return
        #endif
        guard isEnabled && isAuthenticated else { return }
        guard let gameCenterID = AchievementID.fromLocalID(localID) else {
            Logger.gameCenter.warning("No Game Center mapping for achievement: \(localID)")
            return
        }
        
        let achievement = GKAchievement(identifier: gameCenterID)
        achievement.percentComplete = percentComplete
        achievement.showsCompletionBanner = true
        
        GKAchievement.report([achievement]) { error in
            if let error = error {
                Logger.gameCenter.error("Failed to report achievement: \(error.localizedDescription, privacy: .public)")
            } else {
                Logger.gameCenter.notice("Achievement reported: \(gameCenterID), progress: \(percentComplete)%")
            }
        }
    }
    
    /// Reports multiple achievements to Game Center in a single batch.
    ///
    /// This is more efficient than calling `reportAchievement(_:percentComplete:)` multiple times,
    /// as it submits all achievements in one API call.
    ///
    /// All achievements are reported with 100% completion and will show completion banners.
    ///
    /// - Parameter localIDs: An array of local achievement identifiers (e.g., `["color_cadet", "shape_novice"]`)
    ///
    /// - Note: Invalid achievement IDs are silently filtered out.
    /// - Important: Requires `isEnabled` and `isAuthenticated` to be `true`.
    /// - Warning: On watchOS, this method returns immediately without reporting.
    ///
    /// ## Example
    /// ```swift
    /// // Report multiple achievements earned during gameplay
    /// await GameCenterManager.shared.reportAchievements([
    ///     "color_cadet",
    ///     "polygon_prodigy",
    ///     "ultra_instinct"
    /// ])
    /// ```
    func reportAchievements(_ localIDs: [String]) async {
        #if os(watchOS)
        // Achievements reporting disabled on watchOS
        return
        #endif
        guard isEnabled && isAuthenticated else { return }
        
        let achievements = localIDs.compactMap { localID -> GKAchievement? in
            guard let gameCenterID = AchievementID.fromLocalID(localID) else { return nil }
            let achievement = GKAchievement(identifier: gameCenterID)
            achievement.percentComplete = 100.0
            achievement.showsCompletionBanner = true
            return achievement
        }
        
        guard !achievements.isEmpty else { return }
        
        GKAchievement.report(achievements) { error in
            if let error = error {
                Logger.gameCenter.error("Failed to report achievements: \(error.localizedDescription, privacy: .public)")
            } else {
                Logger.gameCenter.notice("Reported \(achievements.count) achievements to Game Center")
            }
        }
    }
    
    /// Loads all earned achievements from Game Center for the authenticated player.
    ///
    /// This method fetches all achievement progress data from Game Center, including both
    /// completed and partially completed achievements.
    ///
    /// - Returns: An array of `GKAchievement` objects representing the player's achievement
    ///   progress. Returns an empty array if loading fails or if Game Center is disabled/unauthenticated.
    ///
    /// - Note: This is useful for syncing achievement data or displaying progress in a custom UI.
    /// - Important: Requires `isEnabled` and `isAuthenticated` to be `true`.
    /// - Warning: On watchOS, this method returns an empty array immediately.
    ///
    /// ## Example
    /// ```swift
    /// let achievements = await GameCenterManager.shared.loadAchievements()
    ///
    /// for achievement in achievements where achievement.isCompleted {
    ///     print("Completed: \(achievement.identifier)")
    /// }
    /// ```
    func loadAchievements() async -> [GKAchievement] {
        #if os(watchOS)
        // Achievements loading from Game Center disabled on watchOS
        return []
        #endif
        guard isEnabled && isAuthenticated else { return [] }
        
        return await withCheckedContinuation { continuation in
            GKAchievement.loadAchievements { achievements, error in
                if let error = error {
                    Logger.gameCenter.error("Failed to load achievements: \(error.localizedDescription, privacy: .public)")
                    continuation.resume(returning: [])
                } else {
                    Logger.gameCenter.debug("Loaded \(achievements?.count ?? 0) achievements from Game Center")
                    continuation.resume(returning: achievements ?? [])
                }
            }
        }
    }
    
    /// Indicates whether Game Center UI can be presented to the user.
    ///
    /// This property returns `true` only when both conditions are met:
    /// - Game Center is enabled (`isEnabled == true`)
    /// - User is authenticated (`isAuthenticated == true`)
    ///
    /// Use this to conditionally show/hide Game Center UI elements like leaderboard and
    /// achievement buttons.
    ///
    /// ## Example
    /// ```swift
    /// if GameCenterManager.shared.canPresentGameCenterUI {
    ///     Button("Show Leaderboards") {
    ///         showLeaderboard = true
    ///     }
    /// }
    /// ```
    var canPresentGameCenterUI: Bool {
        isEnabled && isAuthenticated
    }
    
    // MARK: - Helper Types
    
    /// Platform identifier for leaderboard selection.
    ///
    /// Used by `submitScore(_:gameMode:isPro:platform:)` to determine which platform-specific
    /// leaderboards to submit to.
    enum Platform {
        /// iOS-specific leaderboard (legacy global leaderboard)
        case ios
        /// Current platform (automatically determined by compiler)
        case currentPlatform
    }
    
    // MARK: - Syncing
    
    /// Performs bidirectional sync between local data and Game Center.
    ///
    /// This comprehensive sync operation handles:
    /// 1. **First-time migration**: If this is the player's first Game Center connection and they
    ///    have local data, that data is migrated to their Game Center profile
    /// 2. **Cloud to local sync**: Downloads achievements and scores from Game Center
    /// 3. **Local to cloud sync**: Uploads any local achievements and scores not yet in Game Center
    ///
    /// This method should be called after successful authentication to ensure data consistency
    /// across devices and to restore progress when signing in on a new device.
    ///
    /// - Parameters:
    ///   - achievementStore: The local achievement store to sync with
    ///   - highscoreStore: The local highscore store to sync with
    ///   - previousLocalPlayer: Optional name of the local player before switching to Game Center.
    ///     If provided and this is a first-time connection, their data will be migrated to the
    ///     Game Center profile.
    ///
    /// - Note: This method switches the current player context to the Game Center player.
    /// - Important: Requires `isEnabled` and `isAuthenticated` to be `true`.
    /// - Warning: On watchOS, this method returns immediately without syncing.
    ///
    /// ## Migration Behavior
    /// When a user enables Game Center for the first time:
    /// - If they have local data under a different player name, that data is copied to their
    ///   Game Center profile
    /// - All local achievements are uploaded to Game Center
    /// - The local high score is submitted to Game Center leaderboards
    /// - Level progression is preserved
    ///
    /// ## Example
    /// ```swift
    /// // Sync after authentication
    /// await GameCenterManager.shared.syncFromGameCenter(
    ///     achievementStore: achievementStore,
    ///     highscoreStore: highscoreStore,
    ///     previousLocalPlayer: "Local Player"
    /// )
    /// ```
    func syncFromGameCenter(achievementStore: AchievementStore, highscoreStore: HighscoreStore, previousLocalPlayer: String? = nil) async {
        #if os(watchOS)
        return
        #endif
        guard isEnabled && isAuthenticated else { return }
        guard let playerName = gameCenterPlayerName else { return }
        
        Logger.gameCenter.info("Starting Game Center sync for player: \(playerName)")
        
        // Check if this is a first-time connection (Game Center player doesn't exist yet)
        let isFirstTimeConnection = !achievementStore.playerExists(name: playerName)
        
        // Create player profile if it doesn't exist
        if !achievementStore.playerExists(name: playerName) {
            achievementStore.createPlayer(name: playerName)
            Logger.gameCenter.info("Created new Game Center player profile")
        }
        
        // If first-time connection and we have a previous local player, migrate their data
        if isFirstTimeConnection, let localPlayer = previousLocalPlayer, localPlayer != playerName {
            Logger.gameCenter.info("First-time Game Center connection - migrating local player data from \(localPlayer) to \(playerName)")
            await migrateLocalPlayerToGameCenter(
                from: localPlayer,
                to: playerName,
                achievementStore: achievementStore,
                highscoreStore: highscoreStore
            )
        }
        
        // Switch to Game Center player
        achievementStore.currentPlayerName = playerName
        
        // Sync achievements from Game Center to local (merge any cloud achievements)
        await syncAchievementsFromGameCenter(achievementStore: achievementStore)
        
        // Sync scores from Game Center to local (take the best score)
        await syncScoresFromGameCenter(highscoreStore: highscoreStore, playerName: playerName)
        
        // Sync any local data back to Game Center (in case user played offline)
        await syncLocalToGameCenter(achievementStore: achievementStore, highscoreStore: highscoreStore, playerName: playerName)
        
        Logger.gameCenter.notice("Game Center sync complete for player: \(playerName)")
    }
    
    /// Migrates a local player's data to their Game Center profile on first connection.
    ///
    /// This private method handles the one-time migration of local achievements, level progress,
    /// and high scores when a user enables Game Center for the first time. It ensures that players
    /// don't lose their progress when transitioning from local-only play to Game Center integration.
    ///
    /// The migration process:
    /// 1. Reads all achievements and progress from the local player's profile
    /// 2. Copies that data to the Game Center player's profile
    /// 3. Uploads achievements to Game Center cloud
    /// 4. Submits the high score to Game Center leaderboards
    /// 5. Preserves level completion progress for mode unlocks
    ///
    /// - Parameters:
    ///   - localPlayer: The name of the local player whose data should be migrated
    ///   - gameCenterPlayer: The Game Center player name (destination for migration)
    ///   - achievementStore: The achievement store to read from and write to
    ///   - highscoreStore: The highscore store to read from and write to
    ///
    /// - Note: This method temporarily switches player contexts during migration and restores
    ///   the original context afterward.
    private func migrateLocalPlayerToGameCenter(
        from localPlayer: String,
        to gameCenterPlayer: String,
        achievementStore: AchievementStore,
        highscoreStore: HighscoreStore
    ) async {
        Logger.gameCenter.info("Migrating data from \(localPlayer) to \(gameCenterPlayer)")
        
        // Temporarily switch to local player to read their data
        let originalPlayer = achievementStore.currentPlayerName
        achievementStore.currentPlayerName = localPlayer
        
        // Copy local player's achievements to Game Center player
        let localAchievements = Array(achievementStore.unlockedAchievementIDs)
        let localLevelCompletions = achievementStore.levelCompletions
        
        // Switch to Game Center player
        achievementStore.currentPlayerName = gameCenterPlayer
        
        // Merge achievements
        if !localAchievements.isEmpty {
            Logger.gameCenter.info("Migrating \(localAchievements.count) achievements")
            for achievementID in localAchievements {
                achievementStore.unlockedAchievementIDs.insert(achievementID)
            }
            
            // Upload to Game Center
            await reportAchievements(localAchievements)
            Logger.gameCenter.notice("Uploaded achievements to Game Center")
        }
        
        // Merge level completions
        if !localLevelCompletions.isEmpty {
            Logger.gameCenter.info("Migrating level completion progress")
            for (key, level) in localLevelCompletions {
                let currentLevel = achievementStore.levelCompletions[key] ?? 0
                achievementStore.levelCompletions[key] = max(level, currentLevel)
            }
            Logger.gameCenter.notice("Level progress migrated")
        }
        
        // Copy local player's best score to Game Center player
        if let localBestScore = highscoreStore.entries.first(where: { $0.playerName == localPlayer }) {
            Logger.gameCenter.info("Migrating best score: \(localBestScore.score), level: \(localBestScore.maxLevel)")
            
            // Add to Game Center player's local scores
            highscoreStore.add(
                score: localBestScore.score,
                playerName: gameCenterPlayer,
                maxLevel: localBestScore.maxLevel,
                achievementIDs: localBestScore.achievementIDs,
                gameMode: localBestScore.gameMode,
                isPro: localBestScore.isPro
            )
            
            // Upload to Game Center leaderboard
            await submitScore(localBestScore.score, gameMode: localBestScore.gameMode, isPro: localBestScore.isPro)
            Logger.gameCenter.notice("Score uploaded to Game Center leaderboard")
        }
        
        Logger.gameCenter.notice("Migration complete")
        
        // Restore original player context
        achievementStore.currentPlayerName = originalPlayer
    }
    
    /// Internal convenience method called during authentication.
    ///
    /// This version of `syncFromGameCenter()` is called from authentication handlers but doesn't
    /// have access to the achievement and highscore stores. It logs a warning indicating that
    /// a full sync is pending.
    ///
    /// - Important: The actual sync must be triggered from the app with proper store references
    ///   using `syncFromGameCenter(achievementStore:highscoreStore:previousLocalPlayer:)`.
    private func syncFromGameCenter() async {
        // This will be called from authentication handlers
        // The actual sync needs to be triggered from the app with proper store references
        Logger.gameCenter.warning("Game Center authenticated - sync pending (requires store references)")
    }
    
    /// Syncs achievements from Game Center to local storage.
    ///
    /// This method downloads all completed achievements from Game Center and merges them with
    /// local achievements. Any achievements found in Game Center but not locally are added to
    /// the local store.
    ///
    /// After syncing achievements, this method calls `deriveProgressFromAchievements` to update
    /// level completion progress based on the achievement requirements (e.g., if a player has the
    /// "level 10" achievement, their level progress is set to at least 10).
    ///
    /// - Parameter achievementStore: The local achievement store to update
    ///
    /// - Note: Only completed achievements (100% progress) are synced. Partial progress is not
    ///   currently supported by this implementation.
    private func syncAchievementsFromGameCenter(achievementStore: AchievementStore) async {
        let gcAchievements = await loadAchievements()
        
        guard !gcAchievements.isEmpty else {
            Logger.gameCenter.info("No Game Center achievements to sync")
            return
        }
        
        var syncedCount = 0
        var newAchievements: [String] = []
        
        // Map Game Center achievements back to local IDs
        for gcAchievement in gcAchievements {
            guard gcAchievement.isCompleted else { continue }
            
            // Find matching local achievement ID
            if let localID = localIDFromGameCenter(gcAchievement.identifier) {
                if !achievementStore.isUnlocked(localID) {
                    // Unlock locally if found in Game Center but not local
                    achievementStore.unlockedAchievementIDs.insert(localID)
                    newAchievements.append(localID)
                    syncedCount += 1
                }
            }
        }
        
        if syncedCount > 0 {
            Logger.gameCenter.notice("Synced \(syncedCount) achievements from Game Center to local: \(newAchievements.joined(separator: ", "))")
            
            // Derive level completions from achievements
            // This ensures mode unlocks work correctly after sync
            deriveProgressFromAchievements(achievementStore: achievementStore, achievements: newAchievements)
        } else {
            Logger.gameCenter.info("All Game Center achievements already exist locally")
        }
    }
    
    /// Derives level completion progress from synced achievements.
    ///
    /// Game Center stores achievements as binary completed/incomplete, but the app needs level
    /// progression data to manage mode unlocks. This method infers level completion from
    /// achievements by using a mapping of achievement IDs to their level requirements.
    ///
    /// For example:
    /// - `color_cadet` achievement → at least level 5 in Colors Normal
    /// - `ultra_instinct` achievement → at least level 30 in some mode
    ///
    /// This ensures that mode unlocks work correctly after syncing from Game Center, even on
    /// a fresh device installation.
    ///
    /// - Parameters:
    ///   - achievementStore: The achievement store to update with derived progress
    ///   - achievements: The list of achievement IDs to derive progress from
    ///
    /// - Note: If the current level is already higher than the achievement's level requirement,
    ///   the current level is preserved (no downgrade).
    private func deriveProgressFromAchievements(achievementStore: AchievementStore, achievements: [String]) {
        // Map achievements to their level requirements
        let achievementLevels: [String: (mode: String, level: Int, isPro: Bool)] = [
            "color_cadet": ("colors", 5, false),
            "shape_novice": ("shapes", 5, false),
            "emoji_apprentice": ("emojis", 5, false),
            "polygon_prodigy": ("colors", 10, false),
            "smiley_summoner": ("colors", 20, false),
            "ultra_instinct": ("colors", 30, false),
            "rainbow_wrangler": ("colors", 15, false),
            "triangle_tamer": ("shapes", 15, false),
            "emoji_enthusiast": ("emojis", 15, false),
            "color_virtuoso": ("colors", 25, false),
            "shape_master": ("shapes", 25, false),
            "emoji_expert": ("emojis", 25, false),
            "chromatic_champion": ("colors", 30, false),
            "geometry_genius": ("shapes", 30, false),
            "emoji_overlord": ("emojis", 30, false),
            "rainbow_annihilator": ("colors", 30, true),
            "shape_sorcerer": ("shapes", 30, true),
            "emoji_apocalypse": ("emojis", 30, true),
            "the_unkillable": ("colors", 30, false) // Special case - all modes
        ]
        
        for achievementID in achievements {
            if let info = achievementLevels[achievementID] {
                let key = "\(info.mode)_\(info.isPro)"
                let currentLevel = achievementStore.levelCompletions[key] ?? 0
                
                // Only update if the achievement level is higher
                if info.level > currentLevel {
                    achievementStore.levelCompletions[key] = info.level
                    Logger.gameCenter.debug("Updated \(key) progress to level \(info.level)")
                }
                
                // Special handling for "the_unkillable" - all modes at level 30
                if achievementID == "the_unkillable" {
                    for mode in ["colors", "shapes", "emojis"] {
                        for isPro in [false, true] {
                            let allKey = "\(mode)_\(isPro)"
                            let currentAllLevel = achievementStore.levelCompletions[allKey] ?? 0
                            if 30 > currentAllLevel {
                                achievementStore.levelCompletions[allKey] = 30
                                Logger.gameCenter.debug("Updated \(allKey) progress to level 30 (from ultimate achievement)")
                            }
                        }
                    }
                }
            }
        }
    }
    
    /// Syncs the player's high score from Game Center to local storage.
    ///
    /// This method loads the authenticated player's best score from the legacy global iOS
    /// leaderboard and compares it to their local high score. If the Game Center score is higher,
    /// it's added to the local highscore store.
    ///
    /// The method decodes game mode and pro status from the leaderboard entry's context field
    /// to properly categorize the score.
    ///
    /// - Parameters:
    ///   - highscoreStore: The local highscore store to update
    ///   - playerName: The Game Center player's display name
    ///
    /// - Note: If the local score is already higher than or equal to the Game Center score,
    ///   no changes are made.
    /// - Note: Currently syncs from the legacy iOS global leaderboard. Consider syncing from
    ///   mode-specific leaderboards in future versions.
    private func syncScoresFromGameCenter(highscoreStore: HighscoreStore, playerName: String) async {
        // Load player's best score from Game Center
        let entries = await loadLeaderboard(
            leaderboardID: .ios,
            playerScope: .global,
            timeScope: .allTime,
            range: NSRange(location: 1, length: 1)
        )
        
        // Find the local player's entry
        guard let localPlayerEntry = entries.first(where: { $0.player.gamePlayerID == GKLocalPlayer.local.gamePlayerID }) else {
            Logger.gameCenter.info("No Game Center score found for this player")
            return
        }
        
        let gcScore = localPlayerEntry.score
        
        // Decode game mode and pro status from context
        let context = localPlayerEntry.context
        let gameModeValue = context % 1000
        let isPro = context >= 1000
        let gameMode: String
        switch gameModeValue {
        case 0: gameMode = "colors"
        case 1: gameMode = "numbers"
        case 2: gameMode = "shapes"
        case 3: gameMode = "flags"
        case 4: gameMode = "emojis"
        default: gameMode = "colors"
        }
        
        // Check if this score already exists in local highscores
        let existingScore = highscoreStore.entries.first(where: { $0.playerName == playerName })
        
        if let existing = existingScore {
            if gcScore > existing.score {
                // Game Center has a higher score - add it locally
                Logger.gameCenter.notice("Syncing higher score from Game Center - gcScore: \(gcScore), localScore: \(existing.score)")
                highscoreStore.add(score: gcScore, playerName: playerName, maxLevel: 1, achievementIDs: [], gameMode: gameMode, isPro: isPro)
            } else {
                Logger.gameCenter.info("Local score (\(existing.score)) is >= Game Center score (\(gcScore))")
            }
        } else {
            // No local score for this player - add Game Center score
            Logger.gameCenter.notice("Adding Game Center score to local storage: \(gcScore)")
            highscoreStore.add(score: gcScore, playerName: playerName, maxLevel: 1, achievementIDs: [], gameMode: gameMode, isPro: isPro)
        }
    }
    
    /// Syncs local achievements and scores to Game Center (uploads after offline play).
    ///
    /// This method uploads any local data that may not be in Game Center yet, which can happen
    /// when:
    /// - The player played offline and earned achievements/scores
    /// - The previous sync or upload failed
    /// - The player switched devices
    ///
    /// It uploads:
    /// - All unlocked achievements
    /// - The player's best high score for their profile
    ///
    /// - Parameters:
    ///   - achievementStore: The local achievement store to read from
    ///   - highscoreStore: The local highscore store to read from
    ///   - playerName: The Game Center player's display name
    ///
    /// - Note: This ensures local progress is preserved even if the player was offline.
    private func syncLocalToGameCenter(achievementStore: AchievementStore, highscoreStore: HighscoreStore, playerName: String) async {
        Logger.gameCenter.info("Syncing local data to Game Center")
        
        // Sync achievements
        let localAchievements = Array(achievementStore.unlockedAchievementIDs)
        if !localAchievements.isEmpty {
            await reportAchievements(localAchievements)
            Logger.gameCenter.notice("Uploaded \(localAchievements.count) achievements to Game Center")
        }
        
        // Sync best score for this player
        if let bestLocal = highscoreStore.entries.first(where: { $0.playerName == playerName }) {
            await submitScore(bestLocal.score, gameMode: bestLocal.gameMode, isPro: bestLocal.isPro)
            Logger.gameCenter.notice("Uploaded score to Game Center - score: \(bestLocal.score), mode: \(bestLocal.gameMode), pro: \(bestLocal.isPro)")
        }
    }
    
    /// Maps a Game Center achievement ID back to its local achievement ID.
    ///
    /// This is the reverse mapping of `AchievementID.fromLocalID(_:)`. It converts full
    /// Game Center achievement identifiers (e.g., `"wulf.ai.timekiller.AchievementColorCadet"`)
    /// back to local snake_case IDs (e.g., `"color_cadet"`).
    ///
    /// - Parameter gameCenterID: The full Game Center achievement identifier
    /// - Returns: The local achievement ID if a mapping exists, otherwise `nil`
    ///
    /// - Note: This is used during sync operations to convert downloaded Game Center achievements
    ///   into local achievement data.
    private func localIDFromGameCenter(_ gameCenterID: String) -> String? {
        // Reverse lookup of the AchievementID mapping
        switch gameCenterID {
        case AchievementID.colorCadet.rawValue: return "color_cadet"
        case AchievementID.shapeNovice.rawValue: return "shape_novice"
        case AchievementID.emojiApprentice.rawValue: return "emoji_apprentice"
        case AchievementID.polygonProdigy.rawValue: return "polygon_prodigy"
        case AchievementID.smileySummoner.rawValue: return "smiley_summoner"
        case AchievementID.ultraInstinct.rawValue: return "ultra_instinct"
        case AchievementID.rainbowWrangler.rawValue: return "rainbow_wrangler"
        case AchievementID.triangleTamer.rawValue: return "triangle_tamer"
        case AchievementID.emojiEnthusiast.rawValue: return "emoji_enthusiast"
        case AchievementID.colorVirtuoso.rawValue: return "color_virtuoso"
        case AchievementID.shapeMaster.rawValue: return "shape_master"
        case AchievementID.emojiExpert.rawValue: return "emoji_expert"
        case AchievementID.chromaticChampion.rawValue: return "chromatic_champion"
        case AchievementID.geometryGenius.rawValue: return "geometry_genius"
        case AchievementID.emojiOverlord.rawValue: return "emoji_overlord"
        case AchievementID.rainbowAnnihilator.rawValue: return "rainbow_annihilator"
        case AchievementID.shapeSorcerer.rawValue: return "shape_sorcerer"
        case AchievementID.emojiApocalypse.rawValue: return "emoji_apocalypse"
        case AchievementID.theUnkillable.rawValue: return "the_unkillable"
        default: return nil
        }
    }
}

// MARK: - Game Center Presentation Types

/// Specifies which Game Center content to display in the UI.
///
/// Use this enum with Game Center presentation APIs to show specific leaderboards or the
/// achievements dashboard to the user.
///
/// ## Example
/// ```swift
/// // Show a specific leaderboard
/// let content = GameCenterContent.leaderboard(id: "wulf.ai.timekiller.highscores.colors")
///
/// // Show the achievements dashboard
/// let content = GameCenterContent.achievements
/// ```
enum GameCenterContent {
    /// Display a specific leaderboard by its Game Center ID
    case leaderboard(id: String)
    /// Display the achievements dashboard
    case achievements
}

