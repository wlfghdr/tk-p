//
//  SettingsView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI
import OSLog

// MARK: - Settings View

/// Presents a comprehensive settings interface for configuring game preferences and player options.
///
/// `SettingsView_iOS` provides a Form-based UI that allows players to customize their
/// Timekiller experience across multiple categories: player identity, Game Center integration,
/// feedback preferences, visual theme, language, and developer tools.
///
/// ## Core Responsibilities
///
/// ### 1. Player Management
/// - **Local Player Name**: Editable text field for offline identity
/// - **Game Center Integration**: Shows authenticated player name when connected
/// - **Player Switching**: Button to access player selection screen
/// - **Validation**: Ensures player name is never empty, auto-fills "Player" as default
///
/// When Game Center is enabled and authenticated, the local player name field is replaced
/// with a read-only display showing the Game Center player name with a green indicator.
///
/// ### 2. Game Center Configuration
/// - **Enable/Disable Toggle**: Activates/deactivates online features
/// - **Connection Status**: Visual indicator (green checkmark or red X)
/// - **Authentication State**: Displays current connection status
/// - **Error Feedback**: Shows authentication errors when they occur
/// - **Simulator Warning**: Alerts developers that Game Center may not work in Simulator
///
/// **Important**: Enabling Game Center triggers authentication flow immediately.
///
/// ### 3. Feedback Controls
/// - **Sound Toggle**: System sounds for correct/wrong taps, level complete, etc.
/// - **Haptics Toggle**: Taptic Engine vibrations for tactile feedback
/// - Synced to `FeedbackManager.shared` on change
///
/// ### 4. Visual Theme Selection
/// Segmented picker with three options:
/// - **System**: Follows device appearance (default)
/// - **Light**: Forces light mode
/// - **Dark**: Forces dark mode
///
/// Applied via `.preferredColorScheme()` in root view.
///
/// ### 5. Language Selection
/// Segmented picker with supported languages:
/// - **German (de)**: Full localization
/// - **English (en)**: Full localization
///
/// Changing language during gameplay triggers a game reset to regenerate localized content.
///
/// ### 6. Developer Mode (Hidden)
/// When player name is "Wulf" (case-insensitive), reveals:
/// - **Dev Mode Active Badge**: Orange indicator with checkmark
/// - **Start Level Picker**: Choose starting level (1-30)
/// - **Feature List**: Explains dev-only capabilities
///
/// Dev mode features:
/// - Start at any level for testing
/// - Auto-solve rounds by tapping pause button
/// - Bypass locked content restrictions
///
/// ### 7. About Section
/// - **Version Display**: Shows app version and build number
///
/// ## Data Binding
///
/// All settings are bound to parent view's `@AppStorage` properties:
/// ```swift
/// SettingsView_iOS(
///     playerName: $playerName,
///     appLanguage: $appLanguage,
///     gridSizeRaw: $gridSizeRaw,              // Legacy, not used
///     appTheme: $appTheme,
///     proMode: $proMode,
///     gameModeRaw: $gameModeRaw,
///     soundEnabled: $soundEnabled,
///     hapticsEnabled: $hapticsEnabled,
///     showPlayerSelection: $showPlayerSelection,
///     startLevel: $startLevel,
///     gameCenterManager: gameCenterManager
/// )
/// ```
///
/// ## User Experience
///
/// ### Navigation
/// - Presented as a sheet from start screen
/// - "Done" button in top-right dismisses view
/// - Changes apply immediately (no "Save" button needed)
///
/// ### Validation
/// - Empty player names are auto-filled with "Player" on submit or dismiss
/// - Whitespace is trimmed automatically during typing
///
/// ### Visual Hierarchy
/// - Sections grouped logically
/// - Headers provide context
/// - Footers explain complex features
/// - Color-coded status indicators (green = good, red = error)
///
/// ## Game Center Behavior
///
/// When Game Center is toggled:
/// 1. **Enable**: Triggers `gameCenterManager.authenticate()` → Shows system auth UI
/// 2. **Disable**: Clears authentication, switches to local mode
/// 3. **Status Updates**: Real-time connection status displayed
/// 4. **Error Handling**: Authentication errors shown as red text
///
/// When authenticated:
/// - Local player name is hidden
/// - Game Center player name is displayed (read-only)
/// - Player selection button is hidden
/// - Highscores/achievements sync to iCloud
///
/// ## Layout
///
/// Organized into collapsible Form sections:
/// ```
/// [Dev Mode]           (if isDevMode)
/// Player
/// Game Center
/// Feedback
/// Theme
/// Language
/// About
/// ```
///
/// ## Platform
/// - **iOS Only**: This view is specific to iOS/iPadOS
/// - For watchOS, see `SettingsView_WatchOS` which provides a simplified interface
///
/// - Note: Some sections (like Game Center) are conditionally rendered based on availability.
struct SettingsView_iOS: View {
    // MARK: - Properties
    
    /// Two-way binding to the player's display name for local storage.
    @Binding var playerName: String
    
    /// Two-way binding to the current language code ("en", "de").
    @Binding var appLanguage: String
    
    /// Legacy binding for grid size (not actively used in gameplay anymore).
    @Binding var gridSizeRaw: String
    
    /// Two-way binding to the app theme ("system", "light", "dark").
    @Binding var appTheme: String
    
    /// Two-way binding to Pro mode state (16 items vs 8 items).
    @Binding var proMode: Bool
    
    /// Two-way binding to the current game mode raw value.
    @Binding var gameModeRaw: String
    
    /// Two-way binding to sound feedback toggle.
    @Binding var soundEnabled: Bool
    
    /// Two-way binding to haptic feedback toggle.
    @Binding var hapticsEnabled: Bool
    
    /// Two-way binding that triggers the player selection sheet.
    @Binding var showPlayerSelection: Bool
    
    /// Two-way binding to the starting level for dev mode.
    @Binding var startLevel: Int
    
    /// Reference to the shared Game Center manager for authentication and status.
    let gameCenterManager: GameCenterManager
    
    // MARK: - State
    
    /// Environment dismiss action for closing this settings sheet.
    @Environment(\.dismiss) private var dismiss
    
    /// Tracks whether Game Center is currently being enabled (for loading indicator).
    @State private var isEnablingGameCenter = false
    
    // MARK: - Computed Properties
    
    /// Converts the raw game mode string to a `GameMode` enum, defaulting to colors.
    private var gameMode: GameMode {
        GameMode(rawValue: gameModeRaw) ?? .colors
    }
    
    /// Determines if developer mode is active by checking if player name is "Wulf".
    ///
    /// Dev mode unlocks:
    /// - Start level selector
    /// - Auto-solve capability
    /// - Locked content bypass
    ///
    /// **Case-insensitive**: "Wulf", "wulf", "WULF" all activate dev mode.
    private var isDevMode: Bool {
        let normalized = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.caseInsensitiveCompare("Wulf") == .orderedSame
    }
    
    /// Returns the app version string in format "Version (Build)".
    ///
    /// Example: "1.0.0 (42)"
    private var appVersion: String {
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
        let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "Unknown"
        return "\(version) (\(build))"
    }
    
    // MARK: - Helper Methods
    
    /// Ensures the player name is never empty by setting a default value.
    ///
    /// Called when:
    /// - User submits an empty text field (presses return)
    /// - Settings view is dismissed
    ///
    /// If the trimmed player name is empty, sets it to "Player".
    private func setDefaultNameIfEmpty() {
        let trimmed = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            Logger.app.info("Empty player name detected, setting default")
            playerName = ContentView_iOS.defaultPlayerName()
        }
    }
    
    var body: some View {
        NavigationStack {
            Form {
                // MARK: - Player Section
                Section {
                    // Show Game Center name when enabled and authenticated
                    if gameCenterManager.isEnabled && gameCenterManager.isAuthenticated,
                       let gcPlayerName = gameCenterManager.gameCenterPlayerName {
                        HStack {
                            Image(systemName: "gamecontroller.fill")
                                .foregroundStyle(.green)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(gcPlayerName)
                                    .font(.body.bold())
                                Text(L("GameCenterPlayer", language: appLanguage))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .listRowBackground(Color.green.opacity(0.1))
                    } else {
                        // Local player name (only editable when Game Center is off)
                        TextField(L("PlayerName", language: appLanguage), text: $playerName)
                            .onChange(of: playerName) { oldValue, newValue in
                                // Only trim whitespace, don't set default while typing
                                let trimmed = newValue.trimmingCharacters(in: .whitespaces)
                                if !trimmed.isEmpty && trimmed != newValue {
                                    playerName = trimmed
                                }
                            }
                            .onSubmit {
                                // Set default name when user submits (presses return) with empty field
                                setDefaultNameIfEmpty()
                            }
                    }
                    
                    // Switch player button (only show when Game Center is off)
                    if !gameCenterManager.isEnabled || !gameCenterManager.isAuthenticated {
                        Button {
                            Logger.app.info("Opening player selection")
                            showPlayerSelection = true
                            dismiss()
                        } label: {
                            HStack {
                                Image(systemName: "person.2.fill")
                                Text(L("SwitchPlayer", language: appLanguage))
                            }
                        }
                    }
                }
                
                // MARK: - Dev Mode Section (only visible if dev mode active)
                if isDevMode {
                    Section {
                        HStack {
                            Image(systemName: "wrench.and.screwdriver.fill")
                                .foregroundStyle(.orange)
                            Text(L("DevModeActive", language: appLanguage))
                                .font(.headline)
                            Spacer()
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.orange)
                        }
                        
                        Picker(L("StartLevel", language: appLanguage), selection: $startLevel) {
                            ForEach(1...30, id: \.self) { level in
                                Text("Level \(level)").tag(level)
                            }
                        }
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text(L("DevModeInfo", language: appLanguage))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text("• \(L("DevModeFeature1", language: appLanguage))")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                            Text("• \(L("DevModeFeature2", language: appLanguage))")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    } header: {
                        Text(L("DeveloperMode", language: appLanguage))
                    }
                }
                
                // MARK: - Game Center Section (direkt nach Player, um die Verbindung klar zu machen)
                Section {
                    Toggle(isOn: Binding(
                        get: { gameCenterManager.isEnabled },
                        set: { newValue in
                            Logger.app.info("Game Center toggle changed: enabled=\(newValue)")
                            if newValue {
                                isEnablingGameCenter = true
                                gameCenterManager.enable()
                                isEnablingGameCenter = false
                            } else {
                                gameCenterManager.disable()
                            }
                        }
                    )) {
                        HStack {
                            if isEnablingGameCenter {
                                ProgressView()
                                    .controlSize(.small)
                                    .padding(.trailing, 4)
                            }
                            Text(L("OnlineMode", language: appLanguage))
                        }
                    }
                    .disabled(isEnablingGameCenter)
                    
                    if gameCenterManager.isEnabled {
                        HStack {
                            Text(L("Status", language: appLanguage))
                            Spacer()
                            if gameCenterManager.isAuthenticated {
                                HStack(spacing: 4) {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundStyle(.green)
                                    Text(L("Connected", language: appLanguage))
                                        .foregroundStyle(.secondary)
                                }
                            } else {
                                HStack(spacing: 4) {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundStyle(.red)
                                    Text(L("NotConnected", language: appLanguage))
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                        
                        #if targetEnvironment(simulator)
                        if !gameCenterManager.isAuthenticated {
                            Text("Game Center may not work in Simulator. Please test on a real device.")
                                .font(.caption)
                                .foregroundStyle(.orange)
                        }
                        #endif
                        
                        if let error = gameCenterManager.authenticationError {
                            Text(error)
                                .font(.caption)
                                .foregroundStyle(.red)
                        }
                    }
                } header: {
                    Text(L("GameCenter", language: appLanguage))
                } footer: {
                    Text(L("GameCenterDescription", language: appLanguage))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                
                // MARK: - Feedback Section
                Section {
                    Toggle(L("Sound", language: appLanguage), isOn: $soundEnabled)
                    Toggle(L("Haptics", language: appLanguage), isOn: $hapticsEnabled)
                } header: {
                    Text(L("Feedback", language: appLanguage))
                }
                
                // MARK: - Theme Section
                Section {
                    Picker(L("Theme", language: appLanguage), selection: $appTheme) {
                        Text(L("ThemeSystem", language: appLanguage)).tag("system")
                        Text(L("ThemeLight", language: appLanguage)).tag("light")
                        Text(L("ThemeDark", language: appLanguage)).tag("dark")
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text(L("Theme", language: appLanguage))
                }
                
                Section {
                    Picker(L("Language", language: appLanguage), selection: $appLanguage) {
                        Text(L("German", language: appLanguage)).tag("de")
                        Text(L("English", language: appLanguage)).tag("en")
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text(L("Language", language: appLanguage))
                }
                
                Section {
                    HStack {
                        Text(L("Version", language: appLanguage))
                        Spacer()
                        Text(appVersion)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text(L("About", language: appLanguage))
                }
            }
            .navigationTitle(L("Settings", language: appLanguage))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(L("Done", language: appLanguage)) {
                        dismiss()
                    }
                }
            }
            .onDisappear {
                // Set default name when leaving settings with empty field
                setDefaultNameIfEmpty()
            }
        }
    }
}
