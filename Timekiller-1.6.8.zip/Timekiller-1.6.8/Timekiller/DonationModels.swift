//
//  DonationModels.swift
//  Timekiller
//
//  Created on 01.01.26.
//

import Foundation

// MARK: - Donation Product

/// Represents the available donation tiers for the app's tip jar feature.
///
/// This enum defines all the donation options users can choose from, each with a unique
/// product identifier that matches the In-App Purchase product configured in App Store Connect.
/// The enum provides associated metadata for each tier including emoji icons, localization keys,
/// and fallback pricing information.
///
/// Each donation is configured as a consumable In-App Purchase, meaning users can purchase
/// the same tier multiple times if they wish to support the developer repeatedly.
///
/// - Note: The raw values must exactly match the product identifiers configured in App Store Connect.
enum DonationProduct: String, CaseIterable, Identifiable {
    // MARK: - Cases
    
    /// Small donation tier - equivalent to buying the developer a coffee (~$0.99)
    case coffee = "wulf.ai.timekiller.tip.coffee"
    
    /// Medium-small donation tier - equivalent to buying the developer a beer (~$2.99)
    case beer = "wulf.ai.timekiller.tip.beer"
    
    /// Medium donation tier - equivalent to buying the developer a pizza (~$4.99)
    case pizza = "wulf.ai.timekiller.tip.pizza"
    
    /// Medium-large donation tier - equivalent to buying the developer wine (~$9.99)
    case wine = "wulf.ai.timekiller.tip.wine"
    
    /// Large donation tier - equivalent to a developer subscription (~$24.99)
    case subscription = "wulf.ai.timekiller.tip.devsubscription"
    
    /// Premium donation tier - equivalent to contributing to a sports car (~$49.99)
    case sportscar = "wulf.ai.timekiller.tip.sportscar"
    
    // MARK: - Identifiable Conformance
    
    /// Unique identifier for the donation product.
    /// Uses the raw value (product ID) as the identifier for SwiftUI list compatibility.
    var id: String { rawValue }
    
    // MARK: - Display Properties
    
    /// Returns the emoji icon representing this donation tier.
    ///
    /// Each tier has a unique emoji that visually represents the metaphor of the donation
    /// (e.g., ☕ for coffee, 🏎️ for sports car). These emojis are displayed in the UI
    /// alongside the donation name and price.
    var emoji: String {
        switch self {
        case .coffee: return "☕"
        case .beer: return "🍺"
        case .pizza: return "🍕"
        case .wine: return "🍷"
        case .subscription: return "💻"
        case .sportscar: return "🏎️"
        }
    }
    
    // MARK: - Localization Keys
    
    /// Returns the localization key for the donation tier's display name.
    ///
    /// These keys are used to look up localized strings from the app's string catalogs,
    /// allowing the donation names to be displayed in the user's preferred language.
    ///
    /// - Example: "DonationCoffee" might translate to "Coffee" (English), "Café" (Spanish), etc.
    var nameKey: String {
        switch self {
        case .coffee: return "DonationCoffee"
        case .beer: return "DonationBeer"
        case .pizza: return "DonationPizza"
        case .wine: return "DonationWine"
        case .subscription: return "DonationSubscription"
        case .sportscar: return "DonationSportscar"
        }
    }
    
    /// Returns the localization key for the donation tier's description.
    ///
    /// These keys are used to look up localized descriptions that provide additional context
    /// about each donation tier, helping users understand what their contribution represents.
    ///
    /// - Example: "DonationCoffeeDesc" might translate to "Buy me a coffee to fuel development!"
    var descriptionKey: String {
        switch self {
        case .coffee: return "DonationCoffeeDesc"
        case .beer: return "DonationBeerDesc"
        case .pizza: return "DonationPizzaDesc"
        case .wine: return "DonationWineDesc"
        case .subscription: return "DonationSubscriptionDesc"
        case .sportscar: return "DonationSportscarDesc"
        }
    }
    
    // MARK: - Pricing
    
    /// Returns the fallback price in USD for this donation tier.
    ///
    /// These prices are used in the StoreKit Configuration file for testing and development.
    /// In production, actual prices are fetched from App Store Connect and are automatically
    /// converted to the user's local currency and storefront pricing.
    ///
    /// The fallback prices serve as a reference and are not displayed directly to users.
    /// Always use `Product.displayPrice` for showing prices in the UI.
    ///
    /// - Returns: A `Decimal` value representing the price in USD
    var fallbackPrice: Decimal {
        switch self {
        case .coffee: return 0.99
        case .beer: return 2.99
        case .pizza: return 4.99
        case .wine: return 9.99
        case .subscription: return 24.99
        case .sportscar: return 49.99
        }
    }
}
