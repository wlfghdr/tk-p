//
//  PlayerSelectionView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI

// MARK: - Player Name Selection View

/// A dedicated interface for managing multiple player profiles in Timekiller.
///
/// `PlayerNameSelectionView_iOS` enables users to switch between different player
/// identities, each with their own achievement progress and unlock status. This
/// allows multiple people to share a device while maintaining separate game progress.
///
/// ## Core Features
///
/// ### 1. Player List Display
/// Shows all existing players with:
/// - **Player Name**: Primary identifier (bold)
/// - **Achievement Count**: Number of unlocked achievements
/// - **Current Player Indicator**: Green checkmark for active player
/// - **Swipe to Delete**: Trailing swipe reveals delete action
///
/// Empty state shows "No players" message when list is empty (edge case).
///
/// ### 2. Player Selection
/// Tapping any player row:
/// 1. Sets that player as active (`playerName` binding updated)
/// 2. Updates `AchievementStore.currentPlayerName`
/// 3. Resets game settings to defaults (Colors mode, Standard difficulty)
/// 4. Dismisses the sheet automatically
///
/// **Why Reset Settings?**
/// When switching players, we reset to safe defaults because:
/// - New player may not have unlocked advanced modes
/// - Pro mode requires specific achievements
/// - Prevents confusion from inheriting previous player's settings
///
/// ### 3. New Player Creation
/// Two-step process:
/// 1. Tap "Create New Player" button → Shows text field
/// 2. Enter name + tap checkmark → Player created and selected
///
/// Validation:
/// - Name cannot be empty (checkmark disabled until valid)
/// - Whitespace is trimmed automatically
/// - Player is created via `AchievementStore.createPlayer()`
/// - List refreshes to show new player immediately
///
/// ### 4. Player Deletion
/// Swipe-to-delete with confirmation:
/// - Alert asks for confirmation before deleting
/// - If deleting current player → switches to first remaining player or creates "Player"
/// - Cannot delete all players (auto-creates "Player" as fallback)
/// - Uses `AchievementStore.deletePlayer()` for proper cleanup
///
/// ## Data Flow
///
/// ### Initialization
/// ```swift
/// PlayerNameSelectionView_iOS(
///     playerName: $playerName,                // Current active player
///     achievementStore: achievementStore,     // Source of player data
///     language: appLanguage,                  // For localization
///     gameModeRaw: $gameModeRaw,             // Reset on player switch
///     proMode: $proMode                       // Reset on player switch
/// )
/// ```
///
/// ### Player List Management
/// - `existingPlayersList`: State array populated from `AchievementStore.getAllPlayerNames()`
/// - `refreshPlayerList()`: Called on appear, after create, after delete
/// - List is sorted alphabetically by `AchievementStore`
///
/// ### Achievement Display
/// For each player, shows:
/// - **Count > 0**: "X Achievements" (localized)
/// - **Count = 0**: "No Achievements" (localized)
///
/// Retrieved via `achievementStore.getAchievementCount(for: player)`.
///
/// ## User Experience
///
/// ### Navigation
/// - Presented as a sheet from Settings
/// - "Done" button in top-right dismisses without selecting (keeps current player)
/// - Selecting a player dismisses automatically
///
/// ### Visual Feedback
/// - Green checkmark indicates current player
/// - Delete button appears in red (swipe left)
/// - Text field has rounded border style
/// - Inline checkmark/X buttons for create flow
///
/// ### Safety Features
/// - Cannot delete all players (auto-creates "Player")
/// - Empty names are prevented via disabled checkmark
/// - Confirmation alert before deletion
/// - Immediate player switch when deleting active player
///
/// ## Layout Structure
/// ```
/// NavigationStack
///   List
///     Section: "Existing Players"
///       ForEach(players) → Player Rows with Swipe Actions
///     Section: "New Player"
///       [Text Field + Buttons] OR [Create Button]
/// ```
///
/// ## State Management
/// - `newPlayerName`: Holds text field input for new player
/// - `showingNewPlayerInput`: Toggles between button and text field
/// - `showingDeleteConfirmation`: Controls delete alert visibility
/// - `playerToDelete`: Tracks which player is pending deletion
/// - `existingPlayersList`: Cached list of player names for display
///
/// ## Platform
/// - **iOS Only**: This is the full-featured version for iOS/iPadOS
/// - For watchOS, see `PlayerNameSelectionView_WatchOS` (simplified interface)
///
/// - Note: This view does NOT handle Game Center players. When Game Center is active,
///   player selection is disabled and the Game Center player name is used instead.
struct PlayerNameSelectionView_iOS: View {
    @Binding var playerName: String
    let achievementStore: AchievementStore
    let language: String
    @Binding var gameModeRaw: String
    @Binding var proMode: Bool
    @Environment(\.dismiss) private var dismiss
    
    @State private var newPlayerName: String = ""
    @State private var showingNewPlayerInput: Bool = false
    @State private var showingDeleteConfirmation: Bool = false
    @State private var playerToDelete: String? = nil
    @State private var existingPlayersList: [String] = []  // Add state to track players
    
    var body: some View {
        NavigationStack {
            List {
                // Existing players section
                if !existingPlayersList.isEmpty {
                    Section {
                        ForEach(existingPlayersList, id: \.self) { player in
                            Button {
                                selectPlayer(player)
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(player)
                                            .font(.headline)
                                            .foregroundStyle(.primary)
                                        
                                        let count = achievementStore.getAchievementCount(for: player)
                                        if count > 0 {
                                            Text("\(count) \(L("AchievementsCount", language: language))")
                                                .font(.caption)
                                                .foregroundStyle(.secondary)
                                        } else {
                                            Text(L("NoAchievements", language: language))
                                                .font(.caption)
                                                .foregroundStyle(.secondary)
                                        }
                                    }
                                    
                                    Spacer()
                                    
                                    if player == playerName {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundStyle(.green)
                                    }
                                }
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button(role: .destructive) {
                                    playerToDelete = player
                                    showingDeleteConfirmation = true
                                } label: {
                                    Label(L("Delete", language: language), systemImage: "trash")
                                }
                            }
                        }
                    } header: {
                        Text(L("ExistingPlayers", language: language))
                    }
                }
                
                // Create new player section
                Section {
                    if showingNewPlayerInput {
                        HStack {
                            TextField(L("EnterPlayerName", language: language), text: $newPlayerName)
                                .textFieldStyle(.roundedBorder)
                            
                            Button {
                                createNewPlayer()
                            } label: {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.green)
                            }
                            .disabled(newPlayerName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                            
                            Button {
                                showingNewPlayerInput = false
                                newPlayerName = ""
                            } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundStyle(.red)
                            }
                        }
                    } else {
                        Button {
                            showingNewPlayerInput = true
                        } label: {
                            HStack {
                                Image(systemName: "plus.circle.fill")
                                Text(L("CreateNewPlayer", language: language))
                            }
                        }
                    }
                } header: {
                    Text(L("NewPlayer", language: language))
                }
            }
            .navigationTitle(L("SelectPlayer", language: language))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(L("Done", language: language)) {
                        dismiss()
                    }
                }
            }
            .onAppear {
                // Load players when view appears
                refreshPlayerList()
            }
            .alert(L("DeletePlayerConfirmation", language: language), isPresented: $showingDeleteConfirmation) {
                Button(L("Cancel", language: language), role: .cancel) {
                    playerToDelete = nil
                }
                Button(L("Delete", language: language), role: .destructive) {
                    if let player = playerToDelete {
                        deletePlayer(player)
                    }
                    playerToDelete = nil
                }
            } message: {
                Text(L("DeletePlayerMessage", language: language))
            }
        }
    }
    
    private func refreshPlayerList() {
        existingPlayersList = achievementStore.getAllPlayerNames()
    }
    
    private func selectPlayer(_ player: String) {
        playerName = player
        achievementStore.currentPlayerName = player
        
        // Reset to default unlocked settings when switching players
        gameModeRaw = GameMode.colors.rawValue
        proMode = false
        
        dismiss()
    }
    
    private func createNewPlayer() {
        let trimmedName = newPlayerName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else { return }
        
        // Use AchievementStore's createPlayer method
        achievementStore.createPlayer(name: trimmedName)
        
        // Select the new player immediately
        playerName = trimmedName
        achievementStore.currentPlayerName = trimmedName
        
        // Reset to default unlocked settings for new player
        gameModeRaw = GameMode.colors.rawValue
        proMode = false
        
        // Refresh the list to show the new player
        refreshPlayerList()
        
        // Reset input
        newPlayerName = ""
        showingNewPlayerInput = false
        
        // Dismiss after a short delay to ensure the parent view updates
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            dismiss()
        }
    }
    
    private func deletePlayer(_ player: String) {
        // If deleting the current player, switch to a different player or create default
        if player == playerName {
            let remainingPlayers = existingPlayersList.filter { $0 != player }
            if let firstPlayer = remainingPlayers.first {
                playerName = firstPlayer
                achievementStore.currentPlayerName = firstPlayer
            } else {
                // No players left, create default "Player"
                playerName = "Player"
                achievementStore.currentPlayerName = "Player"
                achievementStore.createPlayer(name: "Player")
            }
        }
        
        // Delete the player
        achievementStore.deletePlayer(name: player)
        
        // Refresh the list
        refreshPlayerList()
    }
}
