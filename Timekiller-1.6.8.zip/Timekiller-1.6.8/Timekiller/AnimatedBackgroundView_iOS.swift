//
//  AnimatedBackgroundView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI

// MARK: - Play Button Style

/// A custom button style that provides subtle press feedback with scale and opacity changes.
///
/// `PlayButtonStyle` creates a tactile feel for important action buttons (like "Play")
/// by slightly shrinking and fading the button when pressed, then smoothly animating
/// back to normal when released.
///
/// ## Visual Effect
/// - **Pressed State**: Scale = 0.95, Opacity = 0.9
/// - **Normal State**: Scale = 1.0, Opacity = 1.0
/// - **Animation**: 0.2 second ease-in-out transition
///
/// ## Usage
/// ```swift
/// Button("Start Game") {
///     startGame()
/// }
/// .buttonStyle(PlayButtonStyle())
/// ```
///
/// This style is commonly applied to the main "Start" button on the game's start screen.
struct PlayButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .opacity(configuration.isPressed ? 0.9 : 1.0)
            .animation(.easeInOut(duration: 0.2), value: configuration.isPressed)
    }
}

// MARK: - Pre-computed shape data for better performance (iOS)

/// Data structure representing a single animated shape in the background.
///
/// `FloatingShapeData_iOS` pre-computes all random values needed for a background shape
/// to avoid expensive random calculations during animation frames. This improves
/// rendering performance by computing once at initialization rather than on every frame.
///
/// ## Properties
/// - `id`: Unique identifier for SwiftUI's `ForEach`
/// - `shapeSize`: Diameter of the shape (90-180 points)
/// - `startX/Y`: Initial position in view coordinates
/// - `offsetX/Y`: Maximum travel distance for animation
/// - `duration`: How long one animation cycle takes (12-28 seconds)
/// - `delay`: Stagger delay for this shape (prevents all shapes moving in sync)
/// - `variant`: Type selector (0 = emoji, 1+ = colored circle)
/// - `color`: Pre-selected color for circle shapes
/// - `emoji`: Pre-selected emoji for emoji shapes
/// - `shapeType`: Sub-type identifier (currently unused, reserved for future shape variety)
///
/// ## Performance Benefit
/// By pre-computing all random values once in `computeShapeData()`, the actual
/// rendering loop only needs to interpolate positions based on `animationPhase`,
/// which is much faster than generating new random values every frame.
struct FloatingShapeData_iOS: Identifiable {
    let id: Int
    let shapeSize: CGFloat
    let startX: CGFloat
    let startY: CGFloat
    let offsetX: CGFloat
    let offsetY: CGFloat
    let duration: Double
    let delay: Double
    let variant: Int
    let color: Color
    let emoji: String
    let shapeType: Int
}

// MARK: - Animated Background

/// A visually engaging animated background with floating shapes and gradient materials.
///
/// `AnimatedBackgroundView` provides an immersive backdrop for the Timekiller game,
/// combining subtle gradients, material effects, and optional floating shapes that
/// animate smoothly across the screen. The design adapts to light/dark mode and
/// respects accessibility preferences.
///
/// ## Visual Layers (Bottom to Top)
///
/// 1. **Base Gradient**: Two-color vertical gradient
///    - **Dark Mode**: Deep blacks (0.08/0.04 RGB)
///    - **Light Mode**: Off-whites (0.97/0.93 RGB)
///    - Provides subtle depth and visual interest
///
/// 2. **Material Overlay**: `.ultraThinMaterial`
///    - Blurs content behind it
///    - Adds translucency effect
///    - Adapts to system appearance automatically
///
/// 3. **Floating Shapes** (only when `!isPlaying && !reduceMotion`)
///    - 8 shapes total (reduced from 16 for better performance)
///    - Mix of emojis (🎨⭐️🎯🔥✨💫🌟🎪🎭🎲🚀⚡️) and colored circles
///    - Blur radius: 3pt (emojis), 25pt (circles)
///    - Opacity: 0.35 (dark), 0.25 (light)
///    - Continuous linear animation (20 seconds per cycle, repeating forever)
///
/// ## Behavior
///
/// ### Animation Control
/// The view intelligently pauses/resumes animations based on:
/// - **isPlaying**: When `true`, shapes stop animating (gameplay screen)
/// - **reduceMotion**: When `true`, animations are completely disabled (accessibility)
/// - **scenePhase**: Pauses when app goes to background, resumes when active
///
/// This ensures:
/// - No wasted CPU cycles during gameplay
/// - Respect for user accessibility preferences
/// - Battery efficiency when app is backgrounded
///
/// ### Performance Optimizations
/// - Pre-computed shape data (no runtime random calculations)
/// - Reduced shape count (8 instead of 16)
/// - Animation only runs when visible
/// - Uses `.linear` animation for GPU acceleration
/// - Automatic cleanup when view disappears
///
/// ## Parameters
/// - `colorScheme`: Optional override for system color scheme (nil = follow system)
/// - `gameMode`: Current game mode (reserved for potential theme customization)
/// - `reduceMotion`: Accessibility setting to disable animations
/// - `isPlaying`: Whether game is active (hides shapes during gameplay for clarity)
///
/// ## Color Palette
/// The view uses a diverse palette of 12 colors:
/// - Primary: red, blue, green, yellow
/// - Secondary: purple, orange, pink, cyan
/// - Tertiary: indigo, teal, mint, brown
///
/// ## Lifecycle
/// - **onAppear**: Pre-computes shape data, starts animation if appropriate
/// - **onChange(scenePhase)**: Stops/resumes animation based on app state
/// - **onChange(isPlaying)**: Stops animation during gameplay, resumes on start screen
///
/// ## Usage
/// ```swift
/// ZStack {
///     AnimatedBackgroundView(
///         colorScheme: appColorScheme,
///         gameMode: currentGameMode,
///         reduceMotion: reduceMotion,
///         isPlaying: isGameActive
///     )
///     
///     // Your content here
/// }
/// ```
///
/// - Note: This is the iOS-specific version. For watchOS, use `AnimatedBackgroundView_WatchOS`
///   which has a simplified implementation optimized for smaller screens.
struct AnimatedBackgroundView: View {
    @Environment(\.colorScheme) var systemColorScheme
    @Environment(\.scenePhase) var scenePhase
    let colorScheme: ColorScheme?
    let gameMode: GameMode
    let reduceMotion: Bool
    let isPlaying: Bool  // Add this parameter to know when to pause/resume
    
    @State private var animationPhase: CGFloat = 0
    @State private var shapeData: [FloatingShapeData_iOS] = []
    @State private var isAnimating: Bool = false
    
    private var effectiveColorScheme: ColorScheme {
        colorScheme ?? systemColorScheme
    }
    
    var body: some View {
        ZStack {
            // Base gradient
            LinearGradient(
                colors: [
                    effectiveColorScheme == .dark ? Color(red: 0.08, green: 0.09, blue: 0.11) : Color(red: 0.97, green: 0.97, blue: 0.98),
                    effectiveColorScheme == .dark ? Color(red: 0.04, green: 0.05, blue: 0.06) : Color(red: 0.93, green: 0.94, blue: 0.96)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            
            // Material overlay in the middle
            Rectangle()
                .fill(.ultraThinMaterial)
            
            // Floating shapes layer - ABOVE material so they're visible
            // Only show animated shapes when NOT playing
            if !isPlaying && !reduceMotion && !shapeData.isEmpty && isAnimating {
                GeometryReader { geometry in
                    // Use ForEach with individual views for better animation support
                    ForEach(shapeData) { data in
                        Group {
                            if data.variant == 0 {
                                // Emoji
                                Text(data.emoji)
                                    .font(.system(size: data.shapeSize * 0.7))
                            } else {
                                // Colored circle
                                Circle()
                                    .fill(data.color)
                                    .frame(width: data.shapeSize, height: data.shapeSize)
                            }
                        }
                        .blur(radius: data.variant == 0 ? 3 : 25)
                        .opacity(effectiveColorScheme == .dark ? 0.35 : 0.25)
                        .offset(
                            x: data.startX + (animationPhase * data.offsetX),
                            y: data.startY + (animationPhase * data.offsetY)
                        )
                    }
                }
            }
        }
        .ignoresSafeArea()
        .onAppear {
            // Pre-compute shape data once when appearing
            if shapeData.isEmpty {
                computeShapeData()
            }
            // Start animation when view appears
            if !isPlaying && !reduceMotion {
                startAnimation()
            }
        }
        .onChange(of: scenePhase) { _, newPhase in
            // Stop animation when app goes to background
            if newPhase == .background || newPhase == .inactive {
                stopAnimation()
            } else if newPhase == .active && !isPlaying && !reduceMotion {
                // Restart animation when app becomes active and shapes should be visible
                startAnimation()
            }
        }
        .onChange(of: isPlaying) { _, newValue in
            if newValue {
                // Stop animation when game starts
                stopAnimation()
            } else if !reduceMotion {
                // Restart animation when returning to start screen
                startAnimation()
            }
        }
    }
    
    private func computeShapeData() {
        // Pre-compute random values once instead of during render
        let emojis = ["🎨", "⭐️", "🎯", "🔥", "✨", "💫", "🌟", "🎪", "🎭", "🎲", "🚀", "⚡️"]
        let colors: [Color] = [.red, .blue, .green, .yellow, .purple, .orange, .pink, .cyan, 
                               .indigo, .teal, .mint, .brown]
        
        // Reduce from 16 to 8 shapes for better performance
        shapeData = (0..<8).map { index in
            FloatingShapeData_iOS(
                id: index,
                shapeSize: CGFloat.random(in: 90...180),
                startX: CGFloat.random(in: -60...400),
                startY: CGFloat.random(in: -60...800),
                offsetX: CGFloat.random(in: -170...170),
                offsetY: CGFloat.random(in: -280...280),
                duration: Double.random(in: 12...28),
                delay: Double(index) * 0.5,
                variant: index % 3,
                color: colors[index % colors.count],
                emoji: emojis[index % emojis.count],
                shapeType: index % 6
            )
        }
    }
    
    private func startAnimation() {
        guard !isAnimating else { return }
        isAnimating = true
        // Reset and restart animation with slower duration
        animationPhase = 0
        withAnimation(.linear(duration: 20).repeatForever(autoreverses: true)) {
            animationPhase = 1
        }
    }
    
    private func stopAnimation() {
        isAnimating = false
        // Stop the animation by setting to a fixed value without animation
        withAnimation(.none) {
            animationPhase = 0
        }
    }
    
    private var allColors: [Color] {
        // Mix all colors from all game modes
        [.red, .blue, .green, .yellow, .purple, .orange, .pink, .cyan, 
         .indigo, .teal, .mint, .brown]
    }
}

// MARK: - Diamond Shape

/// A custom SwiftUI `Shape` that draws a diamond (rotated square) geometry.
///
/// `Diamond` creates a four-pointed diamond shape by connecting four corner points
/// at the midpoints of a rectangle's edges. This shape is currently defined but not
/// actively used in the animated background (reserved for future enhancements).
///
/// ## Geometry
/// The diamond is constructed by:
/// 1. Starting at top center (midX, minY)
/// 2. Drawing to right center (maxX, midY)
/// 3. Drawing to bottom center (midX, maxY)
/// 4. Drawing to left center (minX, midY)
/// 5. Closing the path back to top
///
/// This creates a perfect diamond inscribed in the given rectangle.
///
/// ## Usage (Future)
/// ```swift
/// Diamond()
///     .fill(Color.blue)
///     .frame(width: 50, height: 50)
/// ```
///
/// ## Potential Applications
/// - Alternative shape variant for background animations
/// - Game mode icon for future "Diamonds" mode
/// - Visual decoration in UI elements
struct Diamond: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.midX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.midX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.midY))
        path.closeSubpath()
        return path
    }
}
