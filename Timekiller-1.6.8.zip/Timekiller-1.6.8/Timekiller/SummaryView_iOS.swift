//
//  SummaryView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI
import OSLog

// MARK: - Summary View

/// Displays the game-over summary screen with scores, achievements, and highscore preview.
///
/// `SummaryView_iOS` is presented as a non-dismissible modal sheet after a game ends,
/// providing comprehensive feedback about the player's performance. It combines score
/// breakdowns, newly earned achievements, highscore rankings, and optional donation prompts.
///
/// ## Core Sections (Top to Bottom)
///
/// ### 1. Donation Prompt (iOS Only)
/// - Displays a randomized fun message encouraging optional tips
/// - One of four prompts: `DonateGameOver1`, `DonateGameOver2`, etc.
/// - Includes `DonateButton` with text style
/// - Styled with secondary background and rounded corners
/// - Non-intrusive, positioned at top for visibility without blocking content
///
/// ### 2. Level & Score Display
/// Two-column layout showing:
/// - **Left Column**: Level reached (large number, tinted accent color)
/// - **Right Column**: Total score (large number, green if positive, red if negative)
///
/// Visual design:
/// - 48pt bold rounded system font
/// - Caption labels above numbers
/// - Equal-width columns for balance
/// - Shared background card with secondary system color
///
/// ### 3. New Achievements Section (Conditional)
/// Only displayed if `newAchievements` array is not empty:
/// - "Achievements Earned" header
/// - List of achievement cards with:
///   - Large emoji icon (40pt)
///   - Achievement name (bold)
///   - Achievement explanation (secondary text)
/// - Tertiary background for each card
/// - Container has secondary background
///
/// Uses `Achievement.all.filter()` to fetch full achievement data by ID.
///
/// ### 4. Level Scores Breakdown (Conditional)
/// Only displayed if `levelScores` dictionary is not empty:
/// - "Score Per Level" header
/// - Row per level showing:
///   - Level number (left-aligned)
///   - Score for that level with + prefix (right-aligned, color-coded)
/// - Sorted by level number (ascending)
/// - Shows both positive and negative level scores
///
/// ### 5. Top Highscores Preview
/// Shows the top 3 highscores from `highscoreStore`:
/// - **Empty State**: "No highscores" message (italic, centered)
/// - **Populated State**: Up to 3 highscore entries with:
///   - Player name (bold)
///   - Timestamp (date/time format)
///   - Max level reached
///   - Game mode icon and name
///   - "Pro" badge if Pro mode
///   - Score (large, color-coded)
///
/// Metadata separated by bullets for readability.
///
/// ### 6. Fixed Action Buttons (Bottom)
/// Two buttons outside the `ScrollView` for persistent access:
///
/// **Done Button (Primary)**:
/// - Full-width accent color button
/// - Checkmark icon + "Done" text
/// - Calls `onRestart()` closure → resets game and dismisses
///
/// **Highscores Button (Secondary)**:
/// - Icon-only orange button (60pt wide)
/// - List number icon
/// - Opens highscores sheet modally
///
/// ## Data Flow
///
/// ### Initialization
/// ```swift
/// SummaryView_iOS(
///     level: finalLevel,
///     totalScore: finalScore,
///     levelScores: levelScoreDict,
///     highscoreStore: highscoreStore,
///     language: appLanguage,
///     newAchievements: achievementIDs,
///     onRestart: { resetGame() },
///     achievementStore: achievementStore,
///     playerName: effectivePlayerName,
///     gameCenterManager: gameCenterManager
/// )
/// ```
///
/// ### Highscore Integration
/// When "View Highscores" button is tapped:
/// 1. `showHighscores` state becomes `true`
/// 2. Sheet presents `HighscoreView_iOS` in a `NavigationStack`
/// 3. Full highscore list, achievements, and Game Center features available
/// 4. "Done" button dismisses back to summary
///
/// ### Donation Prompt Randomization
/// On view creation, `donationPromptKey` is set to a random key:
/// - `DonateGameOver1`: Fun message variant 1
/// - `DonateGameOver2`: Fun message variant 2
/// - `DonateGameOver3`: Fun message variant 3
/// - `DonateGameOver4`: Fun message variant 4
///
/// This keeps the donation prompt fresh across multiple game sessions.
///
/// ## User Experience
///
/// ### Modal Presentation
/// - `.interactiveDismissDisabled()` prevents swipe-to-dismiss (from ContentView_iOS)
/// - Only way out is tapping "Done" button (intentional)
/// - Ensures player sees their results before continuing
///
/// ### Scrollable Content
/// All content except action buttons is in a `ScrollView`:
/// - Donation prompt
/// - Scores
/// - Achievements
/// - Level breakdown
/// - Highscore preview
///
/// This ensures all information is accessible regardless of device size or orientation.
///
/// ### Action Buttons
/// Fixed at bottom for easy access:
/// - Always visible (not scrolled away)
/// - Clear visual separation (Divider + background)
/// - Primary action (Done) emphasized with full width + accent color
/// - Secondary action (Highscores) compact icon button
///
/// ## Layout Structure
/// ```
/// NavigationStack
///   VStack (spacing: 0)
///     ScrollView
///       VStack (spacing: 20, padding)
///         [Donation Prompt]
///         [Level & Score]
///         [New Achievements]  (if any)
///         [Level Breakdown]   (if any)
///         [Top Highscores]
///         Color.clear (bottom padding)
///     VStack (spacing: 0)  [Fixed Buttons]
///       Divider
///       HStack
///         [Done Button]
///         [Highscores Button]
/// ```
///
/// ## Helper Functions
///
/// ### `gameModeIcon(for:)`
/// Maps game mode string to SF Symbol name:
/// - "colors" → "paintpalette.fill"
/// - "numbers" → "number.square.fill"
/// - "shapes" → "star.square.fill"
/// - "flags" → "flag.fill"
/// - "emojis" → "face.smiling.fill"
///
/// ### `gameModeNameKey(for:)`
/// Maps game mode string to localization key:
/// - "colors" → "ModeColors"
/// - "numbers" → "ModeNumbers"
/// - etc.
///
/// ## Platform
/// - **iOS Only**: This view is specific to iOS/iPadOS
/// - For watchOS, see `SummaryView_WatchOS` (simplified, more compact)
///
/// - Note: This view is designed to be the final screen of a game session, providing
///   comprehensive feedback before returning to the start screen.
struct SummaryView_iOS: View {
    let level: Int
    let totalScore: Int
    let levelScores: [Int: Int]
    let highscoreStore: HighscoreStore
    let language: String
    let newAchievements: [String]
    let onRestart: () -> Void
    let achievementStore: AchievementStore
    let playerName: String
    let gameCenterManager: GameCenterManager
    
    @State private var showHighscores = false
    @State private var donationPromptKey: String = {
        let prompts = ["DonateGameOver1", "DonateGameOver2", "DonateGameOver3", "DonateGameOver4"]
        return prompts.randomElement() ?? prompts[0]
    }()
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Scrollable content area
                ScrollView {
                    VStack(spacing: 20) {
                        // Donation prompt (random fun text) - Moved to top
                        #if os(iOS)
                        VStack(spacing: 12) {
                            Text(L(donationPromptKey, language: language))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                                .frame(maxWidth: .infinity)
                            
                            DonateButton(language: language, style: .withText)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(12)
                        #endif
                        
                        // Level Reached and Final Score - Combined for compactness
                        HStack(alignment: .top, spacing: 20) {
                            // Level Reached
                            VStack(spacing: 4) {
                                Text(L("ReachedLevel", language: language))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text("\(level)")
                                    .font(.system(size: 48, weight: .bold, design: .rounded))
                                    .foregroundStyle(.tint)
                            }
                            .frame(maxWidth: .infinity)
                            
                            // Final Score
                            VStack(spacing: 4) {
                                Text(L("TotalScore", language: language))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text("\(totalScore)")
                                    .font(.system(size: 48, weight: .bold, design: .rounded))
                                    .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                            }
                            .frame(maxWidth: .infinity)
                        }
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(12)
                        
                        // New Achievements Section
                        if !newAchievements.isEmpty {
                            VStack(alignment: .leading, spacing: 12) {
                                Text(L("AchievementsEarned", language: language))
                                    .font(.headline)
                                
                                ForEach(Achievement.all.filter { newAchievements.contains($0.id) }, id: \.id) { achievement in
                                    HStack(spacing: 12) {
                                        Text(achievement.iconEmoji)
                                            .font(.system(size: 40))
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(L(achievement.nameKey, language: language))
                                                .font(.subheadline.bold())
                                            Text(L(achievement.explanationKey, language: language))
                                                .font(.caption)
                                                .foregroundStyle(.secondary)
                                        }
                                        Spacer()
                                    }
                                    .padding()
                                    .background(Color(.tertiarySystemBackground))
                                    .cornerRadius(12)
                                }
                            }
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(12)
                        }
                        
                        // Level Scores Breakdown
                        if !levelScores.isEmpty {
                            VStack(alignment: .leading, spacing: 12) {
                                Text(L("ScorePerLevel", language: language))
                                    .font(.headline)
                                
                                ForEach(levelScores.keys.sorted(), id: \.self) { levelNum in
                                    if let score = levelScores[levelNum] {
                                        HStack {
                                            Text("Level \(levelNum):")
                                                .font(.subheadline)
                                            Spacer()
                                            Text("\(score > 0 ? "+" : "")\(score)")
                                                .font(.subheadline.bold())
                                                .foregroundStyle(score > 0 ? Color.green : Color.red)
                                        }
                                        .padding(.horizontal)
                                    }
                                }
                            }
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(12)
                        }
                        
                        // Quick preview of top highscores
                        VStack(alignment: .leading, spacing: 12) {
                            Text(L("TopScores", language: language))
                                .font(.headline)
                            
                            if highscoreStore.entries.isEmpty {
                                Text(L("NoHighscores", language: language))
                                    .foregroundStyle(.secondary)
                                    .italic()
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .padding()
                            } else {
                                ForEach(highscoreStore.entries.prefix(3)) { entry in
                                    HStack {
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(entry.playerName)
                                                .font(.subheadline.bold())
                                            HStack(spacing: 6) {
                                                Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                                                    .font(.caption2)
                                                    .foregroundStyle(.secondary)
                                                Text("•")
                                                    .font(.caption2)
                                                    .foregroundStyle(.secondary)
                                                Text("Level \(entry.maxLevel)")
                                                    .font(.caption)
                                                    .foregroundStyle(.secondary)
                                                Text("•")
                                                    .font(.caption2)
                                                    .foregroundStyle(.secondary)
                                                HStack(spacing: 2) {
                                                    Image(systemName: gameModeIcon(for: entry.gameMode))
                                                        .font(.caption2)
                                                    Text(L(gameModeNameKey(for: entry.gameMode), language: language))
                                                        .font(.caption2)
                                                    if entry.isPro {
                                                        Text("Pro")
                                                            .font(.caption2.bold())
                                                            .foregroundStyle(.orange)
                                                    }
                                                }
                                                .foregroundStyle(.secondary)
                                            }
                                        }
                                        
                                        Spacer()
                                        
                                        Text("\(entry.score)")
                                            .font(.title3.bold())
                                            .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
                                    }
                                    .padding(.horizontal)
                                }
                            }
                        }
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(12)
                        
                        // Extra bottom padding to ensure content doesn't get hidden behind buttons
                        Color.clear.frame(height: 20)
                    }
                    .padding()
                }
                
                // Fixed action buttons at bottom (outside ScrollView)
                VStack(spacing: 0) {
                    Divider()
                    
                    HStack(spacing: 16) {
                        // Done Button (dismisses and returns to start)
                        Button {
                            Logger.app.info("Summary dismissed via Done button")
                            onRestart()
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "checkmark.circle.fill")
                                Text(L("Done", language: language))
                            }
                            .font(.title2.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.accentColor)
                            .cornerRadius(12)
                        }
                        
                        // Highscores Button (icon only)
                        Button {
                            showHighscores = true
                        } label: {
                            Image(systemName: "list.number")
                                .font(.title.bold())
                                .foregroundStyle(.white)
                                .frame(width: 60, height: 52)
                                .background(Color.orange)
                                .cornerRadius(12)
                        }
                    }
                    .padding()
                    .background(Color(.systemBackground))
                }
            }
            .navigationTitle(L("GameOver", language: language))
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                Logger.app.info("Summary view appeared - level: \(level), totalScore: \(totalScore), newAchievementsCount: \(newAchievements.count), playerName: \(playerName, privacy: .private)")
            }
            .sheet(isPresented: $showHighscores) {
                NavigationStack {
                    HighscoreView_iOS(
                        store: highscoreStore,
                        language: language,
                        achievementStore: achievementStore,
                        playerName: playerName,
                        gameCenterManager: gameCenterManager
                    )
                        .navigationTitle(L("Highscores", language: language))
                        .navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .navigationBarTrailing) {
                                Button(L("Done", language: language)) {
                                    showHighscores = false
                                }
                            }
                        }
                }
            }
        }
    }
    
    // Helper functions for game mode display
    private func gameModeIcon(for mode: String) -> String {
        switch mode {
        case "colors": return "paintpalette.fill"
        case "numbers": return "number.square.fill"
        case "shapes": return "star.square.fill"
        case "flags": return "flag.fill"
        case "emojis": return "face.smiling.fill"
        default: return "questionmark.circle"
        }
    }
    
    private func gameModeNameKey(for mode: String) -> String {
        switch mode {
        case "colors": return "ModeColors"
        case "numbers": return "ModeNumbers"
        case "shapes": return "ModeShapes"
        case "flags": return "ModeFlags"
        case "emojis": return "ModeEmojis"
        default: return "ModeColors"
        }
    }
}
