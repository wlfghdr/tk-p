//
//  GameModels.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation
import SwiftUI

// MARK: - Game Mode

/// Represents the different game modes available in the app.
///
/// Each game mode presents a different type of content for players to match:
/// - **Colors**: Match color names to color backgrounds
/// - **Numbers**: Match number words to number digits
/// - **Shapes**: Match shape names to geometric shapes
/// - **Flags**: Match country names to country flags
/// - **Emojis**: Match emoji names to emoji characters
///
/// Game modes are unlocked progressively based on player level achievement.
/// Colors and Numbers are always available, while others unlock at specific levels.
///
/// ## Example
/// ```swift
/// let mode = GameMode.colors
/// print(mode.nameKey) // "ModeColors" (localization key)
/// ```
enum GameMode: String, CaseIterable, Identifiable {
    /// Match color names to color backgrounds
    case colors = "colors"
    
    /// Match number words to number digits
    case numbers = "numbers"
    
    /// Match shape names to geometric shapes
    case shapes = "shapes"
    
    /// Match country names to country flags
    case flags = "flags"
    
    /// Match emoji names to emoji characters
    case emojis = "emojis"
    
    /// Unique identifier for this mode (returns the raw value)
    var id: String { rawValue }
    
    /// Localization key for displaying the mode name in the UI
    ///
    /// These keys should be defined in Localizable.strings for each supported language.
    var nameKey: String {
        switch self {
        case .colors: return "ModeColors"
        case .numbers: return "ModeNumbers"
        case .shapes: return "ModeShapes"
        case .flags: return "ModeFlags"
        case .emojis: return "ModeEmojis"
        }
    }
}

// MARK: - Universal Tile Content

/// A unified representation of content that can be displayed on a game tile.
///
/// `TileContent` provides a type-safe wrapper around the different types of game items
/// (colors, numbers, shapes, flags, emojis). This allows game logic to work uniformly
/// across different game modes without needing mode-specific code paths.
///
/// Each case wraps a specific game item type and exposes common properties like
/// `nameKey` and `id` through computed properties.
///
/// ## Example
/// ```swift
/// // Create content for different modes
/// let colorContent = TileContent.color(GameColor.standardColors[0])
/// let numberContent = TileContent.number(GameNumber.standardNumbers[0])
///
/// // Access common properties
/// print(colorContent.nameKey) // "Red"
/// print(colorContent.id) // UUID of the wrapped GameColor
/// ```
enum TileContent: Equatable {
    /// Color content (for Colors mode)
    case color(GameColor)
    
    /// Number content (for Numbers mode)
    case number(GameNumber)
    
    /// Shape content (for Shapes mode)
    case shape(GameShape)
    
    /// Flag content (for Flags mode)
    case flag(GameFlag)
    
    /// Emoji content (for Emojis mode)
    case emoji(GameEmoji)
    
    /// Returns the localization key for the wrapped content's name.
    ///
    /// This key can be used to display the content's name in the user's language.
    var nameKey: String {
        switch self {
        case .color(let gameColor): return gameColor.nameKey
        case .number(let gameNumber): return gameNumber.nameKey
        case .shape(let gameShape): return gameShape.nameKey
        case .flag(let gameFlag): return gameFlag.nameKey
        case .emoji(let gameEmoji): return gameEmoji.nameKey
        }
    }
    
    /// Returns the unique identifier of the wrapped content.
    var id: UUID {
        switch self {
        case .color(let gameColor): return gameColor.id
        case .number(let gameNumber): return gameNumber.id
        case .shape(let gameShape): return gameShape.id
        case .flag(let gameFlag): return gameFlag.id
        case .emoji(let gameEmoji): return gameEmoji.id
        }
    }
}

// MARK: - Grid Size (iOS only)

/// Defines the grid dimensions for iOS gameplay.
///
/// The grid size determines how many tiles are displayed simultaneously and their arrangement.
/// Larger grids provide more challenge by increasing the number of items to track.
///
/// Grid sizes are used on iOS only. watchOS uses a fixed single-tile display.
///
/// ## Available Sizes
/// - **2×2**: 4 tiles (2 columns × 2 rows) - Easiest, used for early levels
/// - **2×4**: 8 tiles (2 columns × 4 rows) - Medium difficulty
/// - **3×5**: 15 tiles (3 columns × 5 rows) - Most challenging, used for advanced levels
///
/// ## Example
/// ```swift
/// let size = GridSize.grid2x4
/// print(size.tileCount) // 8
/// print(size.columns)   // 2
/// print(size.rows)      // 4
/// ```
enum GridSize: String, CaseIterable, Identifiable {
    /// 2×2 grid (4 tiles) - Used for levels 1-4
    case grid2x2 = "2x2"
    
    /// 2×4 grid (8 tiles) - Used for levels 5-10
    case grid2x4 = "2x4"
    
    /// 3×5 grid (15 tiles) - Used for levels 11+
    case grid3x5 = "3x5"
    
    /// Unique identifier (returns the raw value)
    var id: String { rawValue }
    
    /// Total number of tiles in this grid
    var tileCount: Int {
        switch self {
        case .grid2x2: return 4
        case .grid2x4: return 8
        case .grid3x5: return 15
        }
    }
    
    /// Number of columns in this grid
    var columns: Int {
        switch self {
        case .grid2x2: return 2
        case .grid2x4: return 2
        case .grid3x5: return 3
        }
    }
    
    /// Number of rows in this grid
    var rows: Int {
        switch self {
        case .grid2x2: return 2
        case .grid2x4: return 4
        case .grid3x5: return 5
        }
    }
}

// MARK: - Level-Based Progression Functions

/// Determines which grid size should be used for a given level.
///
/// Grid size increases as the player progresses through levels, adding challenge
/// by requiring them to track more tiles simultaneously.
///
/// ## Progression Curve
/// - **Levels 1-4**: 2×2 grid (4 tiles) - Introduction phase
/// - **Levels 5-10**: 2×4 grid (8 tiles) - Intermediate challenge
/// - **Levels 11+**: 3×5 grid (15 tiles) - Advanced gameplay
///
/// - Parameter level: The current level number (1-based)
/// - Returns: The appropriate `GridSize` for this level
///
/// ## Example
/// ```swift
/// let size = gridSizeForLevel(8)
/// print(size) // GridSize.grid2x4 (8 tiles)
/// ```
func gridSizeForLevel(_ level: Int) -> GridSize {
    if level <= 4 {
        return .grid2x2  // Levels 1-4: Small grid (4 tiles)
    } else if level <= 10 {
        return .grid2x4  // Levels 5-10: Medium grid (8 tiles)
    } else {
        return .grid3x5  // Levels 11+: Large grid (15 tiles)
    }
}

/// Calculates how many correct answers are required to complete a given level.
///
/// This creates a difficulty progression where players must find more matching tiles
/// as they advance through levels.
///
/// ## Progression Curve
/// - **Levels 1-7**: 1 correct answer required
/// - **Levels 8-15**: 2 correct answers required
/// - **Levels 16-22**: 3 correct answers required
/// - **Levels 23+**: 4 correct answers required
///
/// - Parameter level: The current level number (1-based)
/// - Returns: The number of correct tiles that must be tapped to complete the level
///
/// ## Example
/// ```swift
/// let required = requiredCorrectAnswers(level: 20)
/// print(required) // 3
/// ```
func requiredCorrectAnswers(level: Int) -> Int {
    if level <= 7 {
        return 1  // Levels 1-7: Single answer
    } else if level <= 15 {
        return 2  // Levels 8-15: Double answers
    } else if level <= 22 {
        return 3  // Levels 16-22: Triple answers
    } else {
        return 4  // Levels 23+: Quad answers
    }
}

/// Calculates the time limit (in seconds) for completing a given level.
///
/// Time limits are based on grid size and decrease gradually for advanced levels,
/// creating increasing time pressure as players progress.
///
/// ## Base Times (Levels 1-24)
/// - **2×2 grid**: 8 seconds
/// - **2×4 grid**: 12 seconds
/// - **3×5 grid**: 15 seconds
///
/// ## Time Reduction (Levels 25+)
/// Starting from level 25, time is reduced by 5% per level:
/// - Level 25: 95% of base time
/// - Level 26: 90.25% of base time
/// - Level 27: 85.7% of base time
/// - And so on (exponential decay)
///
/// This creates a gentler difficulty curve for extended gameplay compared to
/// linear reduction, allowing skilled players to reach higher levels.
///
/// - Parameter level: The current level number (1-based)
/// - Returns: The time limit in seconds (may contain decimal places)
///
/// ## Example
/// ```swift
/// let time = baseTimeForLevel(11)
/// print(time) // 15.0 (level 11 uses 3×5 grid)
///
/// let hardTime = baseTimeForLevel(26)
/// print(hardTime) // ~13.5 (15 seconds × 0.95 × 0.95)
/// ```
func baseTimeForLevel(_ level: Int) -> Double {
    let gridSize = gridSizeForLevel(level)
    
    // Base duration by grid size
    let baseDuration: Double
    switch gridSize {
    case .grid2x2:
        baseDuration = 8.0   // 4 tiles: 8 seconds
    case .grid2x4:
        baseDuration = 12.0  // 8 tiles: 12 seconds
    case .grid3x5:
        baseDuration = 15.0  // 15 tiles: 15 seconds
    }
    
    // No time reduction for levels 1-24
    if level < 25 {
        return baseDuration
    }
    
    // From level 25 onwards: 5% reduction per level (gentler than before)
    // Level 25: 95% time, Level 26: 90.25% time, Level 27: 85.7% time, etc.
    let levelsAbove24 = level - 24
    let reductionFactor = pow(0.95, Double(levelsAbove24))
    return baseDuration * reductionFactor
}

// MARK: - Tile Data Model

/// Represents a single tile in the game grid with display and background content.
///
/// `TileData` is the core model for individual game tiles. Each tile has two types of content:
/// - **Display Content**: The text label shown on the tile (e.g., "Red", "5", "Circle")
/// - **Background Content**: The actual visual content behind the text (color, shape, emoji, etc.)
///
/// The game's core challenge is matching these correctly: players must tap tiles where the
/// display text correctly describes the background content.
///
/// ## Properties
/// - `id`: Unique identifier for SwiftUI list rendering
/// - `displayContent`: What text is shown to the player
/// - `backgroundContent`: What visual content is actually displayed
/// - `backgroundColor`: Computed color for the tile background
/// - `visualContent`: Computed string for non-color modes (shape emoji, number, flag emoji, etc.)
/// - `isCorrect`: Whether the display text matches the background content
///
/// ## Example
/// ```swift
/// // Correct tile: "Red" text on red background
/// let correctTile = TileData(
///     displayContent: .color(redColor),
///     backgroundContent: .color(redColor)
/// )
/// print(correctTile.isCorrect) // true
///
/// // Incorrect tile: "Blue" text on red background
/// let incorrectTile = TileData(
///     displayContent: .color(blueColor),
///     backgroundContent: .color(redColor)
/// )
/// print(incorrectTile.isCorrect) // false
/// ```
struct TileData: Identifiable {
    /// Unique identifier for this tile (used by SwiftUI for list rendering)
    let id = UUID()
    
    /// The text content displayed on the tile (what the player sees as text)
    let displayContent: TileContent
    
    /// The actual background content of the tile (visual representation)
    let backgroundContent: TileContent
    
    /// The background color to render for this tile.
    ///
    /// - For color mode: Returns the actual color from the `GameColor`
    /// - For other modes: Returns a neutral adaptive background that works in light/dark mode
    ///   - iOS: Uses `.secondarySystemBackground` for automatic light/dark adaptation
    ///   - watchOS: Uses dark gray (0.2 white) which works well on watch displays
    var backgroundColor: Color {
        switch backgroundContent {
        case .color(let gameColor):
            return gameColor.color
        case .number(_), .shape(_), .flag(_), .emoji(_):
            // For numbers, shapes, flags and emojis, use a neutral background that adapts to light/dark mode
            #if os(watchOS)
            return Color(white: 0.2) // watchOS: use a dark gray that works well
            #else
            return Color(.secondarySystemBackground)
            #endif
        }
    }
    
    /// The visual content to display on the tile (for non-color modes).
    ///
    /// Returns:
    /// - `nil` for color mode (background color is the visual)
    /// - A string representation for other modes:
    ///   - Numbers: The digit (e.g., "5")
    ///   - Shapes: The shape emoji (e.g., "●", "■", "▲")
    ///   - Flags: The flag emoji (e.g., "🇺🇸", "🇬🇧")
    ///   - Emojis: The emoji character (e.g., "😀", "🎮")
    var visualContent: String? {
        switch backgroundContent {
        case .color(_):
            return nil
        case .number(let gameNumber):
            return String(gameNumber.value)
        case .shape(let gameShape):
            return gameShape.shape
        case .flag(let gameFlag):
            return gameFlag.emoji
        case .emoji(let gameEmoji):
            return gameEmoji.emoji
        }
    }
    
    /// Whether this tile is "correct" (display text matches background content).
    ///
    /// Compares the localization keys of the display and background content.
    /// If they match, the tile is correct and should be tapped by the player.
    ///
    /// - Returns: `true` if the display text accurately describes the background, `false` otherwise
    var isCorrect: Bool {
        displayContent.nameKey == backgroundContent.nameKey
    }
}
