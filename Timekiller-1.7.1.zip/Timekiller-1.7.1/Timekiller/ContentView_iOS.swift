//
//  ContentView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI
import GameKit
import OSLog

// MARK: - Main Content View

/// The primary game view for iOS, managing all gameplay screens and state.
///
/// `ContentView_iOS` orchestrates the complete game experience on iOS, from the start screen
/// through gameplay to level completion and final scoring. It serves as the single source of
/// truth for game state, managing UI presentation, user input, timing, scoring, and
/// achievements in a cohesive SwiftUI architecture.
///
/// ## Architecture
/// - **Observable State**: Uses SwiftUI's `@State` for reactive UI updates
/// - **Persistence**: Leverages `@AppStorage` for user preferences across sessions
/// - **Navigation**: Implements `NavigationStack` for modal presentations and sheets
/// - **Feedback Integration**: Coordinates haptics and sounds via `FeedbackManager`
///
/// ## Core Responsibilities
///
/// ### Game State Management
/// - Tracks current level, round, and scores
/// - Manages timer countdown and progress
/// - Generates tile configurations based on mode and difficulty
/// - Enforces game rules (correct/incorrect taps, timeouts, mistakes)
///
/// ### UI Presentation
/// - **Start Screen**: Game mode selection, Pro mode toggle, example tiles, start button
/// - **Gameplay Screen**: Compact header with live stats, grid of interactive tiles, timer progress bar
/// - **Pause Screen**: Score overview, resume/quit options
/// - **Level Complete Screen**: Celebration animation, score breakdown, continue/quit options
/// - **Summary Screen**: Final scores, highscore entry, achievements display
///
/// ### User Settings
/// - Player name (with Game Center override)
/// - Language (English/German)
/// - Game mode (Colors, Numbers, Shapes, Flags, Emojis)
/// - Pro mode (8 vs 16 items, score multiplier)
/// - Start level (Dev mode only)
/// - Theme (System, Light, Dark)
/// - Sound/Haptic feedback toggles
///
/// ### Difficulty Progression
/// The game automatically increases difficulty across three dimensions:
/// 1. **Grid Size**: 2×2 (4 tiles) → 2×4 (8 tiles) → 3×5 (15 tiles)
/// 2. **Multiple Answers**: Find 1 correct → 2 correct → 3+ correct
/// 3. **Time Pressure**: 8 seconds → reduced by 5% per level after level 24
///
/// ### Scoring System
/// Points are calculated per round using a simple formula:
/// ```
/// Base Points = 10
/// Level Bonus = level × 5
/// Time Bonus = seconds_remaining × 10
/// Pro Multiplier = 1.5 (if Pro Mode enabled)
/// Round Score = (Base + Level Bonus + Time Bonus) × Pro Multiplier
/// ```
///
/// ## Game Flow
/// 1. **Start Screen**: User selects mode and Pro setting → Taps Start
/// 2. **Round Start**: Timer begins, tiles appear with one or more correct answers
/// 3. **User Action**: Tap correct tile(s) → Round complete | Tap wrong tile → Mistake | Timeout → Mistake
/// 4. **Mistake Handling**: 2nd mistake in a level → Game Over
/// 5. **Level Complete**: 6 rounds finished with positive score → Continue to next level
/// 6. **Game Over**: Show summary, save highscore, award achievements
///
/// ## Platform-Specific Features
/// - Dynamic grid sizing based on screen space
/// - Animated background matching game mode theme
/// - Liquid Glass material effects for UI cards
/// - Game Center integration for leaderboards and achievements
/// - StoreKit integration for optional donations
///
/// ## Dev Mode
/// When player name is "Wulf" (case-insensitive):
/// - Start level selector appears in settings
/// - Pause button auto-solves current round
/// - Locked content bypass (for testing)
///
/// ## Example
/// ```swift
/// // In your app's main structure
/// @main
/// struct TimekillerApp: App {
///     var body: some Scene {
///         WindowGroup {
///             ContentView_iOS()
///         }
///     }
/// }
/// ```
///
/// - Note: This view is iOS-only. For watchOS, use `ContentView_WatchOS` which provides
///   a simplified interface optimized for smaller screens and always uses a 2×2 grid.
struct ContentView_iOS: View {
    // MARK: - App Storage (Settings)
    
    /// Player's display name for highscores and local storage.
    ///
    /// When Game Center is enabled and authenticated, this value is overridden by
    /// `effectivePlayerName` which uses the Game Center display name instead.
    ///
    /// **Storage Key**: `tk_playerName`
    /// **Default**: "Player"
    ///
    /// ## Dev Mode Trigger
    /// Setting this to "Wulf" (case-insensitive) activates developer features:
    /// - Start level selector in settings
    /// - Auto-solve on pause button tap
    /// - Access to locked content for testing
    @AppStorage("tk_playerName") private var playerName: String = "Player"
    
    /// Interface language for all text in the app.
    ///
    /// Supports English ("en") and German ("de"). The default language is determined
    /// automatically from system preferences via `defaultLanguage()`.
    ///
    /// **Storage Key**: `tk_language`
    /// **Default**: System language preference (falls back to "en")
    ///
    /// Changing this value during gameplay forces a game reset to regenerate tiles
    /// with correctly localized names.
    @AppStorage("tk_language") private var appLanguage: String = Self.defaultLanguage()
    
    /// Raw grid size string (deprecated, now determined by level).
    ///
    /// Grid size is now automatically determined by `gridSizeForLevel()` rather than
    /// user selection. This property is kept for backward compatibility but no longer
    /// affects gameplay.
    ///
    /// **Storage Key**: `tk_gridSize`
    /// **Default**: "2x2"
    /// **Values**: "2x2", "2x4", "3x5"
    ///
    /// - Note: This will be removed in a future version once all users have migrated.
    @AppStorage("tk_gridSize") private var gridSizeRaw: String = "2x2"
    
    /// Color scheme preference for the app interface.
    ///
    /// Controls whether the app uses light mode, dark mode, or follows system appearance.
    ///
    /// **Storage Key**: `tk_theme`
    /// **Default**: "system"
    /// **Values**: "system", "light", "dark"
    ///
    /// Applied via `.preferredColorScheme()` modifier on the root view.
    @AppStorage("tk_theme") private var appTheme: String = "system"
    
    /// Starting level for new games (Dev mode only).
    ///
    /// When Dev mode is active (player name is "Wulf"), games start at this level
    /// instead of level 1. Useful for testing high-level difficulty and grid configurations.
    ///
    /// **Storage Key**: `tk_startLevel`
    /// **Default**: 1
    /// **Range**: 1+
    ///
    /// In normal mode, this value is ignored and games always start at level 1.
    @AppStorage("tk_startLevel") private var startLevel: Int = 1
    
    /// Whether Pro mode is enabled, increasing item count and score multiplier.
    ///
    /// **Storage Key**: `tk_proMode`
    /// **Default**: false
    ///
    /// ## Pro Mode Changes
    /// - **Standard Mode**: 8 items (colors, shapes, etc.)
    /// - **Pro Mode**: 16 items (twice the variety)
    /// - **Score Multiplier**: 1.5× all points
    ///
    /// ## Unlock Requirements
    /// Pro mode must be unlocked by earning specific achievements before it can be
    /// toggled on. Unlocked separately for each game mode.
    ///
    /// Changing this value during gameplay forces a game reset.
    @AppStorage("tk_proMode") private var proMode: Bool = false
    
    /// Whether Inverse Mode is enabled—spot the odd tile out instead of matching correct tiles.
    ///
    /// **Storage Key**: `tk_inverseMode`
    /// **Default**: false
    ///
    /// ## Inverse Mode Logic
    /// When enabled, the grid is filled with mostly correct answers and one deliberately incorrect tile.
    /// The player must find the odd one out instead of matching correct answers.
    ///
    /// This is a logic flip, not a new game mode. It works with all game modes and Pro Mode.
    ///
    /// Changing this value during gameplay forces a game reset.
    @AppStorage("tk_inverseMode") private var inverseMode: Bool = false
    
    /// Currently selected game mode as raw string value.
    ///
    /// **Storage Key**: `tk_gameMode`
    /// **Default**: "colors"
    /// **Values**: "colors", "numbers", "shapes", "flags", "emojis"
    ///
    /// Determines what content appears on tiles and how tiles are generated. Some
    /// modes require achievements to be unlocked before they can be selected.
    ///
    /// Changing this value during gameplay forces a game reset.
    @AppStorage("tk_gameMode") private var gameModeRaw: String = GameMode.colors.rawValue
    
    /// Whether sound effects are enabled for feedback.
    ///
    /// **Storage Key**: `tk_soundEnabled`
    /// **Default**: true
    ///
    /// When enabled, plays system sounds for:
    /// - Correct taps (tink)
    /// - Wrong taps (tock)
    /// - Time warnings (alert)
    /// - Level complete (fanfare)
    /// - Game start/end
    ///
    /// Synced to `FeedbackManager.shared.soundEnabled` on appear and when changed.
    @AppStorage("tk_soundEnabled") private var soundEnabled: Bool = true
    
    /// Whether haptic feedback is enabled for physical sensations.
    ///
    /// **Storage Key**: `tk_hapticsEnabled`
    /// **Default**: true
    ///
    /// When enabled, triggers Taptic Engine vibrations for:
    /// - Correct taps (success notification)
    /// - Wrong taps (error notification)
    /// - Time warnings (warning notification)
    /// - Level complete (multi-part celebration)
    /// - UI interactions (light impact)
    ///
    /// Synced to `FeedbackManager.shared.hapticsEnabled` on appear and when changed.
    @AppStorage("tk_hapticsEnabled") private var hapticsEnabled: Bool = true
    
    // MARK: - Computed Player Name (Game Center Override)
    
    /// The effective player name displayed in UI and stored in highscores.
    ///
    /// This computed property implements the Game Center integration logic:
    /// - **Game Center Active**: Uses Game Center display name (e.g., "ApplePlayer123")
    /// - **Local Mode**: Uses locally stored player name (e.g., "Player")
    ///
    /// ## Behavior
    /// When Game Center is enabled and the user is authenticated, this property returns
    /// the Game Center player name, ensuring highscores and achievements sync correctly
    /// with Apple's servers. When Game Center is disabled or not authenticated, it falls
    /// back to the local `playerName` value.
    ///
    /// ## Use Cases
    /// ```swift
    /// // Saving a highscore
    /// highscoreStore.add(score: totalScore, playerName: effectivePlayerName, ...)
    ///
    /// // Displaying player in UI
    /// Text("Player: \(effectivePlayerName)")
    /// ```
    ///
    /// - Note: This property is read-only. To change the player name, modify `playerName`
    ///   directly or authenticate with Game Center.
    private var effectivePlayerName: String {
        if gameCenterManager.isEnabled && gameCenterManager.isAuthenticated,
           let gcPlayerName = gameCenterManager.gameCenterPlayerName {
            return gcPlayerName
        }
        return playerName
    }
    
    // MARK: - Environment
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    
    // MARK: - Constants
    private let roundsPerLevel: Int = 6  // 6 rounds per level
    
    // MARK: - State
    @State private var highscoreStore = HighscoreStore()
    @State private var achievementStore = AchievementStore()
    @State private var feedbackManager = FeedbackManager.shared
    @State private var gameCenterManager = GameCenterManager.shared
    @State private var isPlaying = false
    @State private var showSettings = false
    @State private var showHighscores = false
    @State private var showSummary = false
    @State private var showLevelComplete = false
    @State private var isLowTimeWarningTriggered = false  // Track if warning was triggered
    @State private var newAchievementsThisRun: [String] = []  // Track achievements earned in current game
    @State private var newAchievementsThisLevel: [String] = []  // Track achievements earned in current level
    @State private var showLockAlert = false
    @State private var lockAlertMessage = ""
    @State private var showPlayerSelection = false  // Player selection sheet
    
    // Animation states for start screen
    @State private var exampleTileAnimationPhase: Int = 0
    @State private var startButtonScale: CGFloat = 1.0
    @State private var exampleAnimationTimer: Timer? = nil
    @State private var logoAnimationTimer: Timer? = nil  // Store logo timer
    @State private var logoAnimationPhase: Int = 0  // 0 = color blob, 1 = emoji
    @State private var currentLogoColor: GameColor? = nil
    @State private var currentLogoEmoji: GameEmoji? = nil
    
    // Game State
    @State private var level: Int = 1
    @State private var round: Int = 0
    @State private var totalScore: Int = 0
    @State private var levelScore: Int = 0
    @State private var levelScores: [Int: Int] = [:]  // Track score per level
    @State private var tiles: [TileData] = []
    @State private var timer: Timer?
    @State private var scoreDelta: Int? = nil
    @State private var timeRemaining: Double = 0
    @State private var timerProgress: Double = 1.0
    @State private var sessionShapes: [GameShape] = []  // Randomized shape set for this game session
    @State private var sessionFlags: [GameFlag] = []  // Randomized flag set for this game session
    @State private var sessionEmojis: [GameEmoji] = []  // Randomized emoji set for this game session
    @State private var consecutiveTimeouts: Int = 0  // Track consecutive timeouts
    @State private var consecutiveWrongTaps: Int = 0  // Track consecutive wrong taps
    @State private var mistakesThisLevel: Int = 0  // Track mistakes (timeouts or wrong taps) in current level
    
    // Inverse Mode achievement tracking
    @State private var consecutiveInverseCorrect: Int = 0  // Track consecutive correct inverse mode finds
    
    // Multiple correct answers state
    @State private var correctTilesFound: Set<UUID> = []  // Track which correct tiles have been found
    @State private var requiredCorrectCount: Int = 1  // How many correct tiles need to be found this round
    
    // Game over feedback state
    @State private var gameOverFeedback: GameOverFeedback? = nil  // Captures tile state when game ends for feedback
    
    // MARK: - Computed Properties
    private var gridSize: GridSize {
        // Grid size is now determined by level, not by user selection
        gridSizeForLevel(level)
    }
    
    private var gameMode: GameMode {
        GameMode(rawValue: gameModeRaw) ?? .colors
    }
    
    private var availableColors: [GameColor] {
        proMode ? GameColor.proColors : GameColor.standardColors
    }
    
    private var availableShapes: [GameShape] {
        // Return the randomized session shapes if they exist, otherwise the full set
        if !sessionShapes.isEmpty {
            return sessionShapes
        }
        return proMode ? GameShape.proShapes : GameShape.standardShapes
    }
    
    private var availableEmojis: [GameEmoji] {
        // Return the randomized session emojis if they exist, otherwise the full set
        if !sessionEmojis.isEmpty {
            return sessionEmojis
        }
        return proMode ? GameEmoji.proEmojis : GameEmoji.standardEmojis
    }
    
    private var availableFlags: [GameFlag] {
        // Return the randomized session flags if they exist, otherwise the full set
        if !sessionFlags.isEmpty {
            return sessionFlags
        }
        return proMode ? GameFlag.proFlags : GameFlag.standardFlags
    }
    
    private var availableNumbers: [GameNumber] {
        return proMode ? GameNumber.proNumbers : GameNumber.standardNumbers
    }
    
    private var availableItems: Int {
        switch gameMode {
        case .colors:
            return availableColors.count
        case .numbers:
            return availableNumbers.count
        case .shapes:
            return availableShapes.count
        case .flags:
            return availableFlags.count
        case .emojis:
            return availableEmojis.count
        }
    }
    
    private var currentRoundDuration: Double {
        // Use the new baseTimeForLevel function
        return baseTimeForLevel(level)
    }
    
    /// Calculate score for the current round using the new simplified system
    /// Base Points = 10 per round
    /// Level Bonus = level × 5
    /// Time Bonus = seconds remaining × 10
    /// Pro Multiplier = 1.5 (if Pro Mode, otherwise 1.0)
    /// Round Score = (Base + Level Bonus + Time Bonus) × Pro Multiplier
    private func calculateRoundScore(secondsRemaining: Double) -> Int {
        let basePoints = 10
        let levelBonus = level * 5
        let timeBonus = Int(secondsRemaining.rounded()) * 10
        
        let subtotal = basePoints + levelBonus + timeBonus
        let proMultiplier: Double = proMode ? 1.5 : 1.0
        
        return Int(Double(subtotal) * proMultiplier)
    }
    
    private var colorScheme: ColorScheme? {
        switch appTheme {
        case "light": return .light
        case "dark": return .dark
        default: return nil  // system
        }
    }
    
    // Dev Mode: Check if player name is "Wulf" (trimmed, case-insensitive)
    private var isDevMode: Bool {
        let normalized = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.caseInsensitiveCompare("Wulf") == .orderedSame
    }
    
    private var gameModeIcon: String {
        switch gameMode {
        case .colors:
            return "paintpalette.fill"
        case .numbers:
            return "number.square.fill"
        case .shapes:
            return "star.square.fill"
        case .flags:
            return "flag.fill"
        case .emojis:
            return "face.smiling.fill"
        }
    }
    
    // MARK: - Body
    var body: some View {
        NavigationStack {
            ZStack {
                // Animated background
                AnimatedBackgroundView(
                    colorScheme: colorScheme,
                    gameMode: gameMode,
                    reduceMotion: reduceMotion,
                    isPlaying: isPlaying
                )
                
                VStack(spacing: 20) {
                    // Header - only show when playing
                    if isPlaying {
                        headerView
                    }
                    
                    // Grid
                    if isPlaying {
                        VStack(spacing: 0) {
                            gridView
                                .transition(.scale.combined(with: .opacity))
                            
                            // Time Progress Bar
                            GeometryReader { geometry in
                                ZStack(alignment: .leading) {
                                    Rectangle()
                                        .fill(Color.gray.opacity(0.3))
                                        .frame(height: 8)
                                    
                                    Rectangle()
                                        .fill(timerProgress > 0.3 ? Color.green : Color.red)
                                        .frame(width: geometry.size.width * timerProgress, height: 8)
                                        .animation(.linear(duration: 0.1), value: timerProgress)
                                }
                                .cornerRadius(4)
                            }
                            .frame(height: 8)
                            .padding(.top, 20)
                        }
                    } else {
                        startPromptView
                    }
                    
                    Spacer()
                }
                .padding()
                
                // Score Delta Overlay
                if let delta = scoreDelta {
                    scoreDeltaOverlay(delta: delta)
                }
                
                // Level Complete Overlay
                if showLevelComplete {
                    levelCompleteOverlay
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    // Only show settings button on start screen (not during gameplay or pause)
                    if !isPlaying && round == 0 {
                        Button {
                            showSettings = true
                        } label: {
                            Image(systemName: "gear")
                        }
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    if round > 0 && !showLevelComplete {  // Show play/pause only if game has started and not on level complete screen
                        Button {
                            // Dev Mode: Auto-solve on pause button tap during gameplay (invisible)
                            if isDevMode && isPlaying {
                                autoSolveRound()
                            } else if isPlaying {
                                pauseGame()
                            } else {
                                startGame()  // Resume game
                            }
                        } label: {
                            Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                        }
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    // Only show highscores button on start screen (not during gameplay or level complete)
                    if round == 0 && !showLevelComplete {
                        Button {
                            showHighscores = true
                        } label: {
                            Image(systemName: "list.number")
                        }
                    }
                }
            }
            .sheet(isPresented: $showSettings) {
                SettingsView_iOS(
                    playerName: $playerName,
                    appLanguage: $appLanguage,
                    gridSizeRaw: $gridSizeRaw,
                    appTheme: $appTheme,
                    proMode: $proMode,
                    inverseMode: $inverseMode,
                    gameModeRaw: $gameModeRaw,
                    soundEnabled: $soundEnabled,
                    hapticsEnabled: $hapticsEnabled,
                    showPlayerSelection: $showPlayerSelection,
                    startLevel: $startLevel,
                    gameCenterManager: gameCenterManager,
                    achievementStore: achievementStore,
                    highscoreStore: highscoreStore
                )
            }
            .onChange(of: soundEnabled) { _, newValue in
                Logger.app.info("Sound setting changed: \(newValue)")
                feedbackManager.soundEnabled = newValue
            }
            .onChange(of: hapticsEnabled) { _, newValue in
                Logger.app.info("Haptics setting changed: \(newValue)")
                feedbackManager.hapticsEnabled = newValue
            }
            .onChange(of: proMode) { oldValue, newValue in
                Logger.app.info("Pro mode changed from \(oldValue) to \(newValue) (gameMode: \(gameMode.rawValue))")
                // Pro mode changed - force new game
                if isPlaying || round > 0 {
                    resetGame()
                }
            }
            .onChange(of: inverseMode) { oldValue, newValue in
                Logger.app.info("Inverse mode changed from \(oldValue) to \(newValue)")
                // Inverse mode changed - force new game
                if isPlaying || round > 0 {
                    resetGame()
                }
            }
            .onChange(of: gameModeRaw) { oldValue, newValue in
                Logger.app.info("Game mode changed from \(oldValue) to \(newValue) (isPro: \(proMode))")
                // Game mode changed - force new game
                if isPlaying || round > 0 {
                    resetGame()
                }
            }
            .onChange(of: appLanguage) { oldValue, newValue in
                Logger.app.info("Language changed from \(oldValue) to \(newValue)")
                // Language changed - force new game if in progress
                if isPlaying || round > 0 {
                    resetGame()
                }
            }
            .sheet(isPresented: $showHighscores) {
                NavigationStack {
                    HighscoreView_iOS(
                        store: highscoreStore,
                        language: appLanguage,
                        achievementStore: achievementStore,
                        playerName: effectivePlayerName,
                        gameCenterManager: gameCenterManager
                    )
                        .navigationTitle(L("Highscores", language: appLanguage))
                        .navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .navigationBarTrailing) {
                                Button(L("Done", language: appLanguage)) {
                                    showHighscores = false
                                }
                            }
                        }
                }
            }
            .sheet(isPresented: $showSummary) {
                SummaryView_iOS(
                    level: level,
                    totalScore: totalScore,
                    levelScores: levelScores,
                    highscoreStore: highscoreStore,
                    language: appLanguage,
                    newAchievements: newAchievementsThisRun,
                    onRestart: {
                        showSummary = false
                        resetGame()
                    },
                    achievementStore: achievementStore,
                    playerName: effectivePlayerName,
                    gameCenterManager: gameCenterManager,
                    gameOverFeedback: gameOverFeedback
                )
                .interactiveDismissDisabled()  // Prevent swipe-to-dismiss
            }
            .sheet(isPresented: $showPlayerSelection) {
                PlayerNameSelectionView_iOS(
                    playerName: $playerName,
                    achievementStore: achievementStore,
                    language: appLanguage,
                    gameModeRaw: $gameModeRaw,
                    proMode: $proMode
                )
            }
        }
        .preferredColorScheme(colorScheme)
        .onAppear {
            Logger.app.info("ContentView appeared")
            
            // Sync feedback manager settings on appear
            feedbackManager.soundEnabled = soundEnabled
            feedbackManager.hapticsEnabled = hapticsEnabled
            
            // Initialize achievement store with current player
            achievementStore.currentPlayerName = effectivePlayerName
            
            Logger.app.info("Current player: \(effectivePlayerName, privacy: .private), gameMode: \(gameMode.rawValue), isPro: \(proMode)")
            
            // Validate current selections and reset to defaults if locked
            validateSelections()
            
            // Authenticate with Game Center if enabled
            if gameCenterManager.isEnabled {
                gameCenterManager.authenticate()
            }
        }
        .onDisappear {
            Logger.app.debug("ContentView disappeared")
            // Clean up all timers when view disappears
            invalidateTimer()
            stopExampleAnimation()
        }
        .onChange(of: playerName) { oldValue, newValue in
            Logger.app.info("Player name changed from \(oldValue, privacy: .private) to \(newValue, privacy: .private)")
            
            // Update achievement store when player name changes (only if not in Game Center mode)
            if !gameCenterManager.isEnabled || !gameCenterManager.isAuthenticated {
                achievementStore.currentPlayerName = newValue
            }
        }
        .onChange(of: gameCenterManager.isAuthenticated) { _, isAuthenticated in
            Logger.app.info("Game Center authentication changed: isAuthenticated=\(isAuthenticated), isEnabled=\(gameCenterManager.isEnabled)")
            
            // When Game Center authentication changes, sync data and update player
            if isAuthenticated, gameCenterManager.isEnabled {
                // Switch to Game Center player name
                if let gcPlayerName = gameCenterManager.gameCenterPlayerName {
                    Logger.app.info("Switching to Game Center player: \(gcPlayerName, privacy: .private), previousLocalPlayer: \(playerName, privacy: .private)")
                    
                    // Store the previous local player name for first-time migration
                    let previousLocalPlayer = playerName
                    
                    // Trigger sync with Game Center (passing previous local player for migration)
                    Task {
                        await gameCenterManager.syncFromGameCenter(
                            achievementStore: achievementStore,
                            highscoreStore: highscoreStore,
                            previousLocalPlayer: previousLocalPlayer
                        )
                    }
                    
                    // Update to Game Center player (will be set again in sync, but set here for immediate UI update)
                    achievementStore.currentPlayerName = gcPlayerName
                }
            } else {
                Logger.app.info("Switching to local player mode: \(playerName, privacy: .private)")
                // Switched back to local mode - use local player name
                achievementStore.currentPlayerName = playerName
            }
        }
        .onChange(of: gameCenterManager.isEnabled) { _, isEnabled in
            // When Game Center is toggled
            if isEnabled && gameCenterManager.isAuthenticated {
                // Switched to Game Center mode - use Game Center player
                if let gcPlayerName = gameCenterManager.gameCenterPlayerName {
                    // Store the previous local player name for migration
                    let previousLocalPlayer = playerName
                    
                    // Trigger sync (passing previous local player for potential migration)
                    Task {
                        await gameCenterManager.syncFromGameCenter(
                            achievementStore: achievementStore,
                            highscoreStore: highscoreStore,
                            previousLocalPlayer: previousLocalPlayer
                        )
                    }
                    
                    // Update to Game Center player
                    achievementStore.currentPlayerName = gcPlayerName
                }
            } else {
                // Switched to local mode - use local player
                achievementStore.currentPlayerName = playerName
            }
            
            // Reset game if playing
            if isPlaying || round > 0 {
                resetGame()
            }
            
            // Revalidate selections for new player
            validateSelections()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
            Logger.app.info("App entering background")
            // App is going to background or being minimized - pause the game and stop animations
            if isPlaying && round > 0 {
                pauseGame()
            }
            // Stop example animations to reduce CPU usage in background
            stopExampleAnimation()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            Logger.app.info("App returning to foreground")
            // Restart animations if we're on the start screen (not playing and round 0)
            if !isPlaying && round == 0 && !reduceMotion {
                startExampleAnimation()
            }
        }
    }
    
    // MARK: - Header View
    private var headerView: some View {
        VStack(spacing: 8) {
            // Top Row: Level Progress, Find Counter, and Timer - kompakt in einer Zeile
            HStack(spacing: 12) {
                // Level & Round Card - kompakter
                VStack(spacing: 4) {
                    HStack(spacing: 6) {
                        Image(systemName: "mountain.2.fill")
                            .font(.caption2)
                            .foregroundStyle(.white)
                        Text("L\(level)")
                            .font(.caption.bold())
                            .foregroundStyle(.white)
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .cornerRadius(12)
                    
                    // Round Progress Dots - kompakter
                    HStack(spacing: 4) {
                        ForEach(1...roundsPerLevel, id: \.self) { roundNum in
                            Circle()
                                .fill(roundNum <= round ? Color.blue : Color.gray.opacity(0.3))
                                .frame(width: 6, height: 6)
                        }
                    }
                }
                
                // Find X/Y Counter - kompakt, nur wenn benötigt
                if requiredCorrectCount > 1 {
                    HStack(spacing: 6) {
                        Image(systemName: "target")
                            .font(.caption2)
                            .foregroundStyle(.orange)
                        
                        Text("\(correctTilesFound.count)/\(requiredCorrectCount)")
                            .font(.callout.bold())
                            .foregroundStyle(correctTilesFound.count >= requiredCorrectCount ? .green : .primary)
                            .animation(.easeInOut, value: correctTilesFound.count)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(.thinMaterial)
                    )
                }
                
                Spacer()
                
                // Circular Timer - etwas kleiner
                circularTimerView
                    .frame(width: 70, height: 70)
            }
            
            // Bottom Row: Scores - kompakter
            HStack(spacing: 8) {
                // Total Score Card - kompakter
                VStack(spacing: 2) {
                    Text(L("TotalScore", language: appLanguage))
                        .font(.caption2.bold())
                        .foregroundStyle(.secondary)
                        .textCase(.uppercase)
                    
                    Text("\(totalScore)")
                        .font(.title3.bold())
                        .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                        .contentTransition(.numericText())
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(.thinMaterial)
                )
                
                // Level Score Card - kompakter
                VStack(spacing: 2) {
                    Text(L("LevelScore", language: appLanguage))
                        .font(.caption2.bold())
                        .foregroundStyle(.secondary)
                        .textCase(.uppercase)
                    
                    Text("\(levelScore)")
                        .font(.title3.bold())
                        .foregroundStyle(levelScore >= 0 ? Color.green : Color.red)
                        .contentTransition(.numericText())
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(.thinMaterial)
                )
                
                // Pro Mode Indicator - kompakt
                if proMode {
                    VStack(spacing: 2) {
                        Image(systemName: "flame.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                        Text("×1.5")
                            .font(.caption2.bold())
                            .foregroundStyle(.white)
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(
                        Capsule()
                            .fill(
                                LinearGradient(
                                    colors: [.purple, .pink],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                    )
                }
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 6)
    }
    
    // Level & Round Progress Card
    private var levelRoundCard: some View {
        VStack(spacing: 8) {
            // Level Badge
            HStack(spacing: 4) {
                Image(systemName: "mountain.2.fill")
                    .font(.caption)
                    .foregroundStyle(.white)
                Text("\(L("Level", language: appLanguage)) \(level)")
                    .font(.headline.bold())
                    .foregroundStyle(.white)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(
                LinearGradient(
                    colors: [.blue, .purple],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .cornerRadius(20)
            
            // Round Progress Dots
            HStack(spacing: 6) {
                ForEach(1...roundsPerLevel, id: \.self) { roundNum in
                    Circle()
                        .fill(roundNum <= round ? Color.blue : Color.gray.opacity(0.3))
                        .frame(width: 8, height: 8)
                        .scaleEffect(roundNum == round && !reduceMotion ? 1.3 : 1.0)
                }
            }
            .animation(reduceMotion ? .none : .spring(response: 0.3, dampingFraction: 0.6), value: round)
            
            Text("\(round)/\(roundsPerLevel) \(L("Round", language: appLanguage))")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(.secondarySystemBackground))
                .shadow(color: .blue.opacity(0.2), radius: 8, x: 0, y: 4)
        )
    }
    
    // Circular Timer View
    private var circularTimerView: some View {
        ZStack {
            // Background circle
            Circle()
                .stroke(Color.gray.opacity(0.2), lineWidth: 8)
            
            // Progress circle
            Circle()
                .trim(from: 0, to: timerProgress)
                .stroke(
                    timerProgress > 0.5 ? Color.green : (timerProgress > 0.25 ? Color.orange : Color.red),
                    style: StrokeStyle(lineWidth: 8, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.linear(duration: 0.1), value: timerProgress)
            
            // Time text
            VStack(spacing: 2) {
                Text(String(format: "%.1f", timeRemaining))
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundStyle(timerProgress > 0.25 ? Color.primary : Color.red)
                    .contentTransition(.numericText())
                    .animation(.none, value: timeRemaining)
                
                Text("sec")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(.secondary)
            }
            .scaleEffect(timerProgress < 0.25 && !reduceMotion ? 1.1 : 1.0)
            .animation(reduceMotion || timerProgress >= 0.25 ? .none : .easeInOut(duration: 0.5).repeatCount(5, autoreverses: true), value: timerProgress < 0.25)
        }
        .padding(8)
        .background(
            Circle()
                .fill(Color(.secondarySystemBackground))
                .shadow(color: timerProgress > 0.25 ? Color.green.opacity(0.2) : Color.red.opacity(0.3), radius: 8, x: 0, y: 4)
        )
    }
    
    // Score Card Component
    private func scoreCard(title: String, score: Int, isMain: Bool) -> some View {
        VStack(spacing: 4) {
            Text(title)
                .font(.caption.bold())
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
            
            Text("\(score)")
                .font(.system(size: isMain ? 32 : 24, weight: .bold, design: .rounded))
                .foregroundStyle(score >= 0 ? Color.green : Color.red)
                .contentTransition(.numericText())
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(
                    LinearGradient(
                        colors: [
                            Color(.secondarySystemBackground),
                            Color(.tertiarySystemBackground)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .shadow(color: (score >= 0 ? Color.green : Color.red).opacity(0.15), radius: 6, x: 0, y: 3)
        )
    }
    
    // MARK: - Grid View
    private var gridView: some View {
        let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: gridSize.columns)
        
        return LazyVGrid(columns: columns, spacing: 12) {
            ForEach(tiles.indices, id: \.self) { index in
                let tile = tiles[index]
                let isFound = correctTilesFound.contains(tile.id)
                
                Button {
                    handleTileTap(tile: tile)
                } label: {
                    ZStack {
                        Rectangle()
                            .fill(tile.backgroundColor)
                            .cornerRadius(12)
                            .shadow(radius: 4)
                            .opacity(isFound ? 0.5 : 1.0)  // Dim found tiles
                        
                        VStack(spacing: 4) {
                            // Show emoji if in emoji mode
                            if let emoji = tile.visualContent {
                                Text(emoji)
                                    .font(.system(size: 40))
                            }
                            
                            // Show text label
                            Text(localizedContentName(tile.displayContent.nameKey, language: appLanguage))
                                .font(.headline.bold())
                                .foregroundStyle(textColorForTile(tile))
                                .multilineTextAlignment(.center)
                                .minimumScaleFactor(0.5)
                                .lineLimit(2)
                        }
                        .padding(8)
                        .opacity(isFound ? 0.3 : 1.0)  // Dim text on found tiles
                        
                        // Checkmark overlay for found correct tiles
                        if isFound {
                            ZStack {
                                Circle()
                                    .fill(Color.green)
                                    .frame(width: 50, height: 50)
                                    .shadow(color: .green.opacity(0.5), radius: 8, x: 0, y: 4)
                                
                                Image(systemName: "checkmark")
                                    .font(.system(size: 30, weight: .bold))
                                    .foregroundStyle(.white)
                            }
                            .transition(.scale.combined(with: .opacity))
                        }
                    }
                    .frame(maxWidth: .infinity, minHeight: 80)
                }
                .buttonStyle(.plain)
                .disabled(isFound)  // Disable interaction with found tiles
            }
        }
    }
    
    // MARK: - Start Prompt View
    private var startPromptView: some View {
        VStack(spacing: 30) {
            // If game is paused (round > 0 but not playing), show pause screen
            if round > 0 && !isPlaying {
                pauseScreenView
            } else {
                // Normal start screen
                startScreenView
                    .onAppear {
                        if !reduceMotion {
                            startButtonScale = 1.2
                            initializeLogo()
                            startExampleAnimation()
                        } else {
                            initializeLogo()
                        }
                    }
                    .onDisappear {
                        stopExampleAnimation()
                    }
            }
        }
        .padding()
    }
    
    private var pauseScreenView: some View {
        VStack(spacing: 30) {
            // Pause Icon
            Image(systemName: "pause.circle.fill")
                .font(.system(size: 80))
                .foregroundStyle(.orange)
            
            // Pause Title
            Text(L("Pause", language: appLanguage))
                .font(.largeTitle.bold())
            
            // Current Stats - Reusing header style from playing mode
            VStack(spacing: 12) {
                // Level & Round Info
                HStack(spacing: 12) {
                    // Level Badge
                    HStack(spacing: 4) {
                        Image(systemName: "mountain.2.fill")
                            .font(.caption)
                            .foregroundStyle(.white)
                        Text("\(L("Level", language: appLanguage)) \(level)")
                            .font(.headline.bold())
                            .foregroundStyle(.white)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .cornerRadius(20)
                    
                    Spacer()
                    
                    // Round Progress
                    HStack(spacing: 6) {
                        ForEach(1...roundsPerLevel, id: \.self) { roundNum in
                            Circle()
                                .fill(roundNum <= round ? Color.blue : Color.gray.opacity(0.3))
                                .frame(width: 8, height: 8)
                        }
                    }
                    
                    Text("\(round)/\(roundsPerLevel)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                
                // Scores Row
                HStack(spacing: 12) {
                    // Total Score Card
                    scoreCard(
                        title: L("TotalScore", language: appLanguage),
                        score: totalScore,
                        isMain: true
                    )
                    .frame(maxWidth: .infinity)
                    
                    // Level Score Card
                    scoreCard(
                        title: L("LevelScore", language: appLanguage),
                        score: levelScore,
                        isMain: false
                    )
                    .frame(maxWidth: .infinity)
                }
            }
            .padding()
            .background(.regularMaterial)
            .cornerRadius(12)
            
            // Buttons
            VStack(spacing: 16) {
                // Resume Button
                Button {
                    startGame()
                } label: {
                    HStack {
                        Image(systemName: "play.fill")
                        Text(L("Resume", language: appLanguage))
                    }
                    .font(.title2.bold())
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 20)
                    .background(Color.accentColor)
                    .cornerRadius(16)
                }
                
                // Quit Button
                Button {
                    quitGame()
                } label: {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                        Text(L("Quit", language: appLanguage))
                    }
                    .font(.title3.bold())
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(Color.red.opacity(0.8))
                    .cornerRadius(16)
                }
            }
        }
    }
    
    private var startScreenView: some View {
        VStack(spacing: 24) {
            // Welcome Header with animated icon
            VStack(spacing: 12) {
                ZStack {
                    // Alternating logo: color blob or emoji
                    if logoAnimationPhase == 0 {
                        // Color blob phase
                        if let logoColor = currentLogoColor {
                            Circle()
                                .fill(logoColor.color)
                                .frame(width: 55, height: 55)
                                .scaleEffect(reduceMotion ? 1.0 : startButtonScale)
                                .shadow(color: logoColor.color.opacity(0.4), radius: 12, x: 0, y: 4)
                        }
                    } else {
                        // Emoji phase
                        if let logoEmoji = currentLogoEmoji {
                            Text(logoEmoji.emoji)
                                .font(.system(size: 50))
                                .scaleEffect(reduceMotion ? 1.0 : startButtonScale)
                                .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
                        }
                    }
                }
                .frame(width: 60, height: 60)
                .animation(reduceMotion ? nil : .easeInOut(duration: 1.5), value: startButtonScale)
                
                Text(L("Title", language: appLanguage))
                    .font(.system(size: 36, weight: .black, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.orange, .red, .pink],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
            }
            .padding(.top, 20)
            
            // Example Grid with Animation (more prominent)
            VStack(spacing: 12) {
                HStack {
                    Image(systemName: "eye.fill")
                        .foregroundStyle(.orange)
                    Text(L("Example", language: appLanguage))
                        .font(.headline.bold())
                    Spacer()
                }
                
                switch gameMode {
                case .colors:
                    animatedColorExampleGrid
                case .numbers:
                    animatedNumberExampleGrid
                case .shapes:
                    animatedShapeExampleGrid
                case .flags:
                    animatedFlagExampleGrid
                case .emojis:
                    animatedEmojiExampleGrid
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(.regularMaterial)
                    .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
            )
            
            // Settings Section in a card
            VStack(spacing: 12) {
                // Game Mode
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Image(systemName: gameModeIcon)
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .animation(.easeInOut, value: gameMode)
                        Text(L("GameMode", language: appLanguage))
                            .font(.caption.bold())
                            .foregroundStyle(.secondary)
                    }
                    
                    // Custom mode picker with lock support
                    HStack(spacing: 0) {
                        ForEach(GameMode.allCases) { mode in
                            let isLocked = !achievementStore.isModeUnlocked(mode: mode, isPro: false, playerName: playerName)
                            Button {
                                if isLocked {
                                    showUnlockAlert(for: mode)
                                } else {
                                    gameModeRaw = mode.rawValue
                                }
                            } label: {
                                HStack(spacing: 4) {
                                    if isLocked {
                                        Image(systemName: "lock.fill")
                                            .font(.caption2)
                                    }
                                    Text(L(mode.nameKey, language: appLanguage))
                                        .font(.subheadline)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(gameModeRaw == mode.rawValue ? Color.accentColor : Color.clear)
                                .foregroundStyle(gameModeRaw == mode.rawValue ? .white : (isLocked ? .secondary : .primary))
                                .opacity(isLocked ? 0.6 : 1.0)
                            }
                        }
                    }
                    .background(Color(.tertiarySystemBackground))
                    .cornerRadius(8)
                }
                
                // Pro Mode & Inverse Mode Toggles - side by side
                HStack(alignment: .top, spacing: 12) {
                    // Pro Mode Toggle
                    VStack(alignment: .leading, spacing: 8) {
                        let isProLocked = !achievementStore.isModeUnlocked(mode: gameMode, isPro: true, playerName: playerName)

                        HStack {
                            Image(systemName: proMode ? "brain.head.profile" : "person.fill")
                                .font(.caption)
                                .foregroundStyle(proMode ? .purple : .blue)
                                .animation(.easeInOut, value: proMode)
                            Text(L("ProMode", language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.secondary)
                            Spacer()

                            if isProLocked {
                                Button {
                                    showUnlockAlert(forProMode: true)
                                } label: {
                                    Image(systemName: "lock.fill")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            } else {
                                Toggle("", isOn: $proMode)
                                    .labelsHidden()
                            }
                        }

                        proModeDescriptionView
                            .opacity(isProLocked ? 0.5 : 1.0)
                    }
                    .frame(maxWidth: .infinity)

                    // Inverse Mode Toggle
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Image(systemName: inverseMode ? "xmark.circle.fill" : "checkmark.circle.fill")
                                .font(.caption)
                                .foregroundStyle(inverseMode ? .red : .green)
                                .animation(.easeInOut, value: inverseMode)
                            Text(L("InverseMode", language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.secondary)
                            Spacer()
                            Toggle("", isOn: $inverseMode)
                                .labelsHidden()
                        }

                        // Description with gradient background
                        HStack(spacing: 6) {
                            Image(systemName: inverseMode ? "xmark.circle" : "checkmark.circle")
                                .font(.system(size: 14))
                                .foregroundStyle(.white.opacity(0.8))
                                .animation(.bouncy, value: inverseMode)

                            Text(L(inverseMode ? "InverseModeDescription" : "NormalModeDescription", language: appLanguage))
                                .font(.caption2)
                                .foregroundStyle(.white)
                                .fontWeight(.semibold)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(
                            LinearGradient(
                                colors: inverseMode ? [.red, .red.opacity(0.7)] : [.green, .green.opacity(0.7)],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                            .animation(.easeInOut, value: inverseMode)
                        )
                        .cornerRadius(10)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(.regularMaterial)
                    .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
            )
            .alert(L("Locked", language: appLanguage), isPresented: $showLockAlert) {
                Button(L("Done", language: appLanguage), role: .cancel) { }
            } message: {
                Text(lockAlertMessage)
            }
            
            // Big Play Button with gradient and animation
            Button {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                    startGame()
                }
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "play.fill")
                        .font(.title2)
                    Text(L("Start", language: appLanguage))
                        .font(.title.bold())
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 20)
                .background(
                    LinearGradient(
                        colors: [.orange, .red],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(20)
                .shadow(color: .orange.opacity(0.5), radius: 10, x: 0, y: 5)
            }
            .buttonStyle(PlayButtonStyle())
            
            // Donate button (subtle, at bottom)
            #if os(iOS)
            if #available(iOS 18.0, *) {
                HStack {
                    Spacer()
                    DonateButton(language: appLanguage, style: .withText, customText: L("SupportFreeApp", language: appLanguage))
                        .opacity(0.65)
                }
                .padding(.top, 8)
            }
            #endif
        }
        .padding()
    }
    
    
    // MARK: - Animated Example Grids
    
    // Pro Mode Description View
    private var proModeDescriptionView: some View {
        let itemCount: Int
        let itemName: String
        
        if gameMode == .colors {
            itemCount = proMode ? GameColor.proColors.count : GameColor.standardColors.count
            itemName = L("Colors", language: appLanguage)
        } else if gameMode == .numbers {
            itemCount = proMode ? GameNumber.proNumbers.count : GameNumber.standardNumbers.count
            itemName = L("Numbers", language: appLanguage)
        } else if gameMode == .shapes {
            itemCount = proMode ? GameShape.proShapes.count : GameShape.standardShapes.count
            itemName = L("Shapes", language: appLanguage)
        } else if gameMode == .flags {
            itemCount = proMode ? GameFlag.proFlags.count : GameFlag.standardFlags.count
            itemName = L("ModeFlags", language: appLanguage)
        } else {
            itemCount = proMode ? GameEmoji.proEmojis.count : GameEmoji.standardEmojis.count
            itemName = L("Emojis", language: appLanguage)
        }
        
        return HStack(spacing: 6) {
            Image(systemName: proMode ? "flame.fill" : "star.fill")
                .font(.system(size: 14))
                .foregroundStyle(proMode ? .orange : .yellow)
                .animation(.bouncy, value: proMode)
            
            Text("\(itemCount) \(itemName)")
                .font(.caption2)
                .foregroundStyle(.white)
                .fontWeight(.semibold)
                .animation(.none, value: proMode)
            
            Spacer()
            
            // Points multiplier badge (only show if Pro Mode is active)
            if proMode {
                HStack(spacing: 4) {
                    Text(L("PointsMultiplier", language: appLanguage))
                        .font(.system(size: 9))
                        .foregroundStyle(.white.opacity(0.7))
                    
                    Text("×1.5")
                        .font(.caption2.bold())
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(
                            Capsule()
                                .fill(.white.opacity(0.3))
                        )
                }
                .transition(.scale.combined(with: .opacity))
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(
            LinearGradient(
                colors: proMode ? [.purple, .pink] : [.blue, .cyan],
                startPoint: .leading,
                endPoint: .trailing
            )
            .animation(.easeInOut, value: proMode)
        )
        .cornerRadius(10)
    }
    
    // MARK: - Animated Example Grids
    @ViewBuilder
    private var animatedColorExampleGrid: some View {
        // Safety check: ensure we have at least 4 colors available
        if availableColors.count >= 4 {
            let exampleColors: [(GameColor, String)] = [
                (availableColors[0], availableColors[1].nameKey),
                (availableColors[1], availableColors[1].nameKey),  // Correct ✓
                (availableColors[2], availableColors[3].nameKey),
                (availableColors[3], availableColors[0].nameKey)
            ]
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(0..<4, id: \.self) { index in
                    let (bgColor, textKey) = exampleColors[index]
                    let isCorrect = (index == 1)
                    
                    ZStack {
                        Rectangle()
                            .fill(bgColor.color)
                            .frame(height: 80)
                            .cornerRadius(12)
                            .shadow(color: isCorrect ? .green.opacity(0.5) : .clear, radius: 8, x: 0, y: 4)
                            .scaleEffect(isCorrect && exampleTileAnimationPhase == 1 && !reduceMotion ? 1.05 : 1.0)
                            .animation(reduceMotion ? nil : .easeInOut(duration: 0.4), value: exampleTileAnimationPhase)
                        
                        Text(localizedContentName(textKey, language: appLanguage))
                            .font(.headline.bold())
                            .foregroundStyle(.black.opacity(0.8))
                        
                        if isCorrect {
                            // Animated checkmark
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.white)
                                .font(.title)
                                .background(
                                    Circle()
                                        .fill(.green)
                                        .frame(width: 32, height: 32)
                                )
                                .offset(x: 30, y: -28)
                                .scaleEffect(exampleTileAnimationPhase == 1 && !reduceMotion ? 1.1 : 1.0)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 0.4), value: exampleTileAnimationPhase)
                        }
                    }
                }
            }
        } else {
            Text("Not enough colors")
        }
    }
    
    @ViewBuilder
    private var animatedNumberExampleGrid: some View {
        // Safety check: ensure we have at least 4 numbers available
        if availableNumbers.count >= 4 {
            let exampleNumbers: [(GameNumber, String)] = [
                (availableNumbers[0], availableNumbers[1].nameKey),
                (availableNumbers[1], availableNumbers[1].nameKey),  // Correct ✓
                (availableNumbers[2], availableNumbers[3].nameKey),
                (availableNumbers[3], availableNumbers[0].nameKey)
            ]
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(0..<4, id: \.self) { index in
                    let (number, textKey) = exampleNumbers[index]
                    let isCorrect = (index == 1)
                    
                    ZStack {
                        Rectangle()
                            .fill(Color(.tertiarySystemBackground))
                            .frame(height: 80)
                            .cornerRadius(12)
                            .shadow(color: isCorrect ? .green.opacity(0.5) : .clear, radius: 8, x: 0, y: 4)
                            .scaleEffect(isCorrect && exampleTileAnimationPhase == 1 && !reduceMotion ? 1.05 : 1.0)
                            .animation(reduceMotion ? nil : .easeInOut(duration: 0.4), value: exampleTileAnimationPhase)
                        
                        VStack(spacing: 4) {
                            Text(String(number.value))
                                .font(.system(size: 40))
                                .foregroundStyle(.primary)
                            Text(localizedContentName(textKey, language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.primary)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }
                        
                        if isCorrect {
                            // Animated checkmark
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.white)
                                .font(.title)
                                .background(
                                    Circle()
                                        .fill(.green)
                                        .frame(width: 32, height: 32)
                                )
                                .offset(x: 30, y: -28)
                                .scaleEffect(exampleTileAnimationPhase == 1 && !reduceMotion ? 1.1 : 1.0)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 0.4), value: exampleTileAnimationPhase)
                        }
                    }
                }
            }
        } else {
            Text("Not enough numbers")
        }
    }
    
    @ViewBuilder
    private var animatedEmojiExampleGrid: some View {
        // Safety check: ensure we have at least 4 emojis available
        if availableEmojis.count >= 4 {
            let exampleEmojis: [(GameEmoji, String)] = [
                (availableEmojis[0], availableEmojis[1].nameKey),
                (availableEmojis[1], availableEmojis[1].nameKey),  // Correct ✓
                (availableEmojis[2], availableEmojis[3].nameKey),
                (availableEmojis[3], availableEmojis[0].nameKey)
            ]
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(0..<4, id: \.self) { index in
                    let (emoji, textKey) = exampleEmojis[index]
                    let isCorrect = (index == 1)
                    
                    ZStack {
                        Rectangle()
                            .fill(Color(.tertiarySystemBackground))
                            .frame(height: 80)
                            .cornerRadius(12)
                            .shadow(color: isCorrect ? .green.opacity(0.5) : .clear, radius: 8, x: 0, y: 4)
                            .scaleEffect(isCorrect && exampleTileAnimationPhase == 1 && !reduceMotion ? 1.05 : 1.0)
                            .animation(reduceMotion ? nil : .easeInOut(duration: 0.4), value: exampleTileAnimationPhase)
                        
                        VStack(spacing: 4) {
                            Text(emoji.emoji)
                                .font(.system(size: 32))
                            Text(localizedContentName(textKey, language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.primary)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }
                        
                        if isCorrect {
                            // Animated checkmark
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.white)
                                .font(.title)
                                .background(
                                    Circle()
                                        .fill(.green)
                                        .frame(width: 32, height: 32)
                                )
                                .offset(x: 30, y: -28)
                                .scaleEffect(exampleTileAnimationPhase == 1 && !reduceMotion ? 1.1 : 1.0)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 0.4), value: exampleTileAnimationPhase)
                        }
                    }
                }
            }
        } else {
            Text("Not enough emojis")
        }
    }
    
    @ViewBuilder
    private var animatedShapeExampleGrid: some View {
        // Safety check: ensure we have at least 4 shapes available
        if availableShapes.count >= 4 {
            let exampleShapes: [(GameShape, String)] = [
                (availableShapes[0], availableShapes[1].nameKey),
                (availableShapes[1], availableShapes[1].nameKey),  // Correct ✓
                (availableShapes[2], availableShapes[3].nameKey),
                (availableShapes[3], availableShapes[0].nameKey)
            ]
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(0..<4, id: \.self) { index in
                    let (shape, textKey) = exampleShapes[index]
                    let isCorrect = (index == 1)
                    
                    ZStack {
                        Rectangle()
                            .fill(Color(.tertiarySystemBackground))
                            .frame(height: 80)
                            .cornerRadius(12)
                            .shadow(color: isCorrect ? .green.opacity(0.5) : .clear, radius: 8, x: 0, y: 4)
                            .scaleEffect(isCorrect && exampleTileAnimationPhase == 1 && !reduceMotion ? 1.05 : 1.0)
                            .animation(reduceMotion ? nil : .easeInOut(duration: 0.4), value: exampleTileAnimationPhase)
                        
                        VStack(spacing: 4) {
                            Text(shape.shape)
                                .font(.system(size: 40))
                            Text(localizedContentName(textKey, language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.primary)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }
                        
                        if isCorrect {
                            // Animated checkmark
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.white)
                                .font(.title)
                                .background(
                                    Circle()
                                        .fill(.green)
                                        .frame(width: 32, height: 32)
                                )
                                .offset(x: 30, y: -28)
                                .scaleEffect(exampleTileAnimationPhase == 1 && !reduceMotion ? 1.1 : 1.0)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 0.4), value: exampleTileAnimationPhase)
                        }
                    }
                }
            }
        } else {
            Text("Not enough shapes")
        }
    }
    
    @ViewBuilder
    private var animatedFlagExampleGrid: some View {
        // Safety check: ensure we have at least 4 flags available
        if availableFlags.count >= 4 {
            let exampleFlags: [(GameFlag, String)] = [
                (availableFlags[0], availableFlags[1].nameKey),
                (availableFlags[1], availableFlags[1].nameKey),  // Correct ✓
                (availableFlags[2], availableFlags[3].nameKey),
                (availableFlags[3], availableFlags[0].nameKey)
            ]
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(0..<4, id: \.self) { index in
                    let (flag, textKey) = exampleFlags[index]
                    let isCorrect = (index == 1)
                    
                    ZStack {
                        Rectangle()
                            .fill(Color(.tertiarySystemBackground))
                            .frame(height: 80)
                            .cornerRadius(12)
                            .shadow(color: isCorrect ? .green.opacity(0.5) : .clear, radius: 8, x: 0, y: 4)
                            .scaleEffect(isCorrect && exampleTileAnimationPhase == 1 && !reduceMotion ? 1.05 : 1.0)
                            .animation(reduceMotion ? nil : .easeInOut(duration: 0.4), value: exampleTileAnimationPhase)
                        
                        VStack(spacing: 4) {
                            Text(flag.emoji)
                                .font(.system(size: 40))
                            Text(localizedContentName(textKey, language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.primary)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }
                        
                        if isCorrect {
                            // Animated checkmark
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.white)
                                .font(.title)
                                .background(
                                    Circle()
                                        .fill(.green)
                                        .frame(width: 32, height: 32)
                                )
                                .offset(x: 30, y: -28)
                                .scaleEffect(exampleTileAnimationPhase == 1 && !reduceMotion ? 1.1 : 1.0)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 0.4), value: exampleTileAnimationPhase)
                        }
                    }
                }
            }
        } else {
            Text("Not enough flags")
        }
    }
    
    // MARK: - Example Grids
    private var colorExampleGrid: some View {
        let exampleColors: [(GameColor, String)] = [
            (availableColors[0], availableColors[1].nameKey),
            (availableColors[1], availableColors[1].nameKey),  // Correct ✓
            (availableColors[2], availableColors[3].nameKey),
            (availableColors[3], availableColors[0].nameKey)
        ]
        
        return LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
            ForEach(0..<4, id: \.self) { index in
                let (bgColor, textKey) = exampleColors[index]
                ZStack {
                    Rectangle()
                        .fill(bgColor.color)
                        .frame(height: 60)
                        .cornerRadius(8)
                    
                    Text(localizedContentName(textKey, language: appLanguage))
                        .font(.caption.bold())
                        .foregroundStyle(.black.opacity(0.8))
                    
                    if index == 1 {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                            .font(.title2)
                            .offset(x: 25, y: -20)
                    }
                }
            }
        }
        .frame(maxWidth: 200)
    }
    
    private var emojiExampleGrid: some View {
        let exampleEmojis: [(GameEmoji, String)] = [
            (availableEmojis[0], availableEmojis[1].nameKey),
            (availableEmojis[1], availableEmojis[1].nameKey),  // Correct ✓
            (availableEmojis[2], availableEmojis[3].nameKey),
            (availableEmojis[3], availableEmojis[0].nameKey)
        ]
        
        return LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
            ForEach(0..<4, id: \.self) { index in
                let (emoji, textKey) = exampleEmojis[index]
                ZStack {
                    Rectangle()
                        .fill(Color(.secondarySystemBackground))
                        .frame(height: 60)
                        .cornerRadius(8)
                    
                    VStack(spacing: 2) {
                        Text(emoji.emoji)
                            .font(.system(size: 24))
                        Text(localizedContentName(textKey, language: appLanguage))
                            .font(.caption2.bold())
                            .foregroundStyle(.primary)
                            .minimumScaleFactor(0.5)
                            .lineLimit(1)
                    }
                    
                    if index == 1 {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                            .font(.title2)
                            .offset(x: 25, y: -20)
                    }
                }
            }
        }
        .frame(maxWidth: 200)
    }
    
    // MARK: - Level Complete Overlay
    private var levelCompleteOverlay: some View {
        ZStack {
            Color.black.opacity(0.7)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                // Scrollable content area
                ScrollView {
                    VStack(spacing: 20) {
                        // Celebration header
                        VStack(spacing: 6) {
                            Image(systemName: "star.fill")
                                .font(.system(size: 50))
                                .foregroundStyle(.yellow)
                                .shadow(color: .yellow.opacity(0.5), radius: 15)

                            Text(L("LevelComplete", language: appLanguage))
                                .font(.system(size: 28, weight: .bold))
                                .foregroundStyle(.white)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }

                        // Next Level Preview - shown first so it's always visible
                        nextLevelPreviewCard

                        // Level Reached and Total Score - matching summary layout
                        HStack(alignment: .top, spacing: 20) {
                            VStack(spacing: 4) {
                                Text(L("ReachedLevel", language: appLanguage))
                                    .font(.caption)
                                    .foregroundStyle(.white.opacity(0.7))
                                Text("\(level - 1)")
                                    .font(.system(size: 48, weight: .bold, design: .rounded))
                                    .foregroundStyle(.tint)
                            }
                            .frame(maxWidth: .infinity)

                            VStack(spacing: 4) {
                                Text(L("TotalScore", language: appLanguage))
                                    .font(.caption)
                                    .foregroundStyle(.white.opacity(0.7))
                                Text("\(totalScore)")
                                    .font(.system(size: 48, weight: .bold, design: .rounded))
                                    .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                            }
                            .frame(maxWidth: .infinity)
                        }
                        .padding()
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(12)

                        // New Achievements Section - only achievements from this level
                        if !newAchievementsThisLevel.isEmpty {
                            VStack(alignment: .leading, spacing: 12) {
                                Text(L("AchievementsEarned", language: appLanguage))
                                    .font(.headline)
                                    .foregroundStyle(.white)

                                ForEach(Achievement.all.filter { newAchievementsThisLevel.contains($0.id) }, id: \.id) { achievement in
                                    HStack(spacing: 12) {
                                        Text(achievement.iconEmoji)
                                            .font(.system(size: 40))
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(L(achievement.nameKey, language: appLanguage))
                                                .font(.subheadline.bold())
                                                .foregroundStyle(.white)
                                            Text(L(achievement.explanationKey, language: appLanguage))
                                                .font(.caption)
                                                .foregroundStyle(.white.opacity(0.8))
                                        }
                                        Spacer()
                                    }
                                    .padding()
                                    .background(Color.white.opacity(0.1))
                                    .cornerRadius(12)
                                }
                            }
                            .padding()
                            .background(Color.white.opacity(0.1))
                            .cornerRadius(12)
                        }

                        // Level Scores Breakdown - matching summary layout
                        if !levelScores.isEmpty {
                            VStack(alignment: .leading, spacing: 12) {
                                Text(L("ScorePerLevel", language: appLanguage))
                                    .font(.headline)
                                    .foregroundStyle(.white)

                                ForEach(levelScores.keys.sorted(), id: \.self) { levelNum in
                                    if let score = levelScores[levelNum] {
                                        HStack {
                                            Text("Level \(levelNum):")
                                                .font(.subheadline)
                                                .foregroundStyle(.white)
                                            Spacer()
                                            Text("\(score > 0 ? "+" : "")\(score)")
                                                .font(.subheadline.bold())
                                                .foregroundStyle(score > 0 ? Color.green : Color.red)
                                        }
                                        .padding(.horizontal)
                                    }
                                }
                            }
                            .padding()
                            .background(Color.white.opacity(0.1))
                            .cornerRadius(12)
                        }

                        // Top Highscores Preview - matching summary layout
                        VStack(alignment: .leading, spacing: 12) {
                            Text(L("TopScores", language: appLanguage))
                                .font(.headline)
                                .foregroundStyle(.white)

                            if highscoreStore.entries.isEmpty {
                                Text(L("NoHighscores", language: appLanguage))
                                    .foregroundStyle(.white.opacity(0.6))
                                    .italic()
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .padding()
                            } else {
                                ForEach(highscoreStore.entries.prefix(3)) { entry in
                                    HStack {
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(entry.playerName)
                                                .font(.subheadline.bold())
                                                .foregroundStyle(.white)
                                            HStack(spacing: 6) {
                                                Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                                                    .font(.caption2)
                                                    .foregroundStyle(.white.opacity(0.6))
                                                Text("•")
                                                    .font(.caption2)
                                                    .foregroundStyle(.white.opacity(0.6))
                                                Text("Level \(entry.maxLevel)")
                                                    .font(.caption)
                                                    .foregroundStyle(.white.opacity(0.6))
                                                Text("•")
                                                    .font(.caption2)
                                                    .foregroundStyle(.white.opacity(0.6))
                                                HStack(spacing: 2) {
                                                    Image(systemName: gameModeIcon(for: entry.gameMode))
                                                        .font(.caption2)
                                                    Text(L(gameModeNameKey(for: entry.gameMode), language: appLanguage))
                                                        .font(.caption2)
                                                    if entry.isPro {
                                                        Text("Pro")
                                                            .font(.caption2.bold())
                                                            .foregroundStyle(.orange)
                                                    }
                                                }
                                                .foregroundStyle(.white.opacity(0.6))
                                            }
                                        }

                                        Spacer()

                                        Text("\(entry.score)")
                                            .font(.title3.bold())
                                            .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
                                    }
                                    .padding(.horizontal)
                                }
                            }
                        }
                        .padding()
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(12)

                        // Extra bottom padding to ensure content doesn't get hidden behind buttons
                        Color.clear.frame(height: 20)
                    }
                    .padding(20)
                }

                // Fixed action buttons at bottom (outside ScrollView)
                VStack(spacing: 0) {
                    Divider()
                        .background(Color.white.opacity(0.3))

                    HStack(spacing: 16) {
                        // Quit Button
                        Button {
                            withAnimation {
                                showLevelComplete = false
                                // Don't call endGameEarly() which would save levelScore again
                                // Just finalize and show summary
                                isPlaying = false
                                invalidateTimer()

                                // Calculate final score from positive levels only
                                let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
                                highscoreStore.add(score: finalScore, playerName: effectivePlayerName, maxLevel: level - 1, achievementIDs: newAchievementsThisRun, gameMode: gameMode.rawValue, isPro: proMode)
                                totalScore = finalScore

                                // Submit score to Game Center
                                Task {
                                    await gameCenterManager.submitScore(finalScore, gameMode: gameMode.rawValue, isPro: proMode)
                                }

                                feedbackManager.trigger(.gameOver)
                                showSummary = true
                            }
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "xmark.circle.fill")
                                Text(L("Quit", language: appLanguage))
                            }
                            .font(.title3.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(Color.red.opacity(0.8))
                            .cornerRadius(16)
                        }

                        // Continue Button
                        Button {
                            withAnimation {
                                showLevelComplete = false
                                startNextLevel()
                            }
                        } label: {
                            HStack(spacing: 12) {
                                Text(L("Continue", language: appLanguage))
                                Image(systemName: "arrow.right")
                            }
                            .font(.title3.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(Color.accentColor)
                            .cornerRadius(16)
                        }
                    }
                    .padding()
                    .background(Color.black.opacity(0.3))
                }
            }
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(.ultraThinMaterial)
            )
            .padding(20)
        }
        .transition(.scale.combined(with: .opacity))
    }
    
    // MARK: - Next Level Preview Card
    private var nextLevelPreviewCard: some View {
        VStack(spacing: 12) {
            HStack {
                Image(systemName: "arrow.right.circle.fill")
                    .foregroundStyle(.orange)
                Text(L("NextLevelPreview", language: appLanguage))
                    .font(.headline.bold())
                    .foregroundStyle(.white)
                Spacer()
            }
            
            VStack(alignment: .leading, spacing: 8) {
                // Show what changes in next level
                let nextLevel = level
                let currentGridSize = gridSizeForLevel(level - 1)
                let nextGridSize = gridSizeForLevel(nextLevel)
                let currentCorrectCount = requiredCorrectAnswers(level: level - 1)
                let nextCorrectCount = requiredCorrectAnswers(level: nextLevel)
                let currentTime = baseTimeForLevel(level - 1)
                let nextTime = baseTimeForLevel(nextLevel)
                
                // Grid size change?
                if currentGridSize != nextGridSize {
                    HStack(spacing: 8) {
                        Image(systemName: "grid")
                            .foregroundStyle(.blue)
                        Text(nextGridSizeDescription(nextGridSize))
                            .font(.subheadline)
                            .foregroundStyle(.white)
                    }
                }
                
                // Multiple answers change?
                if currentCorrectCount != nextCorrectCount {
                    HStack(spacing: 8) {
                        Image(systemName: "target")
                            .foregroundStyle(.orange)
                        Text(nextCorrectAnswersDescription(nextCorrectCount))
                            .font(.subheadline)
                            .foregroundStyle(.white)
                    }
                }
                
                // Time reduction?
                if nextTime < currentTime {
                    HStack(spacing: 8) {
                        Image(systemName: "timer")
                            .foregroundStyle(.red)
                        Text(L("NextLevelInfo_TimeReduction", language: appLanguage))
                            .font(.subheadline)
                            .foregroundStyle(.white)
                        Text("(\(String(format: "%.1f", nextTime))s)")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.7))
                    }
                }
                
                // If nothing changes, show encouraging message
                if currentGridSize == nextGridSize && currentCorrectCount == nextCorrectCount && nextTime >= currentTime {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                        Text(L("NextLevelInfo_KeepGoing", language: appLanguage))
                            .font(.subheadline)
                            .foregroundStyle(.white)
                    }
                }
            }
        }
        .padding()
        .background(Color.white.opacity(0.15))
        .cornerRadius(16)
        .padding(.horizontal, 20)
    }
    
    private func gameModeIcon(for mode: String) -> String {
        switch mode {
        case "colors": return "paintpalette.fill"
        case "numbers": return "number.square.fill"
        case "shapes": return "star.square.fill"
        case "flags": return "flag.fill"
        case "emojis": return "face.smiling.fill"
        default: return "questionmark.circle"
        }
    }

    private func gameModeNameKey(for mode: String) -> String {
        switch mode {
        case "colors": return "ModeColors"
        case "numbers": return "ModeNumbers"
        case "shapes": return "ModeShapes"
        case "flags": return "ModeFlags"
        case "emojis": return "ModeEmojis"
        default: return "ModeColors"
        }
    }

    private func nextGridSizeDescription(_ gridSize: GridSize) -> String {
        switch gridSize {
        case .grid2x2:
            return L("NextLevelInfo_GridSize_2x2", language: appLanguage)
        case .grid2x4:
            return L("NextLevelInfo_GridSize_2x4", language: appLanguage)
        case .grid3x5:
            return L("NextLevelInfo_GridSize_3x5", language: appLanguage)
        }
    }
    
    private func nextCorrectAnswersDescription(_ count: Int) -> String {
        switch count {
        case 2:
            return L("NextLevelInfo_DoubleAnswers", language: appLanguage)
        case 3:
            return L("NextLevelInfo_TripleAnswers", language: appLanguage)
        case 4:
            return L("NextLevelInfo_QuadAnswers", language: appLanguage)
        default:
            let template = L("NextLevelInfo_MultipleCorrectAnswers", language: appLanguage)
            return String(format: template, count)
        }
    }
    
    // MARK: - Score Delta Overlay
    private func scoreDeltaOverlay(delta: Int) -> some View {
        VStack(spacing: 8) {
            // Animated Icon
            Image(systemName: delta > 0 ? "checkmark.circle.fill" : "xmark.circle.fill")
                .font(.system(size: 50))
                .foregroundStyle(delta > 0 ? Color.green : Color.red)
                .shadow(color: (delta > 0 ? Color.green : Color.red).opacity(0.5), radius: 20)
            
            // Score Delta
            Text(delta > 0 ? "+\(delta)" : "\(delta)")
                .font(.system(size: 60, weight: .bold, design: .rounded))
                .foregroundStyle(delta > 0 ? Color.green : Color.red)
                .shadow(color: (delta > 0 ? Color.green : Color.red).opacity(0.3), radius: 8)
        }
        .scaleEffect(reduceMotion ? 1.2 : 1.5)
        .transition(reduceMotion ? .opacity : .scale.combined(with: .opacity))
        .animation(reduceMotion ? .easeInOut(duration: 0.2) : .spring(response: 0.4, dampingFraction: 0.6), value: scoreDelta)
    }
    
    // MARK: - Game Logic
    private func startGame() {
        isPlaying = true
        if round > 0 {
            // Resume from pause: provide start/resume feedback
            Logger.game.info("Game resumed from pause: level=\(level), round=\(round), totalScore=\(totalScore), levelScore=\(levelScore)")
            feedbackManager.trigger(.gameStart)
        }
        if round == 0 {
            // Use startLevel in dev mode, otherwise always start at level 1
            level = isDevMode ? startLevel : 1
            totalScore = 0
            levelScore = 0
            levelScores = [:]
            consecutiveTimeouts = 0
            consecutiveWrongTaps = 0
            mistakesThisLevel = 0
            
            Logger.game.info("Game started: mode=\(gameMode.rawValue), isPro=\(proMode), startLevel=\(level), playerName=\(effectivePlayerName, privacy: .private), isDevMode=\(isDevMode)")
            
            // Randomize shapes/flags/emoji selection at start of new game
            if gameMode == .shapes {
                let sourceShapes = proMode ? GameShape.proShapes : GameShape.standardShapes
                sessionShapes = sourceShapes.shuffled()
                sessionFlags = []
                sessionEmojis = []
            } else if gameMode == .flags {
                let sourceFlags = proMode ? GameFlag.proFlags : GameFlag.standardFlags
                sessionFlags = sourceFlags.shuffled()
                sessionShapes = []
                sessionEmojis = []
            } else if gameMode == .emojis {
                let sourceEmojis = proMode ? GameEmoji.proEmojis : GameEmoji.standardEmojis
                sessionEmojis = sourceEmojis.shuffled()
                sessionShapes = []
                sessionFlags = []
            } else {
                sessionShapes = []
                sessionFlags = []
                sessionEmojis = []
            }
            
            feedbackManager.trigger(.gameStart)
            nextRound()
        }
        startTimer()
    }
    
    private func pauseGame() {
        isPlaying = false
        invalidateTimer()
        
        Logger.game.info("Game paused: level=\(level), round=\(round), totalScore=\(totalScore), levelScore=\(levelScore), timeRemaining=\(String(format: "%.1f", timeRemaining))")
        
        // Generate new tiles to prevent cheating
        round -= 1
        nextRound()
    }
    
    private func resetGame() {
        Logger.game.info("Game reset: previousLevel=\(level), previousTotalScore=\(totalScore)")
        
        level = 1
        round = 0
        totalScore = 0
        levelScore = 0
        levelScores = [:]
        tiles = []
        sessionShapes = []
        sessionFlags = []
        sessionEmojis = []
        consecutiveTimeouts = 0
        consecutiveWrongTaps = 0
        consecutiveInverseCorrect = 0  // Reset inverse mode streak
        newAchievementsThisRun = []
        newAchievementsThisLevel = []
        mistakesThisLevel = 0
        gameOverFeedback = nil  // Clear game over feedback
        invalidateTimer()
        stopExampleAnimation()
    }
    
    private func startNextLevel() {
        round = 0
        levelScore = 0
        consecutiveTimeouts = 0
        consecutiveWrongTaps = 0
        mistakesThisLevel = 0
        isPlaying = true
        feedbackManager.trigger(.gameStart)
        nextRound()
        startTimer()
    }
    
    private func nextRound() {
        round += 1
        
        // Check if level is complete
        if round > roundsPerLevel {
            endLevel()
            return
        }
        
        Logger.game.debug("Round started: level=\(level), round=\(round), gridSize=\(gridSize.columns)x\(gridSize.rows), requiredCorrect=\(requiredCorrectAnswers(level: level)), timeDuration=\(String(format: "%.1f", currentRoundDuration))")
        
        // Determine how many correct answers are required for this level
        requiredCorrectCount = requiredCorrectAnswers(level: level)
        correctTilesFound = []  // Reset found tiles for new round
        
        // Generate new tiles based on game mode
        let tileCount = gridSize.tileCount
        
        switch gameMode {
        case .colors:
            generateColorTiles(count: tileCount)
        case .numbers:
            generateNumberTiles(count: tileCount)
        case .shapes:
            generateShapeTiles(count: tileCount)
        case .flags:
            generateFlagTiles(count: tileCount)
        case .emojis:
            generateEmojiTiles(count: tileCount)
        }
    }
    
    private func generateColorTiles(count: Int) {
        // Select colors for tiles
        var selectedColors: [GameColor] = []
        if count <= availableColors.count {
            let shuffled = availableColors.shuffled()
            selectedColors = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedColors.append(availableColors.randomElement()!)
            }
        }
        
        // Determine number of correct/incorrect tiles based on mode
        let targetCount: Int
        
        // Both modes scale equally: requiredCorrectCount targets to find
        targetCount = min(requiredCorrectCount, count)
        
        // Pick random indices for target tiles
        var targetIndices = Set<Int>()
        while targetIndices.count < targetCount {
            targetIndices.insert(Int.random(in: 0..<count))
        }
        
        // Create labels based on mode
        var labelArray = [GameColor](repeating: selectedColors[0], count: count)
        
        for i in 0..<count {
            if inverseMode {
                // Inverse mode logic
                if targetIndices.contains(i) {
                    // Make this tile incorrect (the odd one out)
                    let tileColorKey = selectedColors[i].nameKey
                    let candidates = availableColors.filter { $0.nameKey != tileColorKey }
                    if let choice = candidates.randomElement() {
                        labelArray[i] = choice
                    } else {
                        labelArray[i] = availableColors.randomElement()!
                    }
                } else {
                    // Make this tile correct
                    labelArray[i] = selectedColors[i]
                }
            } else {
                // Normal mode logic
                if targetIndices.contains(i) {
                    // Make this tile correct
                    labelArray[i] = selectedColors[i]
                } else {
                    // Make this tile incorrect
                    let tileColorKey = selectedColors[i].nameKey
                    let candidates = availableColors.filter { $0.nameKey != tileColorKey }
                    if let choice = candidates.randomElement() {
                        labelArray[i] = choice
                    } else {
                        labelArray[i] = availableColors.randomElement()!
                    }
                }
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .color(labelArray[i]),
                backgroundContent: .color(selectedColors[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateNumberTiles(count: Int) {
        // Select numbers for tiles
        var selectedNumbers: [GameNumber] = []
        if count <= availableNumbers.count {
            let shuffled = availableNumbers.shuffled()
            selectedNumbers = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedNumbers.append(availableNumbers.randomElement()!)
            }
        }
        
        // Determine number of correct/incorrect tiles based on mode
        let targetCount: Int
        
        // Both modes scale equally: requiredCorrectCount targets to find
        targetCount = min(requiredCorrectCount, count)
        
        // Pick random indices for target tiles
        var targetIndices = Set<Int>()
        while targetIndices.count < targetCount {
            targetIndices.insert(Int.random(in: 0..<count))
        }
        
        // Create labels based on mode
        var labelArray = [GameNumber](repeating: selectedNumbers[0], count: count)
        
        for i in 0..<count {
            if inverseMode {
                // Inverse mode logic
                if targetIndices.contains(i) {
                    // Make this tile incorrect (the odd one out)
                    let tileNumberKey = selectedNumbers[i].nameKey
                    let candidates = availableNumbers.filter { $0.nameKey != tileNumberKey }
                    if let choice = candidates.randomElement() {
                        labelArray[i] = choice
                    } else {
                        labelArray[i] = availableNumbers.randomElement()!
                    }
                } else {
                    // Make this tile correct
                    labelArray[i] = selectedNumbers[i]
                }
            } else {
                // Normal mode logic
                if targetIndices.contains(i) {
                    // Make this tile correct
                    labelArray[i] = selectedNumbers[i]
                } else {
                    // Make this tile incorrect
                    let tileNumberKey = selectedNumbers[i].nameKey
                    let candidates = availableNumbers.filter { $0.nameKey != tileNumberKey }
                    if let choice = candidates.randomElement() {
                        labelArray[i] = choice
                    } else {
                        labelArray[i] = availableNumbers.randomElement()!
                    }
                }
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .number(labelArray[i]),
                backgroundContent: .number(selectedNumbers[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateShapeTiles(count: Int) {
        // Select shapes for tiles
        var selectedShapes: [GameShape] = []
        if count <= availableShapes.count {
            let shuffled = availableShapes.shuffled()
            selectedShapes = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedShapes.append(availableShapes.randomElement()!)
            }
        }
        
        // Determine number of correct/incorrect tiles based on mode
        let targetCount: Int
        
        // Both modes scale equally: requiredCorrectCount targets to find
        targetCount = min(requiredCorrectCount, count)
        
        // Pick random indices for target tiles
        var targetIndices = Set<Int>()
        while targetIndices.count < targetCount {
            targetIndices.insert(Int.random(in: 0..<count))
        }
        
        // Create labels based on mode
        var labelArray = [GameShape](repeating: selectedShapes[0], count: count)
        
        for i in 0..<count {
            if inverseMode {
                // Inverse mode logic
                if targetIndices.contains(i) {
                    // Make this tile incorrect (the odd one out)
                    let tileShapeKey = selectedShapes[i].nameKey
                    let candidates = availableShapes.filter { $0.nameKey != tileShapeKey }
                    if let choice = candidates.randomElement() {
                        labelArray[i] = choice
                    } else {
                        labelArray[i] = availableShapes.randomElement()!
                    }
                } else {
                    // Make this tile correct
                    labelArray[i] = selectedShapes[i]
                }
            } else {
                // Normal mode logic
                if targetIndices.contains(i) {
                    // Make this tile correct
                    labelArray[i] = selectedShapes[i]
                } else {
                    // Make this tile incorrect
                    let tileShapeKey = selectedShapes[i].nameKey
                    let candidates = availableShapes.filter { $0.nameKey != tileShapeKey }
                    if let choice = candidates.randomElement() {
                        labelArray[i] = choice
                    } else {
                        labelArray[i] = availableShapes.randomElement()!
                    }
                }
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .shape(labelArray[i]),
                backgroundContent: .shape(selectedShapes[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateFlagTiles(count: Int) {
        // Select flags for tiles
        var selectedFlags: [GameFlag] = []
        if count <= availableFlags.count {
            let shuffled = availableFlags.shuffled()
            selectedFlags = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedFlags.append(availableFlags.randomElement()!)
            }
        }
        
        // Determine number of correct/incorrect tiles based on mode
        let targetCount: Int
        
        // Both modes scale equally: requiredCorrectCount targets to find
        targetCount = min(requiredCorrectCount, count)
        
        // Pick random indices for target tiles
        var targetIndices = Set<Int>()
        while targetIndices.count < targetCount {
            targetIndices.insert(Int.random(in: 0..<count))
        }
        
        // Create labels based on mode
        var labelArray = [GameFlag](repeating: selectedFlags[0], count: count)
        
        for i in 0..<count {
            if inverseMode {
                // Inverse mode logic
                if targetIndices.contains(i) {
                    // Make this tile incorrect (the odd one out)
                    let tileFlagKey = selectedFlags[i].nameKey
                    let candidates = availableFlags.filter { $0.nameKey != tileFlagKey }
                    if let choice = candidates.randomElement() {
                        labelArray[i] = choice
                    } else {
                        labelArray[i] = availableFlags.randomElement()!
                    }
                } else {
                    // Make this tile correct
                    labelArray[i] = selectedFlags[i]
                }
            } else {
                // Normal mode logic
                if targetIndices.contains(i) {
                    // Make this tile correct
                    labelArray[i] = selectedFlags[i]
                } else {
                    // Make this tile incorrect
                    let tileFlagKey = selectedFlags[i].nameKey
                    let candidates = availableFlags.filter { $0.nameKey != tileFlagKey }
                    if let choice = candidates.randomElement() {
                        labelArray[i] = choice
                    } else {
                        labelArray[i] = availableFlags.randomElement()!
                    }
                }
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .flag(labelArray[i]),
                backgroundContent: .flag(selectedFlags[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateEmojiTiles(count: Int) {
        // Select emojis for tiles
        var selectedEmojis: [GameEmoji] = []
        if count <= availableEmojis.count {
            let shuffled = availableEmojis.shuffled()
            selectedEmojis = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedEmojis.append(availableEmojis.randomElement()!)
            }
        }
        
        // Determine number of correct/incorrect tiles based on mode
        let targetCount: Int
        
        // Both modes scale equally: requiredCorrectCount targets to find
        targetCount = min(requiredCorrectCount, count)
        
        // Pick random indices for target tiles
        var targetIndices = Set<Int>()
        while targetIndices.count < targetCount {
            targetIndices.insert(Int.random(in: 0..<count))
        }
        
        // Create labels based on mode
        var labelArray = [GameEmoji](repeating: selectedEmojis[0], count: count)
        
        for i in 0..<count {
            if inverseMode {
                // Inverse mode logic
                if targetIndices.contains(i) {
                    // Make this tile incorrect (the odd one out)
                    let tileEmojiKey = selectedEmojis[i].nameKey
                    let candidates = availableEmojis.filter { $0.nameKey != tileEmojiKey }
                    if let choice = candidates.randomElement() {
                        labelArray[i] = choice
                    } else {
                        labelArray[i] = availableEmojis.randomElement()!
                    }
                } else {
                    // Make this tile correct
                    labelArray[i] = selectedEmojis[i]
                }
            } else {
                // Normal mode logic
                if targetIndices.contains(i) {
                    // Make this tile correct
                    labelArray[i] = selectedEmojis[i]
                } else {
                    // Make this tile incorrect
                    let tileEmojiKey = selectedEmojis[i].nameKey
                    let candidates = availableEmojis.filter { $0.nameKey != tileEmojiKey }
                    if let choice = candidates.randomElement() {
                        labelArray[i] = choice
                    } else {
                        labelArray[i] = availableEmojis.randomElement()!
                    }
                }
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .emoji(labelArray[i]),
                backgroundContent: .emoji(selectedEmojis[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func endLevel() {
        invalidateTimer()
        isPlaying = false
        
        Logger.game.notice("Level completed: level=\(level), levelScore=\(levelScore), totalScore=\(totalScore), mistakes=\(mistakesThisLevel)")
        
        // Store the score for this level
        levelScores[level] = levelScore
        
        // Track level completion for achievements (only if level completed successfully)
        newAchievementsThisLevel = []
        if levelScore > 0 {
            achievementStore.markLevelCompletion(level: level, mode: gameMode, isPro: proMode)
            let newAchievements = achievementStore.checkAndUnlockAchievements()
            newAchievementsThisLevel = newAchievements
            newAchievementsThisRun.append(contentsOf: newAchievements)

            if !newAchievements.isEmpty {
                Logger.achievements.notice("Achievements unlocked: count=\(newAchievements.count), ids=\(Logger.formatAchievementIDs(newAchievements))")
            }

            // Report new achievements to Game Center
            if !newAchievements.isEmpty {
                Task {
                    await gameCenterManager.reportAchievements(newAchievements)
                }
            }
        }

        if levelScore <= 0 {
            // Game Over - calculate total from positive levels only
            let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
            
            Logger.game.info("Game ended: reason=negativeScore, level=\(level), finalScore=\(finalScore), maxLevel=\(level)")
            
            highscoreStore.add(score: finalScore, playerName: effectivePlayerName, maxLevel: level, achievementIDs: newAchievementsThisRun, gameMode: gameMode.rawValue, isPro: proMode)
            totalScore = finalScore  // Update display score
            
            // Submit score to Game Center
            Task {
                await gameCenterManager.submitScore(finalScore, gameMode: gameMode.rawValue, isPro: proMode)
            }
            
            feedbackManager.trigger(.gameOver)
            showSummary = true
        } else {
            // Add positive score to total
            totalScore += levelScore
            
            // Trigger level complete feedback
            feedbackManager.trigger(.levelComplete)
            
            // Show level complete screen
            level += 1
            withAnimation {
                showLevelComplete = true
            }
        }
    }
    
    private func handleTileTap(tile: TileData) {
        // Provide immediate tap feedback for responsiveness
        feedbackManager.trigger(.tileTap)
        
        let isCorrect = tile.isCorrect
        
        // In inverse mode, logic is flipped: correct tiles are actually wrong
        let isCorrectInCurrentMode = inverseMode ? !isCorrect : isCorrect
        
        // Check if this correct tile was already found (in normal mode)
        if isCorrectInCurrentMode && correctTilesFound.contains(tile.id) {
            // Already found - do nothing
            return
        }
        
        // Use new simplified scoring system
        let points = calculateRoundScore(secondsRemaining: timeRemaining)
        
        if isCorrectInCurrentMode {
            Logger.game.debug("Correct tap: level=\(level), round=\(round), points=\(points), foundCount=\(correctTilesFound.count + 1), requiredCount=\(requiredCorrectCount), inverseMode=\(inverseMode)")
            
            // Mark this correct tile as found
            correctTilesFound.insert(tile.id)
            
            // Reset both counters on correct tap
            consecutiveTimeouts = 0
            consecutiveWrongTaps = 0
            levelScore += points
            showScoreDelta(points)
            
            // Track consecutive inverse mode correct answers for achievement
            if inverseMode {
                consecutiveInverseCorrect += 1
                Logger.game.debug("Inverse mode streak: \(consecutiveInverseCorrect)")
                
                // Check for Bug Hunter achievement (10 consecutive inverse mode finds)
                if consecutiveInverseCorrect >= 10 {
                    let bugHunterID = "bug_hunter"
                    if !achievementStore.isAchievementUnlocked(bugHunterID) {
                        achievementStore.unlockAchievement(bugHunterID)
                        newAchievementsThisRun.append(bugHunterID)
                        Logger.achievements.notice("Achievement unlocked: Bug Hunter (10 consecutive inverse mode finds)")
                    }
                }
            }
            
            // Trigger positive feedback
            feedbackManager.trigger(.correctTap)
            
            // Check if all required correct tiles have been found
            if correctTilesFound.count >= requiredCorrectCount {
                Logger.game.debug("Round completed successfully")
                
                // Round complete! Move to next round
                invalidateTimer()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    if self.isPlaying {
                        self.nextRound()
                        self.startTimer()
                    }
                }
            }
        } else {
            Logger.game.warning("Wrong tap: level=\(level), round=\(round), points=-\(points), mistakesThisLevel=\(mistakesThisLevel + 1), inverseMode=\(inverseMode)")
            
            // Wrong tap - reset inverse mode streak
            if inverseMode {
                consecutiveInverseCorrect = 0
            }
            
            // Wrong tap - increment mistake counter
            mistakesThisLevel += 1
            
            levelScore -= points
            showScoreDelta(-points)
            
            // Trigger negative feedback
            feedbackManager.trigger(.wrongTap)
            
            // Check if this is the second mistake (game over)
            if mistakesThisLevel >= 2 {
                Logger.game.error("Game over: two mistakes in level")
                
                // Capture game over feedback for summary screen
                gameOverFeedback = GameOverFeedback(
                    tiles: tiles,
                    incorrectTileID: tile.id,
                    gridSize: gridSize,
                    inverseMode: inverseMode
                )
                
                // End the game immediately on second mistake
                invalidateTimer()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.endGameEarly()
                }
                return
            } else {
                // First mistake - continue playing but show warning
                // No need to advance round - player can keep trying
            }
        }
    }
    
    // MARK: - Dev Mode Helper
    private func autoSolveRound() {
        guard isDevMode && isPlaying else { return }

        // Find all target tiles that haven't been found yet
        // In inverse mode, the target is the incorrect tile (odd one out)
        let targetTiles = tiles.filter { tile in
            let isCorrectInCurrentMode = inverseMode ? !tile.isCorrect : tile.isCorrect
            return isCorrectInCurrentMode && !correctTilesFound.contains(tile.id)
        }

        // Automatically tap all target tiles
        for tile in targetTiles {
            handleTileTap(tile: tile)
            // Small delay between taps for visual feedback
            Thread.sleep(forTimeInterval: 0.1)
        }
    }
    
    private func showScoreDelta(_ delta: Int) {
        scoreDelta = delta
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            scoreDelta = nil
        }
    }
    
    private func startTimer() {
        invalidateTimer()
        timeRemaining = currentRoundDuration
        timerProgress = 1.0
        isLowTimeWarningTriggered = false  // Reset warning flag
        
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
            if self.isPlaying {
                self.timeRemaining -= 0.05
                self.timerProgress = max(0, self.timeRemaining / self.currentRoundDuration)
                
                // Trigger warning when time drops below 25% (only once per round)
                if self.timerProgress < 0.25 && !self.isLowTimeWarningTriggered {
                    self.isLowTimeWarningTriggered = true
                    self.feedbackManager.trigger(.timeWarning)
                }
                
                if self.timeRemaining <= 0 {
                    self.handleTimeout()
                }
            }
        }
    }
    
    private func handleTimeout() {
        Logger.game.error("Round timeout: level=\(level), round=\(round), mistakesThisLevel=\(mistakesThisLevel + 1)")
        
        // Trigger timeout feedback
        feedbackManager.trigger(.timeout)
        
        // Increment mistake counter
        mistakesThisLevel += 1
        
        // Check if this is the second mistake (game over)
        if mistakesThisLevel >= 2 {
            Logger.game.error("Game over: two mistakes in level (timeout)")
            
            // Capture game over feedback for summary screen (timeout - no specific incorrect tile)
            gameOverFeedback = GameOverFeedback(
                tiles: tiles,
                incorrectTileID: nil,  // No specific tile tapped, timeout occurred
                gridSize: gridSize,
                inverseMode: inverseMode
            )
            
            // Game ends on second mistake
            endGameEarly()
        } else {
            // First mistake - continue to next round after brief pause
            invalidateTimer()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                if self.isPlaying {
                    self.nextRound()
                    self.startTimer()
                }
            }
        }
    }
    
    private func endGameEarly() {
        invalidateTimer()
        isPlaying = false
        
        // Store the score for this level
        levelScores[level] = levelScore
        
        // Calculate final score from positive levels only
        let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
        
        Logger.game.info("Game ended early: reason=mistakes, level=\(level), round=\(round), finalScore=\(finalScore), maxLevel=\(level)")
        
        highscoreStore.add(score: finalScore, playerName: effectivePlayerName, maxLevel: level, achievementIDs: newAchievementsThisRun, gameMode: gameMode.rawValue, isPro: proMode)
        totalScore = finalScore
        
        // Submit score to Game Center
        Task {
            await gameCenterManager.submitScore(finalScore, gameMode: gameMode.rawValue, isPro: proMode)
        }
        
        feedbackManager.trigger(.gameOver)
        showSummary = true
    }
    
    private func quitGame() {
        endGameEarly()
    }
    
    private func invalidateTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    // MARK: - Helper Functions
    private static func defaultLanguage() -> String {
        // Get the first preferred language from the system
        if let preferredLanguage = Locale.preferredLanguages.first {
            // Check if it starts with "de" for German
            if preferredLanguage.hasPrefix("de") {
                return "de"
            }
        }
        // Default to English for all other languages
        return "en"
    }
    
    static func defaultPlayerName() -> String {
        return "Player"
    }
    
    private func localizedContentName(_ nameKey: String, language: String) -> String {
        return L(nameKey, language: language)
    }
    
    // MARK: - Unlock Alert Helpers
    
    private func validateSelections() {
        Logger.app.info("Validating mode selections: currentMode=\(gameMode.rawValue), isPro=\(proMode), playerName=\(effectivePlayerName, privacy: .private)")
        
        // Check if current mode is locked (skip if Dev Mode)
        if !achievementStore.isModeUnlocked(mode: gameMode, isPro: false, playerName: playerName) {
            Logger.app.warning("Current mode is locked, resetting to colors: lockedMode=\(gameMode.rawValue)")
            gameModeRaw = GameMode.colors.rawValue
        }
        
        // Check if Pro mode is locked (skip if Dev Mode)
        if proMode && !achievementStore.isModeUnlocked(mode: gameMode, isPro: true, playerName: playerName) {
            Logger.app.warning("Pro mode is locked, disabling: gameMode=\(gameMode.rawValue)")
            proMode = false
        }
    }
    
    private func showUnlockAlert(for mode: GameMode) {
        // Find the achievement that unlocks this mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .mode(let unlockMode) = unlocked, unlockMode == mode.rawValue {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
    
    private func showUnlockAlert(forProMode: Bool) {
        // Find the achievement that unlocks Pro mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .proMode = unlocked {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
    
    private func textColorForTile(_ tile: TileData) -> Color {
        switch tile.backgroundContent {
        case .color(_):
            // For color tiles, use black text
            return .black.opacity(0.8)
        case .number(_), .shape(_), .emoji(_), .flag(_):
            // For number, shape, emoji and flag tiles, use primary color (adapts to dark/light mode)
            return .primary
        }
    }
    
    private func startExampleAnimation() {
        // Stop any existing timer first
        stopExampleAnimation()

        // Animate the example tiles in a loop - increased interval to reduce CPU usage
        exampleAnimationTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { _ in
            withAnimation(.easeInOut(duration: 0.4)) {
                exampleTileAnimationPhase = (exampleTileAnimationPhase + 1) % 2
            }
        }

        // Animate logo switching between color and emoji - increased interval to reduce CPU usage
        logoAnimationTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) { _ in
            withAnimation(.easeInOut(duration: 0.5)) {
                logoAnimationPhase = (logoAnimationPhase + 1) % 2

                // Update logo content
                if logoAnimationPhase == 0 {
                    // Switch to a new random color
                    currentLogoColor = availableColors.randomElement()
                } else {
                    // Switch to a new random emoji
                    currentLogoEmoji = availableEmojis.randomElement()
                }
            }
        }
    }
    
    private func initializeLogo() {
        // Initialize with a random color
        currentLogoColor = availableColors.randomElement()
        currentLogoEmoji = availableEmojis.randomElement()
        logoAnimationPhase = 0
    }
    
    private func stopExampleAnimation() {
        exampleAnimationTimer?.invalidate()
        exampleAnimationTimer = nil
        logoAnimationTimer?.invalidate()
        logoAnimationTimer = nil
    }
}

// PlayButtonStyle, AnimatedBackgroundView, Diamond, and SummaryView_iOS have been moved to separate files


// MARK: - Preview
#Preview {
    ContentView_iOS()
}


