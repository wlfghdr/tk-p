//
//  RatingManager.swift
//  Timekiller
//
//  Created by Copilot
//

import Foundation
import OSLog

/// Manages in-app rating prompts using Apple's StoreKit framework.
///
/// `RatingManager` provides a centralized system for requesting app ratings
/// from users at appropriate times, following Apple's Human Interface Guidelines.
/// It tracks game completions and whether the user has been prompted, ensuring
/// the rating request is shown at optimal moments without being intrusive.
///
/// ## Key Features
/// - Tracks number of games completed by the player
/// - Records whether a rating prompt has been shown
/// - Works with SwiftUI's environment-based rating request API
/// - Persists state across app launches using UserDefaults
///
/// ## Usage
/// ```swift
/// let ratingManager = RatingManager.shared
///
/// // After a game ends
/// ratingManager.incrementGameCount()
///
/// // Check if conditions are met for showing prompt
/// if ratingManager.shouldRequestReview(hasNewAchievements: true) {
///     // Show "Are you enjoying the game?" dialog
///     // If user answers yes, call:
///     ratingManager.markRatingRequested()
///     // And request review via @Environment(\.requestReview)
/// }
/// ```
@Observable
class RatingManager {
    /// Shared singleton instance
    static let shared = RatingManager()
    
    /// UserDefaults key for storing the number of completed games
    private let gamesCompletedKey = "tk_games_completed"
    
    /// UserDefaults key for tracking if rating has been requested
    private let hasRequestedRatingKey = "tk_has_requested_rating"
    
    /// Number of games the player has completed
    private(set) var gamesCompleted: Int {
        didSet {
            UserDefaults.standard.set(gamesCompleted, forKey: gamesCompletedKey)
            Logger.app.debug("Games completed count updated: \(self.gamesCompleted)")
        }
    }
    
    /// Whether a rating prompt has already been shown to the user
    private(set) var hasRequestedRating: Bool {
        didSet {
            UserDefaults.standard.set(hasRequestedRating, forKey: hasRequestedRatingKey)
            Logger.app.info("Rating request status updated: \(self.hasRequestedRating)")
        }
    }
    
    /// Minimum number of games required before showing rating prompt
    private let minimumGamesForRating = 3
    
    private init() {
        self.gamesCompleted = UserDefaults.standard.integer(forKey: gamesCompletedKey)
        self.hasRequestedRating = UserDefaults.standard.bool(forKey: hasRequestedRatingKey)
        
        Logger.app.info("RatingManager initialized: gamesCompleted=\(self.gamesCompleted), hasRequestedRating=\(self.hasRequestedRating)")
    }
    
    /// Increments the count of completed games.
    ///
    /// Call this method when a game session ends (when the summary screen is shown).
    func incrementGameCount() {
        gamesCompleted += 1
        Logger.app.debug("Game count incremented to: \(self.gamesCompleted)")
    }
    
    /// Determines whether the rating prompt should be offered to the user.
    ///
    /// - Parameters:
    ///   - hasNewAchievements: Whether the player earned any new achievements this session
    ///   - isDevMode: Whether developer mode is active (shows rating dialog every time)
    /// - Returns: `true` if all conditions are met, `false` otherwise
    ///
    /// ## Conditions (Normal Mode)
    /// 1. Player has completed at least 3 games
    /// 2. Player earned at least one achievement in this session
    /// 3. Rating prompt has not been shown before
    ///
    /// ## Dev Mode Behavior
    /// When `isDevMode` is `true`, the rating dialog is shown on every summary screen
    /// regardless of achievements, games completed, or whether it was shown before.
    /// This allows easy testing of the rating flow during development.
    func shouldRequestReview(hasNewAchievements: Bool, isDevMode: Bool = false) -> Bool {
        // In dev mode, always show rating prompt
        if isDevMode {
            Logger.app.debug("Dev mode active - forcing rating prompt")
            return true
        }
        
        let shouldRequest = gamesCompleted >= minimumGamesForRating
            && hasNewAchievements
            && !hasRequestedRating
        
        Logger.app.debug("Should request review check: shouldRequest=\(shouldRequest), gamesCompleted=\(self.gamesCompleted), hasNewAchievements=\(hasNewAchievements), hasRequestedRating=\(self.hasRequestedRating)")
        
        return shouldRequest
    }
    
    /// Marks that a rating request has been shown to the user.
    ///
    /// Call this after the user responds to the rating prompt to prevent
    /// showing it again in the future.
    ///
    /// - Note: This marks the rating as requested, preventing future prompts.
    func markRatingRequested() {
        hasRequestedRating = true
        Logger.app.notice("Rating marked as requested")
    }
    
    /// Resets the rating request state (for testing purposes).
    ///
    /// - Warning: This should only be used during development/testing
    func resetRatingState() {
        hasRequestedRating = false
        Logger.app.debug("Rating state reset for testing")
    }
}
