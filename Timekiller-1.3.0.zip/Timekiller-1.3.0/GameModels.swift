//
//  GameModels.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation
import SwiftUI

// MARK: - Game Mode

enum GameMode: String, CaseIterable, Identifiable {
    case colors = "colors"
    case shapes = "shapes"
    case emojis = "emojis"
    
    var id: String { rawValue }
    
    var nameKey: String {
        switch self {
        case .colors: return "ModeColors"
        case .shapes: return "ModeShapes"
        case .emojis: return "ModeEmojis"
        }
    }
}

// MARK: - Game Item Protocol

protocol GameItem: Identifiable, Equatable {
    var id: UUID { get }
    var nameKey: String { get }
}

// MARK: - Game Color Model

struct GameColor: GameItem {
    let id = UUID()
    let color: Color
    let nameKey: String // Localization key
    
    // Manual Equatable implementation to compare by nameKey
    static func == (lhs: GameColor, rhs: GameColor) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    // Standard mode: 8 colors (easier)
    static let standardColors: [GameColor] = [
        GameColor(color: .red, nameKey: "Red"),
        GameColor(color: .blue, nameKey: "Blue"),
        GameColor(color: .green, nameKey: "Green"),
        GameColor(color: .yellow, nameKey: "Yellow"),
        GameColor(color: .orange, nameKey: "Orange"),
        GameColor(color: .purple, nameKey: "Purple"),
        GameColor(color: .brown, nameKey: "Brown"),
        GameColor(color: .cyan, nameKey: "Cyan")
    ]
    
    // Pro mode: 16 colors (harder, double points)
    static let proColors: [GameColor] = [
        GameColor(color: .red, nameKey: "Red"),
        GameColor(color: .blue, nameKey: "Blue"),
        GameColor(color: .green, nameKey: "Green"),
        GameColor(color: .yellow, nameKey: "Yellow"),
        GameColor(color: .orange, nameKey: "Orange"),
        GameColor(color: .purple, nameKey: "Purple"),
        GameColor(color: .brown, nameKey: "Brown"),
        GameColor(color: .cyan, nameKey: "Cyan"),
        GameColor(color: .gray, nameKey: "Gray"),
        GameColor(color: .indigo, nameKey: "Indigo"),
        GameColor(color: .mint, nameKey: "Mint"),
        GameColor(color: .teal, nameKey: "Teal"),
        GameColor(color: Color(red: 1.0, green: 0.75, blue: 0.8), nameKey: "Pink"),
        GameColor(color: Color(red: 0.5, green: 0.0, blue: 0.5), nameKey: "Violet"),
        GameColor(color: Color(red: 0.6, green: 0.4, blue: 0.2), nameKey: "Tan"),
        GameColor(color: Color(red: 0.5, green: 0.5, blue: 0.5), nameKey: "Silver")
    ]
    
    // Legacy property for backwards compatibility
    static let allColors: [GameColor] = standardColors
}

// MARK: - Game Emoji Model

struct GameEmoji: GameItem {
    let id = UUID()
    let emoji: String
    let nameKey: String // Localization key
    
    // Manual Equatable implementation to compare by nameKey
    static func == (lhs: GameEmoji, rhs: GameEmoji) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    // Standard mode: 16 emojis
    static let standardEmojis: [GameEmoji] = [
        GameEmoji(emoji: "😀", nameKey: "EmojiGrinning"),
        GameEmoji(emoji: "😂", nameKey: "EmojiLaughing"),
        GameEmoji(emoji: "😍", nameKey: "EmojiHeart"),
        GameEmoji(emoji: "🤔", nameKey: "EmojiThinking"),
        GameEmoji(emoji: "😎", nameKey: "EmojiCool"),
        GameEmoji(emoji: "🤯", nameKey: "EmojiMindBlown"),
        GameEmoji(emoji: "🥳", nameKey: "EmojiParty"),
        GameEmoji(emoji: "😴", nameKey: "EmojiSleepy"),
        GameEmoji(emoji: "🤑", nameKey: "EmojiMoney"),
        GameEmoji(emoji: "🤠", nameKey: "EmojiCowboy"),
        GameEmoji(emoji: "👻", nameKey: "EmojiGhost"),
        GameEmoji(emoji: "👽", nameKey: "EmojiAlien"),
        GameEmoji(emoji: "🤖", nameKey: "EmojiRobot"),
        GameEmoji(emoji: "💩", nameKey: "EmojiPoop"),
        GameEmoji(emoji: "🔥", nameKey: "EmojiFire"),
        GameEmoji(emoji: "⭐️", nameKey: "EmojiStar")
    ]
    
    // Pro mode: 64 emojis
    static let proEmojis: [GameEmoji] = [
        // Faces & Emotions (20)
        GameEmoji(emoji: "😀", nameKey: "EmojiGrinning"),
        GameEmoji(emoji: "😂", nameKey: "EmojiLaughing"),
        GameEmoji(emoji: "😍", nameKey: "EmojiHeart"),
        GameEmoji(emoji: "🤔", nameKey: "EmojiThinking"),
        GameEmoji(emoji: "😎", nameKey: "EmojiCool"),
        GameEmoji(emoji: "🤯", nameKey: "EmojiMindBlown"),
        GameEmoji(emoji: "🥳", nameKey: "EmojiParty"),
        GameEmoji(emoji: "😴", nameKey: "EmojiSleepy"),
        GameEmoji(emoji: "🤑", nameKey: "EmojiMoney"),
        GameEmoji(emoji: "🤠", nameKey: "EmojiCowboy"),
        GameEmoji(emoji: "🤡", nameKey: "EmojiClown"),
        GameEmoji(emoji: "😇", nameKey: "EmojiAngel"),
        GameEmoji(emoji: "😈", nameKey: "EmojiDevil"),
        GameEmoji(emoji: "🥶", nameKey: "EmojiFreezing"),
        GameEmoji(emoji: "🥵", nameKey: "EmojiHot"),
        GameEmoji(emoji: "🤢", nameKey: "EmojiNauseated"),
        GameEmoji(emoji: "🤓", nameKey: "EmojiNerd"),
        GameEmoji(emoji: "🧐", nameKey: "EmojiMonocle"),
        GameEmoji(emoji: "😱", nameKey: "EmojiScreaming"),
        GameEmoji(emoji: "🤐", nameKey: "EmojiZipper"),
        
        // Creatures & Fantasy (15)
        GameEmoji(emoji: "👻", nameKey: "EmojiGhost"),
        GameEmoji(emoji: "👽", nameKey: "EmojiAlien"),
        GameEmoji(emoji: "🤖", nameKey: "EmojiRobot"),
        GameEmoji(emoji: "🎃", nameKey: "EmojiPumpkin"),
        GameEmoji(emoji: "💀", nameKey: "EmojiSkull"),
        GameEmoji(emoji: "👹", nameKey: "EmojiOgre"),
        GameEmoji(emoji: "👺", nameKey: "EmojiGoblin"),
        GameEmoji(emoji: "🦄", nameKey: "EmojiUnicorn"),
        GameEmoji(emoji: "🐉", nameKey: "EmojiDragon"),
        GameEmoji(emoji: "🦖", nameKey: "EmojiDino"),
        GameEmoji(emoji: "🐙", nameKey: "EmojiOctopus"),
        GameEmoji(emoji: "🦑", nameKey: "EmojiSquid"),
        GameEmoji(emoji: "🦈", nameKey: "EmojiShark"),
        GameEmoji(emoji: "🐊", nameKey: "EmojiCrocodile"),
        GameEmoji(emoji: "🦎", nameKey: "EmojiLizard"),
        
        // Animals (10)
        GameEmoji(emoji: "🐶", nameKey: "EmojiDog"),
        GameEmoji(emoji: "🐱", nameKey: "EmojiCat"),
        GameEmoji(emoji: "🐭", nameKey: "EmojiMouse"),
        GameEmoji(emoji: "🐼", nameKey: "EmojiPanda"),
        GameEmoji(emoji: "🦁", nameKey: "EmojiLion"),
        GameEmoji(emoji: "🐯", nameKey: "EmojiTiger"),
        GameEmoji(emoji: "🐸", nameKey: "EmojiFrog"),
        GameEmoji(emoji: "🦊", nameKey: "EmojiFox"),
        GameEmoji(emoji: "🐵", nameKey: "EmojiMonkey"),
        GameEmoji(emoji: "🐔", nameKey: "EmojiChicken"),
        
        // Objects & Symbols (19)
        GameEmoji(emoji: "💩", nameKey: "EmojiPoop"),
        GameEmoji(emoji: "🔥", nameKey: "EmojiFire"),
        GameEmoji(emoji: "⭐️", nameKey: "EmojiStar"),
        GameEmoji(emoji: "💎", nameKey: "EmojiDiamond"),
        GameEmoji(emoji: "👑", nameKey: "EmojiCrown"),
        GameEmoji(emoji: "🎯", nameKey: "EmojiTarget"),
        GameEmoji(emoji: "🎮", nameKey: "EmojiGamepad"),
        GameEmoji(emoji: "🎲", nameKey: "EmojiDice"),
        GameEmoji(emoji: "🎪", nameKey: "EmojiTent"),
        GameEmoji(emoji: "🚀", nameKey: "EmojiRocket"),
        GameEmoji(emoji: "⚡️", nameKey: "EmojiLightning"),
        GameEmoji(emoji: "💥", nameKey: "EmojiBoom"),
        GameEmoji(emoji: "💫", nameKey: "EmojiDizzy"),
        GameEmoji(emoji: "🌈", nameKey: "EmojiRainbow"),
        GameEmoji(emoji: "🌙", nameKey: "EmojiMoon"),
        GameEmoji(emoji: "☀️", nameKey: "EmojiSun"),
        GameEmoji(emoji: "🍕", nameKey: "EmojiPizza"),
        GameEmoji(emoji: "🍔", nameKey: "EmojiBurger"),
        GameEmoji(emoji: "🎉", nameKey: "EmojiConfetti")
    ]
}

// MARK: - Game Shape Model

struct GameShape: GameItem {
    let id = UUID()
    let shape: String  // Unicode character for the shape
    let nameKey: String // Localization key
    
    // Manual Equatable implementation to compare by nameKey
    static func == (lhs: GameShape, rhs: GameShape) -> Bool {
        return lhs.nameKey == rhs.nameKey
    }
    
    // Standard mode: 12 shapes (fun and distinct)
    static let standardShapes: [GameShape] = [
        GameShape(shape: "●", nameKey: "ShapeCircle"),
        GameShape(shape: "■", nameKey: "ShapeSquare"),
        GameShape(shape: "▲", nameKey: "ShapeTriangle"),
        GameShape(shape: "★", nameKey: "ShapeStar"),
        GameShape(shape: "♦", nameKey: "ShapeDiamond"),
        GameShape(shape: "♥", nameKey: "ShapeHeart"),
        GameShape(shape: "⬟", nameKey: "ShapeHexagon"),
        GameShape(shape: "⬢", nameKey: "ShapeHexagonOutline"),
        GameShape(shape: "▼", nameKey: "ShapeTriangleDown"),
        GameShape(shape: "◆", nameKey: "ShapeDiamondFilled"),
        GameShape(shape: "✦", nameKey: "ShapeStarOutline"),
        GameShape(shape: "○", nameKey: "ShapeCircleOutline")
    ]
    
    // Pro mode: 24 shapes (more variety and challenge)
    static let proShapes: [GameShape] = [
        // Basic shapes
        GameShape(shape: "●", nameKey: "ShapeCircle"),
        GameShape(shape: "■", nameKey: "ShapeSquare"),
        GameShape(shape: "▲", nameKey: "ShapeTriangle"),
        GameShape(shape: "★", nameKey: "ShapeStar"),
        GameShape(shape: "♦", nameKey: "ShapeDiamond"),
        GameShape(shape: "♥", nameKey: "ShapeHeart"),
        GameShape(shape: "⬟", nameKey: "ShapeHexagon"),
        GameShape(shape: "⬢", nameKey: "ShapeHexagonOutline"),
        GameShape(shape: "▼", nameKey: "ShapeTriangleDown"),
        GameShape(shape: "◆", nameKey: "ShapeDiamondFilled"),
        GameShape(shape: "✦", nameKey: "ShapeStarOutline"),
        GameShape(shape: "○", nameKey: "ShapeCircleOutline"),
        
        // Additional pro shapes
        GameShape(shape: "◼", nameKey: "ShapeSquareSmall"),
        GameShape(shape: "▶", nameKey: "ShapeTriangleRight"),
        GameShape(shape: "◀", nameKey: "ShapeTriangleLeft"),
        GameShape(shape: "♠", nameKey: "ShapeSpade"),
        GameShape(shape: "♣", nameKey: "ShapeClub"),
        GameShape(shape: "☆", nameKey: "ShapeStarEmpty"),
        GameShape(shape: "✪", nameKey: "ShapeStarCircled"),
        GameShape(shape: "◉", nameKey: "ShapeBullseye"),
        GameShape(shape: "◎", nameKey: "ShapeTarget"),
        GameShape(shape: "⬛", nameKey: "ShapeSquareLarge"),
        GameShape(shape: "⬜", nameKey: "ShapeSquareWhite"),
        GameShape(shape: "✚", nameKey: "ShapePlus")
    ]
}

// MARK: - Universal Tile Content

enum TileContent: Equatable {
    case color(GameColor)
    case shape(GameShape)
    case emoji(GameEmoji)
    
    var nameKey: String {
        switch self {
        case .color(let gameColor): return gameColor.nameKey
        case .shape(let gameShape): return gameShape.nameKey
        case .emoji(let gameEmoji): return gameEmoji.nameKey
        }
    }
    
    var id: UUID {
        switch self {
        case .color(let gameColor): return gameColor.id
        case .shape(let gameShape): return gameShape.id
        case .emoji(let gameEmoji): return gameEmoji.id
        }
    }
}

// MARK: - Grid Size (iOS only)

enum GridSize: String, CaseIterable, Identifiable {
    case grid2x2 = "2x2"
    case grid2x4 = "2x4"
    case grid3x5 = "3x5"
    
    var id: String { rawValue }
    
    var tileCount: Int {
        switch self {
        case .grid2x2: return 4
        case .grid2x4: return 8
        case .grid3x5: return 15
        }
    }
    
    var columns: Int {
        switch self {
        case .grid2x2: return 2
        case .grid2x4: return 2
        case .grid3x5: return 3
        }
    }
    
    var rows: Int {
        switch self {
        case .grid2x2: return 2
        case .grid2x4: return 4
        case .grid3x5: return 5
        }
    }
}

// MARK: - Level-Based Progression Functions

/// Returns the grid size that should be used for a given level
func gridSizeForLevel(_ level: Int) -> GridSize {
    if level <= 4 {
        return .grid2x2  // Levels 1-4: Small grid (4 tiles)
    } else if level <= 10 {
        return .grid2x4  // Levels 5-10: Medium grid (8 tiles)
    } else {
        return .grid3x5  // Levels 11+: Large grid (15 tiles)
    }
}

/// Returns the number of correct answers required for a given level
func requiredCorrectAnswers(level: Int) -> Int {
    if level <= 7 {
        return 1  // Levels 1-7: Single answer
    } else if level <= 15 {
        return 2  // Levels 8-15: Double answers
    } else if level <= 22 {
        return 3  // Levels 16-22: Triple answers
    } else {
        return 4  // Levels 23+: Quad answers
    }
}

/// Returns the base time duration for a given level
/// Base times: 2×2 = 8s, 2×4 = 12s, 3×5 = 15s
/// From Level 25 onwards: 5% reduction per level (gentler curve for longer gameplay)
func baseTimeForLevel(_ level: Int) -> Double {
    let gridSize = gridSizeForLevel(level)
    
    // Base duration by grid size
    let baseDuration: Double
    switch gridSize {
    case .grid2x2:
        baseDuration = 8.0   // 4 tiles: 8 seconds
    case .grid2x4:
        baseDuration = 12.0  // 8 tiles: 12 seconds
    case .grid3x5:
        baseDuration = 15.0  // 15 tiles: 15 seconds
    }
    
    // No time reduction for levels 1-24
    if level < 25 {
        return baseDuration
    }
    
    // From level 25 onwards: 5% reduction per level (gentler than before)
    // Level 25: 95% time, Level 26: 90.25% time, Level 27: 85.7% time, etc.
    let levelsAbove24 = level - 24
    let reductionFactor = pow(0.95, Double(levelsAbove24))
    return baseDuration * reductionFactor
}

// MARK: - Highscore Models

struct HighscoreEntry: Identifiable, Codable {
    let id: UUID
    let playerName: String
    let score: Int
    let maxLevel: Int  // Added: maximum level reached
    let date: Date
    let achievementIDs: [String]  // IDs of achievements earned in this run
    
    init(id: UUID = UUID(), playerName: String, score: Int, maxLevel: Int = 1, date: Date = Date(), achievementIDs: [String] = []) {
        self.id = id
        self.playerName = playerName
        self.score = score
        self.maxLevel = maxLevel
        self.date = date
        self.achievementIDs = achievementIDs
    }
    
    // Custom decoder to handle backward compatibility
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        playerName = try container.decode(String.self, forKey: .playerName)
        score = try container.decode(Int.self, forKey: .score)
        maxLevel = try container.decode(Int.self, forKey: .maxLevel)
        date = try container.decode(Date.self, forKey: .date)
        // Handle missing achievementIDs for backward compatibility
        achievementIDs = (try? container.decode([String].self, forKey: .achievementIDs)) ?? []
    }
}

// MARK: - Highscore Store

@Observable
class HighscoreStore {
    private let storageKey = "tk_highscores"
    private let maxEntries = 10
    
    var entries: [HighscoreEntry] = []
    
    init() {
        load()
    }
    
    func add(score: Int, playerName: String, maxLevel: Int = 1, achievementIDs: [String] = []) {
        let newEntry = HighscoreEntry(playerName: playerName, score: score, maxLevel: maxLevel, achievementIDs: achievementIDs)
        entries.append(newEntry)
        entries.sort { $0.score > $1.score }
        
        // Keep only top 10
        if entries.count > maxEntries {
            entries = Array(entries.prefix(maxEntries))
        }
        
        save()
    }
    
    func delete(at offsets: IndexSet) {
        entries.remove(atOffsets: offsets)
        save()
    }
    
    func clear() {
        entries.removeAll()
        save()
    }
    
    private func save() {
        if let encoded = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(encoded, forKey: storageKey)
        }
    }
    
    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([HighscoreEntry].self, from: data) else {
            return
        }
        entries = decoded
    }
}
// MARK: - Tile Data Model

struct TileData: Identifiable {
    let id = UUID()
    let displayContent: TileContent      // The content name to display as text
    let backgroundContent: TileContent   // The actual background content
    
    // Convenience property for rendering background color
    var backgroundColor: Color {
        switch backgroundContent {
        case .color(let gameColor):
            return gameColor.color
        case .shape(_), .emoji(_):
            // For shapes and emojis, use a neutral background that adapts to light/dark mode
            #if os(watchOS)
            return Color(white: 0.2) // watchOS: use a dark gray that works well
            #else
            return Color(.secondarySystemBackground)
            #endif
        }
    }
    
    // Get the visual content (shape/emoji string if not color mode)
    var visualContent: String? {
        switch backgroundContent {
        case .color(_):
            return nil
        case .shape(let gameShape):
            return gameShape.shape
        case .emoji(let gameEmoji):
            return gameEmoji.emoji
        }
    }
    
    // Check if text matches background content
    var isCorrect: Bool {
        displayContent.nameKey == backgroundContent.nameKey
    }
}

// MARK: - Achievement System

/// Represents a specific achievement milestone
struct Achievement: Identifiable, Codable, Equatable {
    let id: String
    let nameKey: String        // Localization key for achievement name
    let iconEmoji: String      // Emoji icon for the achievement
    let explanationKey: String // Localization key for explanation
    let unlockCondition: UnlockCondition
    
    enum UnlockCondition: Codable, Equatable {
        case reachLevel(Int, mode: String, isPro: Bool)  // Generic level reaching
        case reachLevelInAllModes(Int)  // Ultimate achievement
    }
    
    /// What this achievement unlocks (for display purposes)
    var unlocksContent: UnlockedContent? {
        switch unlockCondition {
        case .reachLevel(let level, _, let isPro):
            if isPro {
                return nil  // Pro mode achievements don't unlock anything
            }
            // Level-based unlocks
            switch level {
            case 10:
                return .mode("shapes")
            case 20:
                return .mode("emojis")
            case 30:
                return .proMode
            default:
                return nil
            }
        case .reachLevelInAllModes:
            return nil  // Ultimate achievement doesn't unlock anything
        }
    }
    
    enum UnlockedContent {
        case mode(String)
        case proMode
    }
}

// MARK: - Player Achievement Data

/// Achievement data for a single player
struct PlayerAchievementData: Codable {
    var unlockedAchievementIDs: Set<String>
    var levelCompletions: [String: Int]  // "mode_isPro" -> highest level completed
    
    init() {
        self.unlockedAchievementIDs = []
        self.levelCompletions = [:]
    }
}

/// Tracks player progression and unlocked achievements
@Observable
class AchievementStore {
    private let storageKey = "tk_achievements_per_player"  // New key for per-player storage
    private let playersStorageKey = "tk_players"  // Storage key for player list
    private let legacyStorageKey = "tk_achievements"  // Old global key
    private let legacyProgressKey = "tk_achievement_progress"  // Old global key
    
    /// Per-player achievement data
    private var playerAchievements: [String: PlayerAchievementData] = [:]
    
    /// List of all created players
    private var players: Set<String> = []
    
    /// Currently active player name
    var currentPlayerName: String = "Player" {
        didSet {
            if oldValue != currentPlayerName {
                // Ensure new player exists in the player list
                if !players.contains(currentPlayerName) {
                    createPlayer(name: currentPlayerName)
                }
            }
        }
    }
    
    /// IDs of unlocked achievements for current player
    var unlockedAchievementIDs: Set<String> {
        get {
            return playerAchievements[currentPlayerName]?.unlockedAchievementIDs ?? []
        }
        set {
            if playerAchievements[currentPlayerName] == nil {
                playerAchievements[currentPlayerName] = PlayerAchievementData()
            }
            playerAchievements[currentPlayerName]?.unlockedAchievementIDs = newValue
        }
    }
    
    /// Track Level completions for current player: "mode_isPro" -> highest level
    var levelCompletions: [String: Int] {
        get {
            return playerAchievements[currentPlayerName]?.levelCompletions ?? [:]
        }
        set {
            if playerAchievements[currentPlayerName] == nil {
                playerAchievements[currentPlayerName] = PlayerAchievementData()
            }
            playerAchievements[currentPlayerName]?.levelCompletions = newValue
        }
    }
    
    init() {
        load()
        loadPlayers()
        
        // Ensure current player exists in the player list
        if !players.contains(currentPlayerName) {
            createPlayer(name: currentPlayerName)
        }
    }
    
    /// Get list of all player names (from player list, not just those with achievements)
    func getAllPlayerNames() -> [String] {
        return Array(players).sorted()
    }
    
    /// Get achievement count for a player
    func getAchievementCount(for playerName: String) -> Int {
        return playerAchievements[playerName]?.unlockedAchievementIDs.count ?? 0
    }
    
    /// Check if a player exists
    func playerExists(name: String) -> Bool {
        return players.contains(name)
    }
    
    /// Create a new player and persist immediately
    func createPlayer(name: String) {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else { return }
        
        players.insert(trimmedName)
        savePlayers()
        
        // Initialize empty achievement data for the player if not exists
        if playerAchievements[trimmedName] == nil {
            playerAchievements[trimmedName] = PlayerAchievementData()
            save()
        }
    }
    
    /// Delete a player and their achievement data
    func deletePlayer(name: String) {
        players.remove(name)
        playerAchievements.removeValue(forKey: name)
        savePlayers()
        save()
    }
    
    /// Check if Dev Mode is active (player name is "Wulf")
    func isDevMode(playerName: String) -> Bool {
        let normalized = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.caseInsensitiveCompare("Wulf") == .orderedSame
    }
    
    /// Check if an achievement is unlocked
    func isUnlocked(_ achievementID: String) -> Bool {
        return unlockedAchievementIDs.contains(achievementID)
    }
    
    /// Check if a mode is unlocked based on level progression
    func isModeUnlocked(mode: GameMode, isPro: Bool, playerName: String = "") -> Bool {
        // Dev Mode: Everything is unlocked
        if isDevMode(playerName: playerName) {
            return true
        }
        
        // Colors mode standard is always unlocked
        if mode == .colors && !isPro {
            return true
        }
        
        // Get highest level reached across all standard modes
        let highestStandardLevel = max(
            getHighestLevel(mode: .colors, isPro: false),
            getHighestLevel(mode: .shapes, isPro: false),
            getHighestLevel(mode: .emojis, isPro: false)
        )
        
        // Check for shapes mode unlock (need to reach level 10)
        if mode == .shapes && !isPro {
            return highestStandardLevel >= 10
        }
        
        // Check for emoji mode unlock (need to reach level 20)
        if mode == .emojis && !isPro {
            return highestStandardLevel >= 20
        }
        
        // Check for Pro mode unlock (need to reach level 30 in any standard mode)
        if isPro {
            return highestStandardLevel >= 30
        }
        
        return false
    }
    
    /// Get the highest level reached for a specific mode
    func getHighestLevel(mode: GameMode, isPro: Bool) -> Int {
        let key = "\(mode.rawValue)_\(isPro)"
        return levelCompletions[key] ?? 0
    }
    
    /// Mark that a level was completed for a specific configuration
    func markLevelCompletion(level: Int, mode: GameMode, isPro: Bool) {
        let key = "\(mode.rawValue)_\(isPro)"
        let currentHighest = levelCompletions[key] ?? 0
        if level > currentHighest {
            levelCompletions[key] = level
        }
        save()
    }
    
    /// Check and unlock new achievements based on current progress
    /// Returns array of newly unlocked achievement IDs
    func checkAndUnlockAchievements() -> [String] {
        var newlyUnlocked: [String] = []
        
        for achievement in Achievement.all {
            // Skip if already unlocked
            if isUnlocked(achievement.id) {
                continue
            }
            
            // Check if conditions are met
            let shouldUnlock: Bool
            switch achievement.unlockCondition {
            case .reachLevel(let requiredLevel, let mode, let isPro):
                let key = "\(mode)_\(isPro)"
                let highestLevel = levelCompletions[key] ?? 0
                shouldUnlock = highestLevel >= requiredLevel
                
            case .reachLevelInAllModes(let requiredLevel):
                // Check if all 6 mode combinations reached the required level
                let allModes: [(String, Bool)] = [
                    ("colors", false), ("shapes", false), ("emojis", false),
                    ("colors", true), ("shapes", true), ("emojis", true)
                ]
                shouldUnlock = allModes.allSatisfy { mode, isPro in
                    let key = "\(mode)_\(isPro)"
                    return (levelCompletions[key] ?? 0) >= requiredLevel
                }
            }
            
            if shouldUnlock {
                unlockedAchievementIDs.insert(achievement.id)
                newlyUnlocked.append(achievement.id)
            }
        }
        
        if !newlyUnlocked.isEmpty {
            save()
        }
        
        return newlyUnlocked
    }
    
    private func save() {
        // Save per-player achievements
        if let encoded = try? JSONEncoder().encode(playerAchievements) {
            UserDefaults.standard.set(encoded, forKey: storageKey)
        }
    }
    
    private func savePlayers() {
        // Save player list
        if let encoded = try? JSONEncoder().encode(Array(players)) {
            UserDefaults.standard.set(encoded, forKey: playersStorageKey)
        }
    }
    
    private func load() {
        // Try to load per-player achievements first
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let decoded = try? JSONDecoder().decode([String: PlayerAchievementData].self, from: data) {
            playerAchievements = decoded
            return
        }
        
        // If no per-player data exists, migrate from old global storage
        migrateLegacyAchievements()
    }
    
    private func loadPlayers() {
        // Try to load player list
        if let data = UserDefaults.standard.data(forKey: playersStorageKey),
           let decoded = try? JSONDecoder().decode([String].self, from: data) {
            players = Set(decoded)
        }
        
        // Ensure all players with achievement data are in the player list (migration)
        for playerName in playerAchievements.keys {
            if !players.contains(playerName) {
                players.insert(playerName)
            }
        }
        
        // Save player list if we added any from achievement data
        if !players.isEmpty {
            savePlayers()
        }
    }
    
    /// Migrate achievements from old global storage to per-player storage
    private func migrateLegacyAchievements() {
        var legacyData = PlayerAchievementData()
        
        // Load old unlocked achievements
        if let data = UserDefaults.standard.data(forKey: legacyStorageKey),
           let decoded = try? JSONDecoder().decode([String].self, from: data) {
            legacyData.unlockedAchievementIDs = Set(decoded)
        }
        
        // Load old progress - convert old level5Completions to new format
        if let data = UserDefaults.standard.data(forKey: legacyProgressKey),
           let decoded = try? JSONDecoder().decode([String: Bool].self, from: data) {
            // Old format: "2x2_colors_false" -> true
            // New format: "colors_false" -> 5 (level completed)
            // For migration, we'll extract the mode and isPro, set highest to 5 if completed
            for (key, completed) in decoded where completed {
                let parts = key.split(separator: "_")
                if parts.count == 3 {
                    let mode = String(parts[1])
                    let isPro = parts[2] == "true"
                    let newKey = "\(mode)_\(isPro)"
                    // Set to 5 since old system only tracked level 5 completions
                    let currentMax = legacyData.levelCompletions[newKey] ?? 0
                    legacyData.levelCompletions[newKey] = max(currentMax, 5)
                }
            }
        }
        
        // If we found any legacy data, migrate it to the default player
        if !legacyData.unlockedAchievementIDs.isEmpty || !legacyData.levelCompletions.isEmpty {
            playerAchievements["Player"] = legacyData
            players.insert("Player")
            save()  // Save migrated data
            savePlayers()
        }
    }
}

// MARK: - Achievement Definitions

extension Achievement {
    static let all: [Achievement] = [
        // Early Achievements (3) - Level 5
        Achievement(
            id: "color_cadet",
            nameKey: "AchievementColorCadet",
            iconEmoji: "🎨",
            explanationKey: "AchievementColorCadetExplanation",
            unlockCondition: .reachLevel(5, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "shape_novice",
            nameKey: "AchievementShapeNovice",
            iconEmoji: "🔺",
            explanationKey: "AchievementShapeNoviceExplanation",
            unlockCondition: .reachLevel(5, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_apprentice",
            nameKey: "AchievementEmojiApprentice",
            iconEmoji: "😊",
            explanationKey: "AchievementEmojiApprenticeExplanation",
            unlockCondition: .reachLevel(5, mode: "emojis", isPro: false)
        ),
        
        // Unlocking Achievements (3) - These unlock new modes
        Achievement(
            id: "polygon_prodigy",
            nameKey: "AchievementPolygonProdigy",
            iconEmoji: "🔷",
            explanationKey: "AchievementPolygonProdigyExplanation",
            unlockCondition: .reachLevel(10, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "smiley_summoner",
            nameKey: "AchievementSmileySummoner",
            iconEmoji: "😎",
            explanationKey: "AchievementSmileySummonerExplanation",
            unlockCondition: .reachLevel(20, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "ultra_instinct",
            nameKey: "AchievementUltraInstinct",
            iconEmoji: "🔥",
            explanationKey: "AchievementUltraInstinctExplanation",
            unlockCondition: .reachLevel(30, mode: "colors", isPro: false)
        ),
        
        // Intermediate Achievements (3) - Level 15
        Achievement(
            id: "rainbow_wrangler",
            nameKey: "AchievementRainbowWrangler",
            iconEmoji: "🌈",
            explanationKey: "AchievementRainbowWranglerExplanation",
            unlockCondition: .reachLevel(15, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "triangle_tamer",
            nameKey: "AchievementTriangleTamer",
            iconEmoji: "📐",
            explanationKey: "AchievementTriangleTamerExplanation",
            unlockCondition: .reachLevel(15, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_enthusiast",
            nameKey: "AchievementEmojiEnthusiast",
            iconEmoji: "🤩",
            explanationKey: "AchievementEmojiEnthusiastExplanation",
            unlockCondition: .reachLevel(15, mode: "emojis", isPro: false)
        ),
        
        // Advanced Achievements (3) - Level 25
        Achievement(
            id: "color_virtuoso",
            nameKey: "AchievementColorVirtuoso",
            iconEmoji: "🎭",
            explanationKey: "AchievementColorVirtuosoExplanation",
            unlockCondition: .reachLevel(25, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "shape_master",
            nameKey: "AchievementShapeMaster",
            iconEmoji: "⬢",
            explanationKey: "AchievementShapeMasterExplanation",
            unlockCondition: .reachLevel(25, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_expert",
            nameKey: "AchievementEmojiExpert",
            iconEmoji: "😎",
            explanationKey: "AchievementEmojiExpertExplanation",
            unlockCondition: .reachLevel(25, mode: "emojis", isPro: false)
        ),
        
        // Mastery Achievements (3) - Level 30 Standard
        Achievement(
            id: "chromatic_champion",
            nameKey: "AchievementChromaticChampion",
            iconEmoji: "🎨",
            explanationKey: "AchievementChromaticChampionExplanation",
            unlockCondition: .reachLevel(30, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "geometry_genius",
            nameKey: "AchievementGeometryGenius",
            iconEmoji: "🔷",
            explanationKey: "AchievementGeometryGeniusExplanation",
            unlockCondition: .reachLevel(30, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_overlord",
            nameKey: "AchievementEmojiOverlord",
            iconEmoji: "😄",
            explanationKey: "AchievementEmojiOverlordExplanation",
            unlockCondition: .reachLevel(30, mode: "emojis", isPro: false)
        ),
        
        // Pro Mastery Achievements (3) - Level 30 Pro
        Achievement(
            id: "rainbow_annihilator",
            nameKey: "AchievementRainbowAnnihilator",
            iconEmoji: "🔥🌈",
            explanationKey: "AchievementRainbowAnnihilatorExplanation",
            unlockCondition: .reachLevel(30, mode: "colors", isPro: true)
        ),
        Achievement(
            id: "shape_sorcerer",
            nameKey: "AchievementShapeSorcerer",
            iconEmoji: "🔥📐",
            explanationKey: "AchievementShapeSorcererExplanation",
            unlockCondition: .reachLevel(30, mode: "shapes", isPro: true)
        ),
        Achievement(
            id: "emoji_apocalypse",
            nameKey: "AchievementEmojiApocalypse",
            iconEmoji: "🔥😈",
            explanationKey: "AchievementEmojiApocalypseExplanation",
            unlockCondition: .reachLevel(30, mode: "emojis", isPro: true)
        ),
        
        // Ultimate Achievement (1)
        Achievement(
            id: "the_unkillable",
            nameKey: "AchievementTheUnkillable",
            iconEmoji: "💀",
            explanationKey: "AchievementTheUnkillableExplanation",
            unlockCondition: .reachLevelInAllModes(30)
        )
    ]
}

