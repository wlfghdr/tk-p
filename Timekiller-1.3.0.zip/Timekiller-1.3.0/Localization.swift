//
//  Localization.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation

// MARK: - Localization Helper

func L(_ key: String, language: String = "de") -> String {
    let translations: [String: [String: String]] = [
        // Game UI
        "Title": ["de": "Timekiller", "en": "Timekiller"],
        "Start": ["de": "Start", "en": "Start"],
        "Pause": ["de": "Pause", "en": "Pause"],
        "Resume": ["de": "Weiter", "en": "Resume"],
        "Quit": ["de": "Ende", "en": "Quit"],
        "Settings": ["de": "Einstellungen", "en": "Settings"],
        "Highscores": ["de": "Highscores", "en": "Highscores"],
        "Score": ["de": "Punkte", "en": "Score"],
        "Level": ["de": "Level", "en": "Level"],
        "Round": ["de": "Runde", "en": "Round"],
        "TotalScore": ["de": "Gesamt", "en": "Total"],
        "LevelScore": ["de": "Level", "en": "Level"],
        "Done": ["de": "Fertig", "en": "Done"],
        "Tap": ["de": "Tippe auf", "en": "Tap"],
        "Continue": ["de": "Weiter", "en": "Next"],
        // Level Complete & Next Level Info
        "LevelComplete": ["de": "Abgeschlossen!", "en": "Complete!"],
        "ScorePerLevel": ["de": "Score pro Level", "en": "Score per Level"],
        "NextLevelPreview": ["de": "Nächstes Level", "en": "Next Level"],
        "NextLevelInfo_GridSize": ["de": "Größeres Spielfeld", "en": "Larger Grid"],
        "NextLevelInfo_MultipleAnswers": ["de": "Mehrere richtige Antworten finden", "en": "Find Multiple Correct Answers"],
        "NextLevelInfo_TimeReduction": ["de": "Zeit wird verkürzt", "en": "Time Reduced"],
        "NextLevelInfo_GridSize_2x4": ["de": "Spielfeld: 2×4 (8 Kacheln)", "en": "Grid: 2×4 (8 Tiles)"],
        "NextLevelInfo_GridSize_3x5": ["de": "Spielfeld: 3×5 (15 Kacheln)", "en": "Grid: 3×5 (15 Tiles)"],
        "NextLevelInfo_DoubleAnswers": ["de": "Finde 2 richtige Antworten", "en": "Find 2 Correct Answers"],
        "NextLevelInfo_TripleAnswers": ["de": "Finde 3 richtige Antworten", "en": "Find 3 Correct Answers"],
        "NextLevelInfo_QuadAnswers": ["de": "Finde 4 richtige Antworten", "en": "Find 4 Correct Answers"],
        
        "Example": ["de": "Beispiel", "en": "Example"],
        "Theme": ["de": "Theme", "en": "Theme"],
        "ThemeSystem": ["de": "System", "en": "System"],
        "ThemeLight": ["de": "Hell", "en": "Light"],
        "ThemeDark": ["de": "Dunkel", "en": "Dark"],
        
        // Summary View
        "GameOver": ["de": "Spiel Beendet", "en": "Game Over"],
        "YourScore": ["de": "Deine Punktzahl", "en": "Your Score"],
        "ReachedLevel": ["de": "Erreichtes Level", "en": "Reached Level"],
        "Restart": ["de": "Neustart", "en": "Restart"],
        
        // Settings
        "PlayerName": ["de": "Spielername", "en": "Player Name"],
        "Language": ["de": "Sprache", "en": "Language"],
        "German": ["de": "Deutsch", "en": "German"],
        "English": ["de": "Englisch", "en": "English"],
        "GameMode": ["de": "Spielmodus", "en": "Game Mode"],
        "ProMode": ["de": "Pro-Modus", "en": "Pro Mode"],
        "PointsMultiplier": ["de": "Punkte", "en": "Points"],
        "Colors": ["de": "Farben", "en": "Colors"],
        "Shapes": ["de": "Formen", "en": "Shapes"],
        "Emojis": ["de": "Emojis", "en": "Emojis"],
        
        // Sound & Haptics Settings
        "Sound": ["de": "Sound", "en": "Sound"],
        "Haptics": ["de": "Haptik", "en": "Haptics"],
        "Feedback": ["de": "Feedback", "en": "Feedback"],
        
        // Highscores
        "NoHighscores": ["de": "Keine Highscores", "en": "No Highscores"],
        "TopScores": ["de": "Top 3", "en": "Top 3"],
        "ClearAll": ["de": "Alle löschen", "en": "Clear All"],
        "Delete": ["de": "Löschen", "en": "Delete"],
        
        // Instructions
        "InstructionTitle": ["de": "Wie wird gespielt?", "en": "How to Play?"],
        "InstructionText": ["de": "Tippe auf die Kachel, deren Text zur richtigen Farbe passt!", "en": "Tap the tile whose text matches the correct color!"],
        "InstructionTextColors": ["de": "Tippe auf die Kachel, deren Text zur Hintergrundfarbe passt! Beispiel: Wenn \"Blau\" auf blauem Hintergrund steht, ist das richtig!", "en": "Tap the tile where the text matches the background color! Example: If \"Blue\" is on a blue background, that's correct!"],
        "InstructionTextShapes": ["de": "Tippe auf die Kachel, deren Text zur Form passt! Die Formen werden bei jedem Spiel neu gemischt. 1,2x Punkte!", "en": "Tap the tile where the text matches the shape! Shapes are randomized each game. 1.2x points!"],
        "InstructionTextEmojis": ["de": "Tippe auf die Kachel, deren Text zum Emoji passt! Die Emojis werden bei jedem Spiel neu gemischt. 2x Punkte!", "en": "Tap the tile where the text matches the emoji! Emojis are randomized each game. 2x points!"],
        
        // Colors
        "Red": ["de": "Rot", "en": "Red"],
        "Blue": ["de": "Blau", "en": "Blue"],
        "Green": ["de": "Grün", "en": "Green"],
        "Yellow": ["de": "Gelb", "en": "Yellow"],
        "Orange": ["de": "Orange", "en": "Orange"],
        "Purple": ["de": "Lila", "en": "Purple"],
        "Brown": ["de": "Braun", "en": "Brown"],
        "Cyan": ["de": "Cyan", "en": "Cyan"],
        "Gray": ["de": "Grau", "en": "Gray"],
        "Indigo": ["de": "Indigo", "en": "Indigo"],
        "Mint": ["de": "Mint", "en": "Mint"],
        "Teal": ["de": "Türkis", "en": "Teal"],
        "Pink": ["de": "Rosa", "en": "Pink"],
        "Violet": ["de": "Violett", "en": "Violet"],
        "Tan": ["de": "Beige", "en": "Tan"],
        "Silver": ["de": "Silber", "en": "Silver"],
        
        // Shapes
        "ShapeCircle": ["de": "Kreis", "en": "Circle"],
        "ShapeSquare": ["de": "Quadrat", "en": "Square"],
        "ShapeTriangle": ["de": "Dreieck", "en": "Triangle"],
        "ShapeStar": ["de": "Stern", "en": "Star"],
        "ShapeDiamond": ["de": "Raute", "en": "Diamond"],
        "ShapeHeart": ["de": "Herz", "en": "Heart"],
        "ShapeHexagon": ["de": "Sechseck", "en": "Hexagon"],
        "ShapeHexagonOutline": ["de": "Sechseck-Umriss", "en": "Hexagon Outline"],
        "ShapeTriangleDown": ["de": "Dreieck unten", "en": "Triangle Down"],
        "ShapeDiamondFilled": ["de": "Raute gefüllt", "en": "Diamond Filled"],
        "ShapeStarOutline": ["de": "Stern-Umriss", "en": "Star Outline"],
        "ShapeCircleOutline": ["de": "Kreis-Umriss", "en": "Circle Outline"],
        "ShapeSquareSmall": ["de": "Kleines Quadrat", "en": "Small Square"],
        "ShapeTriangleRight": ["de": "Dreieck rechts", "en": "Triangle Right"],
        "ShapeTriangleLeft": ["de": "Dreieck links", "en": "Triangle Left"],
        "ShapeSpade": ["de": "Pik", "en": "Spade"],
        "ShapeClub": ["de": "Kreuz", "en": "Club"],
        "ShapeStarEmpty": ["de": "Leerer Stern", "en": "Empty Star"],
        "ShapeStarCircled": ["de": "Stern im Kreis", "en": "Star Circled"],
        "ShapeBullseye": ["de": "Zielscheibe", "en": "Bullseye"],
        "ShapeTarget": ["de": "Ziel", "en": "Target"],
        "ShapeSquareLarge": ["de": "Großes Quadrat", "en": "Large Square"],
        "ShapeSquareWhite": ["de": "Weißes Quadrat", "en": "White Square"],
        "ShapePlus": ["de": "Plus", "en": "Plus"],
        
        // Game Modes
        "ModeColors": ["de": "Farben", "en": "Colors"],
        "ModeShapes": ["de": "Formen", "en": "Shapes"],
        "ModeEmojis": ["de": "Emojis", "en": "Emojis"],
        
        // Emojis - Faces & Emotions
        "EmojiGrinning": ["de": "Grinsend", "en": "Grinning"],
        "EmojiLaughing": ["de": "Lachend", "en": "Laughing"],
        "EmojiHeart": ["de": "Herzaugen", "en": "Heart Eyes"],
        "EmojiThinking": ["de": "Denkend", "en": "Thinking"],
        "EmojiCool": ["de": "Cool", "en": "Cool"],
        "EmojiMindBlown": ["de": "Kopfexplosion", "en": "Mind Blown"],
        "EmojiParty": ["de": "Party", "en": "Party"],
        "EmojiSleepy": ["de": "Schlafend", "en": "Sleepy"],
        "EmojiMoney": ["de": "Geld", "en": "Money"],
        "EmojiCowboy": ["de": "Cowboy", "en": "Cowboy"],
        "EmojiClown": ["de": "Clown", "en": "Clown"],
        "EmojiAngel": ["de": "Engel", "en": "Angel"],
        "EmojiDevil": ["de": "Teufel", "en": "Devil"],
        "EmojiFreezing": ["de": "Frierend", "en": "Freezing"],
        "EmojiHot": ["de": "Heiß", "en": "Hot"],
        "EmojiNauseated": ["de": "Übel", "en": "Nauseated"],
        "EmojiNerd": ["de": "Nerd", "en": "Nerd"],
        "EmojiMonocle": ["de": "Monokel", "en": "Monocle"],
        "EmojiScreaming": ["de": "Schreiend", "en": "Screaming"],
        "EmojiZipper": ["de": "Reißverschluss", "en": "Zipper"],
        
        // Emojis - Creatures & Fantasy
        "EmojiGhost": ["de": "Geist", "en": "Ghost"],
        "EmojiAlien": ["de": "Alien", "en": "Alien"],
        "EmojiRobot": ["de": "Roboter", "en": "Robot"],
        "EmojiPumpkin": ["de": "Kürbis", "en": "Pumpkin"],
        "EmojiSkull": ["de": "Totenkopf", "en": "Skull"],
        "EmojiOgre": ["de": "Oger", "en": "Ogre"],
        "EmojiGoblin": ["de": "Goblin", "en": "Goblin"],
        "EmojiUnicorn": ["de": "Einhorn", "en": "Unicorn"],
        "EmojiDragon": ["de": "Drache", "en": "Dragon"],
        "EmojiDino": ["de": "Dino", "en": "Dino"],
        "EmojiOctopus": ["de": "Oktopus", "en": "Octopus"],
        "EmojiSquid": ["de": "Tintenfisch", "en": "Squid"],
        "EmojiShark": ["de": "Hai", "en": "Shark"],
        "EmojiCrocodile": ["de": "Krokodil", "en": "Crocodile"],
        "EmojiLizard": ["de": "Eidechse", "en": "Lizard"],
        
        // Emojis - Animals
        "EmojiDog": ["de": "Hund", "en": "Dog"],
        "EmojiCat": ["de": "Katze", "en": "Cat"],
        "EmojiMouse": ["de": "Maus", "en": "Mouse"],
        "EmojiPanda": ["de": "Panda", "en": "Panda"],
        "EmojiLion": ["de": "Löwe", "en": "Lion"],
        "EmojiTiger": ["de": "Tiger", "en": "Tiger"],
        "EmojiFrog": ["de": "Frosch", "en": "Frog"],
        "EmojiFox": ["de": "Fuchs", "en": "Fox"],
        "EmojiMonkey": ["de": "Affe", "en": "Monkey"],
        "EmojiChicken": ["de": "Huhn", "en": "Chicken"],
        
        // Emojis - Objects & Symbols
        "EmojiPoop": ["de": "Kackhaufen", "en": "Poop"],
        "EmojiFire": ["de": "Feuer", "en": "Fire"],
        "EmojiStar": ["de": "Stern", "en": "Star"],
        "EmojiDiamond": ["de": "Diamant", "en": "Diamond"],
        "EmojiCrown": ["de": "Krone", "en": "Crown"],
        "EmojiTarget": ["de": "Zielscheibe", "en": "Target"],
        "EmojiGamepad": ["de": "Controller", "en": "Gamepad"],
        "EmojiDice": ["de": "Würfel", "en": "Dice"],
        "EmojiTent": ["de": "Zirkuszelt", "en": "Circus Tent"],
        "EmojiRocket": ["de": "Rakete", "en": "Rocket"],
        "EmojiLightning": ["de": "Blitz", "en": "Lightning"],
        "EmojiBoom": ["de": "Knall", "en": "Boom"],
        "EmojiDizzy": ["de": "Schwindelig", "en": "Dizzy"],
        "EmojiRainbow": ["de": "Regenbogen", "en": "Rainbow"],
        "EmojiMoon": ["de": "Mond", "en": "Moon"],
        "EmojiSun": ["de": "Sonne", "en": "Sun"],
        "EmojiPizza": ["de": "Pizza", "en": "Pizza"],
        "EmojiBurger": ["de": "Burger", "en": "Burger"],
        "EmojiConfetti": ["de": "Konfetti", "en": "Confetti"],
        
        // Achievements - NEW SYSTEM (18 Achievements)
        // Early Achievements (3) - Level 5
        "AchievementColorCadet": ["de": "Farb-Kadett", "en": "Color Cadet"],
        "AchievementColorCadetExplanation": ["de": "Erreiche Level 5 in Farben Standard", "en": "Reach Level 5 in Colors Standard"],
        "AchievementShapeNovice": ["de": "Form-Anfänger", "en": "Shape Novice"],
        "AchievementShapeNoviceExplanation": ["de": "Erreiche Level 5 in Formen Standard", "en": "Reach Level 5 in Shapes Standard"],
        "AchievementEmojiApprentice": ["de": "Emoji-Lehrling", "en": "Emoji Apprentice"],
        "AchievementEmojiApprenticeExplanation": ["de": "Erreiche Level 5 in Emojis Standard", "en": "Reach Level 5 in Emojis Standard"],
        
        // Unlocking Achievements (3)
        "AchievementPolygonProdigy": ["de": "Polygon-Profi", "en": "Polygon Prodigy"],
        "AchievementPolygonProdigyExplanation": ["de": "Erreiche Level 10 in Farben Standard – Schaltet Formen-Modus frei", "en": "Reach Level 10 in Colors Standard – Unlocks Shapes Mode"],
        "AchievementSmileySummoner": ["de": "Smiley-Beschwörer", "en": "Smiley Summoner"],
        "AchievementSmileySummonerExplanation": ["de": "Erreiche Level 20 in Farben Standard – Schaltet Emoji-Modus frei", "en": "Reach Level 20 in Colors Standard – Unlocks Emoji Mode"],
        "AchievementUltraInstinct": ["de": "Ultra Instinkt", "en": "Ultra Instinct"],
        "AchievementUltraInstinctExplanation": ["de": "Erreiche Level 30 in einem Standard-Modus – Schaltet Pro-Modus frei", "en": "Reach Level 30 in any Standard Mode – Unlocks Pro Mode"],
        
        // Intermediate Achievements (3 - Level 15)
        "AchievementRainbowWrangler": ["de": "Regenbogen-Bändiger", "en": "Rainbow Wrangler"],
        "AchievementRainbowWranglerExplanation": ["de": "Erreiche Level 15 in Farben Standard", "en": "Reach Level 15 in Colors Standard"],
        "AchievementTriangleTamer": ["de": "Dreieck-Zähmer", "en": "Triangle Tamer"],
        "AchievementTriangleTamerExplanation": ["de": "Erreiche Level 15 in Formen Standard", "en": "Reach Level 15 in Shapes Standard"],
        "AchievementEmojiEnthusiast": ["de": "Emoji-Enthusiast", "en": "Emoji Enthusiast"],
        "AchievementEmojiEnthusiastExplanation": ["de": "Erreiche Level 15 in Emojis Standard", "en": "Reach Level 15 in Emojis Standard"],
        
        // Advanced Achievements (3 - Level 25)
        "AchievementColorVirtuoso": ["de": "Farb-Virtuose", "en": "Color Virtuoso"],
        "AchievementColorVirtuosoExplanation": ["de": "Erreiche Level 25 in Farben Standard", "en": "Reach Level 25 in Colors Standard"],
        "AchievementShapeMaster": ["de": "Form-Meister", "en": "Shape Master"],
        "AchievementShapeMasterExplanation": ["de": "Erreiche Level 25 in Formen Standard", "en": "Reach Level 25 in Shapes Standard"],
        "AchievementEmojiExpert": ["de": "Emoji-Experte", "en": "Emoji Expert"],
        "AchievementEmojiExpertExplanation": ["de": "Erreiche Level 25 in Emojis Standard", "en": "Reach Level 25 in Emojis Standard"],
        
        // Mastery Achievements (3 - Level 30 Standard)
        "AchievementChromaticChampion": ["de": "Chromatischer Champion", "en": "Chromatic Champion"],
        "AchievementChromaticChampionExplanation": ["de": "Erreiche Level 30 in Farben Standard", "en": "Reach Level 30 in Colors Standard"],
        "AchievementGeometryGenius": ["de": "Geometrie-Genie", "en": "Geometry Genius"],
        "AchievementGeometryGeniusExplanation": ["de": "Erreiche Level 30 in Formen Standard", "en": "Reach Level 30 in Shapes Standard"],
        "AchievementEmojiOverlord": ["de": "Emoji-Oberherr", "en": "Emoji Overlord"],
        "AchievementEmojiOverlordExplanation": ["de": "Erreiche Level 30 in Emojis Standard", "en": "Reach Level 30 in Emojis Standard"],
        
        // Pro Mastery Achievements (3 - Level 30 Pro)
        "AchievementRainbowAnnihilator": ["de": "Regenbogen-Vernichter", "en": "Rainbow Annihilator"],
        "AchievementRainbowAnnihilatorExplanation": ["de": "Erreiche Level 30 in Farben Pro", "en": "Reach Level 30 in Colors Pro"],
        "AchievementShapeSorcerer": ["de": "Formen-Zauberer Supremo", "en": "Shape Sorcerer Supreme"],
        "AchievementShapeSorcererExplanation": ["de": "Erreiche Level 30 in Formen Pro", "en": "Reach Level 30 in Shapes Pro"],
        "AchievementEmojiApocalypse": ["de": "Emoji-Apokalypse", "en": "Emoji Apocalypse"],
        "AchievementEmojiApocalypseExplanation": ["de": "Erreiche Level 30 in Emojis Pro", "en": "Reach Level 30 in Emojis Pro"],
        
        // Ultimate Achievement (1)
        "AchievementTheUnkillable": ["de": "Der Unsterbliche", "en": "The Unkillable"],
        "AchievementTheUnkillableExplanation": ["de": "Erreiche Level 30 in allen 6 Modi", "en": "Reach Level 30 in all 6 modes"],
        
        // Achievement UI
        "NewAchievement": ["de": "Neue Errungenschaft!", "en": "New Achievement!"],
        "AchievementsEarned": ["de": "Errungenschaften", "en": "Achievements Earned"],
        "Locked": ["de": "Gesperrt", "en": "Locked"],
        "UnlockBy": ["de": "Freischalten durch:", "en": "Unlock by:"],
        "UnlockMessage": ["de": "Werde zum", "en": "Become"],
        "Achievements": ["de": "Errungenschaften", "en": "Achievements"],
        "AchievementsProgress": ["de": "Fortschritt", "en": "Progress"],
        "UnlockingAchievements": ["de": "Freischaltungen", "en": "Unlocking Achievements"],
        "EarlyAchievements": ["de": "Frühe Erfolge", "en": "Early Achievements"],
        "IntermediateAchievements": ["de": "Fortgeschritten", "en": "Intermediate"],
        "AdvancedAchievements": ["de": "Experten", "en": "Advanced"],
        "MasteryAchievements": ["de": "Meisterschaft", "en": "Mastery"],
        "ProMasteryAchievements": ["de": "Pro-Meisterschaft", "en": "Pro Mastery"],
        "UltimateAchievement": ["de": "Ultimativ", "en": "Ultimate"],
        
        // Dev Mode
        "DevMode": ["de": "🔧 Dev-Modus", "en": "🔧 Dev Mode"],
        "DevModeActive": ["de": "🔧 Dev-Modus Aktiv", "en": "🔧 Dev Mode Active"],
        "DevModeDescription": ["de": "Alle Features freigeschaltet", "en": "All features unlocked"],
        
        // Player Selection
        "SelectPlayer": ["de": "Spieler wählen", "en": "Select Player"],
        "CreateNewPlayer": ["de": "Neuen Spieler erstellen", "en": "Create New Player"],
        "EnterPlayerName": ["de": "Namen eingeben", "en": "Enter Name"],
        "ExistingPlayers": ["de": "Vorhandene Spieler", "en": "Existing Players"],
        "NewPlayer": ["de": "Neuer Spieler", "en": "New Player"],
        "SwitchPlayer": ["de": "Spieler wechseln", "en": "Switch Player"],
        "AchievementsCount": ["de": "Errungenschaften", "en": "Achievements"],
        "NoAchievements": ["de": "Keine Errungenschaften", "en": "No Achievements"],
        "DeletePlayer": ["de": "Spieler löschen", "en": "Delete Player"],
        "DeletePlayerConfirmation": ["de": "Spieler löschen?", "en": "Delete Player?"],
        "DeletePlayerMessage": ["de": "Möchtest du diesen Spieler und alle Errungenschaften wirklich löschen?", "en": "Do you really want to delete this player and all achievements?"],
        "Cancel": ["de": "Abbrechen", "en": "Cancel"],
        
        // About Section
        "About": ["de": "Über", "en": "About"],
        "Version": ["de": "Version", "en": "Version"],
        
        // Game Center
        "GameCenter": ["de": "Game Center", "en": "Game Center"],
        "OnlineMode": ["de": "Online-Modus", "en": "Online Mode"],
        "Status": ["de": "Status", "en": "Status"],
        "Connected": ["de": "Verbunden", "en": "Connected"],
        "NotConnected": ["de": "Nicht verbunden", "en": "Not Connected"],
        "GameCenterDescription": ["de": "Aktiviere den Online-Modus, um deine Highscores und Erfolge mit Game Center zu synchronisieren.", "en": "Enable online mode to sync your highscores and achievements with Game Center."],
        "GameCenterPlayer": ["de": "Game Center Spieler", "en": "Game Center Player"],
        "OnlineLeaderboards": ["de": "Online-Bestenlisten", "en": "Online Leaderboards"],
        "LocalHighscores": ["de": "Lokale Highscores", "en": "Local Highscores"],
        "ViewGlobalLeaderboards": ["de": "Weltweite Bestenliste", "en": "View Global Leaderboards"],
        "CompeteWithPlayers": ["de": "Tritt gegen Spieler weltweit an", "en": "Compete with players worldwide"],
        "ViewGameCenterAchievements": ["de": "Game Center Erfolge", "en": "Game Center Achievements"],
        "TrackYourProgress": ["de": "Verfolge deinen Fortschritt", "en": "Track your progress"],
        "GameCenterNotConnected": ["de": "Nicht mit Game Center verbunden", "en": "Not Connected to Game Center"],
        "EnableInSettings": ["de": "In den Einstellungen aktivieren", "en": "Enable in Settings"],
        "Leaderboard": ["de": "Bestenliste", "en": "Leaderboard"],
        "JoinGlobalLeaderboards": ["de": "Weltweiten Bestenlisten beitreten", "en": "Join Global Leaderboards"],
        "EnableGameCenterInSettings": ["de": "Game Center in Einstellungen aktivieren", "en": "Enable Game Center in Settings"],
        "TapToEnableGameCenter": ["de": "Tippen, um Game Center zu aktivieren", "en": "Tap to enable Game Center"],
        "CompeteWorldwide": ["de": "Messe dich mit Spielern weltweit", "en": "Compete with players worldwide"],
        
        // UI Hints
        "TapSettingsToChangeMode": ["de": "Tippe auf Einstellungen, um Modus zu ändern", "en": "Tap Settings to change mode"],
        
        // Difficulty & Mode Selection
        "Difficulty": ["de": "Schwierigkeit", "en": "Difficulty"],
        "StandardMode": ["de": "Standard", "en": "Standard"],
        "ProModeDescriptionColors": ["de": "16 statt 8 Farben", "en": "16 instead of 8 colors"],
        "ProModeDescriptionShapes": ["de": "24 statt 12 Formen", "en": "24 instead of 12 shapes"],
        "ProModeDescriptionEmojis": ["de": "64 statt 16 Emojis", "en": "64 instead of 16 emojis"]
    ]
    
    return translations[key]?[language] ?? key
}

// Helper function to get localized content name (colors, emojis, etc.)
func localizedContentName(_ nameKey: String, language: String) -> String {
    return L(nameKey, language: language)
}

// Legacy compatibility
func localizedColorName(_ nameKey: String, language: String) -> String {
    return L(nameKey, language: language)
}
