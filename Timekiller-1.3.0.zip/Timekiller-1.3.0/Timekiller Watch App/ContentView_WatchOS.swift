//
//  ContentView.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI

struct ContentView_WatchOS: View {
    // MARK: - App Storage (Settings)
    @AppStorage("tk_playerName") private var playerName: String = "Player"
    @AppStorage("tk_language") private var appLanguage: String = Self.defaultLanguage()
    // Grid size fixed to 2x2 for watchOS
    private let gridSize: GridSize = .grid2x2
    @AppStorage("tk_theme") private var appTheme: String = "system"  // system, light, dark
    @AppStorage("tk_startLevel") private var startLevel: Int = 1  // Which level to start at
    @AppStorage("tk_proMode") private var proMode: Bool = false  // Pro mode: 16 colors instead of 8
    @AppStorage("tk_gameMode") private var gameModeRaw: String = GameMode.colors.rawValue  // Game mode
    @AppStorage("tk_soundEnabled") private var soundEnabled: Bool = true  // Sound feedback
    @AppStorage("tk_hapticsEnabled") private var hapticsEnabled: Bool = true  // Haptic feedback
    
    // MARK: - Environment
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    
    // MARK: - Constants
    private let roundsPerLevel: Int = 6  // 6 rounds per level
    
    // MARK: - State
    @State private var highscoreStore = HighscoreStore()
    @State private var achievementStore = AchievementStore()
    @State private var feedbackManager = FeedbackManager.shared
    @State private var isPlaying = false
    @State private var showSettings = false
    @State private var showHighscores = false
    @State private var showSummary = false
    @State private var showLevelComplete = false
    @State private var isLowTimeWarningTriggered = false  // Track if warning was triggered
    @State private var showPlayerSelection = false  // Player selection sheet
    @State private var showLockAlert = false
    @State private var lockAlertMessage = ""
    
    // Game State
    @State private var level: Int = 1
    @State private var round: Int = 0
    @State private var totalScore: Int = 0
    @State private var levelScore: Int = 0
    @State private var levelScores: [Int: Int] = [:]  // Track score per level
    @State private var tiles: [TileData] = []
    @State private var timer: Timer?
    @State private var scoreDelta: Int? = nil
    @State private var timeRemaining: Double = 0
    @State private var timerProgress: Double = 1.0
    @State private var sessionShapes: [GameShape] = []  // Randomized shape set for this game session
    @State private var sessionEmojis: [GameEmoji] = []  // Randomized emoji set for this game session
    @State private var consecutiveTimeouts: Int = 0  // Track consecutive timeouts
    @State private var consecutiveWrongTaps: Int = 0  // Track consecutive wrong taps
    @State private var newAchievementsThisRun: [String] = []  // Track achievements earned in current game
    @State private var mistakesThisLevel: Int = 0  // Track mistakes (timeouts or wrong taps) in current level
    
    // MARK: - Computed Properties
    private var gameMode: GameMode {
        GameMode(rawValue: gameModeRaw) ?? .colors
    }
    
    private var availableColors: [GameColor] {
        proMode ? GameColor.proColors : GameColor.standardColors
    }
    
    private var availableShapes: [GameShape] {
        // Return the randomized session shapes if they exist, otherwise the full set
        if !sessionShapes.isEmpty {
            return sessionShapes
        }
        return proMode ? GameShape.proShapes : GameShape.standardShapes
    }
    
    private var availableEmojis: [GameEmoji] {
        // Return the randomized session emojis if they exist, otherwise the full set
        if !sessionEmojis.isEmpty {
            return sessionEmojis
        }
        return proMode ? GameEmoji.proEmojis : GameEmoji.standardEmojis
    }
    
    private var availableItems: Int {
        switch gameMode {
        case .colors:
            return availableColors.count
        case .shapes:
            return availableShapes.count
        case .emojis:
            return availableEmojis.count
        }
    }
    
    private var currentRoundDuration: Double {
        // Use the same baseTimeForLevel function as iOS, but adapted for 2x2 grid
        // watchOS always uses 2x2 grid, so we use the base time for that grid size
        let baseDuration: Double = 8.0  // 4 tiles: 8 seconds (same as iOS 2x2)
        
        // No time reduction for levels 1-24 (same as iOS)
        if level < 25 {
            return baseDuration
        }
        
        // From level 25 onwards: 5% reduction per level (same as iOS)
        let levelsAbove24 = level - 24
        let reductionFactor = pow(0.95, Double(levelsAbove24))
        return baseDuration * reductionFactor
    }
    
    /// Calculate score for the current round using the new simplified system (same as iOS)
    /// Base Points = 10 per round
    /// Level Bonus = level × 5
    /// Time Bonus = seconds remaining × 10
    /// Pro Multiplier = 1.5 (if Pro Mode, otherwise 1.0)
    /// Round Score = (Base + Level Bonus + Time Bonus) × Pro Multiplier
    private func calculateRoundScore(secondsRemaining: Double) -> Int {
        let basePoints = 10
        let levelBonus = level * 5
        let timeBonus = Int(secondsRemaining.rounded()) * 10
        
        let subtotal = basePoints + levelBonus + timeBonus
        let proMultiplier: Double = proMode ? 1.5 : 1.0
        
        return Int(Double(subtotal) * proMultiplier)
    }
    
    private var colorScheme: ColorScheme? {
        switch appTheme {
        case "light": return .light
        case "dark": return .dark
        default: return nil  // system
        }
    }
    
    // Dev Mode: Check if player name is "Wulf"
    private var isDevMode: Bool {
        return playerName == "Wulf"
    }
    
    // MARK: - Computed Properties for Display
    private var displayLevel: Int {
        // Show the configured start level if game hasn't started yet
        if !isPlaying && round == 0 {
            return startLevel
        }
        return level
    }
    
    // MARK: - Body
    var body: some View {
        NavigationStack {
            ZStack {
                // Main Content
                if isPlaying {
                    // Playing: Minimal header, maximize grid visibility
                    VStack(spacing: 4) {
                        // Dev Mode Auto-Solve Button
                        if isDevMode {
                            Button {
                                autoSolveRound()
                            } label: {
                                HStack(spacing: 4) {
                                    Image(systemName: "wand.and.stars")
                                        .font(.system(size: 8))
                                    Text("Auto")
                                        .font(.system(size: 9, weight: .bold))
                                }
                                .foregroundStyle(.white)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 3)
                                .background(
                                    Capsule()
                                        .fill(Color.orange)
                                )
                            }
                        }
                        
                        compactHeaderView
                        
                        VStack(spacing: 6) {
                            gridView
                                .transition(.scale.combined(with: .opacity))
                            
                            // Time Progress Bar (thinner for watchOS)
                            GeometryReader { geometry in
                                ZStack(alignment: .leading) {
                                    Rectangle()
                                        .fill(Color.gray.opacity(0.3))
                                        .frame(height: 4)
                                    
                                    Rectangle()
                                        .fill(timerProgress > 0.3 ? Color.green : Color.red)
                                        .frame(width: geometry.size.width * timerProgress, height: 4)
                                        .animation(.linear(duration: 0.1), value: timerProgress)
                                }
                                .cornerRadius(2)
                            }
                            .frame(height: 4)
                        }
                        
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal, 6)
                    .padding(.top, 2)
                } else {
                    // Not playing: Everything scrolls including header
                    startPromptView
                }
                
                // Score Delta Overlay
                if let delta = scoreDelta {
                    scoreDeltaOverlay(delta: delta)
                }
                
                // Level Complete Overlay
                if showLevelComplete {
                    levelCompleteOverlay
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    // Only show settings button on start screen (not during gameplay or pause)
                    if !isPlaying && round == 0 {
                        Button {
                            showSettings = true
                        } label: {
                            Image(systemName: "gear")
                                .imageScale(.small)
                        }
                    }
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    // Hide play/pause button when level complete screen is showing
                    if round > 0 && !showLevelComplete {
                        Button {
                            if isPlaying {
                                pauseGame()
                            } else {
                                startGame()
                            }
                        } label: {
                            Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                                .imageScale(.small)
                        }
                    } else if !showLevelComplete {
                        // Show highscores button on start screen
                        Button {
                            showHighscores = true
                        } label: {
                            Image(systemName: "list.number")
                                .imageScale(.small)
                        }
                    }
                }
            }
            .sheet(isPresented: $showSettings) {
                SettingsView(
                    playerName: $playerName,
                    appLanguage: $appLanguage,
                    appTheme: $appTheme,
                    proMode: $proMode,
                    gameModeRaw: $gameModeRaw,
                    soundEnabled: $soundEnabled,
                    hapticsEnabled: $hapticsEnabled,
                    showPlayerSelection: $showPlayerSelection,
                    achievementStore: achievementStore
                )
            }
            .onChange(of: soundEnabled) { _, newValue in
                feedbackManager.soundEnabled = newValue
            }
            .onChange(of: hapticsEnabled) { _, newValue in
                feedbackManager.hapticsEnabled = newValue
            }
            .onChange(of: proMode) { _, _ in
                if isPlaying || round > 0 {
                    resetGame()
                }
            }
            .onChange(of: gameModeRaw) { _, _ in
                if isPlaying || round > 0 {
                    resetGame()
                }
            }
            .onChange(of: appLanguage) { _, _ in
                if isPlaying || round > 0 {
                    resetGame()
                }
            }
            .sheet(isPresented: $showHighscores) {
                NavigationStack {
                    HighscoreListView(
                        store: highscoreStore,
                        language: appLanguage,
                        achievementStore: achievementStore,
                        playerName: playerName
                    )
                        .navigationTitle(L("Highscores", language: appLanguage))
                        .navigationBarTitleDisplayMode(.inline)
                }
            }
            .sheet(isPresented: $showSummary) {
                SummaryView(
                    level: level,
                    totalScore: totalScore,
                    levelScores: levelScores,
                    highscoreStore: highscoreStore,
                    language: appLanguage,
                    onRestart: {
                        showSummary = false
                        resetGame()
                    },
                    newAchievements: newAchievementsThisRun,
                    achievementStore: achievementStore,
                    playerName: playerName
                )
                .interactiveDismissDisabled()  // Prevent swipe-to-dismiss
            }
            .sheet(isPresented: $showPlayerSelection) {
                PlayerNameSelectionView_WatchOS(
                    playerName: $playerName,
                    achievementStore: achievementStore,
                    language: appLanguage
                )
            }
        }
        .preferredColorScheme(colorScheme)
        .alert(L("Locked", language: appLanguage), isPresented: $showLockAlert) {
            Button(L("Done", language: appLanguage), role: .cancel) { }
        } message: {
            Text(lockAlertMessage)
        }
        .onAppear {
            // Sync feedback manager settings on appear
            feedbackManager.soundEnabled = soundEnabled
            feedbackManager.hapticsEnabled = hapticsEnabled
            
            // Initialize achievement store with current player
            achievementStore.currentPlayerName = playerName
            
            // Validate current selections and reset to defaults if locked
            validateSelections()
        }
        .onChange(of: playerName) { _, newValue in
            // Update achievement store when player name changes
            achievementStore.currentPlayerName = newValue
            
            // Reset game if playing
            if isPlaying || round > 0 {
                resetGame()
            }
            
            // Revalidate selections for new player
            validateSelections()
        }
    }
    
    // MARK: - Compact Header View for watchOS
    private var compactHeaderView: some View {
        // Two rows for better visual hierarchy while staying compact
        VStack(spacing: 3) {
            // Top row: Level badge and round progress
            HStack(spacing: 4) {
                // Level badge with gradient
                HStack(spacing: 2) {
                    Image(systemName: "mountain.2.fill")
                        .font(.system(size: 8))
                    Text("L\(level)")
                        .font(.system(size: 11, weight: .bold))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(8)
                
                // Round progress dots (mini)
                HStack(spacing: 2) {
                    ForEach(1...roundsPerLevel, id: \.self) { roundNum in
                        Circle()
                            .fill(roundNum <= round ? Color.blue : Color.gray.opacity(0.3))
                            .frame(width: 4, height: 4)
                            .scaleEffect(roundNum == round && !reduceMotion ? 1.2 : 1.0)
                    }
                }
                .animation(reduceMotion ? .none : .spring(response: 0.3, dampingFraction: 0.6), value: round)
                
                Spacer(minLength: 2)
                
                // Timer indicator (simplified for space)
                HStack(spacing: 2) {
                    Image(systemName: "timer")
                        .font(.system(size: 8))
                        .foregroundStyle(timerProgress > 0.25 ? Color.green : Color.red)
                    Text(String(format: "%.1f", timeRemaining))
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundStyle(timerProgress > 0.25 ? Color.primary : Color.red)
                }
            }
            
            // Bottom row: Score with badges
            HStack(spacing: 4) {
                // Total score
                Text("\(totalScore)")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                    .contentTransition(.numericText())
                
                Spacer(minLength: 2)
                
                // Pro/Mode badges (if applicable)
                if proMode {
                    Image(systemName: "brain.head.profile")
                        .font(.system(size: 8))
                        .foregroundStyle(.white)
                        .padding(3)
                        .background(Circle().fill(Color.purple))
                }
                
                if gameMode == .shapes {
                    Text("⬟")
                        .font(.system(size: 8))
                        .padding(2)
                        .background(Circle().fill(Color.teal.opacity(0.3)))
                }
                
                if gameMode == .emojis {
                    Text("😀")
                        .font(.system(size: 8))
                        .padding(2)
                        .background(Circle().fill(Color.purple.opacity(0.3)))
                }
            }
        }
        .padding(.horizontal, 4)
        .padding(.vertical, 3)
        .background(
            RoundedRectangle(cornerRadius: 6)
                .fill(Color.black.opacity(0.15))
        )
        .cornerRadius(4)
    }
    
    // MARK: - Grid View
    private var gridView: some View {
        // Fixed 2x2 grid for watchOS
        let columns = Array(repeating: GridItem(.flexible(), spacing: 6), count: 2)
        
        return LazyVGrid(columns: columns, spacing: 6) {
            ForEach(tiles.indices, id: \.self) { index in
                let tile = tiles[index]
                Button {
                    handleTileTap(tile: tile)
                } label: {
                    ZStack {
                        Rectangle()
                            .fill(tile.backgroundColor)
                            .cornerRadius(6)
                            .shadow(radius: 1)
                        
                        VStack(spacing: 1) {
                            // Show emoji if in emoji mode
                            if let emoji = tile.visualContent {
                                Text(emoji)
                                    .font(.system(size: 20))
                            }
                            
                            // Show text label
                            Text(localizedContentName(tile.displayContent.nameKey, language: appLanguage))
                                .font(.system(size: 9, weight: .bold))
                                .foregroundStyle(textColorForTile(tile))
                                .multilineTextAlignment(.center)
                                .minimumScaleFactor(0.4)
                                .lineLimit(2)
                        }
                        .padding(3)
                    }
                    .frame(maxWidth: .infinity, minHeight: 55)
                }
                .buttonStyle(.plain)
            }
        }
    }
    
    // MARK: - Start Prompt View
    private var startPromptView: some View {
        ScrollView {
            VStack(spacing: 10) {
                // Only show header on normal start screen, not on pause screen
                if round == 0 || isPlaying {
                    compactHeaderView
                }
                
                // If game is paused (round > 0 but not playing), show pause screen
                if round > 0 && !isPlaying {
                    pauseScreenView
                } else {
                    // Normal start screen
                    startScreenView
                }
            }
            .padding(.horizontal, 6)
            .padding(.top, 2)
        }
    }
    
    private var pauseScreenView: some View {
        VStack(spacing: 12) {
            // Level & Round Info (compact)
            HStack(spacing: 4) {
                // Level badge
                HStack(spacing: 2) {
                    Image(systemName: "mountain.2.fill")
                        .font(.system(size: 8))
                    Text("L\(level)")
                        .font(.system(size: 11, weight: .bold))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(8)
                
                // Round progress dots (mini)
                HStack(spacing: 2) {
                    ForEach(1...roundsPerLevel, id: \.self) { roundNum in
                        Circle()
                            .fill(roundNum <= round ? Color.blue : Color.gray.opacity(0.3))
                            .frame(width: 4, height: 4)
                    }
                }
                
                Spacer()
                
                Text("\(round)/\(roundsPerLevel)")
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 6)
            .background(Color.gray.opacity(0.2))
            .cornerRadius(8)
            
            // Scores (compact)
            HStack(spacing: 8) {
                // Total Score
                VStack(spacing: 2) {
                    Text(L("TotalScore", language: appLanguage))
                        .font(.system(size: 9))
                        .foregroundStyle(.secondary)
                    Text("\(totalScore)")
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                }
                .frame(maxWidth: .infinity)
                
                // Level Score
                VStack(spacing: 2) {
                    Text(L("LevelScore", language: appLanguage))
                        .font(.system(size: 9))
                        .foregroundStyle(.secondary)
                    Text("\(levelScore)")
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundStyle(levelScore >= 0 ? Color.green : Color.red)
                }
                .frame(maxWidth: .infinity)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 8)
            .background(Color.gray.opacity(0.2))
            .cornerRadius(8)
            
            // Buttons - directly visible, no scrolling needed
            VStack(spacing: 8) {
                // Resume Button
                Button {
                    startGame()
                } label: {
                    HStack {
                        Image(systemName: "play.fill")
                        Text(L("Resume", language: appLanguage))
                    }
                    .font(.headline.bold())
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color.accentColor)
                    .cornerRadius(10)
                }
                .buttonStyle(.plain)
                
                // Quit Button
                Button {
                    quitGame()
                } label: {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                        Text(L("Quit", language: appLanguage))
                    }
                    .font(.caption.bold())
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color.red.opacity(0.8))
                    .cornerRadius(10)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 4)
    }
    
    private var startScreenView: some View {
        VStack(spacing: 8) {
            // Dev Mode Indicator (if active)
            if isDevMode {
                HStack(spacing: 4) {
                    Image(systemName: "wrench.and.screwdriver.fill")
                        .font(.system(size: 8))
                    Text("Dev Mode")
                        .font(.system(size: 9, weight: .bold))
                }
                .foregroundStyle(.orange)
                .padding(.horizontal, 8)
                .padding(.vertical, 3)
                .background(Color.orange.opacity(0.2))
                .cornerRadius(6)
            }
            
            // Game info (compact - minimal padding)
            VStack(spacing: 2) {
                HStack(spacing: 6) {
                    Image(systemName: gameModeIcon)
                        .font(.caption)
                    Text(L(gameMode.nameKey, language: appLanguage))
                        .font(.caption.bold())
                }
                
                Text(proMode ? L("ProMode", language: appLanguage) : L("StandardMode", language: appLanguage))
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 4)
            
            // Play Button
            Button {
                startGame()
            } label: {
                HStack {
                    Image(systemName: "play.fill")
                    Text(L("Start", language: appLanguage))
                }
                .font(.headline.bold())
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(Color.accentColor)
                .cornerRadius(12)
            }
            .buttonStyle(.plain)
            
            // Settings hint
            Text(L("TapSettingsToChangeMode", language: appLanguage))
                .font(.system(size: 9))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
    }
    
    private var gameModeIcon: String {
        switch gameMode {
        case .colors:
            return "paintpalette.fill"
        case .shapes:
            return "star.square.fill"
        case .emojis:
            return "face.smiling.fill"
        }
    }
    
    // MARK: - Level Complete Overlay (compact for watchOS)
    private var levelCompleteOverlay: some View {
        ZStack {
            Color.black.opacity(0.85)
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 16) {
                    // Celebration Icon
                    Image(systemName: "star.fill")
                        .font(.system(size: 40))
                        .foregroundStyle(.yellow)
                        .shadow(color: .yellow.opacity(0.5), radius: 10)
                    
                    // Level Complete Text
                    VStack(spacing: 4) {
                        Text("\(L("Level", language: appLanguage)) \(level - 1)")
                            .font(.caption)
                            .foregroundStyle(.white)
                        
                        Text(L("LevelComplete", language: appLanguage))
                            .font(.caption.bold())
                            .foregroundStyle(.white)
                            .minimumScaleFactor(0.5)
                            .lineLimit(1)
                    }
                    
                    // Score for this level
                    VStack(spacing: 4) {
                        Text(L("LevelScore", language: appLanguage))
                            .font(.system(size: 9))
                            .foregroundStyle(.white.opacity(0.8))
                        
                        if let previousLevelScore = levelScores[level - 1] {
                            Text("\(previousLevelScore > 0 ? "+" : "")\(previousLevelScore)")
                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                .foregroundStyle(previousLevelScore > 0 ? Color.green : Color.red)
                        }
                    }
                    .padding(.vertical, 8)
                    .padding(.horizontal, 12)
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    
                    // Show new achievements if any
                    if !newAchievementsThisRun.isEmpty {
                        VStack(spacing: 8) {
                            Text(L("NewAchievement", language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.white)
                            
                            ForEach(Achievement.all.filter { newAchievementsThisRun.contains($0.id) }, id: \.id) { achievement in
                                HStack(spacing: 6) {
                                    Text(achievement.iconEmoji)
                                        .font(.system(size: 20))
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(L(achievement.nameKey, language: appLanguage))
                                            .font(.system(size: 9, weight: .bold))
                                            .foregroundStyle(.white)
                                        Text(L(achievement.explanationKey, language: appLanguage))
                                            .font(.system(size: 8))
                                            .foregroundStyle(.white.opacity(0.8))
                                            .lineLimit(2)
                                    }
                                }
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.white.opacity(0.15))
                                .cornerRadius(8)
                            }
                        }
                        .padding(.horizontal, 8)
                    }
                    
                    // Buttons
                    VStack(spacing: 8) {
                        // Continue Button
                        Button {
                            withAnimation {
                                showLevelComplete = false
                                startNextLevel()
                            }
                        } label: {
                            HStack(spacing: 8) {
                                Text(L("Continue", language: appLanguage))
                                Image(systemName: "arrow.right")
                            }
                            .font(.caption.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color.accentColor)
                            .cornerRadius(8)
                        }
                        .buttonStyle(.plain)
                        
                        // Quit Button
                        Button {
                            withAnimation {
                                showLevelComplete = false
                                // Don't call quitGame()/endGameEarly() which would save levelScore again
                                // Just finalize and show summary
                                isPlaying = false
                                invalidateTimer()
                                
                                // Calculate final score from positive levels only
                                let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
                                highscoreStore.add(score: finalScore, playerName: playerName, maxLevel: level - 1, achievementIDs: newAchievementsThisRun)
                                totalScore = finalScore
                                feedbackManager.trigger(.gameOver)
                                showSummary = true
                            }
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "xmark.circle.fill")
                                Text(L("Quit", language: appLanguage))
                            }
                            .font(.caption2.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                            .background(Color.red.opacity(0.8))
                            .cornerRadius(8)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 8)
                }
                .padding(16)
            }
        }
        .transition(.scale.combined(with: .opacity))
    }
    
    // MARK: - Score Delta Overlay (compact for watchOS)
    private func scoreDeltaOverlay(delta: Int) -> some View {
        VStack(spacing: 4) {
            // Animated Icon
            Image(systemName: delta > 0 ? "checkmark.circle.fill" : "xmark.circle.fill")
                .font(.system(size: 30))
                .foregroundStyle(delta > 0 ? Color.green : Color.red)
                .shadow(color: (delta > 0 ? Color.green : Color.red).opacity(0.5), radius: 10)
            
            // Score Delta
            Text(delta > 0 ? "+\(delta)" : "\(delta)")
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .foregroundStyle(delta > 0 ? Color.green : Color.red)
                .shadow(color: (delta > 0 ? Color.green : Color.red).opacity(0.3), radius: 6)
        }
        .scaleEffect(reduceMotion ? 1.1 : 1.2)
        .transition(reduceMotion ? .opacity : .scale.combined(with: .opacity))
        .animation(reduceMotion ? .easeInOut(duration: 0.2) : .spring(response: 0.4, dampingFraction: 0.6), value: scoreDelta)
    }
    
    // MARK: - Dev Mode Helper
    private func autoSolveRound() {
        guard isDevMode && isPlaying else { return }
        
        // Find the correct tile (for watchOS, there's only one correct tile)
        if let correctTile = tiles.first(where: { $0.isCorrect }) {
            handleTileTap(tile: correctTile)
        }
    }
    
    // MARK: - Game Logic
    private func startGame() {
        isPlaying = true
        if round > 0 {
            // Resume from pause: provide start/resume feedback
            feedbackManager.trigger(.gameStart)
        }
        if round == 0 {
            level = 1  // Always start at level 1
            totalScore = 0
            levelScore = 0
            levelScores = [:]
            consecutiveTimeouts = 0  // Reset timeout counter
            consecutiveWrongTaps = 0  // Reset wrong tap counter
            newAchievementsThisRun = []  // Reset achievements for new game
            mistakesThisLevel = 0  // Reset mistakes counter
            
            // Randomize shapes/emoji selection at start of new game
            if gameMode == .shapes {
                let sourceShapes = proMode ? GameShape.proShapes : GameShape.standardShapes
                sessionShapes = sourceShapes.shuffled()
                sessionEmojis = []  // Clear emojis for shapes mode
            } else if gameMode == .emojis {
                let sourceEmojis = proMode ? GameEmoji.proEmojis : GameEmoji.standardEmojis
                sessionEmojis = sourceEmojis.shuffled()
                sessionShapes = []  // Clear shapes for emoji mode
            } else {
                sessionShapes = []  // Clear for color mode
                sessionEmojis = []  // Clear for color mode
            }
            
            feedbackManager.trigger(.gameStart)
            nextRound()
        }
        startTimer()
    }
    
    private func pauseGame() {
        isPlaying = false
        invalidateTimer()
        
        // Generate new tiles to prevent cheating
        // Keep the same round number but generate new tiles
        round -= 1  // Decrement because nextRound() will increment it again
        nextRound()
    }
    
    private func resetGame() {
        level = 1
        round = 0
        totalScore = 0
        levelScore = 0
        levelScores = [:]
        tiles = []
        sessionShapes = []  // Clear session shapes
        sessionEmojis = []  // Clear session emojis
        consecutiveTimeouts = 0  // Reset timeout counter
        consecutiveWrongTaps = 0  // Reset wrong tap counter
        newAchievementsThisRun = []  // Reset achievements
        mistakesThisLevel = 0  // Reset mistakes counter
        invalidateTimer()
    }
    
    private func startNextLevel() {
        round = 0
        levelScore = 0
        consecutiveTimeouts = 0  // Reset timeout counter for new level
        consecutiveWrongTaps = 0  // Reset wrong tap counter for new level
        mistakesThisLevel = 0  // Reset mistakes counter for new level
        isPlaying = true
        feedbackManager.trigger(.gameStart)
        nextRound()
        startTimer()
    }
    
    private func nextRound() {
        round += 1
        
        // Check if level is complete
        if round > roundsPerLevel {
            endLevel()
            return
        }
        
        // Fixed 2x2 grid for watchOS = 4 tiles
        let tileCount = 4
        
        switch gameMode {
        case .colors:
            generateColorTiles(count: tileCount)
        case .shapes:
            generateShapeTiles(count: tileCount)
        case .emojis:
            generateEmojiTiles(count: tileCount)
        }
    }
    
    private func generateColorTiles(count: Int) {
        // Select colors for tiles
        var selectedColors: [GameColor] = []
        if count <= availableColors.count {
            let shuffled = availableColors.shuffled()
            selectedColors = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedColors.append(availableColors.randomElement()!)
            }
        }
        
        // Pick one index as the correct one
        let correctIdx = Int.random(in: 0..<count)
        
        // Create labels: one correct, rest incorrect
        var labelArray = [GameColor](repeating: selectedColors[0], count: count)
        labelArray[correctIdx] = selectedColors[correctIdx]
        
        for i in 0..<count where i != correctIdx {
            let tileColorKey = selectedColors[i].nameKey
            let candidates = availableColors.filter { $0.nameKey != tileColorKey }
            if let choice = candidates.randomElement() {
                labelArray[i] = choice
            } else {
                labelArray[i] = availableColors.randomElement()!
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .color(labelArray[i]),
                backgroundContent: .color(selectedColors[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateShapeTiles(count: Int) {
        // Select shapes for tiles
        var selectedShapes: [GameShape] = []
        if count <= availableShapes.count {
            let shuffled = availableShapes.shuffled()
            selectedShapes = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedShapes.append(availableShapes.randomElement()!)
            }
        }
        
        // Pick one index as the correct one
        let correctIdx = Int.random(in: 0..<count)
        
        // Create labels: one correct, rest incorrect
        var labelArray = [GameShape](repeating: selectedShapes[0], count: count)
        labelArray[correctIdx] = selectedShapes[correctIdx]
        
        for i in 0..<count where i != correctIdx {
            let tileShapeKey = selectedShapes[i].nameKey
            let candidates = availableShapes.filter { $0.nameKey != tileShapeKey }
            if let choice = candidates.randomElement() {
                labelArray[i] = choice
            } else {
                labelArray[i] = availableShapes.randomElement()!
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .shape(labelArray[i]),
                backgroundContent: .shape(selectedShapes[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateEmojiTiles(count: Int) {
        // Select emojis for tiles
        var selectedEmojis: [GameEmoji] = []
        if count <= availableEmojis.count {
            let shuffled = availableEmojis.shuffled()
            selectedEmojis = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedEmojis.append(availableEmojis.randomElement()!)
            }
        }
        
        // Pick one index as the correct one
        let correctIdx = Int.random(in: 0..<count)
        
        // Create labels: one correct, rest incorrect
        var labelArray = [GameEmoji](repeating: selectedEmojis[0], count: count)
        labelArray[correctIdx] = selectedEmojis[correctIdx]
        
        for i in 0..<count where i != correctIdx {
            let tileEmojiKey = selectedEmojis[i].nameKey
            let candidates = availableEmojis.filter { $0.nameKey != tileEmojiKey }
            if let choice = candidates.randomElement() {
                labelArray[i] = choice
            } else {
                labelArray[i] = availableEmojis.randomElement()!
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .emoji(labelArray[i]),
                backgroundContent: .emoji(selectedEmojis[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func endLevel() {
        invalidateTimer()
        isPlaying = false
        
        // Store the score for this level
        levelScores[level] = levelScore
        
        // Track level completion for achievements (only if level completed successfully)
        if levelScore > 0 {
            achievementStore.markLevelCompletion(level: level, mode: gameMode, isPro: proMode)
            let newAchievements = achievementStore.checkAndUnlockAchievements()
            newAchievementsThisRun.append(contentsOf: newAchievements)
        }
        
        if levelScore <= 0 {
            // Game Over - calculate total from positive levels only
            let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
            highscoreStore.add(score: finalScore, playerName: playerName, maxLevel: level, achievementIDs: newAchievementsThisRun)
            totalScore = finalScore  // Update display score
            feedbackManager.trigger(.gameOver)
            showSummary = true
        } else {
            // Add positive score to total
            totalScore += levelScore
            
            // Trigger level complete feedback
            feedbackManager.trigger(.levelComplete)
            
            // Show level complete screen
            level += 1
            withAnimation {
                showLevelComplete = true
            }
        }
    }
    
    private func handleTileTap(tile: TileData) {
        // Provide immediate tap feedback for responsiveness
        feedbackManager.trigger(.tileTap)
        
        let isCorrect = tile.isCorrect
        
        // Use new simplified scoring system (same as iOS)
        let points = calculateRoundScore(secondsRemaining: timeRemaining)
        
        if isCorrect {
            // Reset both counters on correct tap
            consecutiveTimeouts = 0
            consecutiveWrongTaps = 0
            levelScore += points
            showScoreDelta(points)
            
            // Trigger positive feedback
            feedbackManager.trigger(.correctTap)
        } else {
            // Wrong tap - increment mistake counter
            mistakesThisLevel += 1
            
            levelScore -= points
            showScoreDelta(-points)
            
            // Trigger negative feedback
            feedbackManager.trigger(.wrongTap)
            
            // Check if this is the second mistake (game over)
            if mistakesThisLevel >= 2 {
                // End the game immediately on second mistake
                invalidateTimer()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.endGameEarly()
                }
                return
            } else {
                // First mistake - continue playing but show warning
                // Continue to next round after brief pause
            }
        }
        
        // Pause briefly for feedback
        invalidateTimer()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            if self.isPlaying {
                self.nextRound()
                self.startTimer()
            }
        }
    }
    
    private func showScoreDelta(_ delta: Int) {
        scoreDelta = delta
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            scoreDelta = nil
        }
    }
    
    private func startTimer() {
        invalidateTimer()
        timeRemaining = currentRoundDuration
        timerProgress = 1.0
        isLowTimeWarningTriggered = false  // Reset warning flag
        
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
            if self.isPlaying {
                self.timeRemaining -= 0.05
                self.timerProgress = max(0, self.timeRemaining / self.currentRoundDuration)
                
                // Trigger warning when time drops below 25% (only once per round)
                if self.timerProgress < 0.25 && !self.isLowTimeWarningTriggered {
                    self.isLowTimeWarningTriggered = true
                    self.feedbackManager.trigger(.timeWarning)
                }
                
                if self.timeRemaining <= 0 {
                    self.handleTimeout()
                }
            }
        }
    }
    
    private func handleTimeout() {
        // Trigger timeout feedback
        feedbackManager.trigger(.timeout)
        
        // Increment mistake counter
        mistakesThisLevel += 1
        
        // Check if this is the second mistake (game over)
        if mistakesThisLevel >= 2 {
            // Game ends on second mistake
            endGameEarly()
        } else {
            // First mistake - continue to next round after brief pause
            invalidateTimer()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                if self.isPlaying {
                    self.nextRound()
                    self.startTimer()
                }
            }
        }
    }
    
    private func endGameEarly() {
        invalidateTimer()
        isPlaying = false
        
        // Store the score for this level
        levelScores[level] = levelScore
        
        // Calculate final score from positive levels only
        let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
        highscoreStore.add(score: finalScore, playerName: playerName, maxLevel: level, achievementIDs: newAchievementsThisRun)
        totalScore = finalScore
        feedbackManager.trigger(.gameOver)
        showSummary = true
    }
    
    private func quitGame() {
        endGameEarly()
    }
    
    private func invalidateTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    // MARK: - Helper Functions
    private static func defaultLanguage() -> String {
        // Get the first preferred language from the system
        if let preferredLanguage = Locale.preferredLanguages.first {
            // Check if it starts with "de" for German
            if preferredLanguage.hasPrefix("de") {
                return "de"
            }
        }
        // Default to English for all other languages
        return "en"
    }
    
    static func defaultPlayerName() -> String {
        return "Player"
    }
    
    private func localizedContentName(_ nameKey: String, language: String) -> String {
        return L(nameKey, language: language)
    }
    
    private func textColorForTile(_ tile: TileData) -> Color {
        switch tile.backgroundContent {
        case .color(_):
            // For color tiles, use black text
            return .black.opacity(0.8)
        case .shape(_), .emoji(_):
            // For shape and emoji tiles, use primary color (adapts to dark/light mode)
            return .primary
        }
    }
    
    // MARK: - Unlock Alert Helpers
    
    private func validateSelections() {
        // Check if current mode is locked
        if !achievementStore.isModeUnlocked(mode: gameMode, isPro: false, playerName: playerName) {
            gameModeRaw = GameMode.colors.rawValue
        }
        
        // Check if Pro mode is locked
        if proMode && !achievementStore.isModeUnlocked(mode: gameMode, isPro: true, playerName: playerName) {
            proMode = false
        }
    }
    
    private func showUnlockAlert(for mode: GameMode) {
        // Find the achievement that unlocks this mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .mode(let unlockMode) = unlocked, unlockMode == mode.rawValue {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
    
    private func showUnlockAlert(forProMode: Bool) {
        // Find the achievement that unlocks Pro mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .proMode = unlocked {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
}

// MARK: - Settings View (watchOS optimized)
struct SettingsView: View {
    @Binding var playerName: String
    @Binding var appLanguage: String
    @Binding var appTheme: String
    @Binding var proMode: Bool
    @Binding var gameModeRaw: String
    @Binding var soundEnabled: Bool
    @Binding var hapticsEnabled: Bool
    @Binding var showPlayerSelection: Bool  // Add binding for player selection
    let achievementStore: AchievementStore  // Add achievement store
    
    @Environment(\.dismiss) private var dismiss
    @State private var showLockAlert = false
    @State private var lockAlertMessage = ""
    
    private var gameMode: GameMode {
        GameMode(rawValue: gameModeRaw) ?? .colors
    }
    
    private var appVersion: String {
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
        let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "Unknown"
        return "\(version) (\(build))"
    }
    
    private func setDefaultNameIfEmpty() {
        let trimmed = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            playerName = ContentView_WatchOS.defaultPlayerName()
        }
    }
    
    var body: some View {
        NavigationStack {
            List {
                Section {
                    // Custom mode picker with lock support
                    VStack(alignment: .leading, spacing: 6) {
                        Text(L("GameMode", language: appLanguage))
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                        
                        ForEach(GameMode.allCases) { mode in
                            let isLocked = !achievementStore.isModeUnlocked(mode: mode, isPro: false, playerName: playerName)
                            let isSelected = gameModeRaw == mode.rawValue
                            
                            Button {
                                if !isLocked {
                                    gameModeRaw = mode.rawValue
                                } else {
                                    showUnlockAlert(for: mode)
                                }
                            } label: {
                                HStack(spacing: 4) {
                                    if isLocked {
                                        Image(systemName: "lock.fill")
                                            .font(.system(size: 8))
                                    }
                                    Text(L(mode.nameKey, language: appLanguage))
                                        .font(.caption)
                                    Spacer()
                                    if isSelected {
                                        Image(systemName: "checkmark")
                                            .font(.system(size: 8))
                                            .foregroundStyle(.blue)
                                    }
                                }
                                .padding(.vertical, 8)
                                .padding(.horizontal, 10)
                                .background(
                                    isSelected ? Color.blue.opacity(0.15) : Color.clear
                                )
                                .cornerRadius(6)
                                .foregroundStyle(isLocked ? .secondary : .primary)
                                .opacity(isLocked ? 0.6 : 1.0)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                
                Section {
                    let isProLocked = !achievementStore.isModeUnlocked(mode: gameMode, isPro: true, playerName: playerName)
                    
                    if isProLocked {
                        Button {
                            showUnlockAlert(forProMode: true)
                        } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(L("ProMode", language: appLanguage))
                                        .font(.caption)
                                    Text(proModeDescription)
                                        .font(.system(size: 9))
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Image(systemName: "lock.fill")
                                    .font(.system(size: 8))
                                    .foregroundStyle(.secondary)
                            }
                        }
                    } else {
                        Toggle(isOn: $proMode) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(L("ProMode", language: appLanguage))
                                    .font(.caption)
                                Text(proModeDescription)
                                    .font(.system(size: 9))
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                } header: {
                    Text(L("Difficulty", language: appLanguage))
                }
                
                Section {
                    Toggle(L("Sound", language: appLanguage), isOn: $soundEnabled)
                    Toggle(L("Haptics", language: appLanguage), isOn: $hapticsEnabled)
                } header: {
                    Text(L("Feedback", language: appLanguage))
                }
                
                Section {
                    TextField(L("PlayerName", language: appLanguage), text: $playerName)
                        .font(.caption)
                        .onChange(of: playerName) { oldValue, newValue in
                            // Only trim whitespace, don't set default while typing
                            let trimmed = newValue.trimmingCharacters(in: .whitespaces)
                            if !trimmed.isEmpty && trimmed != newValue {
                                playerName = trimmed
                            }
                        }
                        .onSubmit {
                            // Set default name when user submits (presses return) with empty field
                            setDefaultNameIfEmpty()
                        }
                    
                    // Switch player button
                    Button {
                        showPlayerSelection = true
                        dismiss()
                    } label: {
                        HStack {
                            Image(systemName: "person.2.fill")
                                .font(.caption)
                            Text(L("SwitchPlayer", language: appLanguage))
                                .font(.caption)
                        }
                    }
                } header: {
                    Text(L("PlayerName", language: appLanguage))
                }
                
                Section {
                    Picker(L("Theme", language: appLanguage), selection: $appTheme) {
                        Text(L("ThemeSystem", language: appLanguage)).tag("system")
                        Text(L("ThemeLight", language: appLanguage)).tag("light")
                        Text(L("ThemeDark", language: appLanguage)).tag("dark")
                    }
                }
                
                Section {
                    Picker(L("Language", language: appLanguage), selection: $appLanguage) {
                        Text(L("German", language: appLanguage)).tag("de")
                        Text(L("English", language: appLanguage)).tag("en")
                    }
                }
                
                Section {
                    HStack {
                        Text(L("Version", language: appLanguage))
                            .font(.caption)
                        Spacer()
                        Text(appVersion)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text(L("About", language: appLanguage))
                }
            }
            .navigationTitle(L("Settings", language: appLanguage))
            .navigationBarTitleDisplayMode(.inline)
            .alert(L("Locked", language: appLanguage), isPresented: $showLockAlert) {
                Button(L("Done", language: appLanguage), role: .cancel) { }
            } message: {
                Text(lockAlertMessage)
            }
            .onDisappear {
                // Set default name when leaving settings with empty field
                setDefaultNameIfEmpty()
            }
        }
    }
    
    private var proModeDescription: String {
        switch gameMode {
        case .colors:
            return L("ProModeDescriptionColors", language: appLanguage)
        case .shapes:
            return L("ProModeDescriptionShapes", language: appLanguage)
        case .emojis:
            return L("ProModeDescriptionEmojis", language: appLanguage)
        }
    }
    
    private func showUnlockAlert(for mode: GameMode) {
        // Find the achievement that unlocks this mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .mode(let unlockMode) = unlocked, unlockMode == mode.rawValue {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
    
    private func showUnlockAlert(forProMode: Bool) {
        // Find the achievement that unlocks Pro mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .proMode = unlocked {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
}

// MARK: - Summary View (watchOS optimized)
struct SummaryView: View {
    let level: Int
    let totalScore: Int
    let levelScores: [Int: Int]
    let highscoreStore: HighscoreStore
    let language: String
    let onRestart: () -> Void
    let newAchievements: [String]  // Add achievements parameter
    let achievementStore: AchievementStore  // Add achievement store
    let playerName: String  // Add player name
    
    @State private var showHighscores = false
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Level Reached and Final Score - Combined for compactness (iOS style)
                    HStack(alignment: .top, spacing: 12) {
                        // Level Reached
                        VStack(spacing: 4) {
                            Text(L("ReachedLevel", language: language))
                                .font(.system(size: 8))
                                .foregroundStyle(.secondary)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                            Text("\(level)")
                                .font(.system(size: 30, weight: .bold, design: .rounded))
                                .foregroundStyle(.tint)
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Final Score
                        VStack(spacing: 4) {
                            Text(L("TotalScore", language: language))
                                .font(.system(size: 8))
                                .foregroundStyle(.secondary)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                            Text("\(totalScore)")
                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                                .minimumScaleFactor(0.6)
                                .lineLimit(1)
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .padding(8)
                    .background(Color.black.opacity(0.2))
                    .cornerRadius(8)
                    
                    // New Achievements Section
                    if !newAchievements.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(L("AchievementsEarned", language: language))
                                .font(.caption.bold())
                            
                            ForEach(Achievement.all.filter { newAchievements.contains($0.id) }, id: \.id) { achievement in
                                HStack(spacing: 8) {
                                    Text(achievement.iconEmoji)
                                        .font(.system(size: 24))
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(L(achievement.nameKey, language: language))
                                            .font(.system(size: 9, weight: .bold))
                                        Text(L(achievement.explanationKey, language: language))
                                            .font(.system(size: 8))
                                            .foregroundStyle(.secondary)
                                            .lineLimit(2)
                                    }
                                    Spacer()
                                }
                                .padding(6)
                                .background(Color.black.opacity(0.15))
                                .cornerRadius(8)
                            }
                        }
                        .padding(8)
                        .background(Color.black.opacity(0.2))
                        .cornerRadius(8)
                    }
                    
                    // Level Scores Breakdown
                    if !levelScores.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(L("ScorePerLevel", language: language))
                                .font(.caption.bold())
                            
                            ForEach(levelScores.keys.sorted(), id: \.self) { levelNum in
                                if let score = levelScores[levelNum] {
                                    HStack {
                                        Text("\(L("Level", language: language)) \(levelNum):")
                                            .font(.system(size: 10))
                                        Spacer()
                                        Text("\(score > 0 ? "+" : "")\(score)")
                                            .font(.system(size: 10, weight: .bold))
                                            .foregroundStyle(score > 0 ? Color.green : Color.red)
                                    }
                                    .padding(.horizontal, 8)
                                }
                            }
                        }
                        .padding(8)
                        .background(Color.black.opacity(0.2))
                        .cornerRadius(8)
                    }
                    
                    // Action Buttons
                    VStack(spacing: 8) {
                        // Done Button
                        Button {
                            onRestart()
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "checkmark.circle.fill")
                                Text(L("Done", language: language))
                            }
                            .font(.caption.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color.accentColor)
                            .cornerRadius(8)
                        }
                        .buttonStyle(.plain)
                        
                        // Highscores Button
                        Button {
                            showHighscores = true
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "list.number")
                                Text(L("Highscores", language: language))
                            }
                            .font(.caption2.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                            .background(Color.orange)
                            .cornerRadius(8)
                        }
                        .buttonStyle(.plain)
                    }
                    
                    // Quick preview of top highscores
                    if !highscoreStore.entries.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(L("TopScores", language: language))
                                .font(.caption.bold())
                            
                            ForEach(highscoreStore.entries.prefix(3)) { entry in
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(entry.playerName)
                                            .font(.system(size: 10, weight: .bold))
                                        HStack(spacing: 4) {
                                            Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                                                .font(.system(size: 7))
                                                .foregroundStyle(.secondary)
                                            Text("•")
                                                .font(.system(size: 7))
                                                .foregroundStyle(.secondary)
                                            Text("Level \(entry.maxLevel)")
                                                .font(.system(size: 8))
                                                .foregroundStyle(.secondary)
                                        }
                                    }
                                    
                                    Spacer()
                                    
                                    Text("\(entry.score)")
                                        .font(.caption.bold())
                                        .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
                                }
                                .padding(.horizontal, 8)
                            }
                        }
                        .padding(8)
                        .background(Color.black.opacity(0.2))
                        .cornerRadius(8)
                    }
                }
                .padding(8)
            }
            .navigationTitle(L("GameOver", language: language))
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true)
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showHighscores) {
                NavigationStack {
                    HighscoreListView(
                        store: highscoreStore,
                        language: language,
                        achievementStore: achievementStore,
                        playerName: playerName
                    )
                        .navigationTitle(L("Highscores", language: language))
                        .navigationBarTitleDisplayMode(.inline)
                }
            }
        }
    }
}

// MARK: - Highscore List View (watchOS optimized)
struct HighscoreListView: View {
    let store: HighscoreStore
    let language: String
    let achievementStore: AchievementStore
    let playerName: String
    
    @State private var showAchievements = false
    
    var body: some View {
        List {
            // Local Highscores Section
            Section {
                if store.entries.isEmpty {
                    Text(L("NoHighscores", language: language))
                        .foregroundStyle(.secondary)
                        .italic()
                        .font(.caption)
                } else {
                    ForEach(store.entries) { entry in
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text(entry.playerName)
                                    .font(.caption.bold())
                                Spacer()
                                Text("\(entry.score)")
                                    .font(.caption.bold())
                                    .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
                            }
                            
                            HStack(spacing: 6) {
                                Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                                    .font(.system(size: 9))
                                    .foregroundStyle(.secondary)
                                Text("•")
                                    .font(.system(size: 9))
                                    .foregroundStyle(.secondary)
                                Text("Level \(entry.maxLevel)")
                                    .font(.system(size: 9))
                                    .foregroundStyle(.tint)
                            }
                            
                            // Show achievements earned in this run
                            if !entry.achievementIDs.isEmpty {
                                VStack(alignment: .leading, spacing: 4) {
                                    ForEach(Achievement.all.filter { entry.achievementIDs.contains($0.id) }, id: \.id) { achievement in
                                        HStack(spacing: 4) {
                                            Text(achievement.iconEmoji)
                                                .font(.system(size: 14))
                                            VStack(alignment: .leading, spacing: 1) {
                                                Text(L(achievement.nameKey, language: language))
                                                    .font(.system(size: 8, weight: .bold))
                                                Text(L(achievement.explanationKey, language: language))
                                                    .font(.system(size: 7))
                                                    .foregroundStyle(.secondary)
                                                    .lineLimit(1)
                                            }
                                        }
                                        .padding(4)
                                        .background(Color.black.opacity(0.15))
                                        .cornerRadius(4)
                                    }
                                }
                                .padding(.top, 2)
                            }
                        }
                    }
                }
            } header: {
                Text(L("LocalHighscores", language: language))
            }
            
            // Achievement Overview Button
            Section {
                Button {
                    showAchievements = true
                } label: {
                    HStack {
                        Image(systemName: "trophy.fill")
                            .foregroundStyle(.yellow)
                            .font(.caption)
                        Text(L("Achievements", language: language))
                            .font(.caption.bold())
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundStyle(.secondary)
                            .font(.caption2)
                    }
                }
            }
        }
        .sheet(isPresented: $showAchievements) {
            NavigationStack {
                AchievementOverviewView_WatchOS(
                    language: language,
                    playerName: playerName,
                    achievementStore: achievementStore
                )
                    .navigationTitle(L("Achievements", language: language))
                    .navigationBarTitleDisplayMode(.inline)
            }
        }
    }
}

// MARK: - Preview
#Preview {
    ContentView_WatchOS()
}

// MARK: - Achievement Overview View (watchOS optimized)
struct AchievementOverviewView_WatchOS: View {
    let language: String
    let playerName: String
    let achievementStore: AchievementStore
    
    var body: some View {
        List {
            // Early Achievements (Level 5)
            Section {
                ForEach(earlyAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("EarlyAchievements", language: language))
            }
            
            // Unlocking Achievements (Level 10, 20, 30)
            Section {
                ForEach(unlockingAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("UnlockingAchievements", language: language))
            }
            
            // Intermediate Achievements (Level 15)
            Section {
                ForEach(intermediateAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("IntermediateAchievements", language: language))
            }
            
            // Advanced Achievements (Level 25)
            Section {
                ForEach(advancedAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("AdvancedAchievements", language: language))
            }
            
            // Mastery Achievements (Level 30 Standard)
            Section {
                ForEach(masteryAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("MasteryAchievements", language: language))
            }
            
            // Pro Mastery Achievements (Level 30 Pro)
            Section {
                ForEach(proMasteryAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("ProMasteryAchievements", language: language))
            }
            
            // Ultimate Achievement
            Section {
                ForEach(ultimateAchievements, id: \.id) { achievement in
                    achievementRow(achievement: achievement)
                }
            } header: {
                Text(L("UltimateAchievement", language: language))
            }
        }
    }
    
    private func achievementRow(achievement: Achievement) -> some View {
        let isUnlocked = achievementStore.isUnlocked(achievement.id)
        
        return HStack(spacing: 6) {
            Text(achievement.iconEmoji)
                .font(.system(size: 20))
                .grayscale(isUnlocked ? 0 : 1)
                .opacity(isUnlocked ? 1 : 0.5)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(L(achievement.nameKey, language: language))
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(isUnlocked ? .primary : .secondary)
                
                Text(L(achievement.explanationKey, language: language))
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            
            Spacer()
            
            if isUnlocked {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.green)
                    .font(.caption2)
            } else {
                Image(systemName: "lock.fill")
                    .foregroundStyle(.secondary)
                    .font(.caption2)
            }
        }
        .padding(.vertical, 2)
    }
    
    // Achievement groupings
    private var earlyAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(5, _, false) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var unlockingAchievements: [Achievement] {
        ["polygon_prodigy", "smiley_summoner", "ultra_instinct"].compactMap { id in
            Achievement.all.first { $0.id == id }
        }
    }
    
    private var intermediateAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(15, _, false) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var advancedAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(25, _, false) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var masteryAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(30, _, false) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var proMasteryAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevel(30, _, true) = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
    
    private var ultimateAchievements: [Achievement] {
        Achievement.all.filter { achievement in
            if case .reachLevelInAllModes = achievement.unlockCondition {
                return true
            }
            return false
        }
    }
}


// MARK: - Player Name Selection View (watchOS optimized)
struct PlayerNameSelectionView_WatchOS: View {
    @Binding var playerName: String
    let achievementStore: AchievementStore
    let language: String
    @Environment(\.dismiss) private var dismiss
    
    @State private var newPlayerName: String = ""
    @State private var showingNewPlayerInput: Bool = false
    @State private var showingDeleteConfirmation: Bool = false
    @State private var playerToDelete: String? = nil
    @State private var existingPlayersList: [String] = []  // Add state to track players
    
    var body: some View {
        NavigationStack {
            List {
                // Existing players section
                if !existingPlayersList.isEmpty {
                    Section {
                        ForEach(existingPlayersList, id: \.self) { player in
                            Button {
                                selectPlayer(player)
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(player)
                                            .font(.caption.bold())
                                        
                                        let count = achievementStore.getAchievementCount(for: player)
                                        if count > 0 {
                                            Text("\(count) \(L("AchievementsCount", language: language))")
                                                .font(.system(size: 9))
                                                .foregroundStyle(.secondary)
                                        } else {
                                            Text(L("NoAchievements", language: language))
                                                .font(.system(size: 9))
                                                .foregroundStyle(.secondary)
                                        }
                                    }
                                    
                                    Spacer()
                                    
                                    if player == playerName {
                                        Image(systemName: "checkmark")
                                            .foregroundStyle(.green)
                                            .font(.caption2)
                                    }
                                }
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button(role: .destructive) {
                                    playerToDelete = player
                                    showingDeleteConfirmation = true
                                } label: {
                                    Label(L("Delete", language: language), systemImage: "trash")
                                }
                            }
                        }
                    } header: {
                        Text(L("ExistingPlayers", language: language))
                    }
                }
                
                // Create new player section
                Section {
                    if showingNewPlayerInput {
                        VStack(spacing: 6) {
                            TextField(L("EnterPlayerName", language: language), text: $newPlayerName)
                                .font(.caption)
                            
                            HStack(spacing: 8) {
                                Button {
                                    createNewPlayer()
                                } label: {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundStyle(.green)
                                }
                                .disabled(newPlayerName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                                
                                Button {
                                    showingNewPlayerInput = false
                                    newPlayerName = ""
                                } label: {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundStyle(.red)
                                }
                            }
                        }
                    } else {
                        Button {
                            showingNewPlayerInput = true
                        } label: {
                            HStack {
                                Image(systemName: "plus.circle.fill")
                                    .font(.caption)
                                Text(L("CreateNewPlayer", language: language))
                                    .font(.caption)
                            }
                        }
                    }
                } header: {
                    Text(L("NewPlayer", language: language))
                }
            }
            .navigationTitle(L("SelectPlayer", language: language))
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                // Load players when view appears
                refreshPlayerList()
            }
            .alert(L("DeletePlayerConfirmation", language: language), isPresented: $showingDeleteConfirmation) {
                Button(L("Cancel", language: language), role: .cancel) {
                    playerToDelete = nil
                }
                Button(L("Delete", language: language), role: .destructive) {
                    if let player = playerToDelete {
                        deletePlayer(player)
                    }
                    playerToDelete = nil
                }
            } message: {
                Text(L("DeletePlayerMessage", language: language))
            }
        }
    }
    
    private func refreshPlayerList() {
        existingPlayersList = achievementStore.getAllPlayerNames()
    }
    
    private func selectPlayer(_ player: String) {
        playerName = player
        achievementStore.currentPlayerName = player
        dismiss()
    }
    
    private func createNewPlayer() {
        let trimmedName = newPlayerName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else { return }
        
        // Use AchievementStore's createPlayer method
        achievementStore.createPlayer(name: trimmedName)
        
        // Select the new player immediately
        playerName = trimmedName
        achievementStore.currentPlayerName = trimmedName
        
        // Refresh the list to show the new player
        refreshPlayerList()
        
        // Reset input
        newPlayerName = ""
        showingNewPlayerInput = false
        
        // Dismiss after a short delay to ensure the parent view updates
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            dismiss()
        }
    }
    
    private func deletePlayer(_ player: String) {
        // If deleting the current player, switch to a different player or create default
        if player == playerName {
            let remainingPlayers = existingPlayersList.filter { $0 != player }
            if let firstPlayer = remainingPlayers.first {
                playerName = firstPlayer
                achievementStore.currentPlayerName = firstPlayer
            } else {
                // No players left, create default "Player"
                playerName = "Player"
                achievementStore.currentPlayerName = "Player"
                achievementStore.createPlayer(name: "Player")
            }
        }
        
        // Delete the player
        achievementStore.deletePlayer(name: player)
        
        // Refresh the list
        refreshPlayerList()
    }
}
