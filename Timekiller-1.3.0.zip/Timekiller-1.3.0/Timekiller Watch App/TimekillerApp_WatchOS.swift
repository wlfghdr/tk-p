//
//  TimekillerApp.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI

@main
struct TimekillerApp_WatchOS: App {
    var body: some Scene {
        WindowGroup {
            ContentView_WatchOS()
        }
    }
}
