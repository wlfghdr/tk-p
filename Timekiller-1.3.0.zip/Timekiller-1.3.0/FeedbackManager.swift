//
//  FeedbackManager.swift
//  Timekiller
//
//  Created by Copilot on 23.12.25.
//

import SwiftUI
import AVFoundation

#if os(iOS)
import UIKit
import AudioToolbox
#endif

#if os(watchOS)
import WatchKit
#endif

// MARK: - Feedback Types

enum FeedbackType {
    case correctTap
    case wrongTap
    case timeout
    case timeWarning
    case levelComplete
    case tileTap
    case gameStart
    case gameOver
}

// MARK: - Sound Constants

#if os(iOS)
private enum SystemSound: UInt32 {
    case tink = 1054        // Correct answer sound
    case tock = 1053        // Wrong answer / timeout sound
    case alert = 1057       // Time warning sound
    case fanfare = 1025     // Level complete sound
    case tap = 1104         // Light tap sound
    case begin = 1110       // Begin recording/start-like sound
    case end = 1111         // End/stop-like sound
}
#endif

// MARK: - Timing Constants

private enum HapticTiming {
    static let levelCompleteCelebrationDelay: TimeInterval = 0.15
    static let iOSDoubleTapDelay: TimeInterval = 0.1
}

// MARK: - Feedback Manager

@Observable
class FeedbackManager {
    static let shared = FeedbackManager()
    
    var soundEnabled: Bool = true
    var hapticsEnabled: Bool = true
    
    private init() {
        #if os(iOS)
        setupAudioSession()
        #endif
    }
    
    // MARK: - Setup
    
    #if os(iOS)
    private func setupAudioSession() {
        // Configure audio session for game sounds
        do {
            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Failed to setup audio session: \(error)")
        }
    }
    #endif
    
    // MARK: - Public API
    
    func trigger(_ type: FeedbackType) {
        if hapticsEnabled {
            triggerHaptic(for: type)
        }
        if soundEnabled {
            triggerSound(for: type)
        }
    }
    
    // MARK: - Haptic Feedback
    
    private func triggerHaptic(for type: FeedbackType) {
        #if os(iOS)
        switch type {
        case .correctTap:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.success)
            
        case .wrongTap:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.error)
            
        case .timeout:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.error)
            
        case .timeWarning:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.warning)
            
        case .levelComplete:
            // Multiple success haptics for celebration
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.success)
            // Capture generator to ensure it stays alive for the delayed execution
            DispatchQueue.main.asyncAfter(deadline: .now() + HapticTiming.iOSDoubleTapDelay) { [generator] in
                generator.notificationOccurred(.success)
            }
            let heavyImpact = UIImpactFeedbackGenerator(style: .heavy)
            DispatchQueue.main.asyncAfter(deadline: .now() + HapticTiming.levelCompleteCelebrationDelay) { [heavyImpact] in
                heavyImpact.impactOccurred()
            }
            
        case .tileTap:
            let generator = UIImpactFeedbackGenerator(style: .light)
            generator.impactOccurred()

        case .gameStart:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.success)
        
        case .gameOver:
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.error)
        }
        #elseif os(watchOS)
        switch type {
        case .correctTap:
            WKInterfaceDevice.current().play(.success)
            
        case .wrongTap:
            WKInterfaceDevice.current().play(.failure)
            
        case .timeout:
            WKInterfaceDevice.current().play(.failure)
            
        case .timeWarning:
            WKInterfaceDevice.current().play(.retry)
            
        case .levelComplete:
            let device = WKInterfaceDevice.current()
            device.play(.success)
            // Add a second success haptic for emphasis
            // Capture device to ensure proper memory management
            DispatchQueue.main.asyncAfter(deadline: .now() + HapticTiming.levelCompleteCelebrationDelay) { [device] in
                device.play(.success)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + (HapticTiming.levelCompleteCelebrationDelay * 2)) { [device] in
                device.play(.click)
            }
            
        case .tileTap:
            WKInterfaceDevice.current().play(.click)

        case .gameStart:
            WKInterfaceDevice.current().play(.success)
        
        case .gameOver:
            WKInterfaceDevice.current().play(.failure)
        }
        #endif
    }
    
    // MARK: - Sound Feedback
    
    private func triggerSound(for type: FeedbackType) {
        #if os(iOS)
        // Use system sound IDs for immediate feedback
        let soundID: UInt32 = switch type {
        case .correctTap:
            SystemSound.tink.rawValue
        case .wrongTap:
            SystemSound.tock.rawValue
        case .timeout:
            SystemSound.tock.rawValue
        case .timeWarning:
            SystemSound.alert.rawValue
        case .levelComplete:
            SystemSound.fanfare.rawValue
        case .tileTap:
            SystemSound.tap.rawValue
        case .gameStart:
            SystemSound.begin.rawValue
        case .gameOver:
            SystemSound.end.rawValue
        }
        
        if type == .levelComplete {
            AudioServicesPlaySystemSound(SystemSound.fanfare.rawValue)
            DispatchQueue.main.asyncAfter(deadline: .now() + HapticTiming.levelCompleteCelebrationDelay) {
                AudioServicesPlaySystemSound(SystemSound.tink.rawValue)
            }
        } else {
            AudioServicesPlaySystemSound(soundID)
        }
        #elseif os(watchOS)
        // On watchOS, haptics already provide sound feedback
        // We don't need to play sounds separately to avoid duplication
        #endif
    }
}

