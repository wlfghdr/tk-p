//
//  AnimatedBackgroundView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI

// MARK: - Animated Background (watchOS)
struct AnimatedBackgroundView_WatchOS: View {
    @Environment(\.colorScheme) var systemColorScheme
    @Environment(\.scenePhase) var scenePhase
    
    let colorScheme: ColorScheme?
    let gameMode: GameMode
    let reduceMotion: Bool
    
    @State private var animationPhase: CGFloat = 0
    
    private var effectiveColorScheme: ColorScheme {
        colorScheme ?? systemColorScheme
    }
    
    var body: some View {
        ZStack {
            // Base gradient
            baseGradient
            
            // Material overlay in the middle
            Rectangle()
                .fill(.ultraThinMaterial)
            
            // Floating shapes layer - ABOVE material
            GeometryReader { geometry in
                ForEach(0..<10, id: \.self) { index in
                    floatingShape(index: index, in: geometry.size)
                }
            }
        }
        .ignoresSafeArea()
        .onAppear {
            startAnimation()
        }
        .onChange(of: scenePhase) { _, newPhase in
            // Restart animation when app becomes active
            if newPhase == .active {
                startAnimation()
            }
        }
    }
    
    // MARK: - Component Views
    
    private var baseGradient: some View {
        LinearGradient(
            colors: [
                effectiveColorScheme == .dark ? Color(red: 0.08, green: 0.09, blue: 0.11) : Color(red: 0.97, green: 0.97, blue: 0.98),
                effectiveColorScheme == .dark ? Color(red: 0.04, green: 0.05, blue: 0.06) : Color(red: 0.93, green: 0.94, blue: 0.96)
            ],
            startPoint: .top,
            endPoint: .bottom
        )
    }
    
    // MARK: - Animation Logic
    
    private func startAnimation() {
        // Reset and restart animation
        animationPhase = 0
        withAnimation(.linear(duration: 12).repeatForever(autoreverses: false)) {
            animationPhase = 1
        }
    }
    
    @ViewBuilder
    private func floatingShape(index: Int, in size: CGSize) -> some View {
        let shapeSize: CGFloat = CGFloat.random(in: 40...90)
        let startX = CGFloat.random(in: -30...size.width + 30)
        let startY = CGFloat.random(in: -30...size.height + 30)
        let offsetX = CGFloat.random(in: -70...70)
        let offsetY = CGFloat.random(in: -120...120)
        let duration = Double.random(in: 12...22)
        let delay = Double(index) * 0.8
        
        // Decide: emoji or colored shape
        let variant = index % 2
        
        if variant == 0 {
            emojiFloatingShape(
                index: index,
                shapeSize: shapeSize,
                startX: startX,
                startY: startY,
                offsetX: offsetX,
                offsetY: offsetY,
                duration: duration,
                delay: delay
            )
        } else {
            coloredFloatingShape(
                index: index,
                shapeSize: shapeSize,
                startX: startX,
                startY: startY,
                offsetX: offsetX,
                offsetY: offsetY,
                duration: duration,
                delay: delay
            )
        }
    }
    
    private func emojiFloatingShape(
        index: Int,
        shapeSize: CGFloat,
        startX: CGFloat,
        startY: CGFloat,
        offsetX: CGFloat,
        offsetY: CGFloat,
        duration: Double,
        delay: Double
    ) -> some View {
        let emojis = ["🎨", "⭐️", "🎯", "✨", "🌟", "🎪"]
        let emoji = emojis[index % emojis.count]
        let fontSize = shapeSize * 0.6
        let opacity = effectiveColorScheme == .dark ? 0.4 : 0.3
        let offsetXValue = startX + (animationPhase * offsetX)
        let offsetYValue = startY + (animationPhase * offsetY)
        let rotationDegrees = animationPhase * 360 * Double.random(in: 0.3...1.2)
        
        return Text(emoji)
            .font(.system(size: fontSize))
            .opacity(opacity)
            .blur(radius: 6)
            .offset(x: offsetXValue, y: offsetYValue)
            .animation(
                .linear(duration: duration)
                    .repeatForever(autoreverses: true)
                    .delay(delay),
                value: animationPhase
            )
            .rotationEffect(.degrees(rotationDegrees))
            .animation(
                .linear(duration: duration * 2)
                    .repeatForever(autoreverses: false)
                    .delay(delay),
                value: animationPhase
            )
    }
    
    private func coloredFloatingShape(
        index: Int,
        shapeSize: CGFloat,
        startX: CGFloat,
        startY: CGFloat,
        offsetX: CGFloat,
        offsetY: CGFloat,
        duration: Double,
        delay: Double
    ) -> some View {
        let colors = allColors
        let color = colors[index % colors.count]
        let colorOpacity = effectiveColorScheme == .dark ? 0.55 : 0.4
        let offsetXValue = startX + (animationPhase * offsetX)
        let offsetYValue = startY + (animationPhase * offsetY)
        let rotationDegrees = animationPhase * 360 * Double.random(in: 0.5...1.5)
        
        return shapeView(for: index)
            .frame(width: shapeSize, height: shapeSize)
            .foregroundStyle(color.opacity(colorOpacity))
            .blur(radius: 30)
            .offset(x: offsetXValue, y: offsetYValue)
            .animation(
                .linear(duration: duration)
                    .repeatForever(autoreverses: true)
                    .delay(delay),
                value: animationPhase
            )
            .rotationEffect(.degrees(rotationDegrees))
            .animation(
                .linear(duration: duration * 2)
                    .repeatForever(autoreverses: false)
                    .delay(delay),
                value: animationPhase
            )
    }
    
    @ViewBuilder
    private func shapeView(for index: Int) -> some View {
        // Mix of different shapes
        let shapeType = index % 4
        switch shapeType {
        case 0:
            Circle()
        case 1:
            RoundedRectangle(cornerRadius: 12)
        case 2:
            Capsule()
        case 3:
            Ellipse()
        default:
            Circle()
        }
    }
    
    private var allColors: [Color] {
        // Mix all colors
        [.red, .blue, .green, .yellow, .purple, .orange, .pink, .cyan, .indigo, .teal]
    }
}

// MARK: - Preview
#Preview {
    AnimatedBackgroundView_WatchOS(
        colorScheme: nil,
        gameMode: .colors,
        reduceMotion: false
    )
}
