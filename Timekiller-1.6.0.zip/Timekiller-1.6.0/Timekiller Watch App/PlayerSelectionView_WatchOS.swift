//
//  PlayerSelectionView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI

// MARK: - Player Name Selection View (watchOS optimized)
struct PlayerNameSelectionView_WatchOS: View {
    @Binding var playerName: String
    let achievementStore: AchievementStore
    let language: String
    
    @Environment(\.dismiss) private var dismiss
    
    @State private var newPlayerName: String = ""
    @State private var showingNewPlayerInput: Bool = false
    @State private var showingDeleteConfirmation: Bool = false
    @State private var playerToDelete: String? = nil
    @State private var existingPlayersList: [String] = []
    
    var body: some View {
        NavigationStack {
            List {
                // Existing players section
                if !existingPlayersList.isEmpty {
                    existingPlayersSection
                }
                
                // Create new player section
                newPlayerSection
            }
            .navigationTitle(L("SelectPlayer", language: language))
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                refreshPlayerList()
            }
            .alert(L("DeletePlayerConfirmation", language: language), isPresented: $showingDeleteConfirmation) {
                Button(L("Cancel", language: language), role: .cancel) {
                    playerToDelete = nil
                }
                Button(L("Delete", language: language), role: .destructive) {
                    if let player = playerToDelete {
                        deletePlayer(player)
                    }
                    playerToDelete = nil
                }
            } message: {
                Text(L("DeletePlayerMessage", language: language))
            }
        }
    }
    
    // MARK: - Section Views
    
    private var existingPlayersSection: some View {
        Section {
            ForEach(existingPlayersList, id: \.self) { player in
                playerRow(player: player)
            }
        } header: {
            Text(L("ExistingPlayers", language: language))
        }
    }
    
    private func playerRow(player: String) -> some View {
        Button {
            selectPlayer(player)
        } label: {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(player)
                        .font(.caption.bold())
                    
                    let count = achievementStore.getAchievementCount(for: player)
                    if count > 0 {
                        Text("\(count) \(L("AchievementsCount", language: language))")
                            .font(.system(size: 9))
                            .foregroundStyle(.secondary)
                    } else {
                        Text(L("NoAchievements", language: language))
                            .font(.system(size: 9))
                            .foregroundStyle(.secondary)
                    }
                }
                
                Spacer()
                
                if player == playerName {
                    Image(systemName: "checkmark")
                        .foregroundStyle(.green)
                        .font(.caption2)
                }
            }
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button(role: .destructive) {
                playerToDelete = player
                showingDeleteConfirmation = true
            } label: {
                Label(L("Delete", language: language), systemImage: "trash")
            }
        }
    }
    
    private var newPlayerSection: some View {
        Section {
            if showingNewPlayerInput {
                newPlayerInputView
            } else {
                createPlayerButton
            }
        } header: {
            Text(L("NewPlayer", language: language))
        }
    }
    
    private var newPlayerInputView: some View {
        VStack(spacing: 6) {
            TextField(L("EnterPlayerName", language: language), text: $newPlayerName)
                .font(.caption)
            
            HStack(spacing: 8) {
                Button {
                    createNewPlayer()
                } label: {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                }
                .disabled(newPlayerName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                
                Button {
                    showingNewPlayerInput = false
                    newPlayerName = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.red)
                }
            }
        }
    }
    
    private var createPlayerButton: some View {
        Button {
            showingNewPlayerInput = true
        } label: {
            HStack {
                Image(systemName: "plus.circle.fill")
                    .font(.caption)
                Text(L("CreateNewPlayer", language: language))
                    .font(.caption)
            }
        }
    }
    
    // MARK: - Helper Functions
    
    private func refreshPlayerList() {
        existingPlayersList = achievementStore.getAllPlayerNames()
    }
    
    private func selectPlayer(_ player: String) {
        playerName = player
        achievementStore.currentPlayerName = player
        dismiss()
    }
    
    private func createNewPlayer() {
        let trimmedName = newPlayerName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else { return }
        
        // Use AchievementStore's createPlayer method
        achievementStore.createPlayer(name: trimmedName)
        
        // Select the new player immediately
        playerName = trimmedName
        achievementStore.currentPlayerName = trimmedName
        
        // Refresh the list to show the new player
        refreshPlayerList()
        
        // Reset input
        newPlayerName = ""
        showingNewPlayerInput = false
        
        // Dismiss after a short delay to ensure the parent view updates
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            dismiss()
        }
    }
    
    private func deletePlayer(_ player: String) {
        // If deleting the current player, switch to a different player or create default
        if player == playerName {
            let remainingPlayers = existingPlayersList.filter { $0 != player }
            if let firstPlayer = remainingPlayers.first {
                playerName = firstPlayer
                achievementStore.currentPlayerName = firstPlayer
            } else {
                // No players left, create default "Player"
                playerName = "Player"
                achievementStore.currentPlayerName = "Player"
                achievementStore.createPlayer(name: "Player")
            }
        }
        
        // Delete the player
        achievementStore.deletePlayer(name: player)
        
        // Refresh the list
        refreshPlayerList()
    }
}

// MARK: - Preview
#Preview {
    PlayerNameSelectionView_WatchOS(
        playerName: .constant("Player"),
        achievementStore: AchievementStore(),
        language: "en"
    )
}
