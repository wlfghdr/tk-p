//
//  SettingsView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI

// MARK: - Settings View (watchOS optimized)
struct SettingsView_WatchOS: View {
    @Binding var playerName: String
    @Binding var appLanguage: String
    @Binding var appTheme: String
    @Binding var proMode: Bool
    @Binding var gameModeRaw: String
    @Binding var soundEnabled: Bool
    @Binding var hapticsEnabled: Bool
    @Binding var startLevel: Int
    @Binding var showPlayerSelection: Bool
    let achievementStore: AchievementStore
    
    @Environment(\.dismiss) private var dismiss
    @State private var showLockAlert = false
    @State private var lockAlertMessage = ""
    
    // MARK: - Computed Properties
    
    private var gameMode: GameMode {
        GameMode(rawValue: gameModeRaw) ?? .colors
    }
    
    // Dev Mode check (case-insensitive)
    private var isDevMode: Bool {
        let normalized = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.caseInsensitiveCompare("Wulf") == .orderedSame
    }
    
    private var appVersion: String {
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
        let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "Unknown"
        return "\(version) (\(build))"
    }
    
    private var proModeDescription: String {
        switch gameMode {
        case .colors:
            return L("ProModeDescriptionColors", language: appLanguage)
        case .numbers:
            return L("ProModeDescriptionNumbers", language: appLanguage)
        case .shapes:
            return L("ProModeDescriptionShapes", language: appLanguage)
        case .flags:
            return L("ProModeDescriptionFlags", language: appLanguage)
        case .emojis:
            return L("ProModeDescriptionEmojis", language: appLanguage)
        }
    }
    
    // MARK: - Body
    
    var body: some View {
        NavigationStack {
            List {
                // Dev Mode Section (only visible when Dev Mode is active)
                if isDevMode {
                    devModeSection
                }
                
                gameModeSection
                
                difficultySection
                
                feedbackSection
                
                playerSection
                
                themeSection
                
                languageSection
                
                aboutSection
            }
            .navigationTitle(L("Settings", language: appLanguage))
            .navigationBarTitleDisplayMode(.inline)
            .alert(L("Locked", language: appLanguage), isPresented: $showLockAlert) {
                Button(L("Done", language: appLanguage), role: .cancel) { }
            } message: {
                Text(lockAlertMessage)
            }
            .onDisappear {
                // Set default name when leaving settings with empty field
                setDefaultNameIfEmpty()
            }
        }
    }
    
    // MARK: - Section Views
    
    private var devModeSection: some View {
        Section {
            // Dev Mode Status
            HStack {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.orange)
                    .font(.caption)
                Text(L("DevModeActive", language: appLanguage))
                    .font(.caption.bold())
                    .foregroundStyle(.orange)
            }
            
            // Start Level Picker
            Picker(L("StartLevel", language: appLanguage), selection: $startLevel) {
                ForEach(1...30, id: \.self) { level in
                    Text("\(level)").tag(level)
                }
            }
            
            // Dev Mode Info
            VStack(alignment: .leading, spacing: 4) {
                Text(L("DevModeInfo", language: appLanguage))
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
                Text("• \(L("DevModeFeature1", language: appLanguage))")
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                Text("• \(L("DevModeFeature2", language: appLanguage))")
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 2)
        } header: {
            Text(L("DeveloperMode", language: appLanguage))
        }
    }
    
    private var gameModeSection: some View {
        Section {
            // Custom mode picker with lock support
            VStack(alignment: .leading, spacing: 6) {
                Text(L("GameMode", language: appLanguage))
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                
                ForEach(GameMode.allCases) { mode in
                    let isLocked = !achievementStore.isModeUnlocked(mode: mode, isPro: false, playerName: playerName)
                    let isSelected = gameModeRaw == mode.rawValue
                    
                    Button {
                        if !isLocked {
                            gameModeRaw = mode.rawValue
                        } else {
                            showUnlockAlert(for: mode)
                        }
                    } label: {
                        HStack(spacing: 4) {
                            if isLocked {
                                Image(systemName: "lock.fill")
                                    .font(.system(size: 8))
                            }
                            Text(L(mode.nameKey, language: appLanguage))
                                .font(.caption)
                            Spacer()
                            if isSelected {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 8))
                                    .foregroundStyle(.blue)
                            }
                        }
                        .padding(.vertical, 8)
                        .padding(.horizontal, 10)
                        .background(
                            isSelected ? Color.blue.opacity(0.15) : Color.clear
                        )
                        .cornerRadius(6)
                        .foregroundStyle(isLocked ? .secondary : .primary)
                        .opacity(isLocked ? 0.6 : 1.0)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
    
    private var difficultySection: some View {
        Section {
            let isProLocked = !achievementStore.isModeUnlocked(mode: gameMode, isPro: true, playerName: playerName)
            
            if isProLocked {
                Button {
                    showUnlockAlert(forProMode: true)
                } label: {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(L("ProMode", language: appLanguage))
                                .font(.caption)
                            Text(proModeDescription)
                                .font(.system(size: 9))
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "lock.fill")
                            .font(.system(size: 8))
                            .foregroundStyle(.secondary)
                    }
                }
            } else {
                Toggle(isOn: $proMode) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(L("ProMode", language: appLanguage))
                            .font(.caption)
                        Text(proModeDescription)
                            .font(.system(size: 9))
                            .foregroundStyle(.secondary)
                    }
                }
            }
        } header: {
            Text(L("Difficulty", language: appLanguage))
        }
    }
    
    private var feedbackSection: some View {
        Section {
            Toggle(L("Sound", language: appLanguage), isOn: $soundEnabled)
            Toggle(L("Haptics", language: appLanguage), isOn: $hapticsEnabled)
        } header: {
            Text(L("Feedback", language: appLanguage))
        }
    }
    
    private var playerSection: some View {
        Section {
            TextField(L("PlayerName", language: appLanguage), text: $playerName)
                .font(.caption)
                .onChange(of: playerName) { oldValue, newValue in
                    // Only trim whitespace, don't set default while typing
                    let trimmed = newValue.trimmingCharacters(in: .whitespaces)
                    if !trimmed.isEmpty && trimmed != newValue {
                        playerName = trimmed
                    }
                }
                .onSubmit {
                    // Set default name when user submits (presses return) with empty field
                    setDefaultNameIfEmpty()
                }
            
            // Switch player button
            Button {
                showPlayerSelection = true
                dismiss()
            } label: {
                HStack {
                    Image(systemName: "person.2.fill")
                        .font(.caption)
                    Text(L("SwitchPlayer", language: appLanguage))
                        .font(.caption)
                }
            }
        } header: {
            Text(L("PlayerName", language: appLanguage))
        }
    }
    
    private var themeSection: some View {
        Section {
            Picker(L("Theme", language: appLanguage), selection: $appTheme) {
                Text(L("ThemeSystem", language: appLanguage)).tag("system")
                Text(L("ThemeLight", language: appLanguage)).tag("light")
                Text(L("ThemeDark", language: appLanguage)).tag("dark")
            }
        }
    }
    
    private var languageSection: some View {
        Section {
            Picker(L("Language", language: appLanguage), selection: $appLanguage) {
                Text(L("German", language: appLanguage)).tag("de")
                Text(L("English", language: appLanguage)).tag("en")
            }
        }
    }
    
    private var aboutSection: some View {
        Section {
            HStack {
                Text(L("Version", language: appLanguage))
                    .font(.caption)
                Spacer()
                Text(appVersion)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        } header: {
            Text(L("About", language: appLanguage))
        }
    }
    
    // MARK: - Helper Functions
    
    private func setDefaultNameIfEmpty() {
        let trimmed = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            playerName = ContentView_WatchOS.defaultPlayerName()
        }
    }
    
    private func showUnlockAlert(for mode: GameMode) {
        // Find the achievement that unlocks this mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .mode(let unlockMode) = unlocked, unlockMode == mode.rawValue {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
    
    private func showUnlockAlert(forProMode: Bool) {
        // Find the achievement that unlocks Pro mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .proMode = unlocked {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
}

// MARK: - Preview
#Preview {
    SettingsView_WatchOS(
        playerName: .constant("Player"),
        appLanguage: .constant("en"),
        appTheme: .constant("system"),
        proMode: .constant(false),
        gameModeRaw: .constant(GameMode.colors.rawValue),
        soundEnabled: .constant(true),
        hapticsEnabled: .constant(true),
        startLevel: .constant(1),
        showPlayerSelection: .constant(false),
        achievementStore: AchievementStore()
    )
}
