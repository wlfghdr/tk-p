//
//  SummaryView_WatchOS.swift
//  Timekiller watchOS
//
//  Created by Wolfgang Heider on 01.01.26.
//

import SwiftUI

// MARK: - Summary View (watchOS optimized)
struct SummaryView_WatchOS: View {
    let level: Int
    let totalScore: Int
    let levelScores: [Int: Int]
    let highscoreStore: HighscoreStore
    let language: String
    let onRestart: () -> Void
    let newAchievements: [String]
    let achievementStore: AchievementStore
    let playerName: String
    
    @State private var showHighscores = false
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Level Reached and Final Score - Combined for compactness
                    statsSection
                    
                    // New Achievements Section
                    if !newAchievements.isEmpty {
                        achievementsSection
                    }
                    
                    // Level Scores Breakdown
                    if !levelScores.isEmpty {
                        levelScoresSection
                    }
                    
                    // Action Buttons
                    actionButtonsSection
                    
                    // Quick preview of top highscores
                    if !highscoreStore.entries.isEmpty {
                        topScoresSection
                    }
                }
                .padding(8)
            }
            .navigationTitle(L("GameOver", language: language))
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true)
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showHighscores) {
                NavigationStack {
                    HighscoreView_WatchOS(
                        store: highscoreStore,
                        language: language,
                        achievementStore: achievementStore,
                        playerName: playerName
                    )
                        .navigationTitle(L("Highscores", language: language))
                        .navigationBarTitleDisplayMode(.inline)
                }
            }
        }
    }
    
    // MARK: - Section Views
    
    private var statsSection: some View {
        HStack(alignment: .top, spacing: 12) {
            // Level Reached
            VStack(spacing: 4) {
                Text(L("ReachedLevel", language: language))
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                    .minimumScaleFactor(0.5)
                    .lineLimit(1)
                Text("\(level)")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .foregroundStyle(.tint)
            }
            .frame(maxWidth: .infinity)
            
            // Final Score
            VStack(spacing: 4) {
                Text(L("TotalScore", language: language))
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                    .minimumScaleFactor(0.5)
                    .lineLimit(1)
                Text("\(totalScore)")
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                    .minimumScaleFactor(0.6)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
        }
        .padding(8)
        .background(Color.black.opacity(0.2))
        .cornerRadius(8)
    }
    
    private var achievementsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(L("AchievementsEarned", language: language))
                .font(.caption.bold())
            
            ForEach(Achievement.all.filter { newAchievements.contains($0.id) }, id: \.id) { achievement in
                achievementRow(achievement: achievement)
            }
        }
        .padding(8)
        .background(Color.black.opacity(0.2))
        .cornerRadius(8)
    }
    
    private func achievementRow(achievement: Achievement) -> some View {
        HStack(spacing: 8) {
            Text(achievement.iconEmoji)
                .font(.system(size: 24))
            VStack(alignment: .leading, spacing: 2) {
                Text(L(achievement.nameKey, language: language))
                    .font(.system(size: 9, weight: .bold))
                Text(L(achievement.explanationKey, language: language))
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            Spacer()
        }
        .padding(6)
        .background(Color.black.opacity(0.15))
        .cornerRadius(8)
    }
    
    private var levelScoresSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(L("ScorePerLevel", language: language))
                .font(.caption.bold())
            
            ForEach(levelScores.keys.sorted(), id: \.self) { levelNum in
                if let score = levelScores[levelNum] {
                    levelScoreRow(levelNum: levelNum, score: score)
                }
            }
        }
        .padding(8)
        .background(Color.black.opacity(0.2))
        .cornerRadius(8)
    }
    
    private func levelScoreRow(levelNum: Int, score: Int) -> some View {
        HStack {
            Text("\(L("Level", language: language)) \(levelNum):")
                .font(.system(size: 10))
            Spacer()
            Text("\(score > 0 ? "+" : "")\(score)")
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(score > 0 ? Color.green : Color.red)
        }
        .padding(.horizontal, 8)
    }
    
    private var actionButtonsSection: some View {
        VStack(spacing: 8) {
            // Done Button
            Button {
                onRestart()
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "checkmark.circle.fill")
                    Text(L("Done", language: language))
                }
                .font(.caption.bold())
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background(Color.accentColor)
                .cornerRadius(8)
            }
            .buttonStyle(.plain)
            
            // Highscores Button
            Button {
                showHighscores = true
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "list.number")
                    Text(L("Highscores", language: language))
                }
                .font(.caption2.bold())
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(Color.orange)
                .cornerRadius(8)
            }
            .buttonStyle(.plain)
        }
    }
    
    private var topScoresSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(L("TopScores", language: language))
                .font(.caption.bold())
            
            ForEach(highscoreStore.entries.prefix(3)) { entry in
                topScoreRow(entry: entry)
            }
        }
        .padding(8)
        .background(Color.black.opacity(0.2))
        .cornerRadius(8)
    }
    
    private func topScoreRow(entry: HighscoreEntry) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(entry.playerName)
                    .font(.system(size: 10, weight: .bold))
                HStack(spacing: 4) {
                    Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                        .font(.system(size: 7))
                        .foregroundStyle(.secondary)
                    Text("•")
                        .font(.system(size: 7))
                        .foregroundStyle(.secondary)
                    Text("Level \(entry.maxLevel)")
                        .font(.system(size: 8))
                        .foregroundStyle(.secondary)
                }
            }
            
            Spacer()
            
            Text("\(entry.score)")
                .font(.caption.bold())
                .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
        }
        .padding(.horizontal, 8)
    }
}

// MARK: - Preview
#Preview {
    SummaryView_WatchOS(
        level: 5,
        totalScore: 450,
        levelScores: [1: 100, 2: 120, 3: 110, 4: 120],
        highscoreStore: HighscoreStore(),
        language: "en",
        onRestart: {},
        newAchievements: [],
        achievementStore: AchievementStore(),
        playerName: "Player"
    )
}
