//
//  Achievements.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation
import SwiftUI

// MARK: - Achievement System

/// Represents a specific achievement milestone
struct Achievement: Identifiable, Codable, Equatable {
    let id: String
    let nameKey: String        // Localization key for achievement name
    let iconEmoji: String      // Emoji icon for the achievement
    let explanationKey: String // Localization key for explanation
    let unlockCondition: UnlockCondition
    
    enum UnlockCondition: Codable, Equatable {
        case reachLevel(Int, mode: String, isPro: Bool)  // Generic level reaching
        case reachLevelInAllModes(Int)  // Ultimate achievement
    }
    
    /// What this achievement unlocks (for display purposes)
    var unlocksContent: UnlockedContent? {
        // Only specific achievements unlock content, not all achievements at that level
        switch id {
        case "polygon_prodigy":
            return .mode("shapes")
        case "flag_dropper":
            return .mode("flags")
        case "smiley_summoner":
            return .mode("emojis")
        case "ultra_instinct":
            return .proMode
        default:
            return nil
        }
    }
    
    enum UnlockedContent {
        case mode(String)
        case proMode
    }
}

// MARK: - Player Achievement Data

/// Achievement data for a single player
struct PlayerAchievementData: Codable {
    var unlockedAchievementIDs: Set<String>
    var levelCompletions: [String: Int]  // "mode_isPro" -> highest level completed
    
    init() {
        self.unlockedAchievementIDs = []
        self.levelCompletions = [:]
    }
}

/// Tracks player progression and unlocked achievements
@Observable
class AchievementStore {
    private let storageKey = "tk_achievements_per_player"  // New key for per-player storage
    private let playersStorageKey = "tk_players"  // Storage key for player list
    private let legacyStorageKey = "tk_achievements"  // Old global key
    private let legacyProgressKey = "tk_achievement_progress"  // Old global key
    
    /// Per-player achievement data
    private var playerAchievements: [String: PlayerAchievementData] = [:]
    
    /// List of all created players
    private var players: Set<String> = []
    
    /// Currently active player name
    var currentPlayerName: String = "Player" {
        didSet {
            if oldValue != currentPlayerName {
                // Ensure new player exists in the player list
                if !players.contains(currentPlayerName) {
                    createPlayer(name: currentPlayerName)
                }
            }
        }
    }
    
    /// IDs of unlocked achievements for current player
    var unlockedAchievementIDs: Set<String> {
        get {
            return playerAchievements[currentPlayerName]?.unlockedAchievementIDs ?? []
        }
        set {
            if playerAchievements[currentPlayerName] == nil {
                playerAchievements[currentPlayerName] = PlayerAchievementData()
            }
            playerAchievements[currentPlayerName]?.unlockedAchievementIDs = newValue
        }
    }
    
    /// Track Level completions for current player: "mode_isPro" -> highest level
    var levelCompletions: [String: Int] {
        get {
            return playerAchievements[currentPlayerName]?.levelCompletions ?? [:]
        }
        set {
            if playerAchievements[currentPlayerName] == nil {
                playerAchievements[currentPlayerName] = PlayerAchievementData()
            }
            playerAchievements[currentPlayerName]?.levelCompletions = newValue
        }
    }
    
    init() {
        load()
        loadPlayers()
        
        // Ensure current player exists in the player list
        if !players.contains(currentPlayerName) {
            createPlayer(name: currentPlayerName)
        }
    }
    
    /// Get list of all player names (from player list, not just those with achievements)
    func getAllPlayerNames() -> [String] {
        return Array(players).sorted()
    }
    
    /// Get achievement count for a player
    func getAchievementCount(for playerName: String) -> Int {
        return playerAchievements[playerName]?.unlockedAchievementIDs.count ?? 0
    }
    
    /// Check if a player exists
    func playerExists(name: String) -> Bool {
        return players.contains(name)
    }
    
    /// Create a new player and persist immediately
    func createPlayer(name: String) {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else { return }
        
        players.insert(trimmedName)
        savePlayers()
        
        // Initialize empty achievement data for the player if not exists
        if playerAchievements[trimmedName] == nil {
            playerAchievements[trimmedName] = PlayerAchievementData()
            save()
        }
    }
    
    /// Delete a player and their achievement data
    func deletePlayer(name: String) {
        players.remove(name)
        playerAchievements.removeValue(forKey: name)
        savePlayers()
        save()
    }
    
    /// Check if Dev Mode is active (player name is "Wulf")
    func isDevMode(playerName: String) -> Bool {
        let normalized = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.caseInsensitiveCompare("Wulf") == .orderedSame
    }
    
    /// Check if an achievement is unlocked
    func isUnlocked(_ achievementID: String) -> Bool {
        return unlockedAchievementIDs.contains(achievementID)
    }
    
    /// Check if a mode is unlocked based on level progression
    func isModeUnlocked(mode: GameMode, isPro: Bool, playerName: String = "") -> Bool {
        // Dev Mode: Everything is unlocked
        if isDevMode(playerName: playerName) {
            return true
        }
        
        // Colors and Numbers modes are always unlocked
        if (mode == .colors || mode == .numbers) && !isPro {
            return true
        }
        
        // Get highest level reached across all standard modes
        let highestStandardLevel = max(
            getHighestLevel(mode: .colors, isPro: false),
            getHighestLevel(mode: .numbers, isPro: false),
            getHighestLevel(mode: .shapes, isPro: false),
            getHighestLevel(mode: .flags, isPro: false),
            getHighestLevel(mode: .emojis, isPro: false)
        )
        
        // Check for shapes mode unlock (need to reach level 10)
        if mode == .shapes && !isPro {
            return highestStandardLevel >= 10
        }
        
        // Check for flags mode unlock (need to reach level 15)
        if mode == .flags && !isPro {
            return highestStandardLevel >= 15
        }
        
        // Check for emoji mode unlock (need to reach level 20)
        if mode == .emojis && !isPro {
            return highestStandardLevel >= 20
        }
        
        // Check for Pro mode unlock (need to reach level 30 in any standard mode)
        if isPro {
            return highestStandardLevel >= 30
        }
        
        return false
    }
    
    /// Get the highest level reached for a specific mode
    func getHighestLevel(mode: GameMode, isPro: Bool) -> Int {
        let key = "\(mode.rawValue)_\(isPro)"
        return levelCompletions[key] ?? 0
    }
    
    /// Mark that a level was completed for a specific configuration
    func markLevelCompletion(level: Int, mode: GameMode, isPro: Bool) {
        let key = "\(mode.rawValue)_\(isPro)"
        let currentHighest = levelCompletions[key] ?? 0
        if level > currentHighest {
            levelCompletions[key] = level
        }
        save()
    }
    
    /// Check and unlock new achievements based on current progress
    /// Returns array of newly unlocked achievement IDs
    func checkAndUnlockAchievements() -> [String] {
        var newlyUnlocked: [String] = []
        
        for achievement in Achievement.all {
            // Skip if already unlocked
            if isUnlocked(achievement.id) {
                continue
            }
            
            // Check if conditions are met
            let shouldUnlock: Bool
            switch achievement.unlockCondition {
            case .reachLevel(let requiredLevel, let mode, let isPro):
                let key = "\(mode)_\(isPro)"
                let highestLevel = levelCompletions[key] ?? 0
                shouldUnlock = highestLevel >= requiredLevel
                
            case .reachLevelInAllModes(let requiredLevel):
                // Check if all 10 mode combinations reached the required level (5 modes × 2 difficulties)
                let allModes: [(String, Bool)] = [
                    ("colors", false), ("numbers", false), ("shapes", false), ("flags", false), ("emojis", false),
                    ("colors", true), ("numbers", true), ("shapes", true), ("flags", true), ("emojis", true)
                ]
                shouldUnlock = allModes.allSatisfy { mode, isPro in
                    let key = "\(mode)_\(isPro)"
                    return (levelCompletions[key] ?? 0) >= requiredLevel
                }
            }
            
            if shouldUnlock {
                unlockedAchievementIDs.insert(achievement.id)
                newlyUnlocked.append(achievement.id)
            }
        }
        
        if !newlyUnlocked.isEmpty {
            save()
        }
        
        return newlyUnlocked
    }
    
    private func save() {
        // Save per-player achievements
        if let encoded = try? JSONEncoder().encode(playerAchievements) {
            UserDefaults.standard.set(encoded, forKey: storageKey)
        }
    }
    
    private func savePlayers() {
        // Save player list
        if let encoded = try? JSONEncoder().encode(Array(players)) {
            UserDefaults.standard.set(encoded, forKey: playersStorageKey)
        }
    }
    
    private func load() {
        // Try to load per-player achievements first
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let decoded = try? JSONDecoder().decode([String: PlayerAchievementData].self, from: data) {
            playerAchievements = decoded
            return
        }
        
        // If no per-player data exists, migrate from old global storage
        migrateLegacyAchievements()
    }
    
    private func loadPlayers() {
        // Try to load player list
        if let data = UserDefaults.standard.data(forKey: playersStorageKey),
           let decoded = try? JSONDecoder().decode([String].self, from: data) {
            players = Set(decoded)
        }
        
        // Ensure all players with achievement data are in the player list (migration)
        for playerName in playerAchievements.keys {
            if !players.contains(playerName) {
                players.insert(playerName)
            }
        }
        
        // Save player list if we added any from achievement data
        if !players.isEmpty {
            savePlayers()
        }
    }
    
    /// Migrate achievements from old global storage to per-player storage
    private func migrateLegacyAchievements() {
        var legacyData = PlayerAchievementData()
        
        // Load old unlocked achievements
        if let data = UserDefaults.standard.data(forKey: legacyStorageKey),
           let decoded = try? JSONDecoder().decode([String].self, from: data) {
            legacyData.unlockedAchievementIDs = Set(decoded)
        }
        
        // Load old progress - convert old level5Completions to new format
        if let data = UserDefaults.standard.data(forKey: legacyProgressKey),
           let decoded = try? JSONDecoder().decode([String: Bool].self, from: data) {
            // Old format: "2x2_colors_false" -> true
            // New format: "colors_false" -> 5 (level completed)
            // For migration, we'll extract the mode and isPro, set highest to 5 if completed
            for (key, completed) in decoded where completed {
                let parts = key.split(separator: "_")
                if parts.count == 3 {
                    let mode = String(parts[1])
                    let isPro = parts[2] == "true"
                    let newKey = "\(mode)_\(isPro)"
                    // Set to 5 since old system only tracked level 5 completions
                    let currentMax = legacyData.levelCompletions[newKey] ?? 0
                    legacyData.levelCompletions[newKey] = max(currentMax, 5)
                }
            }
        }
        
        // If we found any legacy data, migrate it to the default player
        if !legacyData.unlockedAchievementIDs.isEmpty || !legacyData.levelCompletions.isEmpty {
            playerAchievements["Player"] = legacyData
            players.insert("Player")
            save()  // Save migrated data
            savePlayers()
        }
    }
}

// MARK: - Achievement Definitions

extension Achievement {
    static let all: [Achievement] = [
        // Early Achievements (3) - Level 5
        Achievement(
            id: "color_cadet",
            nameKey: "AchievementColorCadet",
            iconEmoji: "🎨",
            explanationKey: "AchievementColorCadetExplanation",
            unlockCondition: .reachLevel(5, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "shape_novice",
            nameKey: "AchievementShapeNovice",
            iconEmoji: "🔺",
            explanationKey: "AchievementShapeNoviceExplanation",
            unlockCondition: .reachLevel(5, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_apprentice",
            nameKey: "AchievementEmojiApprentice",
            iconEmoji: "😊",
            explanationKey: "AchievementEmojiApprenticeExplanation",
            unlockCondition: .reachLevel(5, mode: "emojis", isPro: false)
        ),
        
        // Unlocking Achievements (3) - These unlock new modes
        Achievement(
            id: "polygon_prodigy",
            nameKey: "AchievementPolygonProdigy",
            iconEmoji: "🔷",
            explanationKey: "AchievementPolygonProdigyExplanation",
            unlockCondition: .reachLevel(10, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "flag_dropper",
            nameKey: "AchievementFlagDropper",
            iconEmoji: "🚩",
            explanationKey: "AchievementFlagDropperExplanation",
            unlockCondition: .reachLevel(15, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "smiley_summoner",
            nameKey: "AchievementSmileySummoner",
            iconEmoji: "😎",
            explanationKey: "AchievementSmileySummonerExplanation",
            unlockCondition: .reachLevel(20, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "ultra_instinct",
            nameKey: "AchievementUltraInstinct",
            iconEmoji: "🔥",
            explanationKey: "AchievementUltraInstinctExplanation",
            unlockCondition: .reachLevel(30, mode: "colors", isPro: false)
        ),
        
        // Intermediate Achievements (3) - Level 15
        Achievement(
            id: "rainbow_wrangler",
            nameKey: "AchievementRainbowWrangler",
            iconEmoji: "🌈",
            explanationKey: "AchievementRainbowWranglerExplanation",
            unlockCondition: .reachLevel(15, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "triangle_tamer",
            nameKey: "AchievementTriangleTamer",
            iconEmoji: "📐",
            explanationKey: "AchievementTriangleTamerExplanation",
            unlockCondition: .reachLevel(15, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_enthusiast",
            nameKey: "AchievementEmojiEnthusiast",
            iconEmoji: "🤩",
            explanationKey: "AchievementEmojiEnthusiastExplanation",
            unlockCondition: .reachLevel(15, mode: "emojis", isPro: false)
        ),
        
        // Advanced Achievements (3) - Level 25
        Achievement(
            id: "color_virtuoso",
            nameKey: "AchievementColorVirtuoso",
            iconEmoji: "🎭",
            explanationKey: "AchievementColorVirtuosoExplanation",
            unlockCondition: .reachLevel(25, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "shape_master",
            nameKey: "AchievementShapeMaster",
            iconEmoji: "⬢",
            explanationKey: "AchievementShapeMasterExplanation",
            unlockCondition: .reachLevel(25, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_expert",
            nameKey: "AchievementEmojiExpert",
            iconEmoji: "😎",
            explanationKey: "AchievementEmojiExpertExplanation",
            unlockCondition: .reachLevel(25, mode: "emojis", isPro: false)
        ),
        
        // Numbers Achievements (2) - Fun and accessible
        Achievement(
            id: "count_on_me",
            nameKey: "AchievementCountOnMe",
            iconEmoji: "🔢",
            explanationKey: "AchievementCountOnMeExplanation",
            unlockCondition: .reachLevel(10, mode: "numbers", isPro: false)
        ),
        Achievement(
            id: "number_cruncher",
            nameKey: "AchievementNumberCruncher",
            iconEmoji: "🧮",
            explanationKey: "AchievementNumberCruncherExplanation",
            unlockCondition: .reachLevel(25, mode: "numbers", isPro: false)
        ),
        
        // Flags Achievement (1)
        Achievement(
            id: "flag_nerd",
            nameKey: "AchievementFlagNerd",
            iconEmoji: "🌍",
            explanationKey: "AchievementFlagNerdExplanation",
            unlockCondition: .reachLevel(20, mode: "flags", isPro: false)
        ),
        
        // Mastery Achievements (3) - Level 30 Standard
        Achievement(
            id: "chromatic_champion",
            nameKey: "AchievementChromaticChampion",
            iconEmoji: "🎨",
            explanationKey: "AchievementChromaticChampionExplanation",
            unlockCondition: .reachLevel(30, mode: "colors", isPro: false)
        ),
        Achievement(
            id: "geometry_genius",
            nameKey: "AchievementGeometryGenius",
            iconEmoji: "🔷",
            explanationKey: "AchievementGeometryGeniusExplanation",
            unlockCondition: .reachLevel(30, mode: "shapes", isPro: false)
        ),
        Achievement(
            id: "emoji_overlord",
            nameKey: "AchievementEmojiOverlord",
            iconEmoji: "😄",
            explanationKey: "AchievementEmojiOverlordExplanation",
            unlockCondition: .reachLevel(30, mode: "emojis", isPro: false)
        ),
        
        // Pro Mastery Achievements (3) - Level 30 Pro
        Achievement(
            id: "rainbow_annihilator",
            nameKey: "AchievementRainbowAnnihilator",
            iconEmoji: "🔥🌈",
            explanationKey: "AchievementRainbowAnnihilatorExplanation",
            unlockCondition: .reachLevel(30, mode: "colors", isPro: true)
        ),
        Achievement(
            id: "shape_sorcerer",
            nameKey: "AchievementShapeSorcerer",
            iconEmoji: "🔥📐",
            explanationKey: "AchievementShapeSorcererExplanation",
            unlockCondition: .reachLevel(30, mode: "shapes", isPro: true)
        ),
        Achievement(
            id: "emoji_apocalypse",
            nameKey: "AchievementEmojiApocalypse",
            iconEmoji: "🔥😈",
            explanationKey: "AchievementEmojiApocalypseExplanation",
            unlockCondition: .reachLevel(30, mode: "emojis", isPro: true)
        ),
        
        // Ultimate Achievement (1)
        Achievement(
            id: "the_unkillable",
            nameKey: "AchievementTheUnkillable",
            iconEmoji: "💀",
            explanationKey: "AchievementTheUnkillableExplanation",
            unlockCondition: .reachLevelInAllModes(30)
        )
    ]
}
