//
//  HighscoreModels.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import Foundation
import SwiftUI

// MARK: - Highscore Models

struct HighscoreEntry: Identifiable, Codable {
    let id: UUID
    let playerName: String
    let score: Int
    let maxLevel: Int  // Added: maximum level reached
    let date: Date
    let achievementIDs: [String]  // IDs of achievements earned in this run
    
    init(id: UUID = UUID(), playerName: String, score: Int, maxLevel: Int = 1, date: Date = Date(), achievementIDs: [String] = []) {
        self.id = id
        self.playerName = playerName
        self.score = score
        self.maxLevel = maxLevel
        self.date = date
        self.achievementIDs = achievementIDs
    }
    
    // Custom decoder to handle backward compatibility
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        playerName = try container.decode(String.self, forKey: .playerName)
        score = try container.decode(Int.self, forKey: .score)
        maxLevel = try container.decode(Int.self, forKey: .maxLevel)
        date = try container.decode(Date.self, forKey: .date)
        // Handle missing achievementIDs for backward compatibility
        achievementIDs = (try? container.decode([String].self, forKey: .achievementIDs)) ?? []
    }
}

// MARK: - Highscore Store

@Observable
class HighscoreStore {
    private let storageKey = "tk_highscores"
    private let maxEntries = 10
    
    var entries: [HighscoreEntry] = []
    
    init() {
        load()
    }
    
    func add(score: Int, playerName: String, maxLevel: Int = 1, achievementIDs: [String] = []) {
        let newEntry = HighscoreEntry(playerName: playerName, score: score, maxLevel: maxLevel, achievementIDs: achievementIDs)
        entries.append(newEntry)
        entries.sort { $0.score > $1.score }
        
        // Keep only top 10
        if entries.count > maxEntries {
            entries = Array(entries.prefix(maxEntries))
        }
        
        save()
    }
    
    func delete(at offsets: IndexSet) {
        entries.remove(atOffsets: offsets)
        save()
    }
    
    func clear() {
        entries.removeAll()
        save()
    }
    
    private func save() {
        if let encoded = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(encoded, forKey: storageKey)
        }
    }
    
    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([HighscoreEntry].self, from: data) else {
            return
        }
        entries = decoded
    }
}
