//
//  DonationService.swift
//  Timekiller
//
//  Created on 01.01.26.
//

#if os(iOS)
import Foundation
import StoreKit

/// Service for managing donation/tip jar In-App Purchases using StoreKit 2
@Observable
class DonationService {
    private(set) var products: [Product] = []
    private(set) var purchasedProductIDs: Set<String> = []
    private(set) var isLoading: Bool = false
    private(set) var error: String? = nil
    
    init() {
        Task {
            await loadProducts()
        }
    }
    
    /// Load available products from the App Store
    @MainActor
    func loadProducts() async {
        isLoading = true
        error = nil
        
        do {
            let productIDs = DonationProduct.allCases.map(\.rawValue)
            products = try await Product.products(for: Set(productIDs))
            
            // Sort products by price (ascending)
            products.sort { $0.price < $1.price }
            
            isLoading = false
        } catch {
            self.error = "Failed to load products: \(error.localizedDescription)"
            isLoading = false
            print("❌ DonationService: Failed to load products: \(error)")
        }
    }
    
    /// Purchase a donation product
    @MainActor
    func purchase(_ product: Product) async throws -> Bool {
        let result = try await product.purchase()
        
        switch result {
        case .success(let verification):
            // Verify the transaction
            let transaction = try checkVerified(verification)
            
            // Consumable: immediately "consume" the purchase
            await transaction.finish()
            
            print("✅ DonationService: Successfully purchased \(product.displayName)")
            return true
            
        case .userCancelled:
            print("ℹ️ DonationService: User cancelled purchase")
            return false
            
        case .pending:
            print("⏳ DonationService: Purchase pending")
            return false
            
        @unknown default:
            print("⚠️ DonationService: Unknown purchase result")
            return false
        }
    }
    
    /// Verify a transaction
    private func checkVerified<T>(_ result: VerificationResult<T>) throws -> T {
        switch result {
        case .unverified(_, let error):
            throw error
        case .verified(let safe):
            return safe
        }
    }
    
    /// Get formatted price for a product
    func formattedPrice(for product: Product) -> String {
        product.displayPrice
    }
    
    /// Get product by donation type
    func product(for donationType: DonationProduct) -> Product? {
        products.first { $0.id == donationType.rawValue }
    }
}
#endif
