//
//  HighscoreView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI
import GameKit

// MARK: - Highscore View
struct HighscoreView_iOS: View {
    let store: HighscoreStore
    let language: String
    let achievementStore: AchievementStore
    let playerName: String
    let gameCenterManager: GameCenterManager
    
    @State private var showAchievements = false
    @State private var showGameCenterLeaderboard = false
    @State private var showGameCenterAchievements = false
    @State private var isEnablingGameCenter = false
    
    var body: some View {
        List {
            // Game Center Promotion Section - Always visible
            Section {
                if gameCenterManager.isEnabled && gameCenterManager.isAuthenticated {
                    // Authenticated - Show leaderboard and achievements buttons
                    Button {
                        showGameCenterLeaderboard = true
                    } label: {
                        HStack {
                            Image(systemName: "trophy.fill")
                                .font(.title2)
                                .foregroundStyle(.yellow)
                                .frame(width: 44)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(L("ViewGlobalLeaderboards", language: language))
                                    .font(.headline)
                                    .foregroundStyle(.primary)
                                Text(L("CompeteWithPlayers", language: language))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundStyle(.tertiary)
                        }
                        .padding(.vertical, 4)
                    }
                    
                    Button {
                        showGameCenterAchievements = true
                    } label: {
                        HStack {
                            Image(systemName: "star.fill")
                                .font(.title2)
                                .foregroundStyle(.orange)
                                .frame(width: 44)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(L("ViewGameCenterAchievements", language: language))
                                    .font(.headline)
                                    .foregroundStyle(.primary)
                                Text(L("TrackYourProgress", language: language))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundStyle(.tertiary)
                        }
                        .padding(.vertical, 4)
                    }
                } else if gameCenterManager.isEnabled && !gameCenterManager.isAuthenticated {
                    // Enabled but not authenticated - Show warning
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 12) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .font(.title2)
                                .foregroundStyle(.orange)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(L("GameCenterNotConnected", language: language))
                                    .font(.headline)
                                Text(L("EnableInSettings", language: language))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                        }
                    }
                    .padding(.vertical, 4)
                } else {
                    // Game Center not enabled - Show compact attractive promotion button
                    Button {
                        enableGameCenter()
                    } label: {
                        HStack(spacing: 12) {
                            // Icon
                            ZStack {
                                Circle()
                                    .fill(
                                        LinearGradient(
                                            colors: [.blue, .cyan],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        )
                                    )
                                    .frame(width: 50, height: 50)
                                
                                Image(systemName: "globe.americas.fill")
                                    .font(.title3)
                                    .foregroundStyle(.white)
                            }
                            
                            // Text content
                            VStack(alignment: .leading, spacing: 4) {
                                Text(L("JoinGlobalLeaderboards", language: language))
                                    .font(.headline)
                                    .foregroundStyle(.primary)
                                
                                Text(L("CompeteWorldwide", language: language))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            
                            Spacer()
                            
                            // Action indicator
                            if isEnablingGameCenter {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle())
                            } else {
                                Image(systemName: "arrow.right.circle.fill")
                                    .font(.title2)
                                    .foregroundStyle(
                                        LinearGradient(
                                            colors: [.blue, .cyan],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        )
                                    )
                            }
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color(.secondarySystemBackground))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(
                                    LinearGradient(
                                        colors: [.blue.opacity(0.3), .cyan.opacity(0.3)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ),
                                    lineWidth: 2
                                )
                        )
                    }
                    .buttonStyle(.plain)
                    .disabled(isEnablingGameCenter)
                    .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                    .listRowBackground(Color.clear)
                }
            } header: {
                if gameCenterManager.isEnabled {
                    Text(L("OnlineLeaderboards", language: language))
                }
            }
            
            // Donation Section
            #if os(iOS)
            Section {
                VStack(spacing: 12) {
                    let prompts = ["DonateHighscore1", "DonateHighscore2", "DonateHighscore3"]
                    let randomPrompt = prompts.randomElement() ?? prompts[0]
                    
                    Text(L(randomPrompt, language: language))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                    
                    DonateButton(language: language, style: .withText)
                        .frame(maxWidth: .infinity)
                }
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets(top: 12, leading: 16, bottom: 12, trailing: 16))
            }
            #endif
            
            // Achievement Overview Button
            Section {
                Button {
                    showAchievements = true
                } label: {
                    HStack {
                        Image(systemName: "trophy.fill")
                            .foregroundStyle(.yellow)
                        Text(L("Achievements", language: language))
                            .font(.headline)
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            
            // Local Highscores Section
            Section {
                if store.entries.isEmpty {
                    Text(L("NoHighscores", language: language))
                        .foregroundStyle(.secondary)
                        .italic()
                } else {
                    ForEach(store.entries) { entry in
                    VStack(spacing: 8) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(entry.playerName)
                                    .font(.headline)
                                HStack(spacing: 8) {
                                    Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                    Text("•")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                    Text("Level \(entry.maxLevel)")
                                        .font(.caption)
                                        .foregroundStyle(.tint)
                                }
                            }
                            
                            Spacer()
                            
                            Text("\(entry.score)")
                                .font(.title2.bold())
                                .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
                        }
                        
                        // Show achievements earned in this run
                        if !entry.achievementIDs.isEmpty {
                            VStack(alignment: .leading, spacing: 8) {
                                ForEach(Achievement.all.filter { entry.achievementIDs.contains($0.id) }, id: \.id) { achievement in
                                    HStack(spacing: 8) {
                                        Text(achievement.iconEmoji)
                                            .font(.system(size: 24))
                                            .frame(width: 32, alignment: .center)
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(L(achievement.nameKey, language: language))
                                                .font(.caption.bold())
                                            Text(L(achievement.explanationKey, language: language))
                                                .font(.caption2)
                                                .foregroundStyle(.secondary)
                                        }
                                        Spacer()
                                    }
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(8)
                                    .background(Color(.tertiarySystemBackground))
                                    .cornerRadius(8)
                                }
                            }
                            .padding(.top, 4)
                        }
                        }
                    }
                }
            } header: {
                Text(L("LocalHighscores", language: language))
            }
        }
        .sheet(isPresented: $showGameCenterLeaderboard) {
            gameCenterManager.gameCenterLeaderboardView(
                leaderboardID: .ios,
                playerScope: .global,
                timeScope: .allTime
            )
            .ignoresSafeArea()
        }
        .sheet(isPresented: $showGameCenterAchievements) {
            gameCenterManager.gameCenterAchievementsView()
                .ignoresSafeArea()
        }
        .sheet(isPresented: $showAchievements) {
            NavigationStack {
                AchievementView_iOS(language: language, playerName: playerName, achievementStore: achievementStore)
                    .navigationTitle(L("Achievements", language: language))
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button(L("Done", language: language)) {
                                showAchievements = false
                            }
                        }
                    }
            }
        }
    }
    
    private func enableGameCenter() {
        isEnablingGameCenter = true
        Task {
            await gameCenterManager.enable()
            isEnablingGameCenter = false
        }
    }
}
