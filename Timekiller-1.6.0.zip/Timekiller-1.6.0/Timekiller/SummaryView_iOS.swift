//
//  SummaryView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI

// MARK: - Summary View
struct SummaryView_iOS: View {
    let level: Int
    let totalScore: Int
    let levelScores: [Int: Int]
    let highscoreStore: HighscoreStore
    let language: String
    let newAchievements: [String]
    let onRestart: () -> Void
    let achievementStore: AchievementStore
    let playerName: String
    let gameCenterManager: GameCenterManager
    
    @State private var showHighscores = false
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Scrollable content area
                ScrollView {
                    VStack(spacing: 20) {
                        // Level Reached and Final Score - Combined for compactness
                        HStack(alignment: .top, spacing: 20) {
                            // Level Reached
                            VStack(spacing: 4) {
                                Text(L("ReachedLevel", language: language))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text("\(level)")
                                    .font(.system(size: 48, weight: .bold, design: .rounded))
                                    .foregroundStyle(.tint)
                            }
                            .frame(maxWidth: .infinity)
                            
                            // Final Score
                            VStack(spacing: 4) {
                                Text(L("TotalScore", language: language))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text("\(totalScore)")
                                    .font(.system(size: 48, weight: .bold, design: .rounded))
                                    .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                            }
                            .frame(maxWidth: .infinity)
                        }
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(12)
                        
                        // New Achievements Section
                        if !newAchievements.isEmpty {
                            VStack(alignment: .leading, spacing: 12) {
                                Text(L("AchievementsEarned", language: language))
                                    .font(.headline)
                                
                                ForEach(Achievement.all.filter { newAchievements.contains($0.id) }, id: \.id) { achievement in
                                    HStack(spacing: 12) {
                                        Text(achievement.iconEmoji)
                                            .font(.system(size: 40))
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(L(achievement.nameKey, language: language))
                                                .font(.subheadline.bold())
                                            Text(L(achievement.explanationKey, language: language))
                                                .font(.caption)
                                                .foregroundStyle(.secondary)
                                        }
                                        Spacer()
                                    }
                                    .padding()
                                    .background(Color(.tertiarySystemBackground))
                                    .cornerRadius(12)
                                }
                            }
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(12)
                        }
                        
                        // Level Scores Breakdown
                        if !levelScores.isEmpty {
                            VStack(alignment: .leading, spacing: 12) {
                                Text(L("ScorePerLevel", language: language))
                                    .font(.headline)
                                
                                ForEach(levelScores.keys.sorted(), id: \.self) { levelNum in
                                    if let score = levelScores[levelNum] {
                                        HStack {
                                            Text("Level \(levelNum):")
                                                .font(.subheadline)
                                            Spacer()
                                            Text("\(score > 0 ? "+" : "")\(score)")
                                                .font(.subheadline.bold())
                                                .foregroundStyle(score > 0 ? Color.green : Color.red)
                                        }
                                        .padding(.horizontal)
                                    }
                                }
                            }
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(12)
                        }
                        
                        // Quick preview of top highscores
                        VStack(alignment: .leading, spacing: 12) {
                            Text(L("TopScores", language: language))
                                .font(.headline)
                            
                            if highscoreStore.entries.isEmpty {
                                Text(L("NoHighscores", language: language))
                                    .foregroundStyle(.secondary)
                                    .italic()
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .padding()
                            } else {
                                ForEach(highscoreStore.entries.prefix(3)) { entry in
                                    HStack {
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(entry.playerName)
                                                .font(.subheadline.bold())
                                            HStack(spacing: 6) {
                                                Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                                                    .font(.caption2)
                                                    .foregroundStyle(.secondary)
                                                Text("•")
                                                    .font(.caption2)
                                                    .foregroundStyle(.secondary)
                                                Text("Level \(entry.maxLevel)")
                                                    .font(.caption)
                                                    .foregroundStyle(.secondary)
                                            }
                                        }
                                        
                                        Spacer()
                                        
                                        Text("\(entry.score)")
                                            .font(.title3.bold())
                                            .foregroundStyle(entry.score >= 0 ? Color.green : Color.red)
                                    }
                                    .padding(.horizontal)
                                }
                            }
                        }
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(12)
                        
                        // Donation prompt (random fun text)
                        #if os(iOS)
                        VStack(spacing: 12) {
                            let prompts = ["DonateGameOver1", "DonateGameOver2", "DonateGameOver3", "DonateGameOver4"]
                            let randomPrompt = prompts.randomElement() ?? prompts[0]
                            
                            Text(L(randomPrompt, language: language))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                            
                            DonateButton(language: language, style: .withText)
                        }
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(12)
                        #endif
                        
                        // Extra bottom padding to ensure content doesn't get hidden behind buttons
                        Color.clear.frame(height: 20)
                    }
                    .padding()
                }
                
                // Fixed action buttons at bottom (outside ScrollView)
                VStack(spacing: 0) {
                    Divider()
                    
                    HStack(spacing: 16) {
                        // Done Button (dismisses and returns to start)
                        Button {
                            onRestart()
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "checkmark.circle.fill")
                                Text(L("Done", language: language))
                            }
                            .font(.title2.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.accentColor)
                            .cornerRadius(12)
                        }
                        
                        // Highscores Button (icon only)
                        Button {
                            showHighscores = true
                        } label: {
                            Image(systemName: "list.number")
                                .font(.title.bold())
                                .foregroundStyle(.white)
                                .frame(width: 60, height: 52)
                                .background(Color.orange)
                                .cornerRadius(12)
                        }
                    }
                    .padding()
                    .background(Color(.systemBackground))
                }
            }
            .navigationTitle(L("GameOver", language: language))
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showHighscores) {
                NavigationStack {
                    HighscoreView_iOS(
                        store: highscoreStore,
                        language: language,
                        achievementStore: achievementStore,
                        playerName: playerName,
                        gameCenterManager: gameCenterManager
                    )
                        .navigationTitle(L("Highscores", language: language))
                        .navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .navigationBarTrailing) {
                                Button(L("Done", language: language)) {
                                    showHighscores = false
                                }
                            }
                        }
                }
            }
        }
    }
}
