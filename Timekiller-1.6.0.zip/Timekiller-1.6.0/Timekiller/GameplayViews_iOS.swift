//
//  GameplayViews_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI

// MARK: - Play Button Style
struct PlayButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .opacity(configuration.isPressed ? 0.9 : 1.0)
            .animation(.easeInOut(duration: 0.2), value: configuration.isPressed)
    }
}

// MARK: - Animated Background
struct AnimatedBackgroundView: View {
    @Environment(\.colorScheme) var systemColorScheme
    @Environment(\.scenePhase) var scenePhase
    let colorScheme: ColorScheme?
    let gameMode: GameMode
    let reduceMotion: Bool
    
    @State private var animationPhase: CGFloat = 0
    
    private var effectiveColorScheme: ColorScheme {
        colorScheme ?? systemColorScheme
    }
    
    var body: some View {
        ZStack {
            // Base gradient
            LinearGradient(
                colors: [
                    effectiveColorScheme == .dark ? Color(red: 0.08, green: 0.09, blue: 0.11) : Color(red: 0.97, green: 0.97, blue: 0.98),
                    effectiveColorScheme == .dark ? Color(red: 0.04, green: 0.05, blue: 0.06) : Color(red: 0.93, green: 0.94, blue: 0.96)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            
            // Material overlay in the middle
            Rectangle()
                .fill(.ultraThinMaterial)
            
            // Floating shapes layer - ABOVE material so they're visible (MORE!)
            GeometryReader { geometry in
                ForEach(0..<16, id: \.self) { index in
                    floatingShape(index: index, in: geometry.size)
                }
            }
        }
        .ignoresSafeArea()
        .onAppear {
            startAnimation()
        }
        .onChange(of: scenePhase) { _, newPhase in
            // Restart animation when app becomes active
            if newPhase == .active {
                startAnimation()
            }
        }
    }
    
    private func startAnimation() {
        // Reset and restart animation
        animationPhase = 0
        withAnimation(.linear(duration: 15).repeatForever(autoreverses: false)) {
            animationPhase = 1
        }
    }
    
    @ViewBuilder
    private func floatingShape(index: Int, in size: CGSize) -> some View {
        let shapeSize: CGFloat = CGFloat.random(in: 90...200)
        let startX = CGFloat.random(in: -60...size.width + 60)
        let startY = CGFloat.random(in: -60...size.height + 60)
        let offsetX = CGFloat.random(in: -170...170)
        let offsetY = CGFloat.random(in: -280...280)
        let duration = Double.random(in: 12...28)
        let delay = Double(index) * 0.5
        
        // Decide: emoji, colored shape, or semi-transparent shape
        let variant = index % 3
        
        if variant == 0 {
            // Emoji variant (every 3rd item) - MORE emojis!
            let emojis = ["🎨", "⭐️", "🎯", "🔥", "✨", "💫", "🌟", "🎪", "🎭", "🎲", "🚀", "⚡️", "🌈", "💎", "🎯", "🎮"]
            Text(emojis[index % emojis.count])
                .font(.system(size: shapeSize * 0.7))
                .opacity(effectiveColorScheme == .dark ? 0.55 : 0.4)
                .blur(radius: 5)
                .offset(
                    x: startX + (animationPhase * offsetX),
                    y: startY + (animationPhase * offsetY)
                )
                .animation(
                    .linear(duration: duration)
                        .repeatForever(autoreverses: true)
                        .delay(delay),
                    value: animationPhase
                )
                .rotationEffect(.degrees(animationPhase * 360 * Double.random(in: 0.3...1.2)))
                .animation(
                    .linear(duration: duration * 2)
                        .repeatForever(autoreverses: false)
                        .delay(delay),
                    value: animationPhase
                )
        } else {
            // Colored shape variant
            let colors = allColors
            let color = colors[index % colors.count]
            
            shapeView(for: index)
                .frame(width: shapeSize, height: shapeSize)
                .foregroundStyle(color.opacity(effectiveColorScheme == .dark ? 0.6 : 0.45))
                .blur(radius: 40)
                .offset(
                    x: startX + (animationPhase * offsetX),
                    y: startY + (animationPhase * offsetY)
                )
                .animation(
                    .linear(duration: duration)
                        .repeatForever(autoreverses: true)
                        .delay(delay),
                    value: animationPhase
                )
                .rotationEffect(.degrees(animationPhase * 360 * Double.random(in: 0.5...1.5)))
                .animation(
                    .linear(duration: duration * 2)
                        .repeatForever(autoreverses: false)
                        .delay(delay),
                    value: animationPhase
                )
        }
    }
    
    @ViewBuilder
    private func shapeView(for index: Int) -> some View {
        // Mix of different shapes
        let shapeType = index % 6
        switch shapeType {
        case 0:
            Circle()
        case 1:
            RoundedRectangle(cornerRadius: 20)
        case 2:
            Capsule()
        case 3:
            Diamond()
        case 4:
            RoundedRectangle(cornerRadius: 40)
        case 5:
            Ellipse()
        default:
            Circle()
        }
    }
    
    private var allColors: [Color] {
        // Mix all colors from all game modes
        [.red, .blue, .green, .yellow, .purple, .orange, .pink, .cyan, 
         .indigo, .teal, .mint, .brown]
    }
}

// MARK: - Diamond Shape
struct Diamond: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.midX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.midX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.midY))
        path.closeSubpath()
        return path
    }
}
