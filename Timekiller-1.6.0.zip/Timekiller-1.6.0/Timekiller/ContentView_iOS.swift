//
//  ContentView_iOS.swift
//  Timekiller
//
//  Created by Wolfgang Heider on 22.12.25.
//

import SwiftUI
import GameKit

struct ContentView_iOS: View {
    // MARK: - App Storage (Settings)
    @AppStorage("tk_playerName") private var playerName: String = "Player"
    @AppStorage("tk_language") private var appLanguage: String = Self.defaultLanguage()
    @AppStorage("tk_gridSize") private var gridSizeRaw: String = "2x2"
    @AppStorage("tk_theme") private var appTheme: String = "system"  // system, light, dark
    @AppStorage("tk_startLevel") private var startLevel: Int = 1  // Which level to start at
    @AppStorage("tk_proMode") private var proMode: Bool = false  // Pro mode: 16 colors instead of 8
    @AppStorage("tk_gameMode") private var gameModeRaw: String = GameMode.colors.rawValue  // Game mode
    @AppStorage("tk_soundEnabled") private var soundEnabled: Bool = true  // Sound feedback
    @AppStorage("tk_hapticsEnabled") private var hapticsEnabled: Bool = true  // Haptic feedback
    
    // MARK: - Computed Player Name (Game Center Override)
    /// When Game Center is enabled and authenticated, use the Game Center player name
    private var effectivePlayerName: String {
        if gameCenterManager.isEnabled && gameCenterManager.isAuthenticated,
           let gcPlayerName = gameCenterManager.gameCenterPlayerName {
            return gcPlayerName
        }
        return playerName
    }
    
    // MARK: - Environment
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    
    // MARK: - Constants
    private let roundsPerLevel: Int = 6  // 6 rounds per level
    
    // MARK: - State
    @State private var highscoreStore = HighscoreStore()
    @State private var achievementStore = AchievementStore()
    @State private var feedbackManager = FeedbackManager.shared
    @State private var gameCenterManager = GameCenterManager.shared
    @State private var isPlaying = false
    @State private var showSettings = false
    @State private var showHighscores = false
    @State private var showSummary = false
    @State private var showLevelComplete = false
    @State private var isLowTimeWarningTriggered = false  // Track if warning was triggered
    @State private var newAchievementsThisRun: [String] = []  // Track achievements earned in current game
    @State private var showLockAlert = false
    @State private var lockAlertMessage = ""
    @State private var showPlayerSelection = false  // Player selection sheet
    
    // Animation states for start screen
    @State private var exampleTileAnimationPhase: Int = 0
    @State private var startButtonScale: CGFloat = 1.0
    @State private var exampleAnimationTimer: Timer? = nil
    @State private var logoAnimationPhase: Int = 0  // 0 = color blob, 1 = emoji
    @State private var currentLogoColor: GameColor? = nil
    @State private var currentLogoEmoji: GameEmoji? = nil
    
    // Game State
    @State private var level: Int = 1
    @State private var round: Int = 0
    @State private var totalScore: Int = 0
    @State private var levelScore: Int = 0
    @State private var levelScores: [Int: Int] = [:]  // Track score per level
    @State private var tiles: [TileData] = []
    @State private var timer: Timer?
    @State private var scoreDelta: Int? = nil
    @State private var timeRemaining: Double = 0
    @State private var timerProgress: Double = 1.0
    @State private var sessionShapes: [GameShape] = []  // Randomized shape set for this game session
    @State private var sessionFlags: [GameFlag] = []  // Randomized flag set for this game session
    @State private var sessionEmojis: [GameEmoji] = []  // Randomized emoji set for this game session
    @State private var consecutiveTimeouts: Int = 0  // Track consecutive timeouts
    @State private var consecutiveWrongTaps: Int = 0  // Track consecutive wrong taps
    @State private var mistakesThisLevel: Int = 0  // Track mistakes (timeouts or wrong taps) in current level
    
    // Multiple correct answers state
    @State private var correctTilesFound: Set<UUID> = []  // Track which correct tiles have been found
    @State private var requiredCorrectCount: Int = 1  // How many correct tiles need to be found this round
    
    // MARK: - Computed Properties
    private var gridSize: GridSize {
        // Grid size is now determined by level, not by user selection
        gridSizeForLevel(level)
    }
    
    private var gameMode: GameMode {
        GameMode(rawValue: gameModeRaw) ?? .colors
    }
    
    private var availableColors: [GameColor] {
        proMode ? GameColor.proColors : GameColor.standardColors
    }
    
    private var availableShapes: [GameShape] {
        // Return the randomized session shapes if they exist, otherwise the full set
        if !sessionShapes.isEmpty {
            return sessionShapes
        }
        return proMode ? GameShape.proShapes : GameShape.standardShapes
    }
    
    private var availableEmojis: [GameEmoji] {
        // Return the randomized session emojis if they exist, otherwise the full set
        if !sessionEmojis.isEmpty {
            return sessionEmojis
        }
        return proMode ? GameEmoji.proEmojis : GameEmoji.standardEmojis
    }
    
    private var availableFlags: [GameFlag] {
        // Return the randomized session flags if they exist, otherwise the full set
        if !sessionFlags.isEmpty {
            return sessionFlags
        }
        return proMode ? GameFlag.proFlags : GameFlag.standardFlags
    }
    
    private var availableNumbers: [GameNumber] {
        return proMode ? GameNumber.proNumbers : GameNumber.standardNumbers
    }
    
    private var availableItems: Int {
        switch gameMode {
        case .colors:
            return availableColors.count
        case .numbers:
            return availableNumbers.count
        case .shapes:
            return availableShapes.count
        case .flags:
            return availableFlags.count
        case .emojis:
            return availableEmojis.count
        }
    }
    
    private var currentRoundDuration: Double {
        // Use the new baseTimeForLevel function
        return baseTimeForLevel(level)
    }
    
    /// Calculate score for the current round using the new simplified system
    /// Base Points = 10 per round
    /// Level Bonus = level × 5
    /// Time Bonus = seconds remaining × 10
    /// Pro Multiplier = 1.5 (if Pro Mode, otherwise 1.0)
    /// Round Score = (Base + Level Bonus + Time Bonus) × Pro Multiplier
    private func calculateRoundScore(secondsRemaining: Double) -> Int {
        let basePoints = 10
        let levelBonus = level * 5
        let timeBonus = Int(secondsRemaining.rounded()) * 10
        
        let subtotal = basePoints + levelBonus + timeBonus
        let proMultiplier: Double = proMode ? 1.5 : 1.0
        
        return Int(Double(subtotal) * proMultiplier)
    }
    
    private var colorScheme: ColorScheme? {
        switch appTheme {
        case "light": return .light
        case "dark": return .dark
        default: return nil  // system
        }
    }
    
    // Dev Mode: Check if player name is "Wulf" (trimmed, case-insensitive)
    private var isDevMode: Bool {
        let normalized = playerName.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.caseInsensitiveCompare("Wulf") == .orderedSame
    }
    
    private var gameModeIcon: String {
        switch gameMode {
        case .colors:
            return "paintpalette.fill"
        case .numbers:
            return "number.square.fill"
        case .shapes:
            return "star.square.fill"
        case .flags:
            return "flag.fill"
        case .emojis:
            return "face.smiling.fill"
        }
    }
    
    // MARK: - Body
    var body: some View {
        NavigationStack {
            ZStack {
                // Animated background
                AnimatedBackgroundView(
                    colorScheme: colorScheme,
                    gameMode: gameMode,
                    reduceMotion: reduceMotion
                )
                
                VStack(spacing: 20) {
                    // Header - only show when playing
                    if isPlaying {
                        headerView
                    }
                    
                    // Grid
                    if isPlaying {
                        VStack(spacing: 0) {
                            gridView
                                .transition(.scale.combined(with: .opacity))
                            
                            // Time Progress Bar
                            GeometryReader { geometry in
                                ZStack(alignment: .leading) {
                                    Rectangle()
                                        .fill(Color.gray.opacity(0.3))
                                        .frame(height: 8)
                                    
                                    Rectangle()
                                        .fill(timerProgress > 0.3 ? Color.green : Color.red)
                                        .frame(width: geometry.size.width * timerProgress, height: 8)
                                        .animation(.linear(duration: 0.1), value: timerProgress)
                                }
                                .cornerRadius(4)
                            }
                            .frame(height: 8)
                            .padding(.top, 20)
                        }
                    } else {
                        startPromptView
                    }
                    
                    Spacer()
                }
                .padding()
                
                // Score Delta Overlay
                if let delta = scoreDelta {
                    scoreDeltaOverlay(delta: delta)
                }
                
                // Level Complete Overlay
                if showLevelComplete {
                    levelCompleteOverlay
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    // Only show settings button on start screen (not during gameplay or pause)
                    if !isPlaying && round == 0 {
                        Button {
                            showSettings = true
                        } label: {
                            Image(systemName: "gear")
                        }
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    if round > 0 && !showLevelComplete {  // Show play/pause only if game has started and not on level complete screen
                        Button {
                            // Dev Mode: Auto-solve on pause button tap during gameplay (invisible)
                            if isDevMode && isPlaying {
                                autoSolveRound()
                            } else if isPlaying {
                                pauseGame()
                            } else {
                                startGame()  // Resume game
                            }
                        } label: {
                            Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                        }
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    // Only show highscores button on start screen (not during gameplay or level complete)
                    if round == 0 && !showLevelComplete {
                        Button {
                            showHighscores = true
                        } label: {
                            Image(systemName: "list.number")
                        }
                    }
                }
            }
            .sheet(isPresented: $showSettings) {
                SettingsView_iOS(
                    playerName: $playerName,
                    appLanguage: $appLanguage,
                    gridSizeRaw: $gridSizeRaw,
                    appTheme: $appTheme,
                    proMode: $proMode,
                    gameModeRaw: $gameModeRaw,
                    soundEnabled: $soundEnabled,
                    hapticsEnabled: $hapticsEnabled,
                    showPlayerSelection: $showPlayerSelection,
                    startLevel: $startLevel,
                    gameCenterManager: gameCenterManager
                )
            }
            .onChange(of: soundEnabled) { _, newValue in
                feedbackManager.soundEnabled = newValue
            }
            .onChange(of: hapticsEnabled) { _, newValue in
                feedbackManager.hapticsEnabled = newValue
            }
            .onChange(of: proMode) { _, _ in
                // Pro mode changed - force new game
                if isPlaying || round > 0 {
                    resetGame()
                }
            }
            .onChange(of: gameModeRaw) { _, _ in
                // Game mode changed - force new game
                if isPlaying || round > 0 {
                    resetGame()
                }
            }
            .onChange(of: appLanguage) { _, _ in
                // Language changed - force new game if in progress
                if isPlaying || round > 0 {
                    resetGame()
                }
            }
            .sheet(isPresented: $showHighscores) {
                NavigationStack {
                    HighscoreView_iOS(
                        store: highscoreStore,
                        language: appLanguage,
                        achievementStore: achievementStore,
                        playerName: effectivePlayerName,
                        gameCenterManager: gameCenterManager
                    )
                        .navigationTitle(L("Highscores", language: appLanguage))
                        .navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .navigationBarTrailing) {
                                Button(L("Done", language: appLanguage)) {
                                    showHighscores = false
                                }
                            }
                        }
                }
            }
            .sheet(isPresented: $showSummary) {
                SummaryView_iOS(
                    level: level,
                    totalScore: totalScore,
                    levelScores: levelScores,
                    highscoreStore: highscoreStore,
                    language: appLanguage,
                    newAchievements: newAchievementsThisRun,
                    onRestart: {
                        showSummary = false
                        resetGame()
                    },
                    achievementStore: achievementStore,
                    playerName: effectivePlayerName,
                    gameCenterManager: gameCenterManager
                )
                .interactiveDismissDisabled()  // Prevent swipe-to-dismiss
            }
            .sheet(isPresented: $showPlayerSelection) {
                PlayerNameSelectionView_iOS(
                    playerName: $playerName,
                    achievementStore: achievementStore,
                    language: appLanguage,
                    gameModeRaw: $gameModeRaw,
                    proMode: $proMode
                )
            }
        }
        .preferredColorScheme(colorScheme)
        .onAppear {
            // Sync feedback manager settings on appear
            feedbackManager.soundEnabled = soundEnabled
            feedbackManager.hapticsEnabled = hapticsEnabled
            
            // Initialize achievement store with current player
            achievementStore.currentPlayerName = effectivePlayerName
            
            // Validate current selections and reset to defaults if locked
            validateSelections()
            
            // Authenticate with Game Center if enabled
            if gameCenterManager.isEnabled {
                gameCenterManager.authenticate()
            }
        }
        .onChange(of: playerName) { _, newValue in
            // Update achievement store when player name changes (only if not in Game Center mode)
            if !gameCenterManager.isEnabled || !gameCenterManager.isAuthenticated {
                achievementStore.currentPlayerName = newValue
            }
        }
        .onChange(of: gameCenterManager.isAuthenticated) { _, isAuthenticated in
            // When Game Center authentication changes, sync data and update player
            if isAuthenticated, gameCenterManager.isEnabled {
                // Switch to Game Center player name
                if let gcPlayerName = gameCenterManager.gameCenterPlayerName {
                    // Store the previous local player name for first-time migration
                    let previousLocalPlayer = playerName
                    
                    // Trigger sync with Game Center (passing previous local player for migration)
                    Task {
                        await gameCenterManager.syncFromGameCenter(
                            achievementStore: achievementStore,
                            highscoreStore: highscoreStore,
                            previousLocalPlayer: previousLocalPlayer
                        )
                    }
                    
                    // Update to Game Center player (will be set again in sync, but set here for immediate UI update)
                    achievementStore.currentPlayerName = gcPlayerName
                }
            } else {
                // Switched back to local mode - use local player name
                achievementStore.currentPlayerName = playerName
            }
        }
        .onChange(of: gameCenterManager.isEnabled) { _, isEnabled in
            // When Game Center is toggled
            if isEnabled && gameCenterManager.isAuthenticated {
                // Switched to Game Center mode - use Game Center player
                if let gcPlayerName = gameCenterManager.gameCenterPlayerName {
                    // Store the previous local player name for migration
                    let previousLocalPlayer = playerName
                    
                    // Trigger sync (passing previous local player for potential migration)
                    Task {
                        await gameCenterManager.syncFromGameCenter(
                            achievementStore: achievementStore,
                            highscoreStore: highscoreStore,
                            previousLocalPlayer: previousLocalPlayer
                        )
                    }
                    
                    // Update to Game Center player
                    achievementStore.currentPlayerName = gcPlayerName
                }
            } else {
                // Switched to local mode - use local player
                achievementStore.currentPlayerName = playerName
            }
            
            // Reset game if playing
            if isPlaying || round > 0 {
                resetGame()
            }
            
            // Revalidate selections for new player
            validateSelections()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
            // App is going to background or being minimized - pause the game
            if isPlaying && round > 0 {
                pauseGame()
            }
        }
    }
    
    // MARK: - Header View
    private var headerView: some View {
        VStack(spacing: 8) {
            // Top Row: Level Progress, Find Counter, and Timer - kompakt in einer Zeile
            HStack(spacing: 12) {
                // Level & Round Card - kompakter
                VStack(spacing: 4) {
                    HStack(spacing: 6) {
                        Image(systemName: "mountain.2.fill")
                            .font(.caption2)
                            .foregroundStyle(.white)
                        Text("L\(level)")
                            .font(.caption.bold())
                            .foregroundStyle(.white)
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .cornerRadius(12)
                    
                    // Round Progress Dots - kompakter
                    HStack(spacing: 4) {
                        ForEach(1...roundsPerLevel, id: \.self) { roundNum in
                            Circle()
                                .fill(roundNum <= round ? Color.blue : Color.gray.opacity(0.3))
                                .frame(width: 6, height: 6)
                        }
                    }
                }
                
                // Find X/Y Counter - kompakt, nur wenn benötigt
                if requiredCorrectCount > 1 {
                    HStack(spacing: 6) {
                        Image(systemName: "target")
                            .font(.caption2)
                            .foregroundStyle(.orange)
                        
                        Text("\(correctTilesFound.count)/\(requiredCorrectCount)")
                            .font(.callout.bold())
                            .foregroundStyle(correctTilesFound.count >= requiredCorrectCount ? .green : .primary)
                            .animation(.easeInOut, value: correctTilesFound.count)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(.thinMaterial)
                    )
                }
                
                Spacer()
                
                // Circular Timer - etwas kleiner
                circularTimerView
                    .frame(width: 70, height: 70)
            }
            
            // Bottom Row: Scores - kompakter
            HStack(spacing: 8) {
                // Total Score Card - kompakter
                VStack(spacing: 2) {
                    Text(L("TotalScore", language: appLanguage))
                        .font(.caption2.bold())
                        .foregroundStyle(.secondary)
                        .textCase(.uppercase)
                    
                    Text("\(totalScore)")
                        .font(.title3.bold())
                        .foregroundStyle(totalScore >= 0 ? Color.green : Color.red)
                        .contentTransition(.numericText())
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(.thinMaterial)
                )
                
                // Level Score Card - kompakter
                VStack(spacing: 2) {
                    Text(L("LevelScore", language: appLanguage))
                        .font(.caption2.bold())
                        .foregroundStyle(.secondary)
                        .textCase(.uppercase)
                    
                    Text("\(levelScore)")
                        .font(.title3.bold())
                        .foregroundStyle(levelScore >= 0 ? Color.green : Color.red)
                        .contentTransition(.numericText())
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(.thinMaterial)
                )
                
                // Pro Mode Indicator - kompakt
                if proMode {
                    VStack(spacing: 2) {
                        Image(systemName: "flame.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                        Text("×1.5")
                            .font(.caption2.bold())
                            .foregroundStyle(.white)
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(
                        Capsule()
                            .fill(
                                LinearGradient(
                                    colors: [.purple, .pink],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                    )
                }
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 6)
    }
    
    // Level & Round Progress Card
    private var levelRoundCard: some View {
        VStack(spacing: 8) {
            // Level Badge
            HStack(spacing: 4) {
                Image(systemName: "mountain.2.fill")
                    .font(.caption)
                    .foregroundStyle(.white)
                Text("\(L("Level", language: appLanguage)) \(level)")
                    .font(.headline.bold())
                    .foregroundStyle(.white)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(
                LinearGradient(
                    colors: [.blue, .purple],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .cornerRadius(20)
            
            // Round Progress Dots
            HStack(spacing: 6) {
                ForEach(1...roundsPerLevel, id: \.self) { roundNum in
                    Circle()
                        .fill(roundNum <= round ? Color.blue : Color.gray.opacity(0.3))
                        .frame(width: 8, height: 8)
                        .scaleEffect(roundNum == round && !reduceMotion ? 1.3 : 1.0)
                }
            }
            .animation(reduceMotion ? .none : .spring(response: 0.3, dampingFraction: 0.6), value: round)
            
            Text("\(round)/\(roundsPerLevel) \(L("Round", language: appLanguage))")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(.secondarySystemBackground))
                .shadow(color: .blue.opacity(0.2), radius: 8, x: 0, y: 4)
        )
    }
    
    // Circular Timer View
    private var circularTimerView: some View {
        ZStack {
            // Background circle
            Circle()
                .stroke(Color.gray.opacity(0.2), lineWidth: 8)
            
            // Progress circle
            Circle()
                .trim(from: 0, to: timerProgress)
                .stroke(
                    timerProgress > 0.5 ? Color.green : (timerProgress > 0.25 ? Color.orange : Color.red),
                    style: StrokeStyle(lineWidth: 8, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.linear(duration: 0.1), value: timerProgress)
            
            // Time text
            VStack(spacing: 2) {
                Text(String(format: "%.1f", timeRemaining))
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundStyle(timerProgress > 0.25 ? Color.primary : Color.red)
                    .contentTransition(.numericText())
                    .animation(.none, value: timeRemaining)
                
                Text("sec")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(.secondary)
            }
            .scaleEffect(timerProgress < 0.25 && !reduceMotion ? 1.1 : 1.0)
            .animation(reduceMotion || timerProgress >= 0.25 ? .none : .easeInOut(duration: 0.5).repeatCount(5, autoreverses: true), value: timerProgress < 0.25)
        }
        .padding(8)
        .background(
            Circle()
                .fill(Color(.secondarySystemBackground))
                .shadow(color: timerProgress > 0.25 ? Color.green.opacity(0.2) : Color.red.opacity(0.3), radius: 8, x: 0, y: 4)
        )
    }
    
    // Score Card Component
    private func scoreCard(title: String, score: Int, isMain: Bool) -> some View {
        VStack(spacing: 4) {
            Text(title)
                .font(.caption.bold())
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
            
            Text("\(score)")
                .font(.system(size: isMain ? 32 : 24, weight: .bold, design: .rounded))
                .foregroundStyle(score >= 0 ? Color.green : Color.red)
                .contentTransition(.numericText())
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(
                    LinearGradient(
                        colors: [
                            Color(.secondarySystemBackground),
                            Color(.tertiarySystemBackground)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .shadow(color: (score >= 0 ? Color.green : Color.red).opacity(0.15), radius: 6, x: 0, y: 3)
        )
    }
    
    // MARK: - Grid View
    private var gridView: some View {
        let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: gridSize.columns)
        
        return LazyVGrid(columns: columns, spacing: 12) {
            ForEach(tiles.indices, id: \.self) { index in
                let tile = tiles[index]
                let isFound = correctTilesFound.contains(tile.id)
                
                Button {
                    handleTileTap(tile: tile)
                } label: {
                    ZStack {
                        Rectangle()
                            .fill(tile.backgroundColor)
                            .cornerRadius(12)
                            .shadow(radius: 4)
                            .opacity(isFound ? 0.5 : 1.0)  // Dim found tiles
                        
                        VStack(spacing: 4) {
                            // Show emoji if in emoji mode
                            if let emoji = tile.visualContent {
                                Text(emoji)
                                    .font(.system(size: 40))
                            }
                            
                            // Show text label
                            Text(localizedContentName(tile.displayContent.nameKey, language: appLanguage))
                                .font(.headline.bold())
                                .foregroundStyle(textColorForTile(tile))
                                .multilineTextAlignment(.center)
                                .minimumScaleFactor(0.5)
                                .lineLimit(2)
                        }
                        .padding(8)
                        .opacity(isFound ? 0.3 : 1.0)  // Dim text on found tiles
                        
                        // Checkmark overlay for found correct tiles
                        if isFound {
                            ZStack {
                                Circle()
                                    .fill(Color.green)
                                    .frame(width: 50, height: 50)
                                    .shadow(color: .green.opacity(0.5), radius: 8, x: 0, y: 4)
                                
                                Image(systemName: "checkmark")
                                    .font(.system(size: 30, weight: .bold))
                                    .foregroundStyle(.white)
                            }
                            .transition(.scale.combined(with: .opacity))
                        }
                    }
                    .frame(maxWidth: .infinity, minHeight: 80)
                }
                .buttonStyle(.plain)
                .disabled(isFound)  // Disable interaction with found tiles
            }
        }
    }
    
    // MARK: - Start Prompt View
    private var startPromptView: some View {
        VStack(spacing: 30) {
            // If game is paused (round > 0 but not playing), show pause screen
            if round > 0 && !isPlaying {
                pauseScreenView
            } else {
                // Normal start screen
                startScreenView
            }
        }
        .padding()
    }
    
    private var pauseScreenView: some View {
        VStack(spacing: 30) {
            // Pause Icon
            Image(systemName: "pause.circle.fill")
                .font(.system(size: 80))
                .foregroundStyle(.orange)
            
            // Pause Title
            Text(L("Pause", language: appLanguage))
                .font(.largeTitle.bold())
            
            // Current Stats - Reusing header style from playing mode
            VStack(spacing: 12) {
                // Level & Round Info
                HStack(spacing: 12) {
                    // Level Badge
                    HStack(spacing: 4) {
                        Image(systemName: "mountain.2.fill")
                            .font(.caption)
                            .foregroundStyle(.white)
                        Text("\(L("Level", language: appLanguage)) \(level)")
                            .font(.headline.bold())
                            .foregroundStyle(.white)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .cornerRadius(20)
                    
                    Spacer()
                    
                    // Round Progress
                    HStack(spacing: 6) {
                        ForEach(1...roundsPerLevel, id: \.self) { roundNum in
                            Circle()
                                .fill(roundNum <= round ? Color.blue : Color.gray.opacity(0.3))
                                .frame(width: 8, height: 8)
                        }
                    }
                    
                    Text("\(round)/\(roundsPerLevel)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                
                // Scores Row
                HStack(spacing: 12) {
                    // Total Score Card
                    scoreCard(
                        title: L("TotalScore", language: appLanguage),
                        score: totalScore,
                        isMain: true
                    )
                    .frame(maxWidth: .infinity)
                    
                    // Level Score Card
                    scoreCard(
                        title: L("LevelScore", language: appLanguage),
                        score: levelScore,
                        isMain: false
                    )
                    .frame(maxWidth: .infinity)
                }
            }
            .padding()
            .background(.regularMaterial)
            .cornerRadius(12)
            
            // Buttons
            VStack(spacing: 16) {
                // Resume Button
                Button {
                    startGame()
                } label: {
                    HStack {
                        Image(systemName: "play.fill")
                        Text(L("Resume", language: appLanguage))
                    }
                    .font(.title2.bold())
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 20)
                    .background(Color.accentColor)
                    .cornerRadius(16)
                }
                
                // Quit Button
                Button {
                    quitGame()
                } label: {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                        Text(L("Quit", language: appLanguage))
                    }
                    .font(.title3.bold())
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(Color.red.opacity(0.8))
                    .cornerRadius(16)
                }
            }
        }
    }
    
    private var startScreenView: some View {
        VStack(spacing: 24) {
            // Welcome Header with animated icon
            VStack(spacing: 12) {
                ZStack {
                    // Alternating logo: color blob or emoji
                    if logoAnimationPhase == 0 {
                        // Color blob phase
                        if let logoColor = currentLogoColor {
                            Circle()
                                .fill(logoColor.color)
                                .frame(width: 55, height: 55)
                                .scaleEffect(reduceMotion ? 1.0 : startButtonScale)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 1.5).repeatForever(autoreverses: true), value: startButtonScale)
                                .shadow(color: logoColor.color.opacity(0.4), radius: 12, x: 0, y: 4)
                        }
                    } else {
                        // Emoji phase
                        if let logoEmoji = currentLogoEmoji {
                            Text(logoEmoji.emoji)
                                .font(.system(size: 50))
                                .scaleEffect(reduceMotion ? 1.0 : startButtonScale)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 1.5).repeatForever(autoreverses: true), value: startButtonScale)
                                .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
                        }
                    }
                }
                .frame(width: 60, height: 60)
                .onAppear {
                    if !reduceMotion {
                        startButtonScale = 1.2
                        initializeLogo()
                        startExampleAnimation()
                    } else {
                        initializeLogo()
                    }
                }
                .onDisappear {
                    stopExampleAnimation()
                }
                
                Text(L("Title", language: appLanguage))
                    .font(.system(size: 36, weight: .black, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.orange, .red, .pink],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
            }
            .padding(.top, 20)
            
            // Example Grid with Animation (more prominent)
            VStack(spacing: 12) {
                HStack {
                    Image(systemName: "eye.fill")
                        .foregroundStyle(.orange)
                    Text(L("Example", language: appLanguage))
                        .font(.headline.bold())
                    Spacer()
                }
                
                switch gameMode {
                case .colors:
                    animatedColorExampleGrid
                case .numbers:
                    animatedNumberExampleGrid
                case .shapes:
                    animatedShapeExampleGrid
                case .flags:
                    animatedFlagExampleGrid
                case .emojis:
                    animatedEmojiExampleGrid
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(.regularMaterial)
                    .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
            )
            
            // Settings Section in a card
            VStack(spacing: 12) {
                // Game Mode
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Image(systemName: gameModeIcon)
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .animation(.easeInOut, value: gameMode)
                        Text(L("GameMode", language: appLanguage))
                            .font(.caption.bold())
                            .foregroundStyle(.secondary)
                    }
                    
                    // Custom mode picker with lock support
                    HStack(spacing: 0) {
                        ForEach(GameMode.allCases) { mode in
                            let isLocked = !achievementStore.isModeUnlocked(mode: mode, isPro: false, playerName: playerName)
                            Button {
                                if isLocked {
                                    showUnlockAlert(for: mode)
                                } else {
                                    gameModeRaw = mode.rawValue
                                }
                            } label: {
                                HStack(spacing: 4) {
                                    if isLocked {
                                        Image(systemName: "lock.fill")
                                            .font(.caption2)
                                    }
                                    Text(L(mode.nameKey, language: appLanguage))
                                        .font(.subheadline)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(gameModeRaw == mode.rawValue ? Color.accentColor : Color.clear)
                                .foregroundStyle(gameModeRaw == mode.rawValue ? .white : (isLocked ? .secondary : .primary))
                                .opacity(isLocked ? 0.6 : 1.0)
                            }
                        }
                    }
                    .background(Color(.tertiarySystemBackground))
                    .cornerRadius(8)
                }
                
                // Pro Mode Toggle with fancy description
                VStack(alignment: .leading, spacing: 8) {
                    let isProLocked = !achievementStore.isModeUnlocked(mode: gameMode, isPro: true, playerName: playerName)
                    
                    HStack {
                        Image(systemName: proMode ? "brain.head.profile" : "person.fill")
                            .font(.caption)
                            .foregroundStyle(proMode ? .purple : .blue)
                            .animation(.easeInOut, value: proMode)
                        Text(L("ProMode", language: appLanguage))
                            .font(.caption.bold())
                            .foregroundStyle(.secondary)
                        Spacer()
                        
                        if isProLocked {
                            Button {
                                showUnlockAlert(forProMode: true)
                            } label: {
                                HStack(spacing: 4) {
                                    Image(systemName: "lock.fill")
                                        .font(.caption)
                                    Text(L("Locked", language: appLanguage))
                                        .font(.caption)
                                }
                                .foregroundStyle(.secondary)
                            }
                        } else {
                            Toggle("", isOn: $proMode)
                                .labelsHidden()
                        }
                    }
                    
                    // Dynamic, fun description with gradient background
                    proModeDescriptionView
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(
                        LinearGradient(
                            colors: proMode ? [.purple, .pink] : [.blue, .cyan],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                        .animation(.easeInOut, value: proMode)
                    )
                    .cornerRadius(10)
                    .opacity(isProLocked ? 0.5 : 1.0)
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(.regularMaterial)
                    .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
            )
            .alert(L("Locked", language: appLanguage), isPresented: $showLockAlert) {
                Button(L("Done", language: appLanguage), role: .cancel) { }
            } message: {
                Text(lockAlertMessage)
            }
            
            // Big Play Button with gradient and animation
            Button {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                    startGame()
                }
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "play.fill")
                        .font(.title2)
                    Text(L("Start", language: appLanguage))
                        .font(.title.bold())
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 20)
                .background(
                    LinearGradient(
                        colors: [.orange, .red],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(20)
                .shadow(color: .orange.opacity(0.5), radius: 10, x: 0, y: 5)
            }
            .buttonStyle(PlayButtonStyle())
            
            // Donate button (subtle, at bottom)
            #if os(iOS)
            HStack {
                Spacer()
                DonateButton(language: appLanguage, style: .withText, customText: L("SupportFreeApp", language: appLanguage))
                    .opacity(0.65)
            }
            .padding(.top, 8)
            #endif
        }
        .padding()
    }
    
    
    // MARK: - Animated Example Grids
    
    // Pro Mode Description View
    private var proModeDescriptionView: some View {
        let itemCount: Int
        let itemName: String
        
        if gameMode == .colors {
            itemCount = proMode ? GameColor.proColors.count : GameColor.standardColors.count
            itemName = L("Colors", language: appLanguage)
        } else if gameMode == .numbers {
            itemCount = proMode ? GameNumber.proNumbers.count : GameNumber.standardNumbers.count
            itemName = L("Numbers", language: appLanguage)
        } else if gameMode == .shapes {
            itemCount = proMode ? GameShape.proShapes.count : GameShape.standardShapes.count
            itemName = L("Shapes", language: appLanguage)
        } else if gameMode == .flags {
            itemCount = proMode ? GameFlag.proFlags.count : GameFlag.standardFlags.count
            itemName = L("ModeFlags", language: appLanguage)
        } else {
            itemCount = proMode ? GameEmoji.proEmojis.count : GameEmoji.standardEmojis.count
            itemName = L("Emojis", language: appLanguage)
        }
        
        return HStack(spacing: 6) {
            Image(systemName: proMode ? "flame.fill" : "star.fill")
                .font(.system(size: 14))
                .foregroundStyle(proMode ? .orange : .yellow)
                .animation(.bouncy, value: proMode)
            
            Text("\(itemCount) \(itemName)")
                .font(.caption2)
                .foregroundStyle(.white)
                .fontWeight(.semibold)
                .animation(.none, value: proMode)
            
            Spacer()
            
            // Points multiplier badge (only show if Pro Mode is active)
            if proMode {
                HStack(spacing: 4) {
                    Text(L("PointsMultiplier", language: appLanguage))
                        .font(.system(size: 9))
                        .foregroundStyle(.white.opacity(0.7))
                    
                    Text("×1.5")
                        .font(.caption2.bold())
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(
                            Capsule()
                                .fill(.white.opacity(0.3))
                        )
                }
                .transition(.scale.combined(with: .opacity))
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(
            LinearGradient(
                colors: proMode ? [.purple, .pink] : [.blue, .cyan],
                startPoint: .leading,
                endPoint: .trailing
            )
            .animation(.easeInOut, value: proMode)
        )
        .cornerRadius(10)
    }
    
    // MARK: - Animated Example Grids
    @ViewBuilder
    private var animatedColorExampleGrid: some View {
        // Safety check: ensure we have at least 4 colors available
        if availableColors.count >= 4 {
            let exampleColors: [(GameColor, String)] = [
                (availableColors[0], availableColors[1].nameKey),
                (availableColors[1], availableColors[1].nameKey),  // Correct ✓
                (availableColors[2], availableColors[3].nameKey),
                (availableColors[3], availableColors[0].nameKey)
            ]
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(0..<4, id: \.self) { index in
                    let (bgColor, textKey) = exampleColors[index]
                    let isCorrect = (index == 1)
                    
                    ZStack {
                        Rectangle()
                            .fill(bgColor.color)
                            .frame(height: 80)
                            .cornerRadius(12)
                            .shadow(color: isCorrect ? .green.opacity(0.5) : .clear, radius: 8, x: 0, y: 4)
                            .scaleEffect(isCorrect && exampleTileAnimationPhase == 1 && !reduceMotion ? 1.05 : 1.0)
                            .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: exampleTileAnimationPhase)
                        
                        Text(localizedContentName(textKey, language: appLanguage))
                            .font(.headline.bold())
                            .foregroundStyle(.black.opacity(0.8))
                        
                        if isCorrect {
                            // Animated checkmark
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.white)
                                .font(.title)
                                .background(
                                    Circle()
                                        .fill(.green)
                                        .frame(width: 32, height: 32)
                                )
                                .offset(x: 30, y: -28)
                                .scaleEffect(exampleTileAnimationPhase == 1 && !reduceMotion ? 1.1 : 1.0)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: exampleTileAnimationPhase)
                        }
                    }
                }
            }
        } else {
            Text("Not enough colors")
        }
    }
    
    @ViewBuilder
    private var animatedNumberExampleGrid: some View {
        // Safety check: ensure we have at least 4 numbers available
        if availableNumbers.count >= 4 {
            let exampleNumbers: [(GameNumber, String)] = [
                (availableNumbers[0], availableNumbers[1].nameKey),
                (availableNumbers[1], availableNumbers[1].nameKey),  // Correct ✓
                (availableNumbers[2], availableNumbers[3].nameKey),
                (availableNumbers[3], availableNumbers[0].nameKey)
            ]
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(0..<4, id: \.self) { index in
                    let (number, textKey) = exampleNumbers[index]
                    let isCorrect = (index == 1)
                    
                    ZStack {
                        Rectangle()
                            .fill(Color(.tertiarySystemBackground))
                            .frame(height: 80)
                            .cornerRadius(12)
                            .shadow(color: isCorrect ? .green.opacity(0.5) : .clear, radius: 8, x: 0, y: 4)
                            .scaleEffect(isCorrect && exampleTileAnimationPhase == 1 && !reduceMotion ? 1.05 : 1.0)
                            .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: exampleTileAnimationPhase)
                        
                        VStack(spacing: 4) {
                            Text(String(number.value))
                                .font(.system(size: 40))
                                .foregroundStyle(.primary)
                            Text(localizedContentName(textKey, language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.primary)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }
                        
                        if isCorrect {
                            // Animated checkmark
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.white)
                                .font(.title)
                                .background(
                                    Circle()
                                        .fill(.green)
                                        .frame(width: 32, height: 32)
                                )
                                .offset(x: 30, y: -28)
                                .scaleEffect(exampleTileAnimationPhase == 1 && !reduceMotion ? 1.1 : 1.0)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: exampleTileAnimationPhase)
                        }
                    }
                }
            }
        } else {
            Text("Not enough numbers")
        }
    }
    
    @ViewBuilder
    private var animatedEmojiExampleGrid: some View {
        // Safety check: ensure we have at least 4 emojis available
        if availableEmojis.count >= 4 {
            let exampleEmojis: [(GameEmoji, String)] = [
                (availableEmojis[0], availableEmojis[1].nameKey),
                (availableEmojis[1], availableEmojis[1].nameKey),  // Correct ✓
                (availableEmojis[2], availableEmojis[3].nameKey),
                (availableEmojis[3], availableEmojis[0].nameKey)
            ]
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(0..<4, id: \.self) { index in
                    let (emoji, textKey) = exampleEmojis[index]
                    let isCorrect = (index == 1)
                    
                    ZStack {
                        Rectangle()
                            .fill(Color(.tertiarySystemBackground))
                            .frame(height: 80)
                            .cornerRadius(12)
                            .shadow(color: isCorrect ? .green.opacity(0.5) : .clear, radius: 8, x: 0, y: 4)
                            .scaleEffect(isCorrect && exampleTileAnimationPhase == 1 && !reduceMotion ? 1.05 : 1.0)
                            .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: exampleTileAnimationPhase)
                        
                        VStack(spacing: 4) {
                            Text(emoji.emoji)
                                .font(.system(size: 32))
                            Text(localizedContentName(textKey, language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.primary)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }
                        
                        if isCorrect {
                            // Animated checkmark
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.white)
                                .font(.title)
                                .background(
                                    Circle()
                                        .fill(.green)
                                        .frame(width: 32, height: 32)
                                )
                                .offset(x: 30, y: -28)
                                .scaleEffect(exampleTileAnimationPhase == 1 && !reduceMotion ? 1.1 : 1.0)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: exampleTileAnimationPhase)
                        }
                    }
                }
            }
        } else {
            Text("Not enough emojis")
        }
    }
    
    @ViewBuilder
    private var animatedShapeExampleGrid: some View {
        // Safety check: ensure we have at least 4 shapes available
        if availableShapes.count >= 4 {
            let exampleShapes: [(GameShape, String)] = [
                (availableShapes[0], availableShapes[1].nameKey),
                (availableShapes[1], availableShapes[1].nameKey),  // Correct ✓
                (availableShapes[2], availableShapes[3].nameKey),
                (availableShapes[3], availableShapes[0].nameKey)
            ]
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(0..<4, id: \.self) { index in
                    let (shape, textKey) = exampleShapes[index]
                    let isCorrect = (index == 1)
                    
                    ZStack {
                        Rectangle()
                            .fill(Color(.tertiarySystemBackground))
                            .frame(height: 80)
                            .cornerRadius(12)
                            .shadow(color: isCorrect ? .green.opacity(0.5) : .clear, radius: 8, x: 0, y: 4)
                            .scaleEffect(isCorrect && exampleTileAnimationPhase == 1 && !reduceMotion ? 1.05 : 1.0)
                            .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: exampleTileAnimationPhase)
                        
                        VStack(spacing: 4) {
                            Text(shape.shape)
                                .font(.system(size: 40))
                            Text(localizedContentName(textKey, language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.primary)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }
                        
                        if isCorrect {
                            // Animated checkmark
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.white)
                                .font(.title)
                                .background(
                                    Circle()
                                        .fill(.green)
                                        .frame(width: 32, height: 32)
                                )
                                .offset(x: 30, y: -28)
                                .scaleEffect(exampleTileAnimationPhase == 1 && !reduceMotion ? 1.1 : 1.0)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: exampleTileAnimationPhase)
                        }
                    }
                }
            }
        } else {
            Text("Not enough shapes")
        }
    }
    
    @ViewBuilder
    private var animatedFlagExampleGrid: some View {
        // Safety check: ensure we have at least 4 flags available
        if availableFlags.count >= 4 {
            let exampleFlags: [(GameFlag, String)] = [
                (availableFlags[0], availableFlags[1].nameKey),
                (availableFlags[1], availableFlags[1].nameKey),  // Correct ✓
                (availableFlags[2], availableFlags[3].nameKey),
                (availableFlags[3], availableFlags[0].nameKey)
            ]
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(0..<4, id: \.self) { index in
                    let (flag, textKey) = exampleFlags[index]
                    let isCorrect = (index == 1)
                    
                    ZStack {
                        Rectangle()
                            .fill(Color(.tertiarySystemBackground))
                            .frame(height: 80)
                            .cornerRadius(12)
                            .shadow(color: isCorrect ? .green.opacity(0.5) : .clear, radius: 8, x: 0, y: 4)
                            .scaleEffect(isCorrect && exampleTileAnimationPhase == 1 && !reduceMotion ? 1.05 : 1.0)
                            .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: exampleTileAnimationPhase)
                        
                        VStack(spacing: 4) {
                            Text(flag.emoji)
                                .font(.system(size: 40))
                            Text(localizedContentName(textKey, language: appLanguage))
                                .font(.caption.bold())
                                .foregroundStyle(.primary)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }
                        
                        if isCorrect {
                            // Animated checkmark
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.white)
                                .font(.title)
                                .background(
                                    Circle()
                                        .fill(.green)
                                        .frame(width: 32, height: 32)
                                )
                                .offset(x: 30, y: -28)
                                .scaleEffect(exampleTileAnimationPhase == 1 && !reduceMotion ? 1.1 : 1.0)
                                .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: exampleTileAnimationPhase)
                        }
                    }
                }
            }
        } else {
            Text("Not enough flags")
        }
    }
    
    // MARK: - Example Grids
    private var colorExampleGrid: some View {
        let exampleColors: [(GameColor, String)] = [
            (availableColors[0], availableColors[1].nameKey),
            (availableColors[1], availableColors[1].nameKey),  // Correct ✓
            (availableColors[2], availableColors[3].nameKey),
            (availableColors[3], availableColors[0].nameKey)
        ]
        
        return LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
            ForEach(0..<4, id: \.self) { index in
                let (bgColor, textKey) = exampleColors[index]
                ZStack {
                    Rectangle()
                        .fill(bgColor.color)
                        .frame(height: 60)
                        .cornerRadius(8)
                    
                    Text(localizedContentName(textKey, language: appLanguage))
                        .font(.caption.bold())
                        .foregroundStyle(.black.opacity(0.8))
                    
                    if index == 1 {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                            .font(.title2)
                            .offset(x: 25, y: -20)
                    }
                }
            }
        }
        .frame(maxWidth: 200)
    }
    
    private var emojiExampleGrid: some View {
        let exampleEmojis: [(GameEmoji, String)] = [
            (availableEmojis[0], availableEmojis[1].nameKey),
            (availableEmojis[1], availableEmojis[1].nameKey),  // Correct ✓
            (availableEmojis[2], availableEmojis[3].nameKey),
            (availableEmojis[3], availableEmojis[0].nameKey)
        ]
        
        return LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
            ForEach(0..<4, id: \.self) { index in
                let (emoji, textKey) = exampleEmojis[index]
                ZStack {
                    Rectangle()
                        .fill(Color(.secondarySystemBackground))
                        .frame(height: 60)
                        .cornerRadius(8)
                    
                    VStack(spacing: 2) {
                        Text(emoji.emoji)
                            .font(.system(size: 24))
                        Text(localizedContentName(textKey, language: appLanguage))
                            .font(.caption2.bold())
                            .foregroundStyle(.primary)
                            .minimumScaleFactor(0.5)
                            .lineLimit(1)
                    }
                    
                    if index == 1 {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                            .font(.title2)
                            .offset(x: 25, y: -20)
                    }
                }
            }
        }
        .frame(maxWidth: 200)
    }
    
    // MARK: - Level Complete Overlay
    private var levelCompleteOverlay: some View {
        ZStack {
            Color.black.opacity(0.7)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Scrollable content area
                ScrollView {
                    VStack(spacing: 25) {
                        // Celebration Icon
                        Image(systemName: "star.fill")
                            .font(.system(size: 70))
                            .foregroundStyle(.yellow)
                            .shadow(color: .yellow.opacity(0.5), radius: 20)
                        
                        // Level Complete Text
                        VStack(spacing: 8) {
                            Text("Level \(level - 1)")
                                .font(.system(size: 22, weight: .semibold))
                                .foregroundStyle(.white)
                            
                            Text(L("LevelComplete", language: appLanguage))
                                .font(.system(size: 32, weight: .bold))
                                .foregroundStyle(.white)
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                        }
                        
                        // Show new achievements if any
                        if !newAchievementsThisRun.isEmpty {
                            VStack(spacing: 12) {
                                Text(L("NewAchievement", language: appLanguage))
                                    .font(.headline)
                                    .foregroundStyle(.white)
                                
                                ForEach(Achievement.all.filter { newAchievementsThisRun.contains($0.id) }, id: \.id) { achievement in
                                    HStack(spacing: 12) {
                                        Text(achievement.iconEmoji)
                                            .font(.system(size: 32))
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(L(achievement.nameKey, language: appLanguage))
                                                .font(.subheadline.bold())
                                                .foregroundStyle(.white)
                                            Text(L(achievement.explanationKey, language: appLanguage))
                                                .font(.caption)
                                                .foregroundStyle(.white.opacity(0.8))
                                        }
                                    }
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 8)
                                    .background(Color.white.opacity(0.15))
                                    .cornerRadius(12)
                                }
                            }
                            .padding(.horizontal, 20)
                        }
                        
                        // Score for this level
                        VStack(spacing: 8) {
                            Text(L("LevelScore", language: appLanguage))
                                .font(.subheadline)
                                .foregroundStyle(.white.opacity(0.8))
                            
                            if let previousLevelScore = levelScores[level - 1] {
                                Text("\(previousLevelScore > 0 ? "+" : "")\(previousLevelScore)")
                                    .font(.system(size: 44, weight: .bold, design: .rounded))
                                    .foregroundStyle(previousLevelScore > 0 ? Color.green : Color.red)
                            }
                        }
                        .padding(.vertical, 16)
                        .padding(.horizontal, 24)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(16)
                        
                        // Next Level Preview
                        nextLevelPreviewCard
                        
                        // Extra bottom padding to ensure content doesn't get hidden behind buttons
                        Color.clear.frame(height: 20)
                    }
                    .padding(30)
                }
                
                // Fixed action buttons at bottom (outside ScrollView)
                VStack(spacing: 0) {
                    Divider()
                        .background(Color.white.opacity(0.3))
                    
                    HStack(spacing: 16) {
                        // Quit Button
                        Button {
                            withAnimation {
                                showLevelComplete = false
                                // Don't call endGameEarly() which would save levelScore again
                                // Just finalize and show summary
                                isPlaying = false
                                invalidateTimer()
                                
                                // Calculate final score from positive levels only
                                let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
                                highscoreStore.add(score: finalScore, playerName: effectivePlayerName, maxLevel: level - 1, achievementIDs: newAchievementsThisRun)
                                totalScore = finalScore
                                
                                // Submit score to Game Center
                                Task {
                                    await gameCenterManager.submitScore(finalScore)
                                }
                                
                                feedbackManager.trigger(.gameOver)
                                showSummary = true
                            }
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "xmark.circle.fill")
                                Text(L("Quit", language: appLanguage))
                            }
                            .font(.title3.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(Color.red.opacity(0.8))
                            .cornerRadius(16)
                        }
                        
                        // Continue Button
                        Button {
                            withAnimation {
                                showLevelComplete = false
                                startNextLevel()
                            }
                        } label: {
                            HStack(spacing: 12) {
                                Text(L("Continue", language: appLanguage))
                                Image(systemName: "arrow.right")
                            }
                            .font(.title3.bold())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(Color.accentColor)
                            .cornerRadius(16)
                        }
                    }
                    .padding()
                    .background(Color.black.opacity(0.3))
                }
            }
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(.ultraThinMaterial)
            )
            .padding(20)
        }
        .transition(.scale.combined(with: .opacity))
    }
    
    // MARK: - Next Level Preview Card
    private var nextLevelPreviewCard: some View {
        VStack(spacing: 12) {
            HStack {
                Image(systemName: "arrow.right.circle.fill")
                    .foregroundStyle(.orange)
                Text(L("NextLevelPreview", language: appLanguage))
                    .font(.headline.bold())
                    .foregroundStyle(.white)
                Spacer()
            }
            
            VStack(alignment: .leading, spacing: 8) {
                // Show what changes in next level
                let nextLevel = level
                let currentGridSize = gridSizeForLevel(level - 1)
                let nextGridSize = gridSizeForLevel(nextLevel)
                let currentCorrectCount = requiredCorrectAnswers(level: level - 1)
                let nextCorrectCount = requiredCorrectAnswers(level: nextLevel)
                let currentTime = baseTimeForLevel(level - 1)
                let nextTime = baseTimeForLevel(nextLevel)
                
                // Grid size change?
                if currentGridSize != nextGridSize {
                    HStack(spacing: 8) {
                        Image(systemName: "grid")
                            .foregroundStyle(.blue)
                        Text(nextGridSizeDescription(nextGridSize))
                            .font(.subheadline)
                            .foregroundStyle(.white)
                    }
                }
                
                // Multiple answers change?
                if currentCorrectCount != nextCorrectCount {
                    HStack(spacing: 8) {
                        Image(systemName: "target")
                            .foregroundStyle(.orange)
                        Text(nextCorrectAnswersDescription(nextCorrectCount))
                            .font(.subheadline)
                            .foregroundStyle(.white)
                    }
                }
                
                // Time reduction?
                if nextTime < currentTime {
                    HStack(spacing: 8) {
                        Image(systemName: "timer")
                            .foregroundStyle(.red)
                        Text(L("NextLevelInfo_TimeReduction", language: appLanguage))
                            .font(.subheadline)
                            .foregroundStyle(.white)
                        Text("(\(String(format: "%.1f", nextTime))s)")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.7))
                    }
                }
                
                // If nothing changes, show encouraging message
                if currentGridSize == nextGridSize && currentCorrectCount == nextCorrectCount && nextTime >= currentTime {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                        Text(L("NextLevelInfo_KeepGoing", language: appLanguage))
                            .font(.subheadline)
                            .foregroundStyle(.white)
                    }
                }
            }
        }
        .padding()
        .background(Color.white.opacity(0.15))
        .cornerRadius(16)
        .padding(.horizontal, 20)
    }
    
    private func nextGridSizeDescription(_ gridSize: GridSize) -> String {
        switch gridSize {
        case .grid2x2:
            return L("NextLevelInfo_GridSize_2x2", language: appLanguage)
        case .grid2x4:
            return L("NextLevelInfo_GridSize_2x4", language: appLanguage)
        case .grid3x5:
            return L("NextLevelInfo_GridSize_3x5", language: appLanguage)
        }
    }
    
    private func nextCorrectAnswersDescription(_ count: Int) -> String {
        switch count {
        case 2:
            return L("NextLevelInfo_DoubleAnswers", language: appLanguage)
        case 3:
            return L("NextLevelInfo_TripleAnswers", language: appLanguage)
        case 4:
            return L("NextLevelInfo_QuadAnswers", language: appLanguage)
        default:
            let template = L("NextLevelInfo_MultipleCorrectAnswers", language: appLanguage)
            return String(format: template, count)
        }
    }
    
    // MARK: - Score Delta Overlay
    private func scoreDeltaOverlay(delta: Int) -> some View {
        VStack(spacing: 8) {
            // Animated Icon
            Image(systemName: delta > 0 ? "checkmark.circle.fill" : "xmark.circle.fill")
                .font(.system(size: 50))
                .foregroundStyle(delta > 0 ? Color.green : Color.red)
                .shadow(color: (delta > 0 ? Color.green : Color.red).opacity(0.5), radius: 20)
            
            // Score Delta
            Text(delta > 0 ? "+\(delta)" : "\(delta)")
                .font(.system(size: 60, weight: .bold, design: .rounded))
                .foregroundStyle(delta > 0 ? Color.green : Color.red)
                .shadow(color: (delta > 0 ? Color.green : Color.red).opacity(0.3), radius: 8)
        }
        .scaleEffect(reduceMotion ? 1.2 : 1.5)
        .transition(reduceMotion ? .opacity : .scale.combined(with: .opacity))
        .animation(reduceMotion ? .easeInOut(duration: 0.2) : .spring(response: 0.4, dampingFraction: 0.6), value: scoreDelta)
    }
    
    // MARK: - Game Logic
    private func startGame() {
        isPlaying = true
        if round > 0 {
            // Resume from pause: provide start/resume feedback
            feedbackManager.trigger(.gameStart)
        }
        if round == 0 {
            // Use startLevel in dev mode, otherwise always start at level 1
            level = isDevMode ? startLevel : 1
            totalScore = 0
            levelScore = 0
            levelScores = [:]
            consecutiveTimeouts = 0  // Reset timeout counter
            consecutiveWrongTaps = 0  // Reset wrong tap counter
            mistakesThisLevel = 0  // Reset mistakes counter
            
            // Randomize shapes/flags/emoji selection at start of new game
            if gameMode == .shapes {
                let sourceShapes = proMode ? GameShape.proShapes : GameShape.standardShapes
                sessionShapes = sourceShapes.shuffled()
                sessionFlags = []  // Clear flags for shapes mode
                sessionEmojis = []  // Clear emojis for shapes mode
            } else if gameMode == .flags {
                let sourceFlags = proMode ? GameFlag.proFlags : GameFlag.standardFlags
                sessionFlags = sourceFlags.shuffled()
                sessionShapes = []  // Clear shapes for flags mode
                sessionEmojis = []  // Clear emojis for flags mode
            } else if gameMode == .emojis {
                let sourceEmojis = proMode ? GameEmoji.proEmojis : GameEmoji.standardEmojis
                sessionEmojis = sourceEmojis.shuffled()
                sessionShapes = []  // Clear shapes for emoji mode
                sessionFlags = []  // Clear flags for emoji mode
            } else {
                sessionShapes = []  // Clear for color/number modes
                sessionFlags = []  // Clear for color/number modes
                sessionEmojis = []  // Clear for color/number modes
            }
            
            feedbackManager.trigger(.gameStart)
            nextRound()
        }
        startTimer()
    }
    
    private func pauseGame() {
        isPlaying = false
        invalidateTimer()
        
        // Generate new tiles to prevent cheating
        // Keep the same round number but generate new tiles
        round -= 1  // Decrement because nextRound() will increment it again
        nextRound()
    }
    
    private func resetGame() {
        level = 1
        round = 0
        totalScore = 0
        levelScore = 0
        levelScores = [:]
        tiles = []
        sessionShapes = []  // Clear session shapes
        sessionFlags = []  // Clear session flags
        sessionEmojis = []  // Clear session emojis
        consecutiveTimeouts = 0  // Reset timeout counter
        consecutiveWrongTaps = 0  // Reset wrong tap counter
        newAchievementsThisRun = []  // Clear achievements for new run
        mistakesThisLevel = 0  // Reset mistakes counter
        invalidateTimer()
    }
    
    private func startNextLevel() {
        round = 0
        levelScore = 0
        consecutiveTimeouts = 0  // Reset timeout counter for new level
        consecutiveWrongTaps = 0  // Reset wrong tap counter for new level
        mistakesThisLevel = 0  // Reset mistakes counter for new level
        isPlaying = true
        feedbackManager.trigger(.gameStart)
        nextRound()
        startTimer()
    }
    
    private func nextRound() {
        round += 1
        
        // Check if level is complete
        if round > roundsPerLevel {
            endLevel()
            return
        }
        
        // Determine how many correct answers are required for this level
        requiredCorrectCount = requiredCorrectAnswers(level: level)
        correctTilesFound = []  // Reset found tiles for new round
        
        // Generate new tiles based on game mode
        let tileCount = gridSize.tileCount
        
        switch gameMode {
        case .colors:
            generateColorTiles(count: tileCount)
        case .numbers:
            generateNumberTiles(count: tileCount)
        case .shapes:
            generateShapeTiles(count: tileCount)
        case .flags:
            generateFlagTiles(count: tileCount)
        case .emojis:
            generateEmojiTiles(count: tileCount)
        }
    }
    
    private func generateColorTiles(count: Int) {
        // Select colors for tiles
        var selectedColors: [GameColor] = []
        if count <= availableColors.count {
            let shuffled = availableColors.shuffled()
            selectedColors = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedColors.append(availableColors.randomElement()!)
            }
        }
        
        // Determine number of correct tiles needed
        let correctCount = min(requiredCorrectCount, count)
        
        // Pick random indices as correct ones
        var correctIndices = Set<Int>()
        while correctIndices.count < correctCount {
            correctIndices.insert(Int.random(in: 0..<count))
        }
        
        // Create labels: some correct, rest incorrect
        var labelArray = [GameColor](repeating: selectedColors[0], count: count)
        
        for i in 0..<count {
            if correctIndices.contains(i) {
                // Make this tile correct
                labelArray[i] = selectedColors[i]
            } else {
                // Make this tile incorrect
                let tileColorKey = selectedColors[i].nameKey
                let candidates = availableColors.filter { $0.nameKey != tileColorKey }
                if let choice = candidates.randomElement() {
                    labelArray[i] = choice
                } else {
                    labelArray[i] = availableColors.randomElement()!
                }
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .color(labelArray[i]),
                backgroundContent: .color(selectedColors[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateNumberTiles(count: Int) {
        // Select numbers for tiles
        var selectedNumbers: [GameNumber] = []
        if count <= availableNumbers.count {
            let shuffled = availableNumbers.shuffled()
            selectedNumbers = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedNumbers.append(availableNumbers.randomElement()!)
            }
        }
        
        // Determine number of correct tiles needed
        let correctCount = min(requiredCorrectCount, count)
        
        // Pick random indices as correct ones
        var correctIndices = Set<Int>()
        while correctIndices.count < correctCount {
            correctIndices.insert(Int.random(in: 0..<count))
        }
        
        // Create labels: some correct, rest incorrect
        var labelArray = [GameNumber](repeating: selectedNumbers[0], count: count)
        
        for i in 0..<count {
            if correctIndices.contains(i) {
                // Make this tile correct
                labelArray[i] = selectedNumbers[i]
            } else {
                // Make this tile incorrect
                let tileNumberKey = selectedNumbers[i].nameKey
                let candidates = availableNumbers.filter { $0.nameKey != tileNumberKey }
                if let choice = candidates.randomElement() {
                    labelArray[i] = choice
                } else {
                    labelArray[i] = availableNumbers.randomElement()!
                }
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .number(labelArray[i]),
                backgroundContent: .number(selectedNumbers[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateShapeTiles(count: Int) {
        // Select shapes for tiles
        var selectedShapes: [GameShape] = []
        if count <= availableShapes.count {
            let shuffled = availableShapes.shuffled()
            selectedShapes = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedShapes.append(availableShapes.randomElement()!)
            }
        }
        
        // Determine number of correct tiles needed
        let correctCount = min(requiredCorrectCount, count)
        
        // Pick random indices as correct ones
        var correctIndices = Set<Int>()
        while correctIndices.count < correctCount {
            correctIndices.insert(Int.random(in: 0..<count))
        }
        
        // Create labels: some correct, rest incorrect
        var labelArray = [GameShape](repeating: selectedShapes[0], count: count)
        
        for i in 0..<count {
            if correctIndices.contains(i) {
                // Make this tile correct
                labelArray[i] = selectedShapes[i]
            } else {
                // Make this tile incorrect
                let tileShapeKey = selectedShapes[i].nameKey
                let candidates = availableShapes.filter { $0.nameKey != tileShapeKey }
                if let choice = candidates.randomElement() {
                    labelArray[i] = choice
                } else {
                    labelArray[i] = availableShapes.randomElement()!
                }
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .shape(labelArray[i]),
                backgroundContent: .shape(selectedShapes[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateFlagTiles(count: Int) {
        // Select flags for tiles
        var selectedFlags: [GameFlag] = []
        if count <= availableFlags.count {
            let shuffled = availableFlags.shuffled()
            selectedFlags = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedFlags.append(availableFlags.randomElement()!)
            }
        }
        
        // Determine number of correct tiles needed
        let correctCount = min(requiredCorrectCount, count)
        
        // Pick random indices as correct ones
        var correctIndices = Set<Int>()
        while correctIndices.count < correctCount {
            correctIndices.insert(Int.random(in: 0..<count))
        }
        
        // Create labels: some correct, rest incorrect
        var labelArray = [GameFlag](repeating: selectedFlags[0], count: count)
        
        for i in 0..<count {
            if correctIndices.contains(i) {
                // Make this tile correct
                labelArray[i] = selectedFlags[i]
            } else {
                // Make this tile incorrect
                let tileFlagKey = selectedFlags[i].nameKey
                let candidates = availableFlags.filter { $0.nameKey != tileFlagKey }
                if let choice = candidates.randomElement() {
                    labelArray[i] = choice
                } else {
                    labelArray[i] = availableFlags.randomElement()!
                }
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .flag(labelArray[i]),
                backgroundContent: .flag(selectedFlags[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func generateEmojiTiles(count: Int) {
        // Select emojis for tiles
        var selectedEmojis: [GameEmoji] = []
        if count <= availableEmojis.count {
            let shuffled = availableEmojis.shuffled()
            selectedEmojis = Array(shuffled.prefix(count))
        } else {
            for _ in 0..<count {
                selectedEmojis.append(availableEmojis.randomElement()!)
            }
        }
        
        // Determine number of correct tiles needed
        let correctCount = min(requiredCorrectCount, count)
        
        // Pick random indices as correct ones
        var correctIndices = Set<Int>()
        while correctIndices.count < correctCount {
            correctIndices.insert(Int.random(in: 0..<count))
        }
        
        // Create labels: some correct, rest incorrect
        var labelArray = [GameEmoji](repeating: selectedEmojis[0], count: count)
        
        for i in 0..<count {
            if correctIndices.contains(i) {
                // Make this tile correct
                labelArray[i] = selectedEmojis[i]
            } else {
                // Make this tile incorrect
                let tileEmojiKey = selectedEmojis[i].nameKey
                let candidates = availableEmojis.filter { $0.nameKey != tileEmojiKey }
                if let choice = candidates.randomElement() {
                    labelArray[i] = choice
                } else {
                    labelArray[i] = availableEmojis.randomElement()!
                }
            }
        }
        
        // Build tiles
        var newTiles: [TileData] = []
        for i in 0..<count {
            newTiles.append(TileData(
                displayContent: .emoji(labelArray[i]),
                backgroundContent: .emoji(selectedEmojis[i])
            ))
        }
        
        tiles = newTiles
    }
    
    private func endLevel() {
        invalidateTimer()
        isPlaying = false
        
        // Store the score for this level
        levelScores[level] = levelScore
        
        // Track level completion for achievements (only if level completed successfully)
        if levelScore > 0 {
            achievementStore.markLevelCompletion(level: level, mode: gameMode, isPro: proMode)
            let newAchievements = achievementStore.checkAndUnlockAchievements()
            newAchievementsThisRun.append(contentsOf: newAchievements)
            
            // Report new achievements to Game Center
            if !newAchievements.isEmpty {
                Task {
                    await gameCenterManager.reportAchievements(newAchievements)
                }
            }
        }
        
        if levelScore <= 0 {
            // Game Over - calculate total from positive levels only
            let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
            highscoreStore.add(score: finalScore, playerName: effectivePlayerName, maxLevel: level, achievementIDs: newAchievementsThisRun)
            totalScore = finalScore  // Update display score
            
            // Submit score to Game Center
            Task {
                await gameCenterManager.submitScore(finalScore)
            }
            
            feedbackManager.trigger(.gameOver)
            showSummary = true
        } else {
            // Add positive score to total
            totalScore += levelScore
            
            // Trigger level complete feedback
            feedbackManager.trigger(.levelComplete)
            
            // Show level complete screen
            level += 1
            withAnimation {
                showLevelComplete = true
            }
        }
    }
    
    private func handleTileTap(tile: TileData) {
        // Provide immediate tap feedback for responsiveness
        feedbackManager.trigger(.tileTap)
        
        let isCorrect = tile.isCorrect
        
        // Check if this correct tile was already found
        if isCorrect && correctTilesFound.contains(tile.id) {
            // Already found - do nothing
            return
        }
        
        // Use new simplified scoring system
        let points = calculateRoundScore(secondsRemaining: timeRemaining)
        
        if isCorrect {
            // Mark this correct tile as found
            correctTilesFound.insert(tile.id)
            
            // Reset both counters on correct tap
            consecutiveTimeouts = 0
            consecutiveWrongTaps = 0
            levelScore += points
            showScoreDelta(points)
            
            // Trigger positive feedback
            feedbackManager.trigger(.correctTap)
            
            // Check if all required correct tiles have been found
            if correctTilesFound.count >= requiredCorrectCount {
                // Round complete! Move to next round
                invalidateTimer()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    if self.isPlaying {
                        self.nextRound()
                        self.startTimer()
                    }
                }
            }
        } else {
            // Wrong tap - increment mistake counter
            mistakesThisLevel += 1
            
            levelScore -= points
            showScoreDelta(-points)
            
            // Trigger negative feedback
            feedbackManager.trigger(.wrongTap)
            
            // Check if this is the second mistake (game over)
            if mistakesThisLevel >= 2 {
                // End the game immediately on second mistake
                invalidateTimer()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.endGameEarly()
                }
                return
            } else {
                // First mistake - continue playing but show warning
                // No need to advance round - player can keep trying
            }
        }
    }
    
    // MARK: - Dev Mode Helper
    private func autoSolveRound() {
        guard isDevMode && isPlaying else { return }
        
        // Find all correct tiles that haven't been found yet
        let correctTiles = tiles.filter { tile in
            tile.isCorrect && !correctTilesFound.contains(tile.id)
        }
        
        // Automatically tap all correct tiles
        for tile in correctTiles {
            handleTileTap(tile: tile)
            // Small delay between taps for visual feedback
            Thread.sleep(forTimeInterval: 0.1)
        }
    }
    
    private func showScoreDelta(_ delta: Int) {
        scoreDelta = delta
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            scoreDelta = nil
        }
    }
    
    private func startTimer() {
        invalidateTimer()
        timeRemaining = currentRoundDuration
        timerProgress = 1.0
        isLowTimeWarningTriggered = false  // Reset warning flag
        
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
            if self.isPlaying {
                self.timeRemaining -= 0.05
                self.timerProgress = max(0, self.timeRemaining / self.currentRoundDuration)
                
                // Trigger warning when time drops below 25% (only once per round)
                if self.timerProgress < 0.25 && !self.isLowTimeWarningTriggered {
                    self.isLowTimeWarningTriggered = true
                    self.feedbackManager.trigger(.timeWarning)
                }
                
                if self.timeRemaining <= 0 {
                    self.handleTimeout()
                }
            }
        }
    }
    
    private func handleTimeout() {
        // Trigger timeout feedback
        feedbackManager.trigger(.timeout)
        
        // Increment mistake counter
        mistakesThisLevel += 1
        
        // Check if this is the second mistake (game over)
        if mistakesThisLevel >= 2 {
            // Game ends on second mistake
            endGameEarly()
        } else {
            // First mistake - continue to next round after brief pause
            invalidateTimer()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                if self.isPlaying {
                    self.nextRound()
                    self.startTimer()
                }
            }
        }
    }
    
    private func endGameEarly() {
        invalidateTimer()
        isPlaying = false
        
        // Store the score for this level
        levelScores[level] = levelScore
        
        // Calculate final score from positive levels only
        let finalScore = levelScores.values.filter { $0 > 0 }.reduce(0, +)
        highscoreStore.add(score: finalScore, playerName: effectivePlayerName, maxLevel: level, achievementIDs: newAchievementsThisRun)
        totalScore = finalScore
        
        // Submit score to Game Center
        Task {
            await gameCenterManager.submitScore(finalScore)
        }
        
        feedbackManager.trigger(.gameOver)
        showSummary = true
    }
    
    private func quitGame() {
        endGameEarly()
    }
    
    private func invalidateTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    // MARK: - Helper Functions
    private static func defaultLanguage() -> String {
        // Get the first preferred language from the system
        if let preferredLanguage = Locale.preferredLanguages.first {
            // Check if it starts with "de" for German
            if preferredLanguage.hasPrefix("de") {
                return "de"
            }
        }
        // Default to English for all other languages
        return "en"
    }
    
    static func defaultPlayerName() -> String {
        return "Player"
    }
    
    private func localizedContentName(_ nameKey: String, language: String) -> String {
        return L(nameKey, language: language)
    }
    
    // MARK: - Unlock Alert Helpers
    
    private func validateSelections() {
        // Check if current mode is locked (skip if Dev Mode)
        if !achievementStore.isModeUnlocked(mode: gameMode, isPro: false, playerName: playerName) {
            gameModeRaw = GameMode.colors.rawValue
        }
        
        // Check if Pro mode is locked (skip if Dev Mode)
        if proMode && !achievementStore.isModeUnlocked(mode: gameMode, isPro: true, playerName: playerName) {
            proMode = false
        }
    }
    
    private func showUnlockAlert(for mode: GameMode) {
        // Find the achievement that unlocks this mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .mode(let unlockMode) = unlocked, unlockMode == mode.rawValue {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
    
    private func showUnlockAlert(forProMode: Bool) {
        // Find the achievement that unlocks Pro mode
        let requiredAchievement = Achievement.all.first { achievement in
            guard let unlocked = achievement.unlocksContent else { return false }
            if case .proMode = unlocked {
                return true
            }
            return false
        }
        
        if let achievement = requiredAchievement {
            let achievementName = L(achievement.nameKey, language: appLanguage)
            let achievementExplanation = L(achievement.explanationKey, language: appLanguage)
            lockAlertMessage = "\(L("UnlockBy", language: appLanguage)) \(achievement.iconEmoji) \(achievementName) – \(achievementExplanation)"
        } else {
            lockAlertMessage = L("Locked", language: appLanguage)
        }
        showLockAlert = true
    }
    
    private func textColorForTile(_ tile: TileData) -> Color {
        switch tile.backgroundContent {
        case .color(_):
            // For color tiles, use black text
            return .black.opacity(0.8)
        case .number(_), .shape(_), .emoji(_), .flag(_):
            // For number, shape, emoji and flag tiles, use primary color (adapts to dark/light mode)
            return .primary
        }
    }
    
    private func startExampleAnimation() {
        // Stop any existing timer first
        stopExampleAnimation()
        
        // Animate the example tiles in a loop
        exampleAnimationTimer = Timer.scheduledTimer(withTimeInterval: 0.8, repeats: true) { _ in
            withAnimation {
                exampleTileAnimationPhase = (exampleTileAnimationPhase + 1) % 2
            }
        }
        
        // Animate logo switching between color and emoji
        Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { _ in
            withAnimation(.easeInOut(duration: 0.5)) {
                logoAnimationPhase = (logoAnimationPhase + 1) % 2
                
                // Update logo content
                if logoAnimationPhase == 0 {
                    // Switch to a new random color
                    currentLogoColor = availableColors.randomElement()
                } else {
                    // Switch to a new random emoji
                    currentLogoEmoji = availableEmojis.randomElement()
                }
            }
        }
    }
    
    private func initializeLogo() {
        // Initialize with a random color
        currentLogoColor = availableColors.randomElement()
        currentLogoEmoji = availableEmojis.randomElement()
        logoAnimationPhase = 0
    }
    
    private func stopExampleAnimation() {
        exampleAnimationTimer?.invalidate()
        exampleAnimationTimer = nil
    }
}

// PlayButtonStyle, AnimatedBackgroundView, Diamond, and SummaryView_iOS have been moved to separate files


// MARK: - Preview
#Preview {
    ContentView_iOS()
}


