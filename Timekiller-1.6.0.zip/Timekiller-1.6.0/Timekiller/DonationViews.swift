//
//  DonationViews.swift
//  Timekiller
//
//  Created on 01.01.26.
//

#if os(iOS)
import SwiftUI
import StoreKit

// MARK: - Donate Button

struct DonateButton: View {
    let language: String
    let style: DonateButtonStyle
    let customText: String?
    
    @State private var showDonationSheet = false
    @State private var donationService = DonationService()
    
    enum DonateButtonStyle {
        case iconOnly
        case withText
    }
    
    init(language: String, style: DonateButtonStyle = .iconOnly, customText: String? = nil) {
        self.language = language
        self.style = style
        self.customText = customText
    }
    
    var body: some View {
        Button {
            showDonationSheet = true
        } label: {
            switch style {
            case .iconOnly:
                Image(systemName: "heart.fill")
                    .foregroundStyle(.pink)
                    .font(.title2)
            case .withText:
                HStack(spacing: 6) {
                    Image(systemName: "heart.fill")
                        .foregroundStyle(.pink)
                        .font(.caption)
                    Text(customText ?? L("Donate", language: language))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(.ultraThinMaterial)
                )
            }
        }
        .sheet(isPresented: $showDonationSheet) {
            DonationSheet(language: language, donationService: donationService)
        }
    }
}

// MARK: - Donation Sheet

struct DonationSheet: View {
    let language: String
    let donationService: DonationService
    
    @Environment(\.dismiss) private var dismiss
    @State private var isPurchasing = false
    @State private var showThankYou = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                ScrollView {
                    VStack(spacing: 24) {
                        // Header
                        VStack(spacing: 8) {
                            Text("❤️")
                                .font(.system(size: 60))
                            Text(L("SupportTimekiller", language: language))
                                .font(.title.bold())
                            Text(L("ChooseYourTip", language: language))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.top, 20)
                        
                        // Products Grid
                        if donationService.isLoading {
                            ProgressView()
                                .padding(40)
                        } else if let error = donationService.error {
                            VStack(spacing: 12) {
                                Image(systemName: "exclamationmark.triangle")
                                    .font(.largeTitle)
                                    .foregroundStyle(.orange)
                                Text(error)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                                Button("Retry") {
                                    Task {
                                        await donationService.loadProducts()
                                    }
                                }
                                .buttonStyle(.borderedProminent)
                            }
                            .padding(40)
                        } else {
                            LazyVGrid(columns: [
                                GridItem(.flexible()),
                                GridItem(.flexible()),
                                GridItem(.flexible())
                            ], spacing: 16) {
                                ForEach(DonationProduct.allCases) { tier in
                                    if let product = donationService.product(for: tier) {
                                        DonationTierCard(
                                            product: product,
                                            tier: tier,
                                            language: language,
                                            isPurchasing: isPurchasing,
                                            onPurchase: {
                                                await handlePurchase(product)
                                            }
                                        )
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                        
                        // Footer message
                        Text(L("ThanksForSupport", language: language))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .padding(.top, 8)
                            .padding(.bottom, 20)
                        
                        // Link to GitHub for feature requests
                        Link(destination: URL(string: "https://github.com/wlfghdr/tk-p")!) {
                            HStack(spacing: 6) {
                                Image(systemName: "bubble.left.and.bubble.right")
                                    .font(.caption)
                                Text("Discuss wishes & ideas")
                                    .font(.caption)
                            }
                            .foregroundStyle(.blue)
                        }
                        .padding(.bottom, 20)
                    }
                }
                
                // Thank You Overlay
                if showThankYou {
                    thankYouOverlay
                }
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }
    
    private var thankYouOverlay: some View {
        ZStack {
            Color.black.opacity(0.4)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("🎉")
                    .font(.system(size: 80))
                Text(L("DonationThankYou", language: language))
                    .font(.title.bold())
                    .multilineTextAlignment(.center)
                Text(L("DonationThankYouMessage", language: language))
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                
                Button {
                    showThankYou = false
                    dismiss()
                } label: {
                    Text(L("Done", language: language))
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.accentColor)
                        .cornerRadius(12)
                }
                .padding(.top, 10)
            }
            .padding(30)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(.regularMaterial)
            )
            .padding(40)
        }
    }
    
    @MainActor
    private func handlePurchase(_ product: Product) async {
        isPurchasing = true
        
        do {
            let success = try await donationService.purchase(product)
            if success {
                // Show thank you message
                showThankYou = true
            }
        } catch {
            print("❌ Purchase error: \(error)")
        }
        
        isPurchasing = false
    }
}

// MARK: - Donation Tier Card

struct DonationTierCard: View {
    let product: Product
    let tier: DonationProduct
    let language: String
    let isPurchasing: Bool
    let onPurchase: () async -> Void
    
    var body: some View {
        Button {
            Task {
                await onPurchase()
            }
        } label: {
            VStack(spacing: 12) {
                Text(tier.emoji)
                    .font(.system(size: 40))
                
                Text(L(tier.nameKey, language: language))
                    .font(.caption.bold())
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
                
                Text(product.displayPrice)
                    .font(.title3.bold())
                    .foregroundStyle(.green)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(.secondarySystemBackground))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.accentColor.opacity(0.3), lineWidth: 1)
            )
        }
        .disabled(isPurchasing)
        .buttonStyle(.plain)
    }
}

#endif
